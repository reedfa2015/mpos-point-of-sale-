/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.swing.JFormattedTextField.AbstractFormatter;

/**
 *
 * @author Grudge
 */
public class DateLabelFormatter1 extends AbstractFormatter{
  private SimpleDateFormat dateFormatter = new SimpleDateFormat("yyy-MM-dd");
  
  @Override
  
  public Object stringToValue(String text)throws ParseException {
      return dateFormatter.parseObject(text);
  }
  @Override
  public String valueToString(Object value)throws ParseException{
      if(value !=null){
          Calendar cal =(Calendar) value;
          return dateFormatter.format(cal.getTime());
          
      }
      return "";
  }
}
