/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus;

/**
 *
 * @author PSL-STUFF
 */
import java.sql.*;
import java.util.ArrayList;
import java.util.Enumeration;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import static maliplus.Configurations1.settings_tree;
import static maliplus.Dynamic1.conn;

 
public class DisplayCategory extends javax.swing.JFrame {
static Connection con = null;
 static   Statement stm = null;
  static ResultSet rs = null;
  
    public DisplayCategory() {
        initComponents();
        con=DBConnection.ConnectDB();
        //call to populate the JTree
    }
    //System generated code
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">
    private void initComponents() {
 
        
    }// </editor-fold>
 
    @SuppressWarnings("CallToThreadDumpStack")
    public static final void pop_tree() {
        try {
 
            try {
               con= DBConnection.ConnectDB();
                stm = con.createStatement();
            
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            ArrayList list = new ArrayList();
            list.add("MALIPLUS Settings");
            String sql = "SELECT SETTING_GROUP from SETTINGS_CODE_LIST";
 
               try{
                   rs = stm.executeQuery(sql); 
                }
                catch(Exception e){
                    e.printStackTrace();
                }
 
            while (rs.next()) {
                Object value[] = {rs.getString(1)};
                list.add(value);
            }
            Object hierarchy[] = list.toArray();
            DefaultMutableTreeNode root = processHierarchy(hierarchy);
 
            DefaultTreeModel treeModel = new DefaultTreeModel(root);
            settings_tree.setModel(treeModel);
        } catch (Exception e) {
            e.printStackTrace();
        }
 
    }
 
    @SuppressWarnings("CallToThreadDumpStack")
    public static DefaultMutableTreeNode processHierarchy(Object[] hierarchy) {
        DefaultMutableTreeNode node = null;
        if(node == null){
            node = new DefaultMutableTreeNode(hierarchy[0]);
        
         try {
            int ctrow = 0;
            int i = 0;
            try {
 
                try {
                    con = DBConnection.ConnectDB();
                    stm = con.createStatement();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                String sql = "SELECT SETTING_GROUP,DESCRIPTION from SETTINGS_CODE_LIST";
                try{
                   rs = stm.executeQuery(sql); 
                }
                catch(Exception e){
                    e.printStackTrace();
                }
                
                while (rs.next()) {
                    ctrow = rs.getRow();
                }
                String L1Nam[] = new String[ctrow];
                String L1Id[] = new String[ctrow];
                ResultSet rs1 = stm.executeQuery(sql);
                while (rs1.next()) {
                  L1Nam[i] = rs1.getString("DESCRIPTION");
                    L1Id[i] = rs1.getString("SETTING_GROUP");
                    i++;
                }
                DefaultMutableTreeNode child, grandchild;
               
                for (int childIndex = 0; childIndex < L1Nam.length;childIndex++) {
                
                    
                    child = new DefaultMutableTreeNode(L1Id[childIndex]);
             
                     node.add(child);//add each created child to root
                    
                    String sql2 = "SELECT DESCRIPTION from SETTINGS_CODE_LIST where DESCRIPTION= '" + L1Nam[childIndex++] + "'";
                    ResultSet rs3 = stm.executeQuery(sql2);
                   while (rs3.next()) {
                      
                        grandchild = new DefaultMutableTreeNode(rs3.getString("DESCRIPTION"));
                        child.add(grandchild);//add each grandchild to each child      
                         
                   
          
                
                        
                   }   
                  
                    
                    
               
                }
 
            } catch (Exception ex) {
                ex.printStackTrace();
            }
 
        } catch (Exception e) {
        }
        }
       
        
        return (node);
    }
 
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
 
            public void run() {
              //  new DisplayCategory().setVisible(true);
              pop_tree();
            }
        });
    }
    // Variables declaration - do not modify
    private static javax.swing.JTree cat_tree;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration
}
