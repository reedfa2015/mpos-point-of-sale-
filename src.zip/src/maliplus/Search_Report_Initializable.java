/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus;

import java.awt.Toolkit;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javax.swing.SwingUtilities;
/**
 *
 * @author PSL-STUFF
 */
public class Search_Report_Initializable extends Application{
    //public static Boolean isSplashLoaded= false;
   
   // public static Boolean loadProgressBar=false;
    
    @Override
    public void start(Stage primarystage3) throws Exception{
     
      
        Pane mainPane = (Pane) FXMLLoader.load(Search_Report_Initializable.class.getResource("Search_Report_Engine.fxml"));
        primarystage3.setScene(new Scene(mainPane));
        mainPane.getStylesheets().addAll(this.getClass().getResource("style.css").toExternalForm());
        primarystage3.setTitle("Search Reports ");
        primarystage3.getIcons().add(new Image("/images_/mali2.png"));
        primarystage3.setResizable(false);
        primarystage3.show();
        
       
   
    }
    
    
    public void run(){
         Platform.runLater(new Runnable() {
             @Override
             public void run() {
                 try {
                     Stage primarystage3 = new Stage();
                     Pane mainPane = (Pane) FXMLLoader.load(Search_Report_Initializable.class.getResource("Search_Report_Engine.fxml"));
                     primarystage3.setScene(new Scene(mainPane));
                     mainPane.getStylesheets().addAll(this.getClass().getResource("style.css").toExternalForm());
                     primarystage3.setTitle("Search Reports ");
                     primarystage3.getIcons().add(new Image("/images_/mali2.png"));
                     primarystage3.setResizable(false);
                     primarystage3.show();
                 } catch (IOException ex) {
                     Logger.getLogger(Search_Report_Initializable.class.getName()).log(Level.SEVERE, null, ex);
                 }
             }
         }); 
    }
   
       public static void main(String[]args){
         
        launch(args);
     
    }
}
