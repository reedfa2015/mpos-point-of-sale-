/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus;

import java.awt.Color;
import java.awt.HeadlessException;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import javax.swing.JOptionPane;
import static maliplus.Dynamic1.conn;
import static maliplus.Dynamic1.dp;
import static maliplus.Dynamic1.rs;
import maliplus.detailsPanels.TableDetails_Panel;
import net.proteanit.sql.DbUtils;
import net.sourceforge.jdatepicker.impl.JDatePanelImpl;
import net.sourceforge.jdatepicker.impl.JDatePickerImpl;
import net.sourceforge.jdatepicker.impl.UtilDateModel;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.sql.SQLException;
import java.util.Arrays;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.swing.table.TableModel;
/**
 *
 * @author PSL-STUFF
 */
public class users_2 extends javax.swing.JFrame {
static Connection conn = null;
    static ResultSet rs = null;
    static PreparedStatement pst = null;
    
    
private static users_2 df=null;


 public static users_2 getObj() {

        if (df == null) {

            df = new users_2();
        }
        return df;

    }
String update_user_table="Select USER_IDENTIFICATION,USERNAME,GRP,INITIAL_WINDOW,USTP,EMAIL_ADDRESS,EXPIRED,EXPIRY_DATE,PASS_DATE,DISABLED,DISB_DATE from USERS2";
       
    /**
     * Creates new form users_2
     */
    
    /**
     * Creates new form users_2
     */
    
    private void automatically_select_check_box_values(){
     int row = user_table.getSelectedRow();
       if (user_table.getModel().getValueAt(row, 6).equals("Y")) {
            expire_password.setSelected(true);
            expire_password.setText("Y");

        } else {
            expire_password.setSelected(false);
            expire_password.setText("N");
        }
       
        if (user_table.getModel().getValueAt(row, 9).equals("Y")) {
            disable_user_profile.setSelected(true);
            disable_user_profile.setText("Y");

        } else {
            disable_user_profile.setSelected(false);
            disable_user_profile.setText("N");
        }
        
        
       
       String check_status = DBConnection.global_resultSet("select restrict_group from users2 where user_identification = '"+user_table.getValueAt(row, 0).toString()+"'");
       if(check_status.equals("Y")){ 
       
       restrict_group.setSelected(true);
       restrict_group.setText("Y");
       }
       else {
            restrict_group.setSelected(false);
            restrict_group.setText("N");
        }
    
       
       String check_status2 = DBConnection.global_resultSet("select creditor_approver from users2 where user_identification = '"+user_table.getValueAt(row, 0).toString()+"'");
       if(check_status2.equals("Y")){ 
       
       approve_creditors.setSelected(true);
       approve_creditors.setText("Y");
       }
       else {
            approve_creditors.setSelected(false);
            approve_creditors.setText("N");
        }
        
        String check_status3 = DBConnection.global_resultSet("select debtor_approver from users2 where user_identification = '"+user_table.getValueAt(row, 0).toString()+"'");
       if(check_status3.equals("Y")){ 
       
       approve_debtors.setSelected(true);
       approve_debtors.setText("Y");
       }
       else {
            approve_debtors.setSelected(false);
            approve_debtors.setText("N");
        }
         
       String check_status4 = DBConnection.global_resultSet("select approve_others from users2 where user_identification = '"+user_table.getValueAt(row, 0).toString()+"'");
       if(check_status4.equals("Y")){ 
       
        approve_others.setSelected(true);
        approve_others.setText("Y");
       }
       else {
             approve_others.setSelected(false);
             approve_others.setText("N");
        }
         
         String check_status5 = DBConnection.global_resultSet("select journal_approver from users2 where user_identification = '"+user_table.getValueAt(row, 0).toString()+"'");
       if(check_status5.equals("Y")){ 
       
        approve_journals.setSelected(true);
        approve_journals.setText("Y");
       }
       else {
             approve_journals.setSelected(false);
             approve_journals.setText("N");
        }
          
           String check_status6 = DBConnection.global_resultSet("select restrict_business_group from users2 where user_identification = '"+user_table.getValueAt(row, 0).toString()+"'");
       if(check_status6.equals("Y")){ 
       
        restrict_customer.setSelected(true);
       restrict_customer.setText("Y");
       }
       else {
             restrict_customer.setSelected(false);
             restrict_customer.setText("N");
        }
             
               String check_status7 = DBConnection.global_resultSet("select close_account from users2 where user_identification = '"+user_table.getValueAt(row, 0).toString()+"'");
       if(check_status7.equals("Y")){ 
       
         close_account.setSelected(true);
        close_account.setText("Y");
       }
       else {
              close_account.setSelected(false);
              close_account.setText("N");
        }
       
       
        
    }
    private static String generateStorngPasswordHash(String password) throws NoSuchAlgorithmException, InvalidKeySpecException
    {
        int iterations = 1000;
        char[] chars = password.toCharArray();
        byte[] salt = getSalt();
         
        PBEKeySpec spec = new PBEKeySpec(chars, salt, iterations, 64 * 8);
        SecretKeyFactory skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
        byte[] hash = skf.generateSecret(spec).getEncoded();
        return iterations + ":" + toHex(salt) + ":" + toHex(hash);
    }
     
    private static byte[] getSalt() throws NoSuchAlgorithmException
    {
        SecureRandom sr = SecureRandom.getInstance("SHA1PRNG");
        byte[] salt = new byte[16];
        sr.nextBytes(salt);
        return salt;
    }
     
    private static String toHex(byte[] array) throws NoSuchAlgorithmException
    {
        BigInteger bi = new BigInteger(1, array);
        String hex = bi.toString(16);
        int paddingLength = (array.length * 2) - hex.length();
        if(paddingLength > 0)
        {
            return String.format("%0"  +paddingLength + "d", 0) + hex;
        }else{
            return hex;
        }
    }
       private static boolean validatePassword(String originalPassword, String storedPassword) throws NoSuchAlgorithmException, InvalidKeySpecException
    {
        String[] parts = storedPassword.split(":");
        int iterations = Integer.parseInt(parts[0]);
        byte[] salt = fromHex(parts[1]);
        byte[] hash = fromHex(parts[2]);
         
        PBEKeySpec spec = new PBEKeySpec(originalPassword.toCharArray(), salt, iterations, hash.length * 8);
        SecretKeyFactory skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
        byte[] testHash = skf.generateSecret(spec).getEncoded();
         
        int diff = hash.length ^ testHash.length;
        for(int i = 0; i < hash.length && i < testHash.length; i++)
        {
            diff |= hash[i] ^ testHash[i];
        }
        return diff == 0;
    }
    private static byte[] fromHex(String hex) throws NoSuchAlgorithmException
    {
        byte[] bytes = new byte[hex.length() / 2];
        for(int i = 0; i<bytes.length ;i++)
        {
            bytes[i] = (byte)Integer.parseInt(hex.substring(2 * i, 2 * i + 2), 16);
        }
        return bytes;
    }
        
        
      
        public void PBKDF2()throws NoSuchAlgorithmException, InvalidKeySpecException 
        {
        String  originalPassword = ""+password.getText()+"";
        String generatedSecuredPasswordHash = generateStorngPasswordHash(originalPassword);
         String sql="update USERS2 set PASSWORD='"+generatedSecuredPasswordHash+"' where USER_IDENTIFICATION='"+user_identification.getText()+"'";
        try{
            pst= conn.prepareStatement(sql);
            pst.execute();
            System.out.println(generatedSecuredPasswordHash);
            boolean matched = validatePassword(""+password.getText()+"", generatedSecuredPasswordHash);
            System.out.println(matched);
        }
        catch(SQLException | NoSuchAlgorithmException | InvalidKeySpecException e){
           e.printStackTrace(); 
        }   
        }
        
    	//System.out.println("Hex format : " + hexString.toString());
    
    
    
    
    public UtilDateModel model = new UtilDateModel();
     public JDatePanelImpl datePanel = new JDatePanelImpl(model);
      public JDatePickerImpl datePicker = new JDatePickerImpl(datePanel, new DateLabelFormatter1());
    public users_2() {
        initComponents();
    }
    
    public void dateP1() {
        try {

            expire_date.setLayout(new java.awt.BorderLayout());
            expire_date.add(datePicker);
            expire_date.revalidate();
            expire_date.repaint();
            //System.out.println(datePicker.getComponentListeners());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
     public void Insert_Timestamp(){
        
      if(!"".equals(password.getText())){
          Calendar calendar = Calendar.getInstance();
    java.sql.Timestamp ourJavaTimestampObject = new java.sql.Timestamp(calendar.getTime().getTime());
    
    // (3) create a java timestamp insert statement
    String sqlTimestampInsertStatement = "Update users2 set pass_date = ? where USER_IDENTIFICATION='" + user_identification.getText() + "'"; 
   try( PreparedStatement preparedStatement = conn.prepareStatement(sqlTimestampInsertStatement)) {
    preparedStatement.setTimestamp(1, ourJavaTimestampObject);

    // (4) execute the sql timestamp insert statement, then shut everything down
    preparedStatement.executeUpdate();
   }
   catch(Exception e){
       e.printStackTrace();
   }  
      }
      
      if(disable_user_profile.getText().equals("Y")){
          Calendar calendar = Calendar.getInstance();
    java.sql.Timestamp ourJavaTimestampObject = new java.sql.Timestamp(calendar.getTime().getTime());
    
    // (3) create a java timestamp insert statement
    String sqlTimestampInsertStatement = "Update users2 set disb_date = ? where USER_IDENTIFICATION='" + user_identification.getText() + "'"; 
   try( PreparedStatement preparedStatement = conn.prepareStatement(sqlTimestampInsertStatement)) {
    preparedStatement.setTimestamp(1, ourJavaTimestampObject);

    // (4) execute the sql timestamp insert statement, then shut everything down
    preparedStatement.executeUpdate();
   }
   catch(Exception e){
       e.printStackTrace();
   }  
      }
          
        
        
      
    
    
      
    }
    


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jToolBar1 = new javax.swing.JToolBar();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        user_identification = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        username = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        user_group = new javax.swing.JTextField();
        expire_password = new javax.swing.JCheckBox();
        disable_user_profile = new javax.swing.JCheckBox();
        jLabel13 = new javax.swing.JLabel();
        expire_date = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        access_usage = new javax.swing.JTextField();
        initial_window = new javax.swing.JTextField();
        base_location = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        login_attempts = new javax.swing.JCheckBox();
        password = new javax.swing.JPasswordField();
        show_password = new javax.swing.JCheckBox();
        jPanel2 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        user_role_type = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        account_number = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        restrict_group = new javax.swing.JCheckBox();
        restrict_customer = new javax.swing.JCheckBox();
        approve_journals = new javax.swing.JCheckBox();
        approve_creditors = new javax.swing.JCheckBox();
        approve_others = new javax.swing.JCheckBox();
        jLabel29 = new javax.swing.JLabel();
        user_approver = new javax.swing.JTextField();
        email_address = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        restrict_to_item_group = new javax.swing.JTextField();
        restrict_to_customer = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        close_account = new javax.swing.JCheckBox();
        approve_debtors = new javax.swing.JCheckBox();
        jLabel33 = new javax.swing.JLabel();
        approve_sales = new javax.swing.JCheckBox();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        approve_purchase = new javax.swing.JCheckBox();
        jLabel36 = new javax.swing.JLabel();
        amount_limit = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        user_table = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;}
        };
        save_successful = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Users");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jToolBar1.setRollover(true);

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/edit.JPG"))); // NOI18N
        jButton1.setFocusable(false);
        jButton1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jToolBar1.add(jButton1);

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Actions-document-save-all-icon2.png"))); // NOI18N
        jButton2.setFocusable(false);
        jButton2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jToolBar1.add(jButton2);

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/delete3.png"))); // NOI18N
        jButton3.setFocusable(false);
        jButton3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton3.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jToolBar1.add(jButton3);

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        jButton4.setFocusable(false);
        jButton4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton4.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jToolBar1.add(jButton4);

        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/exel2.png"))); // NOI18N
        jButton5.setFocusable(false);
        jButton5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton5.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jToolBar1.add(jButton5);

        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/back - Copy.png"))); // NOI18N
        jButton6.setFocusable(false);
        jButton6.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton6.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jToolBar1.add(jButton6);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 0, 255), null));

        jLabel1.setText("User Identification:");

        jLabel2.setText("User Group:");

        jLabel3.setText("User Name:");

        jLabel4.setText("Expire Password:");

        jLabel5.setText("Password:");

        jLabel6.setText("Access/Usage:");

        jLabel7.setText("Disable user Profile:");

        jLabel8.setText("Base Location:");

        jLabel9.setText("Initial Window:");

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N

        user_identification.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                user_identificationActionPerformed(evt);
            }
        });

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel11MouseClicked(evt);
            }
        });

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        jLabel12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel12MouseClicked(evt);
            }
        });

        user_group.setEditable(false);

        expire_password.setText("N");
        expire_password.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                expire_passwordActionPerformed(evt);
            }
        });

        disable_user_profile.setText("N");
        disable_user_profile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                disable_user_profileActionPerformed(evt);
            }
        });

        jLabel13.setText("Expire Date:");

        expire_date.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 255, 0), null));
        expire_date.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                expire_dateMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout expire_dateLayout = new javax.swing.GroupLayout(expire_date);
        expire_date.setLayout(expire_dateLayout);
        expire_dateLayout.setHorizontalGroup(
            expire_dateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 139, Short.MAX_VALUE)
        );
        expire_dateLayout.setVerticalGroup(
            expire_dateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 16, Short.MAX_VALUE)
        );

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        jLabel14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel14MouseClicked(evt);
            }
        });

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        jLabel15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel15MouseClicked(evt);
            }
        });

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        jLabel16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel16MouseClicked(evt);
            }
        });

        access_usage.setEditable(false);

        initial_window.setEditable(false);

        base_location.setEditable(false);

        jLabel17.setText("Login Attempts:");

        login_attempts.setText("N");
        login_attempts.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                login_attemptsActionPerformed(evt);
            }
        });

        password.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                passwordMouseClicked(evt);
            }
        });
        password.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                passwordKeyTyped(evt);
            }
        });

        show_password.setToolTipText("Reset Password");
        show_password.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                show_passwordActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(27, 27, 27)
                                        .addComponent(jLabel10)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(user_identification, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel11))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(23, 23, 23)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(expire_password, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(show_password, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(26, 26, 26)
                                        .addComponent(jLabel12)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(username, javax.swing.GroupLayout.DEFAULT_SIZE, 389, Short.MAX_VALUE)
                                            .addComponent(user_group)
                                            .addComponent(password)))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 89, Short.MAX_VALUE)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(31, 31, 31)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel15)
                                    .addComponent(jLabel14)
                                    .addComponent(jLabel16))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(initial_window, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 393, Short.MAX_VALUE)
                                    .addComponent(base_location)
                                    .addComponent(access_usage, javax.swing.GroupLayout.Alignment.LEADING))))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(expire_date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(115, 115, 115))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 6, Short.MAX_VALUE)
                        .addComponent(disable_user_profile, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(204, 204, 204)
                        .addComponent(jLabel17)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(login_attempts)
                        .addGap(90, 90, 90))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 23, Short.MAX_VALUE)
                            .addComponent(user_identification, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(username, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(user_group, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(password, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(3, 3, 3)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(show_password)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(expire_date, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(expire_password)
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(login_attempts))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(disable_user_profile)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(access_usage, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, 23, Short.MAX_VALUE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(initial_window, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, 23, Short.MAX_VALUE))
                    .addComponent(base_location, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 0, 255), null));

        jLabel18.setText("User Role Type:");

        jLabel19.setText("Restrict to client group:");

        jLabel20.setText("Restrict to business group:");

        jLabel21.setText("Can approve Journals:");

        jLabel22.setText("Can approve Creditors:");

        jLabel23.setText("Can approve Others:");

        jLabel24.setText("User Approver:");

        jLabel25.setText("Email Address:");

        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        jLabel26.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel26MouseClicked(evt);
            }
        });

        user_role_type.setEditable(false);
        user_role_type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                user_role_typeActionPerformed(evt);
            }
        });

        jLabel27.setText("Account Number:");

        account_number.setEditable(false);
        account_number.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                account_numberActionPerformed(evt);
            }
        });

        jLabel28.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N

        restrict_group.setText("N");
        restrict_group.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                restrict_groupActionPerformed(evt);
            }
        });

        restrict_customer.setText("N");
        restrict_customer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                restrict_customerActionPerformed(evt);
            }
        });

        approve_journals.setText("N");
        approve_journals.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                approve_journalsActionPerformed(evt);
            }
        });

        approve_creditors.setText("N");
        approve_creditors.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                approve_creditorsActionPerformed(evt);
            }
        });

        approve_others.setText("N");
        approve_others.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                approve_othersActionPerformed(evt);
            }
        });

        jLabel29.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        jLabel29.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel29MouseClicked(evt);
            }
        });

        user_approver.setEditable(false);
        user_approver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                user_approverActionPerformed(evt);
            }
        });

        email_address.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                email_addressActionPerformed(evt);
            }
        });

        jLabel30.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        jLabel30.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel30MouseClicked(evt);
            }
        });

        restrict_to_item_group.setEditable(false);
        restrict_to_item_group.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                restrict_to_item_groupActionPerformed(evt);
            }
        });

        restrict_to_customer.setEditable(false);
        restrict_to_customer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                restrict_to_customerActionPerformed(evt);
            }
        });

        jLabel31.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        jLabel31.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel31MouseClicked(evt);
            }
        });

        jLabel32.setText("Can close account periods:");

        close_account.setText("N");
        close_account.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                close_accountActionPerformed(evt);
            }
        });

        approve_debtors.setText("N");
        approve_debtors.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                approve_debtorsActionPerformed(evt);
            }
        });

        jLabel33.setText("Can approve debtors:");

        approve_sales.setText("N");
        approve_sales.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                approve_salesActionPerformed(evt);
            }
        });

        jLabel34.setText("Can approve sale returns:");

        jLabel35.setText("Can approve purchase returns:");

        approve_purchase.setText("N");
        approve_purchase.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                approve_purchaseActionPerformed(evt);
            }
        });

        jLabel36.setText("Amount limit:");

        amount_limit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                amount_limitActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(jLabel22, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 129, Short.MAX_VALUE)
                                        .addComponent(jLabel21, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                            .addComponent(jLabel18)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(jLabel26)))
                                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(user_role_type, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(account_number, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel28)
                                        .addGap(0, 4, Short.MAX_VALUE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(restrict_customer)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jLabel31))
                                            .addComponent(approve_journals)
                                            .addComponent(approve_creditors)
                                            .addComponent(approve_others))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(restrict_to_customer)
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(jPanel2Layout.createSequentialGroup()
                                                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                .addComponent(jLabel33)
                                                                .addComponent(jLabel32))
                                                            .addGap(28, 28, 28))
                                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                                            .addComponent(jLabel35)
                                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                                        .addComponent(jLabel34)
                                                        .addGap(31, 31, 31)))
                                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(approve_sales)
                                                    .addComponent(close_account)
                                                    .addComponent(approve_debtors)
                                                    .addComponent(approve_purchase))
                                                .addGap(0, 0, Short.MAX_VALUE))))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(restrict_group)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel30)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(restrict_to_item_group))))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(38, 38, 38)
                                .addComponent(email_address))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(user_approver, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(amount_limit, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(140, Short.MAX_VALUE))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel18)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(user_role_type, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel27)
                                .addComponent(account_number, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(restrict_to_item_group, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel30))
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(restrict_group)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(restrict_customer)))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(restrict_to_customer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel31)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(approve_journals)
                    .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(close_account))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(approve_creditors)
                    .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(approve_debtors))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(approve_sales)
                        .addComponent(approve_others)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel35, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(approve_purchase)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jLabel29, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(user_approver, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(amount_limit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(email_address, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, new java.awt.Color(204, 0, 204), null));

        user_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        user_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                user_tableMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                user_tableMousePressed(evt);
            }
        });
        jScrollPane1.setViewportView(user_table);

        save_successful.setFont(new java.awt.Font("Vrinda", 1, 24)); // NOI18N
        save_successful.setForeground(new java.awt.Color(51, 0, 204));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1333, Short.MAX_VALUE)
                    .addComponent(save_successful, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(save_successful, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jToolBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jToolBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(26, 26, 26)
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        
        String sql="insert into USERS2 ("
                      + "USER_IDENTIFICATION,"
                      + "USERNAME,"
                      + "GRP,"
                      + "INITIAL_WINDOW,"
                      + "USTP,"
                      + "EMAIL_ADDRESS,"
                      + "EXPIRED,"
                      + "EXPIRY_DATE,"
                      + "DISABLED,"
                      + "USER_LOCATION,"
                      + "RESTRICT_GROUP,"
                      + "CREDITOR_APPROVER,"
                      + "DEBTOR_APPROVER,"
                      + "APPROVE_OTHERS,"
                      + "APPROVER,"
                      + "JOURNAL_APPROVER,"
                      + "RESTRICT_BUSINESS_GROUP,"
                      + "CLOSE_ACCOUNT,"
                      + "ACCESS_TYPE)"
               + "values('"+user_identification.getText()+"',"
                + "'"+username.getText()+"',"
                + "'"+user_group.getText()+"',"
               + "'"+initial_window.getText()+"',"
               + "'"+user_role_type.getText()+"',"
               + "'"+email_address.getText()+"',"
               + "'"+expire_password.getText()+"',"
               + "'"+datePicker.getJFormattedTextField().getText()+"',"
                + "'"+disable_user_profile.getText()+"',"
                + "'"+base_location.getText()+"',"
                + "'"+restrict_group.getText()+"',"
                + "'"+approve_creditors.getText()+"',"
                + "'"+approve_debtors.getText()+"',"
                + "'"+approve_others.getText()+"',"
                + "'"+user_approver.getText()+"',"
                + "'"+approve_journals.getText()+"',"
                + "'"+restrict_customer.getText()+"',"
                + "'"+close_account.getText()+"',"
                + "'"+access_usage.getText()+"')";
        try{
           conn = DBConnection.ConnectDB();
            pst = conn.prepareStatement(sql);
            pst.execute();
            //PBKDF2();
        
            
            Insert_Timestamp();
            DBConnection.update_table(update_user_table, user_table);
        }
        catch(Exception e){
            e.printStackTrace();
            
        }
         String sql2="update USERS2 set PASSWORD='"+password.getText()+"' where USER_IDENTIFICATION='"+user_identification.getText()+"'";
        try{
            pst= conn.prepareStatement(sql2);
            pst.execute();
            save_successful.setForeground(Color.BLUE);
            save_successful.setText(""+user_identification.getText()+"'s record saved successfully!!");
           // System.out.println(generatedSecuredPasswordHash);
           // boolean matched = validatePassword(""+password.getText()+"", generatedSecuredPasswordHash);
          //  System.out.println(matched);
        }
        catch(Exception e){
           e.printStackTrace();
           save_successful.setForeground(Color.red);
            save_successful.setText("Record already exists!!duplicates not allowed contact system Administrator for further instructions!!");
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        int result=
            JOptionPane.showConfirmDialog(rootPane,"Are you sure you want to Delete "+user_identification.getText()+",record from the list? ","Delete User?",JOptionPane.YES_NO_OPTION);
            if(result==JOptionPane.YES_OPTION){
                String sql2 = "delete from USERS2 where USER_IDENTIFICATION = '"+user_identification.getText()+"'";
            try{              
                          conn=DBConnection.ConnectDB(); 
                          pst=conn.prepareStatement(sql2);
                          pst.execute();
                         DBConnection.update_table(update_user_table, user_table);
            }
            catch(SQLException | HeadlessException e){ e.printStackTrace(); }
            }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void expire_passwordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_expire_passwordActionPerformed
        // TODO add your handling code here:
        if(expire_password.isSelected()==true){
            expire_password.setText("Y");
        }
        else{
            expire_password.setText("N");
        }
    }//GEN-LAST:event_expire_passwordActionPerformed

    private void disable_user_profileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_disable_user_profileActionPerformed
        // TODO add your handling code here:
        if(disable_user_profile.isSelected()==true){
            disable_user_profile.setText("Y");
        }
        else{
            disable_user_profile.setText("N");
        }
    }//GEN-LAST:event_disable_user_profileActionPerformed

    private void expire_dateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_expire_dateMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_expire_dateMouseClicked

    private void login_attemptsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_login_attemptsActionPerformed
        // TODO add your handling code here:
        if(login_attempts.isSelected()==true){
            login_attempts.setText("Y");
        }
        else{
              login_attempts.setText("N");
        }
    }//GEN-LAST:event_login_attemptsActionPerformed

    private void user_identificationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_user_identificationActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_user_identificationActionPerformed

    private void user_role_typeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_user_role_typeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_user_role_typeActionPerformed

    private void account_numberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_account_numberActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_account_numberActionPerformed

    private void restrict_groupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_restrict_groupActionPerformed
        // TODO add your handling code here:
        if(restrict_group.isSelected()==true){
            restrict_group.setText("Y");
        }
        else{
             restrict_group.setText("N");
        }
            
    }//GEN-LAST:event_restrict_groupActionPerformed

    private void restrict_customerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_restrict_customerActionPerformed
        // TODO add your handling code here:
        if(restrict_customer.isSelected()==true){
            restrict_customer.setText("Y");
        }
        else{
            restrict_customer.setText("N");
        }
    }//GEN-LAST:event_restrict_customerActionPerformed

    private void approve_journalsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_approve_journalsActionPerformed
        // TODO add your handling code here:
        if(approve_journals.isSelected()==true){
            approve_journals.setText("Y");
        }
        else{
           approve_journals.setText("N"); 
        }
    }//GEN-LAST:event_approve_journalsActionPerformed

    private void approve_creditorsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_approve_creditorsActionPerformed
        // TODO add your handling code here:
        if(approve_creditors.isSelected()==true){
            approve_creditors.setText("Y");
        }
        else{
            approve_creditors.setText("N");
        }
            
    }//GEN-LAST:event_approve_creditorsActionPerformed

    private void approve_othersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_approve_othersActionPerformed
        // TODO add your handling code here:
        if(approve_others.isSelected()==true){
            approve_others.setText("Y");
        }
        else{
            approve_others.setText("N");
        }
    }//GEN-LAST:event_approve_othersActionPerformed

    private void user_approverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_user_approverActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_user_approverActionPerformed

    private void email_addressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_email_addressActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_email_addressActionPerformed

    private void restrict_to_item_groupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_restrict_to_item_groupActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_restrict_to_item_groupActionPerformed

    private void restrict_to_customerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_restrict_to_customerActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_restrict_to_customerActionPerformed

    private void close_accountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_close_accountActionPerformed
        // TODO add your handling code here:
        if(close_account.isSelected()==true){
            close_account.setText("Y");
        }
        else{
            close_account.setText("N");
        }
    }//GEN-LAST:event_close_accountActionPerformed

    private void approve_debtorsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_approve_debtorsActionPerformed
        // TODO add your handling code here
        if(approve_debtors.isSelected()==true){
            approve_debtors.setText("Y");
        }
        else{
             approve_debtors.setText("N");
        }
    }//GEN-LAST:event_approve_debtorsActionPerformed

    private void approve_salesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_approve_salesActionPerformed
        // TODO add your handling code here:
        if(approve_sales.isSelected()==true){
            approve_sales.setText("Y");
            
        }
        else{
            approve_sales.setText("N");
            
        }
    }//GEN-LAST:event_approve_salesActionPerformed

    private void approve_purchaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_approve_purchaseActionPerformed
        // TODO add your handling code here:
        if(approve_purchase.isSelected()==true){
            approve_purchase.setText("Y");
        }
        else
        {
            approve_purchase.setText("N");
        }
    }//GEN-LAST:event_approve_purchaseActionPerformed

    private void amount_limitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_amount_limitActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_amount_limitActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        // TODO add your handling code here:
            dateP1();
            conn = DBConnection.ConnectDB();
            DBConnection.update_table(update_user_table, user_table);
            user_table.getTableHeader().setReorderingAllowed(false);
            
    }//GEN-LAST:event_formWindowOpened

    private void jLabel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseClicked
        // TODO add your handling code here:
        DBConnection.dynamic_sql = "select user_identification as USER_NAMES,user_location from users2";
        DBConnection.panel(new TableDetails_Panel(), "User Identification");
    }//GEN-LAST:event_jLabel11MouseClicked

    private void jLabel12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel12MouseClicked
        // TODO add your handling code here:
        
        
        String user_group= "USER GROUP";
        String sub_code = "###";
         
            DBConnection.dynamic_sql = "select description as DESCRIPTION from list_control where reference_code='"+ user_group +"' AND sub_code='"+sub_code+"'";
        DBConnection.panel(new TableDetails_Panel(), "User Group");
          // DBConnection.sth = TableDetails_Panel.code_list_pop_up.getColumnCount();
    }//GEN-LAST:event_jLabel12MouseClicked

    private void jLabel14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel14MouseClicked
        // TODO add your handling code here:
          String access = "ACCESS/USAGE";
        String sub_code = "###";
         
            DBConnection.dynamic_sql = "select description as DESCRIPTION from list_control where reference_code='"+ access +"' AND sub_code='"+sub_code+"'";
            DBConnection.panel(new TableDetails_Panel(), "Access/Usage");
    }//GEN-LAST:event_jLabel14MouseClicked

    private void jLabel15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel15MouseClicked
        // TODO add your handling code here:
          String initial_window = "INITIAL WINDOW";
        String sub_code = "###";
         
            DBConnection.dynamic_sql = "select description as DESCRIPTION from list_control where reference_code='"+ initial_window +"' AND sub_code='"+sub_code+"'";
            DBConnection.panel(new TableDetails_Panel(), "Initial Window");
    }//GEN-LAST:event_jLabel15MouseClicked

    private void jLabel16MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel16MouseClicked
        // TODO add your handling code here:
       
         
            DBConnection.dynamic_sql = "select main_location as MAIN_LOCATION,location_name as LOCATION_NAME from locations"; 
            DBConnection.panel(new TableDetails_Panel(), "Base Location");
    }//GEN-LAST:event_jLabel16MouseClicked

    private void jLabel26MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel26MouseClicked
        // TODO add your handling code here:
           String user_role_type = "USER ROLE TYPE";
        String sub_code = "###";
         
            DBConnection.dynamic_sql = "select description as DESCRIPTION from list_control where reference_code='"+ user_role_type +"' AND sub_code='"+sub_code+"'";
            DBConnection.panel(new TableDetails_Panel(), "User Role Type");
    }//GEN-LAST:event_jLabel26MouseClicked

    private void jLabel30MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel30MouseClicked
        // TODO add your handling code here:
        String restrict_to_client_groups = "RESTRICT CLIENT GROUPS";
        String sub_code = "###";
         
            DBConnection.dynamic_sql = "select description as DESCRIPTION from list_control where reference_code='"+ restrict_to_client_groups +"' AND sub_code='"+sub_code+"'";
            DBConnection.panel(new TableDetails_Panel(), "Restrict to client group");
    }//GEN-LAST:event_jLabel30MouseClicked

    private void jLabel31MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel31MouseClicked
        // TODO add your handling code here:
         String restrict_to_business_groups = "RESTRICT BUSINESS GROUPS";
        String sub_code = "###";
         
            DBConnection.dynamic_sql = "select description as DESCRIPTION from list_control where reference_code='"+ restrict_to_business_groups +"' AND sub_code='"+sub_code+"'";
            DBConnection.panel(new TableDetails_Panel(), "Restrict to business group");
    }//GEN-LAST:event_jLabel31MouseClicked

    private void jLabel29MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel29MouseClicked
        // TODO add your handling code here:
        String priviledge="Administrators";
         DBConnection.dynamic_sql = "select user_identification as USER_NAMES from users2 WHERE GRP='"+priviledge+"'";
        DBConnection.panel(new TableDetails_Panel(), "User Approver");
    }//GEN-LAST:event_jLabel29MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
         if(password.getText().equals("")){
         

                 password.setBackground(Color.red);
                 password.setForeground(Color.white);
                 password.setText("Required!!");
                 password.setEchoChar((char) 0);
                save_successful.setForeground(Color.red); 
                save_successful.setText(""+user_identification.getText()+"'s record not updated successfully!!"); 
                
         } 
         else{
           String sql="update USERS2 set "
                + "USERNAME='"+username.getText()+"',"
                + "GRP='"+user_group.getText()+"',"
                + "INITIAL_WINDOW='"+initial_window.getText()+"',"
                + "USTP='"+user_role_type.getText()+"',"
                + "EMAIL_ADDRESS='"+email_address.getText()+"',"
                + "EXPIRED='"+expire_password.getText()+"',"
                + "EXPIRY_DATE='"+datePicker.getJFormattedTextField().getText()+"',"
                + "DISABLED='"+disable_user_profile.getText()+"',"
                + "USER_LOCATION='"+base_location.getText()+"',"
                + "RESTRICT_GROUP='"+restrict_group.getText()+"',"
                + "CREDITOR_APPROVER='"+approve_creditors.getText()+"',"
                + "DEBTOR_APPROVER='"+approve_debtors.getText()+"',"
                + "APPROVE_OTHERS='"+approve_others.getText()+"',"
                + "APPROVER='"+user_approver.getText()+"',"
                + "JOURNAL_APPROVER='"+approve_journals.getText()+"',"
                + "RESTRICT_BUSINESS_GROUP='"+restrict_customer.getText()+"',"
                + "CLOSE_ACCOUNT='"+close_account.getText()+"',"
                + "ACCESS_TYPE='"+access_usage.getText()+"'"
                + " where USER_IDENTIFICATION='"+user_identification.getText()+"'";
        try{
            pst=conn.prepareStatement(sql);
            pst.execute();
            //PBKDF2();
            DBConnection.update_table(update_user_table, user_table);
             save_successful.setForeground(Color.BLUE);
            save_successful.setText(""+user_identification.getText()+"'s record updated successfully!!");
            
            
        }
        catch(Exception e){
            e.printStackTrace();
             
            
            
        }
           String sql2="update USERS2 set PASSWORD='"+password.getText()+"' where USER_IDENTIFICATION='"+user_identification.getText()+"'";
        try{
            pst= conn.prepareStatement(sql2);
            pst.execute();
            save_successful.setForeground(Color.BLUE);
            save_successful.setText(""+user_identification.getText()+"'s record updated successfully!!");
           // System.out.println(generatedSecuredPasswordHash);
           // boolean matched = validatePassword(""+password.getText()+"", generatedSecuredPasswordHash);
          //  System.out.println(matched);
        }
        catch(Exception e){
           e.printStackTrace();
           save_successful.setForeground(Color.red);
            save_successful.setText("Record NOT updated successfully!!");
        }
         }
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void passwordKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_passwordKeyTyped
        // TODO add your handling code here:
        password.setBackground(Color.white);
        password.setForeground(Color.BLACK);
        
        
    }//GEN-LAST:event_passwordKeyTyped

    private void passwordMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_passwordMouseClicked
        // TODO add your handling code here:
        password.setText("");
        password.setBackground(Color.WHITE);
        password.setEchoChar('*');
    }//GEN-LAST:event_passwordMouseClicked

    private void user_tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_user_tableMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_user_tableMouseClicked

    private void user_tableMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_user_tableMousePressed
        // TODO add your handling code here:
        int click = evt.getClickCount();
         int row = user_table.getSelectedRow();
    if(click ==2){ 
        user_identification.setText(user_table.getModel().getValueAt(row, 0).toString());
        username.setText(user_table.getModel().getValueAt(row, 1).toString());
        user_group.setText(user_table.getModel().getValueAt(row, 2).toString());
        initial_window.setText(user_table.getModel().getValueAt(row, 3).toString());
        user_role_type.setText(user_table.getModel().getValueAt(row, 4).toString());
        email_address.setText(user_table.getModel().getValueAt(row, 5).toString());
        datePicker.getJFormattedTextField().setText(user_table.getModel().getValueAt(row, 7).toString());
        
        String check_status8 = DBConnection.global_resultSet("select user_location from users2 where user_identification = '"+user_table.getValueAt(row, 0).toString()+"'");
        base_location.setText(check_status8);
         
        String check_status9 = DBConnection.global_resultSet("select approver from users2 where user_identification = '"+user_table.getValueAt(row, 0).toString()+"'");
        user_approver.setText(check_status9);
        
        String check_status10 = DBConnection.global_resultSet("select access_type from users2 where user_identification = '"+user_table.getValueAt(row, 0).toString()+"'");
        access_usage.setText(check_status10);
        
        String check_status11 = DBConnection.global_resultSet("select password from users2 where user_identification = '"+user_table.getValueAt(row, 0).toString()+"'");
        password.setText(check_status11);
        
        automatically_select_check_box_values();
    }  
       
        
    }//GEN-LAST:event_user_tableMousePressed

    private void show_passwordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_show_passwordActionPerformed
        // TODO add your handling code here:
         if(show_password.isSelected()==true){
          
             password.setEchoChar('*');
             show_password.setVisible(false);
           }
         else{
               
             }
    }//GEN-LAST:event_show_passwordActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(users_2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(users_2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(users_2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(users_2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new users_2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JTextField access_usage;
    private javax.swing.JTextField account_number;
    private javax.swing.JTextField amount_limit;
    private javax.swing.JCheckBox approve_creditors;
    private javax.swing.JCheckBox approve_debtors;
    private javax.swing.JCheckBox approve_journals;
    private javax.swing.JCheckBox approve_others;
    private javax.swing.JCheckBox approve_purchase;
    private javax.swing.JCheckBox approve_sales;
    public static javax.swing.JTextField base_location;
    private javax.swing.JCheckBox close_account;
    private javax.swing.JCheckBox disable_user_profile;
    private javax.swing.JTextField email_address;
    public static javax.swing.JPanel expire_date;
    private javax.swing.JCheckBox expire_password;
    public static javax.swing.JTextField initial_window;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JCheckBox login_attempts;
    public static javax.swing.JPasswordField password;
    private javax.swing.JCheckBox restrict_customer;
    private javax.swing.JCheckBox restrict_group;
    public static javax.swing.JTextField restrict_to_customer;
    public static javax.swing.JTextField restrict_to_item_group;
    private javax.swing.JLabel save_successful;
    private javax.swing.JCheckBox show_password;
    public static javax.swing.JTextField user_approver;
    public static javax.swing.JTextField user_group;
    public static javax.swing.JTextField user_identification;
    public static javax.swing.JTextField user_role_type;
    private javax.swing.JTable user_table;
    private javax.swing.JTextField username;
    // End of variables declaration//GEN-END:variables
}
