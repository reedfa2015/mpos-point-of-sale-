/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus;

/**
 *
 * @author PSL-STUFF
 */

import javafx.application.Application;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;



public class login extends Application{
public static Stage primarystage1;

public static Pane mainPane2; 

    @Override
    public  void start(Stage primarystage1) throws Exception{
    
       mainPane2 = (Pane) FXMLLoader.load(login.class.getResource("login.fxml")); 
       primarystage1.setScene(new Scene(mainPane2));
       mainPane2.getStylesheets().addAll(this.getClass().getResource("style.css").toExternalForm());
       primarystage1.setTitle("MALIPLUS © 2016 PRIME SOFT SOLUTIONS ");
       primarystage1.getIcons().add(new Image("/images_/mali2X.png"));
       primarystage1.show();
        
  
    }
    public static void main(String[] args) {
       launch(args);
    }
}