/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus;

import maliplus.detailsPanels.import_settings;
import java.awt.Color;
import java.awt.Toolkit;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BoundedRangeModel;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import net.proteanit.sql.DbUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author Extus
 */
public class DBConnection{

    private static Connection conn;
    private static Statement st;
    private static PreparedStatement pst;
    private static ResultSet rs;
    private static String result;

    ////////////////////////////////////////////////////////////////////////////
    static String jdbcClassName = "com.ibm.db2.jcc.DB2Driver";
    static String db_ID = "db2";
    static String ip = "127.0.0.1";
    static String port = "50000";
    static String dataBase = "ZANAS";
    static String url = "jdbc:" + db_ID + "://" + ip + ":" + port + "/" + dataBase;
    static String user = "ZANAS";
    static String password = "pa55word";
    ////////////////////////////////////////////////////////////////////////////
    public static String dynamic_sql;
    private static int dum;
    public static String MY_CODE_REFERENCE;
    public static String JFrame_Title;

//------------------------------------------------------------------------------
    public static String MY_MAJOR_CODE;
    public static String MY_MINOR_CODE;
    public static String MY_SUB_CODE;
    public static String MY_SUB_CODE2;
    public static String MY_CODE_REFERENCE2;
    public static int MY_TEXT_FIELD;

    public static String SELECTED_LIST_CONTENT;
    public static String SELECTED_LIST_CONTENT2;
    public static String SELECTED_LIST_CONTENT3;
    public static String SELECTED_LIST_CONTENT4;
    public static String SELECTED_TABLE;

    public static JTextField jtf_value = new JTextField();
    public static JTextField jtf_value2 = new JTextField();
    public static JTextField jtf_code = new JTextField();
    public static JTextField jtf_code2 = new JTextField();
    public static JTextField jtf_code3 = new JTextField();

    public static JDialog jd = new JDialog(new JFrame(), true);
    static Random rand = new Random();

    
    public static Connection ConnectDB() {

        try {
            Class.forName(jdbcClassName);
            Connection con = DriverManager.getConnection(url, user, password);
            //System.out.println("Connection Succeeded");
            return con;
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, e);
            e.printStackTrace();
            return null;
        }
    }

    private static void shutdown() {
        try {
            if (st != null) {
                st.close();
            }
            if (conn != null) {
                DriverManager.getConnection(url + ";Shutdown=true");
                conn.close();
            }
        } catch (Exception e) {

        }
    }

    public static void populateCombo(String sql, JComboBox combo_id) {

        try {
            Connection con = DriverManager.getConnection(url, user, password);
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {

                combo_id.addItem(rs.getString(1));

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e + "\n cannot popullate combobox");
        }

    }

    public static void cleanCombo(JComboBox combo_id) {
        combo_id.removeAllItems();
    }

    public static void update_table(String sql, JTable table) {

        try {
            conn = DBConnection.ConnectDB();
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();

            table.setModel(DbUtils.resultSetToTableModel(rs));

            TableColumnModel colmdl = table.getColumnModel();
            TableModel tmdl = table.getModel();
            
            int allColumns = colmdl.getColumnCount();
            for (int i = 0; i < allColumns; i++) {
                int size = table.getColumnName(i).length() * 8;
                
                int allRows = tmdl.getRowCount();

                for (int j = 0; j < allRows; j++) {
                    if (tmdl.getValueAt(j, i) != null) {
                        int size2 = tmdl.getValueAt(j, i).toString().length() * 8;
                        if (size2 > size) {
                            size = size2;
                        }
                    }
                    colmdl.getColumn(i).setPreferredWidth(size);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String global_resultSet(String sql) {
        Connection conn = DBConnection.ConnectDB();
        
        try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {

                result = rs.getString(1);
                if(rs.isClosed()){conn.close();}                
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return result;
    }

    public static void panel(JPanel panel, String j_title) {

        jd.setTitle(j_title);
        jd.setContentPane(panel);
        jd.setLocationRelativeTo(null);
        jd.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        jd.pack();
        jd.setVisible(true);
    }

    public static void check_if_exist(String sql, JTextField textfield, String inner_sql, JLabel error_label) {
        try {
            conn = DBConnection.ConnectDB();
            pst = conn.prepareStatement(sql);
            pst.setString(1, textfield.getText());
            rs = pst.executeQuery();

            if (rs.next()) {
                error_label.setForeground(Color.red);
                error_label.setText("Exists!");
            } else {

                try {
                    conn = DBConnection.ConnectDB();
                    pst = conn.prepareStatement(inner_sql);
                    pst.execute();
                    error_label.setForeground(Color.blue);
                    error_label.setText("Added");
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e);
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void regular_sql_executor(String sql, JLabel label, String error_message) {
        try {
            conn = DBConnection.ConnectDB();
            pst = conn.prepareStatement(sql);
            pst.execute();

            if (label == null) {
                JOptionPane.showMessageDialog(null, error_message);
            } else {
                label.setBackground(Color.blue);
                label.setText(error_message);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static int colCount(JTable table) {

        dum = table.getColumnCount();
        return dum;
    }

    public static void percentage_amount(JSpinner spinner, JTextField field1, JTextField field2) {

        if (!field1.getText().isEmpty()) {

            String spin1 = spinner.getValue().toString();

            double v1 = Double.parseDouble(spin1);
            if (v1 < 1) {

                spinner.setValue(0);
            }
            if (!field1.getText().equals("") && v1 != 0) {
                double a = Double.parseDouble(field1.getText());
                double y = a * v1;
                double z = y / 100;
                field2.setText(Double.toString(z));
            }
        }
    }

    public static void table_filter_with_specify(JTable table, String text, int n) {

        TableRowSorter<TableModel> rowSorter = new TableRowSorter<>(table.getModel());
        table.setRowSorter(rowSorter);

        if (text.trim().length() == 0) {
            rowSorter.setRowFilter(null);
        } else {
            rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text, n));
        }
    }

    public static void table_filter_without_specify(JTable table, String text) {

        TableRowSorter<TableModel> rowSorter = new TableRowSorter<>(table.getModel());
        table.setRowSorter(rowSorter);

        if (text.trim().length() == 0) {
            rowSorter.setRowFilter(null);
        } else {
            rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
        }
    }

    public static void main(String[] args) {

        ConnectDB();
    }

    public static String file_path(){

        JFileChooser fc = new JFileChooser();
        fc.setAcceptAllFileFilterUsed(false);
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Excel File", "xlsx");
        fc.addChoosableFileFilter(filter);

        fc.showSaveDialog(null);
        File f = fc.getSelectedFile();

        String path = f.getAbsolutePath();
        if (!path.endsWith(".xlsx")) {
            path = path.concat(".xlsx");
            }
        return path;       
    }

    public static int get_allRows(JTextField textfield) {

        System.out.println("Getting number of rows...");

        int sth = 0;
        try {
            FileInputStream inputi = new FileInputStream(textfield.getText());
            Workbook wbe = WorkbookFactory.create(inputi);
            Sheet sheete = wbe.getSheetAt(0);
            sth = sheete.getLastRowNum();
        } catch (IOException | InvalidFormatException | EncryptedDocumentException ex) {
            ex.printStackTrace();
        }
        //info_label.setText("Number of rows: "+sth);
        //info_label.setText("Number of rows: "+sth);
        
        //info_label.setText("Number of rows: "+sth);
        //info_label.setText("Number of rows: "+sth);

        return sth;
    }

    public static int Array_size(ArrayList list) {
        int elements = list.size();

        return elements;
    }

    private static String format_excel_headers(ArrayList list) {

        String a = list.toString();

        String replace = a.replace("[", "");
        String replace1 = replace.replace("]", "");
        String trim = replace1.trim();
        return trim;
    }

    public static void excel_to_db(JProgressBar progressbar, JTextField textfield) {

        BoundedRangeModel brm = progressbar.getModel();
        brm.setMaximum(get_allRows(textfield));

        //import_btn.setEnabled(false);
        progressbar.setStringPainted(true);
        try {
            Connection con = DBConnection.ConnectDB();
            //con.setAutoCommit(false);
            FileInputStream input = new FileInputStream(textfield.getText());
            Workbook wb = WorkbookFactory.create(input);
            Sheet sheet = wb.getSheetAt(0);
            ArrayList data = new ArrayList();
            Row row;
            String quote = "'";

            DataFormatter formatter = new DataFormatter();
            int i = 0;
            //setProgress(0);
            while (i <= sheet.getLastRowNum()) {

                row = sheet.getRow(i);

                for (int j = 0; j < Array_size(read_excel_header(textfield)); j++) {
                    data.add(quote + formatter.formatCellValue(sheet.getRow(i).getCell(j)) + quote);

                }
                String sql = "INSERT INTO " + import_settings.table_name_combo.getSelectedItem().toString() + " (" + format_excel_headers(read_excel_header(textfield)) + ") VALUES(" + format_excel_headers(data) + ")";

                pst = con.prepareStatement(sql);
                pst.execute();

                if (i % 50 == 0) {
                    //update_table();
                }
                System.out.println(sql);
                data.removeAll(data);
                System.out.println("Import rows " + i);
                progressbar.setValue(i);
                try {
                    Thread.sleep(rand.nextInt(10));
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }

                i = Math.min(i, sheet.getLastRowNum() + 1);

            }
            Toolkit.getDefaultToolkit().beep();
            //import_btn.setEnabled(true);
            //update_table();
            pst.close();
            con.close();
            input.close();

            JOptionPane.showMessageDialog(null, "Successfully imported to Database");
            progressbar.setValue(0);
            progressbar.setStringPainted(false);
        } catch (SQLException | IOException | InvalidFormatException | EncryptedDocumentException ex) {
            ex.printStackTrace();
        }
    }

    public static void writeToExcell(JTable Result_Table, JTextField textfield) throws FileNotFoundException, IOException {

        //new WorkbookFactory();
        XSSFWorkbook wb = new XSSFWorkbook(); //Excell workbook
        Sheet sheet = wb.createSheet(); //WorkSheet
        Row row = sheet.createRow(2); //Row created at line 3
        TableModel model = Result_Table.getModel(); //Table model

        Row headerRow = sheet.createRow(0); //Create row at line 0
        for (int headings = 0; headings < model.getColumnCount(); headings++) { //For each column
            headerRow.createCell(headings).setCellValue(model.getColumnName(Result_Table.convertColumnIndexToModel(headings)));//Write column name
        }

        for (int rows = 0; rows < model.getRowCount(); rows++) { //For each table row
            for (int cols = 0; cols < Result_Table.getColumnCount(); cols++) { //For each table column

                Object obj = model.getValueAt((Result_Table.convertRowIndexToModel(rows)), Result_Table.convertColumnIndexToModel(cols));
                String sth = (obj == null ? "" : obj.toString());

                row.createCell(cols).setCellValue(sth); //Write value
            }

            row = sheet.createRow((rows + 3));
        }
        wb.write(new FileOutputStream(textfield.getText()));//Save the file
        JOptionPane.showMessageDialog(null, "Data Exported Successfully");
    }

    private static ArrayList read_excel_header(JTextField textfield) throws FileNotFoundException, IOException {

        FileInputStream input = new FileInputStream(textfield.getText());
        XSSFWorkbook workbook = new XSSFWorkbook(input);

        XSSFSheet sheet = workbook.getSheetAt(0);

        ArrayList<String> columndata = null;

        Iterator<Row> rowIterator = sheet.iterator();
        columndata = new ArrayList<>();

        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            while (cellIterator.hasNext()) {
                Cell cell = cellIterator.next();

                if (row.getRowNum() == 0) {
                    if (cell.getRowIndex() == 0) {

                        switch (cell.getCellType()) {
                            case Cell.CELL_TYPE_NUMERIC:
                                columndata.add(cell.getNumericCellValue() + "");
                                break;
                            case Cell.CELL_TYPE_STRING:
                                columndata.add(cell.getStringCellValue());

                                break;
                        }
                    }
                }
            }
        }
        return columndata;
    }
        public static void apache_from_db_export(String sql, JTextField textfield) {

        XSSFWorkbook xlsxWorkbook = new XSSFWorkbook();
        XSSFSheet xlsSheet = xlsxWorkbook.createSheet();
        short rowIndex = 1;

        try {
            Connection con = DBConnection.ConnectDB();
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
// Get the list of column names and store them as the first row of the spreadsheet.

            ResultSetMetaData colInfo = rs.getMetaData();
            ArrayList<String> colNames = new ArrayList<>();
            XSSFRow titleRow = xlsSheet.createRow(rowIndex++);

            for (int i = 1; i <= colInfo.getColumnCount(); i++) {
                colNames.add(colInfo.getColumnName(i));
                titleRow.createCell((short) (i - 1)).setCellValue(
                        new XSSFRichTextString(colInfo.getColumnName(i)));
                xlsSheet.setColumnWidth((short) (i - 1), (short) 4000);
            }

// Save all the data from the database table rows
            while (rs.next()) {
                XSSFRow dataRow = xlsSheet.createRow(rowIndex++);
                short colIndex = 0;
                for (String colName : colNames) {
                    dataRow.createCell(colIndex++).setCellValue(
                            new XSSFRichTextString(rs.getString(colName)));
                }
            }
// Write to disk
            xlsxWorkbook.write(new FileOutputStream(textfield.getText()));
            JOptionPane.showMessageDialog(null, "Data Exported Successfully");
        } catch (SQLException | IOException e) {
            e.printStackTrace();
        }
    }
}
