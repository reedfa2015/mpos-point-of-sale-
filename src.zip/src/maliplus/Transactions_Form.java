/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus;

import com.sun.glass.events.KeyEvent;
import java.awt.Color;
import java.awt.Component;
import java.awt.HeadlessException;
import java.awt.Image;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SingleSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import maliplus.detailsPanels.TableDetails_Panel2;
import net.sf.jasperreports.view.JRViewer;
import net.sf.jasperreports.engine.design.*;
import net.sf.jasperreports.view.JasperViewer;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sourceforge.jdatepicker.impl.JDatePanelImpl;
import net.sourceforge.jdatepicker.impl.JDatePickerImpl;
import net.sourceforge.jdatepicker.impl.UtilDateModel;
import javax.swing.border.TitledBorder;
/**
 *
 * @author Admin-Pc
 */
public class Transactions_Form extends javax.swing.JFrame {

    private static Transactions_Form tf = null;

    static Connection conn = DBConnection.ConnectDB();
    static ResultSet rs;
    static PreparedStatement pst;

    public static String notify;
    String recur_status;
    String y_n_status;
    String trns_type;
    String acc_cat;
    String cash;
    private String flag;
    
    public JRViewer jv;
    void printReceipts(){
        TitledBorder border = new TitledBorder("RECEIPTS");
    border.setTitleJustification(TitledBorder.CENTER);
    border.setTitlePosition(TitledBorder.TOP);
    border.setTitleColor(Color.BLUE);
        DefaultTableModel model = (DefaultTableModel) receive_table.getModel();
        String refcode = model.getValueAt(receive_table.getSelectedRow(),39).toString();
        try{      
                conn = DBConnection.ConnectDB();
                JasperDesign jasperDesign= JRXmlLoader.load("receipts.jrxml");
                 String sql= "SELECT TRANSACTIONS_DETAIL.*, CONFIGURATIONS.FULL_NAME,CONFIGURATIONS.ADDRESS,CONFIGURATIONS.CITY,CONFIGURATIONS.EMAIL_ADDRESS,CONFIGURATIONS.TELEPHONES\n" +
                             "FROM TRANSACTIONS_DETAIL,  CONFIGURATIONS WHERE TRANSACTION_ID="+refcode+"";
                 JRDesignQuery newQuery= new JRDesignQuery();
                newQuery.setText(sql);
                jasperDesign.setQuery(newQuery);
                JasperReport jasperReport= JasperCompileManager.compileReport(jasperDesign);
                JasperPrint jasperPrint= JasperFillManager.fillReport(jasperReport, null, conn);
                // jv = new JasperViewer(jasperPrint, false);
                jv=new JRViewer(jasperPrint);
                jasperviewer.setPreferredSize(new java.awt.Dimension(400,400));
                jasperviewer.setLayout(new java.awt.BorderLayout());
                jasperviewer.removeAll();
                jasperviewer.add(jv);
                jasperviewer.revalidate();
                jasperviewer.repaint();  
                jv.setZoomRatio((float) 0.75);
                jv.setBorder(border);
                jv.setVisible(true);
                
                
                 
               
            }
            catch(Exception e){
                e.printStackTrace();
            }
    }
    private String selected_status(JRadioButton jrb) {

        if (jrb.isSelected()) {
            y_n_status = "Y";
        } else {
            y_n_status = "N";
        }
        return y_n_status;
    }

    private String checked_status(JCheckBox jcb) {

        if (jcb.isSelected()) {
            y_n_status = "Y";
        } else {
            y_n_status = "N";
        }
        return y_n_status;
    }

    String sql_recurrents_jtable = "select account_number,ledger_number,transaction_date,document_number,document_type,description,reference_number,reference_type,contra_account,transaction_type,transaction_status,amount,RECEIVE_IN,PAY_OUT,is_recurrent,approved,property_id,is_paid,amount_value as Balance from ledger_recurrents";

    String sql_payments_table = "SELECT account_number,ledger_number,transaction_date,document_number,document_type,description,reference_number,reference_type,contra_account,transaction_type,transaction_status,amount,APPROVED,property_id,amount_value as Balance from ledger_recurrents where approved = 'Y' and transaction_status = 'N' and (transaction_type = 'EOF' or transaction_type = 'EOW')";

    String sql_receipts_table="select * from transactions_detail";
    
    public static String sql_disbursements_table = "SELECT account_number,ledger_number,ledger_type,transaction_date,document_number,document_type,description,reference_number,reference_type,transaction_type,transaction_status,owner_id,property_id,due_amount,due_date,collected_amount,collection_date,is_collected,collection_balance,post_flag1,post_flag2,post_flag3,post_flag4 from ledger_recurrents where is_collected ='N'";

    static String cat_status;
    String payer;
    char receive;
    char pay;
    char pay_status;
    char approved_status;
    char recurring_status;

    String trans_type;
    String ledger_type;
    private static String trans_cat_type;
    char IN_OUT;

    public UtilDateModel model = new UtilDateModel();
    public UtilDateModel model2 = new UtilDateModel();
    public UtilDateModel model3 = new UtilDateModel();
    public UtilDateModel model4 = new UtilDateModel();
    public JDatePanelImpl datePanel = new JDatePanelImpl(model);
    public JDatePanelImpl datePanel2 = new JDatePanelImpl(model2);
    public JDatePanelImpl datePanel3 = new JDatePanelImpl(model3);
    public JDatePanelImpl datePanel4 = new JDatePanelImpl(model4);
    public JDatePickerImpl datePicker = new JDatePickerImpl(datePanel, new DateLabelFormatter1());
    public JDatePickerImpl datePicker2 = new JDatePickerImpl(datePanel2, new DateLabelFormatter1());
    public JDatePickerImpl datePicker3 = new JDatePickerImpl(datePanel3, new DateLabelFormatter1());
    public JDatePickerImpl datePicker4 = new JDatePickerImpl(datePanel4, new DateLabelFormatter1());

    public void dateP1() {
        try {

            dp.setLayout(new java.awt.BorderLayout());
            dp.add(datePicker);
            dp.revalidate();
            dp.repaint();
            //System.out.println(datePicker.getComponentListeners());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

    }

    public void dateP2() {
        try {

            dp1.setLayout(new java.awt.BorderLayout());
            dp1.add(datePicker2);
            dp1.revalidate();
            dp1.repaint();
            //System.out.println(datePicker.getComponentListeners());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public void dateP3() {
        try {

            dp2.setLayout(new java.awt.BorderLayout());
            dp2.add(datePicker3);
            dp2.revalidate();
            dp2.repaint();
            //System.out.println(datePicker.getComponentListeners());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public void dateP4() {
        try {

            dp3.setLayout(new java.awt.BorderLayout());
            dp3.add(datePicker4);
            dp3.revalidate();
            dp3.repaint();
            //System.out.println(datePicker.getComponentListeners());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    /**
     * Creates new form Transactions_Form
     */
    public Transactions_Form() {
        initComponents();
        setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);
        if (payments_panel.isShowing()) {
            new_btn.setEnabled(false);
        } else {
            new_btn.setEnabled(true);
        }
    }

    public static Transactions_Form getobj() {
        if (tf == null) {
            tf = new Transactions_Form();
        }

        return tf;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Category_buttonGroup = new javax.swing.ButtonGroup();
        Beneficiary_buttonGroup = new javax.swing.ButtonGroup();
        buttonGroup_in_out = new javax.swing.ButtonGroup();
        Category_buttonGroup2 = new javax.swing.ButtonGroup();
        Beneficiary_buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup_in_out2 = new javax.swing.ButtonGroup();
        transaction_categories = new javax.swing.ButtonGroup();
        jTextField1 = new javax.swing.JTextField();
        buttonGroup_payee = new javax.swing.ButtonGroup();
        jLabel20 = new javax.swing.JLabel();
        buttonGroup_srch_cat_rcpt = new javax.swing.ButtonGroup();
        buttonGroup_srch_cat_pmnt = new javax.swing.ButtonGroup();
        buttonGroup_in_out_rcpt = new javax.swing.ButtonGroup();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        create_inc_exp_panel = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        recurrents_jtable = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;}
        };
        jToolBar5 = new javax.swing.JToolBar();
        jLabel29 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox();
        serch_tf2 = new javax.swing.JTextField();
        jProgressBar1 = new javax.swing.JProgressBar();
        jPanel2 = new javax.swing.JPanel();
        search_contra_acc = new javax.swing.JLabel();
        jRB_office = new javax.swing.JRadioButton();
        transaction_amnt_tf = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jRadioButton_lease = new javax.swing.JRadioButton();
        jRB_receive = new javax.swing.JRadioButton();
        jLabel11 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel_trans_type = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jCheckBox_approved = new javax.swing.JCheckBox();
        jLabel32 = new javax.swing.JLabel();
        reference_tf = new javax.swing.JTextField();
        searchContact = new javax.swing.JLabel();
        dp = new javax.swing.JPanel();
        transaction_acc_tf = new javax.swing.JTextField();
        post_tranctn_btn = new javax.swing.JButton();
        jRadioButton_sale = new javax.swing.JRadioButton();
        jSeparator2 = new javax.swing.JSeparator();
        jL_ref = new javax.swing.JLabel();
        document_tf = new javax.swing.JTextField();
        search_trn_acc = new javax.swing.JLabel();
        jRadioButton_other = new javax.swing.JRadioButton();
        jLabel_contact = new javax.swing.JLabel();
        jRB_owner = new javax.swing.JRadioButton();
        jLabel3 = new javax.swing.JLabel();
        property_id_tf = new javax.swing.JTextField();
        ref_dscrptn_lbl = new javax.swing.JLabel();
        jL_doc = new javax.swing.JLabel();
        contact_id_tf = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel_sno2 = new javax.swing.JLabel();
        jCheckBox_recurring = new javax.swing.JCheckBox();
        jCombo_reference = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jRB_income = new javax.swing.JRadioButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea_trans_desp = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        TA_property = new javax.swing.JTextArea();
        jLabel22 = new javax.swing.JLabel();
        jRB_out = new javax.swing.JRadioButton();
        jLabel5 = new javax.swing.JLabel();
        jRB_expense = new javax.swing.JRadioButton();
        jLabel_recv_pay = new javax.swing.JLabel();
        pay_acc_tf = new javax.swing.JTextField();
        searchProperty_inc_exp = new javax.swing.JLabel();
        jCombo_document = new javax.swing.JComboBox<>();
        jCheckBox_paid = new javax.swing.JCheckBox();
        jLabel6 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel_transaction = new javax.swing.JLabel();
        receipts_panel = new javax.swing.JPanel();
        jSeparator7 = new javax.swing.JSeparator();
        jScrollPane4 = new javax.swing.JScrollPane();
        receive_table = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;}
        };
        jToolBar6 = new javax.swing.JToolBar();
        jLabel33 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox();
        serch_tf3 = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        trans_amnt_tf = new javax.swing.JTextField();
        jLabel76 = new javax.swing.JLabel();
        jLabel73 = new javax.swing.JLabel();
        ref_dscrptn_lbl1 = new javax.swing.JLabel();
        jLabel_sno1 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        doc_type_combo = new javax.swing.JComboBox<>();
        jLabel19 = new javax.swing.JLabel();
        jRadioButton35 = new javax.swing.JRadioButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        TA_property1 = new javax.swing.JTextArea();
        jCheckBox_debtor = new javax.swing.JCheckBox();
        reference_combo1 = new javax.swing.JComboBox<>();
        jLabel74 = new javax.swing.JLabel();
        jLabel69 = new javax.swing.JLabel();
        jRadioButton34 = new javax.swing.JRadioButton();
        jRadioButton_own_acc = new javax.swing.JRadioButton();
        jLabel_contact1 = new javax.swing.JLabel();
        search_contra_acc2 = new javax.swing.JLabel();
        contact_id_tf3 = new javax.swing.JTextField();
        dp1 = new javax.swing.JPanel();
        jLabel75 = new javax.swing.JLabel();
        receiv_acc_tf = new javax.swing.JTextField();
        balance_lbl = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel67 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        jLabel_transaction1 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jL_doc1 = new javax.swing.JLabel();
        prop_id_tf3 = new javax.swing.JTextField();
        jLabel_recv_pay1 = new javax.swing.JLabel();
        trans_acc = new javax.swing.JTextField();
        jRadioButton_off_acc = new javax.swing.JRadioButton();
        jLabel71 = new javax.swing.JLabel();
        doc_vouch_tf = new javax.swing.JTextField();
        jLabel72 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel77 = new javax.swing.JLabel();
        jLabel_trans_type1 = new javax.swing.JLabel();
        jScrollPane10 = new javax.swing.JScrollPane();
        trans_descrip_TA = new javax.swing.JTextArea();
        ref_tf = new javax.swing.JTextField();
        jLabel78 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        jasperviewer = new javax.swing.JPanel();
        payments_panel = new javax.swing.JPanel();
        jLabel45 = new javax.swing.JLabel();
        contact_id_tf2 = new javax.swing.JTextField();
        property_id_tf2 = new javax.swing.JTextField();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jRB_owner2 = new javax.swing.JRadioButton();
        jLabel49 = new javax.swing.JLabel();
        transaction_acc_tf2 = new javax.swing.JTextField();
        jLabel50 = new javax.swing.JLabel();
        transaction_amnt_tf2 = new javax.swing.JTextField();
        jRB_receive2 = new javax.swing.JRadioButton();
        jRB_out2 = new javax.swing.JRadioButton();
        jLabel51 = new javax.swing.JLabel();
        pay_acc_tf2 = new javax.swing.JTextField();
        jLabel52 = new javax.swing.JLabel();
        document_tf2 = new javax.swing.JTextField();
        jLabel53 = new javax.swing.JLabel();
        jCombo_document2 = new javax.swing.JComboBox<>();
        jLabel54 = new javax.swing.JLabel();
        reference_tf2 = new javax.swing.JTextField();
        jLabel55 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTextArea_trans_desp2 = new javax.swing.JTextArea();
        jSeparator5 = new javax.swing.JSeparator();
        jLabel79 = new javax.swing.JLabel();
        jRB_office2 = new javax.swing.JRadioButton();
        dp2 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        reference_combo = new javax.swing.JComboBox<>();
        jCheckBox_creditor_pay = new javax.swing.JCheckBox();
        jLabel16 = new javax.swing.JLabel();
        jScrollPane11 = new javax.swing.JScrollPane();
        payments_table = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;}
        };
        jScrollPane7 = new javax.swing.JScrollPane();
        TA_property2 = new javax.swing.JTextArea();
        jLabel_transaction3 = new javax.swing.JLabel();
        jLabel_recv_pay2 = new javax.swing.JLabel();
        jLabel_contact2 = new javax.swing.JLabel();
        jLabel_trans_type2 = new javax.swing.JLabel();
        ref_dscrptn_lbl2 = new javax.swing.JLabel();
        jL_doc2 = new javax.swing.JLabel();
        balance_lbl1 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        jLabel_sno = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jToolBar7 = new javax.swing.JToolBar();
        jLabel34 = new javax.swing.JLabel();
        jComboBox3 = new javax.swing.JComboBox();
        serch_tf4 = new javax.swing.JTextField();
        search_contra_acc3 = new javax.swing.JLabel();
        jSeparator9 = new javax.swing.JSeparator();
        disbursements_panel = new javax.swing.JPanel();
        jSeparator6 = new javax.swing.JSeparator();
        jScrollPane9 = new javax.swing.JScrollPane();
        disbursements_table = new javax.swing.JTable();
        jSeparator4 = new javax.swing.JSeparator();
        jPanel1 = new javax.swing.JPanel();
        dp3 = new javax.swing.JPanel();
        owner_tf = new javax.swing.JTextField();
        searchBeneficiary = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        dis_doc_type = new javax.swing.JComboBox<>();
        jScrollPane12 = new javax.swing.JScrollPane();
        TA_property3 = new javax.swing.JTextArea();
        jLabel61 = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        dis_ref_tf = new javax.swing.JTextField();
        jLabel60 = new javax.swing.JLabel();
        contact_tf = new javax.swing.JTextField();
        Trans_Acc_desc = new javax.swing.JLabel();
        owner_paymnt = new javax.swing.JCheckBox();
        jLabel_owner = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        dis_doc_tf = new javax.swing.JTextField();
        jLabel65 = new javax.swing.JLabel();
        searchProperty = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        rec_pay_acc = new javax.swing.JTextField();
        jLabel59 = new javax.swing.JLabel();
        jLabel80 = new javax.swing.JLabel();
        searchOwner = new javax.swing.JLabel();
        jRadioButton29 = new javax.swing.JRadioButton();
        property_tf = new javax.swing.JTextField();
        jLabel64 = new javax.swing.JLabel();
        jRadioButton30 = new javax.swing.JRadioButton();
        jScrollPane8 = new javax.swing.JScrollPane();
        dis_TA = new javax.swing.JTextArea();
        trn_amt_tf = new javax.swing.JTextField();
        trn_acc_tf = new javax.swing.JTextField();
        contra_label = new javax.swing.JLabel();
        jLabel_beneficiary = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        jSeparator8 = new javax.swing.JSeparator();
        Load_owner_Trans = new javax.swing.JButton();
        searchContra_acc1 = new javax.swing.JLabel();
        jToolBar1 = new javax.swing.JToolBar();
        new_btn = new javax.swing.JButton();
        update_btn = new javax.swing.JButton();
        clear_btn = new javax.swing.JButton();
        delete_btn = new javax.swing.JButton();
        export_btn = new javax.swing.JButton();
        refresh_btn = new javax.swing.JButton();
        delete_me = new javax.swing.JButton();
        error_msg_lbl = new javax.swing.JLabel();

        jTextField1.setText("jTextField1");

        jLabel20.setText("jLabel20");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jTabbedPane1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jTabbedPane1MouseReleased(evt);
            }
        });
        jTabbedPane1.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                jTabbedPane1PropertyChange(evt);
            }
        });

        recurrents_jtable.setAutoCreateRowSorter(true);
        recurrents_jtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        recurrents_jtable.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        recurrents_jtable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                recurrents_jtableMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                recurrents_jtableMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                recurrents_jtableMouseReleased(evt);
            }
        });
        jScrollPane2.setViewportView(recurrents_jtable);

        jToolBar5.setRollover(true);

        jLabel29.setText("Search By:    ");
        jToolBar5.add(jLabel29);

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "All", "Contact ID", "Property ID", "Lease ID" }));
        jToolBar5.add(jComboBox1);

        serch_tf2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                serch_tf2KeyReleased(evt);
            }
        });
        jToolBar5.add(serch_tf2);

        jProgressBar1.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jProgressBar1StateChanged(evt);
            }
        });
        jProgressBar1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jProgressBar1MouseClicked(evt);
            }
        });

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 0, 204), null));

        search_contra_acc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        search_contra_acc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                search_contra_accMouseClicked(evt);
            }
        });

        Beneficiary_buttonGroup.add(jRB_office);
        jRB_office.setSelected(true);
        jRB_office.setText("Office");
        jRB_office.setToolTipText("Credit");
        jRB_office.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRB_officeActionPerformed(evt);
            }
        });

        transaction_amnt_tf.setToolTipText("Enter Transaction Amount");
        transaction_amnt_tf.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                transaction_amnt_tfKeyTyped(evt);
            }
        });

        jLabel7.setText("Transaction");

        jLabel18.setText("Description");

        transaction_categories.add(jRadioButton_lease);
        jRadioButton_lease.setSelected(true);
        jRadioButton_lease.setText("Lease");
        jRadioButton_lease.setToolTipText("transaction for lease");
        jRadioButton_lease.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton_leaseActionPerformed(evt);
            }
        });

        buttonGroup_in_out.add(jRB_receive);
        jRB_receive.setSelected(true);
        jRB_receive.setText("Receive/IN");
        jRB_receive.setToolTipText("Debit");
        jRB_receive.setEnabled(false);

        jLabel11.setText("Transaction Category :");

        jLabel4.setText("Transaction Date");

        jLabel_trans_type.setForeground(new java.awt.Color(102, 102, 102));
        jLabel_trans_type.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        jLabel10.setText("Property ID");

        jLabel12.setText("Beneficiary/Payer :");

        jCheckBox_approved.setText("Approved");
        jCheckBox_approved.setEnabled(false);
        jCheckBox_approved.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox_approvedActionPerformed(evt);
            }
        });

        jLabel32.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel32.setText("S.No:");

        searchContact.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        searchContact.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchContactMouseClicked(evt);
            }
        });

        dp.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        javax.swing.GroupLayout dpLayout = new javax.swing.GroupLayout(dp);
        dp.setLayout(dpLayout);
        dpLayout.setHorizontalGroup(
            dpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 176, Short.MAX_VALUE)
        );
        dpLayout.setVerticalGroup(
            dpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 33, Short.MAX_VALUE)
        );

        transaction_acc_tf.setEditable(false);

        post_tranctn_btn.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        post_tranctn_btn.setText("Approve");
        post_tranctn_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                post_tranctn_btnActionPerformed(evt);
            }
        });

        transaction_categories.add(jRadioButton_sale);
        jRadioButton_sale.setText("Sale");
        jRadioButton_sale.setToolTipText("transaction for sale");
        jRadioButton_sale.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton_saleActionPerformed(evt);
            }
        });

        search_trn_acc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        search_trn_acc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                search_trn_accMouseClicked(evt);
            }
        });

        transaction_categories.add(jRadioButton_other);
        jRadioButton_other.setText("Other");
        jRadioButton_other.setToolTipText("transaction for owner");
        jRadioButton_other.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton_otherActionPerformed(evt);
            }
        });

        Beneficiary_buttonGroup.add(jRB_owner);
        jRB_owner.setText("Owner");
        jRB_owner.setToolTipText("Credit");
        jRB_owner.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRB_ownerActionPerformed(evt);
            }
        });

        jLabel3.setText("Contact ID");

        property_id_tf.setEditable(false);

        ref_dscrptn_lbl.setForeground(new java.awt.Color(60, 63, 65));

        jL_doc.setForeground(new java.awt.Color(102, 102, 102));

        contact_id_tf.setEditable(false);
        contact_id_tf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contact_id_tfActionPerformed(evt);
            }
        });

        jLabel9.setText("Reference");

        jCheckBox_recurring.setText("Reccuring");

        jCombo_reference.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCombo_referenceActionPerformed(evt);
            }
        });

        jLabel1.setText("Transaction Account");

        jLabel8.setText("Document/Voucher");

        Category_buttonGroup.add(jRB_income);
        jRB_income.setSelected(true);
        jRB_income.setText("Income");
        jRB_income.setToolTipText("Debit");
        jRB_income.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRB_incomeActionPerformed(evt);
            }
        });

        jTextArea_trans_desp.setColumns(20);
        jTextArea_trans_desp.setLineWrap(true);
        jTextArea_trans_desp.setRows(5);
        jTextArea_trans_desp.setWrapStyleWord(true);
        jScrollPane1.setViewportView(jTextArea_trans_desp);

        TA_property.setEditable(false);
        TA_property.setBackground(new java.awt.Color(240, 240, 240));
        TA_property.setColumns(20);
        TA_property.setLineWrap(true);
        TA_property.setRows(5);
        TA_property.setWrapStyleWord(true);
        jScrollPane3.setViewportView(TA_property);

        buttonGroup_in_out.add(jRB_out);
        jRB_out.setText("Pay/OUT");
        jRB_out.setToolTipText("Credit");
        jRB_out.setEnabled(false);

        jLabel5.setText("Transaction Amount");

        Category_buttonGroup.add(jRB_expense);
        jRB_expense.setText("Expense");
        jRB_expense.setToolTipText("Credit");
        jRB_expense.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRB_expenseActionPerformed(evt);
            }
        });

        pay_acc_tf.setEditable(false);

        searchProperty_inc_exp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        searchProperty_inc_exp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchProperty_inc_expMouseClicked(evt);
            }
        });

        jCombo_document.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCombo_documentActionPerformed(evt);
            }
        });

        jCheckBox_paid.setText("Paid");
        jCheckBox_paid.setEnabled(false);

        jLabel6.setText("Receiving/Pay Account");

        jLabel2.setText("Doc/Voucher Type");

        jLabel14.setText("Reference Type");

        jLabel_transaction.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                jLabel_transactionComponentResized(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator2)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel11)
                                    .addComponent(jLabel12)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel18))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                            .addComponent(pay_acc_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(18, 18, 18)
                                            .addComponent(search_contra_acc)
                                            .addGap(53, 53, 53)
                                            .addComponent(jLabel_recv_pay, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGroup(jPanel2Layout.createSequentialGroup()
                                            .addComponent(transaction_acc_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(18, 18, 18)
                                            .addComponent(search_trn_acc)
                                            .addGap(347, 347, 347)))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(jRadioButton_lease)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jRadioButton_sale, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jRadioButton_other)
                                                .addGap(92, 92, 92)
                                                .addComponent(jCheckBox_recurring)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(post_tranctn_btn)
                                                .addGap(13, 13, 13)
                                                .addComponent(jCheckBox_paid)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jCheckBox_approved))
                                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                                        .addComponent(transaction_amnt_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                        .addComponent(jLabel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addComponent(jRB_income)
                                                            .addComponent(jRB_office))
                                                        .addGap(18, 18, 18)
                                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addComponent(jRB_expense)
                                                            .addComponent(jRB_owner))
                                                        .addGap(91, 91, 91)))
                                                .addGap(18, 18, 18)
                                                .addComponent(jRB_receive)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jRB_out))
                                            .addComponent(dp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(reference_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(jLabel14)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jCombo_reference, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(document_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(21, 21, 21)
                                                .addComponent(jLabel2)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jCombo_document, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addComponent(property_id_tf)
                                                    .addComponent(contact_id_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGap(18, 18, 18)
                                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(searchContact)
                                                    .addComponent(searchProperty_inc_exp))
                                                .addGap(18, 18, 18)
                                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addComponent(jScrollPane3)
                                                    .addComponent(jLabel_contact, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jLabel32)))
                                        .addGap(471, 471, 471))))
                            .addComponent(jLabel3)
                            .addComponent(jLabel1)
                            .addComponent(jLabel10)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jL_ref, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel_transaction, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel_trans_type, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(ref_dscrptn_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jL_doc, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel_sno2, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jRadioButton_lease)
                    .addComponent(jRadioButton_sale)
                    .addComponent(jRadioButton_other)
                    .addComponent(jCheckBox_paid)
                    .addComponent(post_tranctn_btn)
                    .addComponent(jCheckBox_approved)
                    .addComponent(jCheckBox_recurring))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(9, 9, 9)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(jLabel3)
                    .addComponent(contact_id_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel_contact, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchContact)
                    .addComponent(jLabel32))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addComponent(property_id_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchProperty_inc_exp)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(jCombo_reference, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14)
                    .addComponent(reference_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(dp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                            .addComponent(search_trn_acc)
                            .addComponent(transaction_acc_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                                    .addComponent(jLabel11)
                                    .addComponent(jRB_income)
                                    .addComponent(jRB_expense))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel12)
                                    .addComponent(jRB_office)
                                    .addComponent(jRB_owner)))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jRB_receive)
                                    .addComponent(jRB_out))
                                .addGap(9, 9, 9)))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(transaction_amnt_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5)
                            .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel6)
                                .addComponent(pay_acc_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel_recv_pay, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(search_contra_acc))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(document_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2)
                            .addComponent(jCombo_document, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addGap(0, 0, 0)
                                .addComponent(jLabel18)))))
                .addGap(42, 42, 42)
                .addComponent(jLabel_sno2, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(89, 89, 89)
                .addComponent(ref_dscrptn_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(54, 54, 54)
                .addComponent(jLabel_transaction, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addComponent(jLabel_trans_type, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(67, 67, 67)
                .addComponent(jL_doc, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jL_ref, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout create_inc_exp_panelLayout = new javax.swing.GroupLayout(create_inc_exp_panel);
        create_inc_exp_panel.setLayout(create_inc_exp_panelLayout);
        create_inc_exp_panelLayout.setHorizontalGroup(
            create_inc_exp_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(create_inc_exp_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(create_inc_exp_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(create_inc_exp_panelLayout.createSequentialGroup()
                        .addGap(264, 264, 264)
                        .addComponent(jToolBar5, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jProgressBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(927, Short.MAX_VALUE))
                    .addGroup(create_inc_exp_panelLayout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addComponent(jScrollPane2)))
        );
        create_inc_exp_panelLayout.setVerticalGroup(
            create_inc_exp_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(create_inc_exp_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 475, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addGroup(create_inc_exp_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jToolBar5, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jProgressBar1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 448, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("    Create Income/Expenses     ", create_inc_exp_panel);

        receive_table.setAutoCreateRowSorter(true);
        receive_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        receive_table.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        receive_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                receive_tableMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(receive_table);

        jToolBar6.setRollover(true);

        jLabel33.setText("Search By:    ");
        jToolBar6.add(jLabel33);

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "All", "Contact ID", "Property ID", "Lease ID" }));
        jToolBar6.add(jComboBox2);

        serch_tf3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                serch_tf3KeyReleased(evt);
            }
        });
        jToolBar6.add(serch_tf3);

        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 0, 204), null));

        trans_amnt_tf.setToolTipText("Enter Transaction Amount");
        trans_amnt_tf.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                trans_amnt_tfKeyTyped(evt);
            }
        });

        jLabel76.setText("Reference");

        jLabel73.setText("Receiving Account");

        ref_dscrptn_lbl1.setForeground(new java.awt.Color(60, 63, 65));

        jLabel31.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel31.setText("S.No:");

        doc_type_combo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                doc_type_comboActionPerformed(evt);
            }
        });

        jLabel19.setText("Reference Type");

        buttonGroup_in_out_rcpt.add(jRadioButton35);
        jRadioButton35.setText("Reverse/OUT");
        jRadioButton35.setToolTipText("Credit");
        jRadioButton35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton35ActionPerformed(evt);
            }
        });

        TA_property1.setEditable(false);
        TA_property1.setBackground(new java.awt.Color(240, 240, 240));
        TA_property1.setColumns(20);
        TA_property1.setLineWrap(true);
        TA_property1.setRows(5);
        TA_property1.setWrapStyleWord(true);
        jScrollPane5.setViewportView(TA_property1);

        jCheckBox_debtor.setSelected(true);
        jCheckBox_debtor.setText("Debtor Receipt");
        jCheckBox_debtor.setEnabled(false);

        reference_combo1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reference_combo1ActionPerformed(evt);
            }
        });

        jLabel74.setText("Document/Voucher");

        jLabel69.setText("Transaction Date");

        buttonGroup_in_out_rcpt.add(jRadioButton34);
        jRadioButton34.setSelected(true);
        jRadioButton34.setText("Receive/IN");
        jRadioButton34.setToolTipText("Debit");
        jRadioButton34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton34ActionPerformed(evt);
            }
        });

        buttonGroup_payee.add(jRadioButton_own_acc);
        jRadioButton_own_acc.setText("Owner A/c");
        jRadioButton_own_acc.setToolTipText("Credit");
        jRadioButton_own_acc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton_own_accActionPerformed(evt);
            }
        });

        search_contra_acc2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        search_contra_acc2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                search_contra_acc2MouseClicked(evt);
            }
        });

        contact_id_tf3.setEditable(false);
        contact_id_tf3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contact_id_tf3ActionPerformed(evt);
            }
        });

        dp1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        javax.swing.GroupLayout dp1Layout = new javax.swing.GroupLayout(dp1);
        dp1.setLayout(dp1Layout);
        dp1Layout.setHorizontalGroup(
            dp1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 176, Short.MAX_VALUE)
        );
        dp1Layout.setVerticalGroup(
            dp1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 33, Short.MAX_VALUE)
        );

        jLabel75.setText("Doc/Voucher Type");

        receiv_acc_tf.setEditable(false);
        receiv_acc_tf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                receiv_acc_tfActionPerformed(evt);
            }
        });

        jLabel21.setText("Balance ");

        jLabel67.setText("Contact ID");

        jLabel68.setText("Property ID");

        jLabel_transaction1.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                jLabel_transaction1ComponentResized(evt);
            }
        });

        jL_doc1.setForeground(new java.awt.Color(102, 102, 102));

        prop_id_tf3.setEditable(false);
        prop_id_tf3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prop_id_tf3ActionPerformed(evt);
            }
        });

        trans_acc.setEditable(false);
        trans_acc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                trans_accActionPerformed(evt);
            }
        });

        buttonGroup_payee.add(jRadioButton_off_acc);
        jRadioButton_off_acc.setSelected(true);
        jRadioButton_off_acc.setText("Office A/c");
        jRadioButton_off_acc.setToolTipText("Credit");
        jRadioButton_off_acc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton_off_accActionPerformed(evt);
            }
        });

        jLabel71.setText("Transaction Account");

        doc_vouch_tf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                doc_vouch_tfActionPerformed(evt);
            }
        });

        jLabel72.setText("Transaction Amount");

        jLabel13.setText("Description");

        jLabel77.setText("Transaction");

        jLabel_trans_type1.setForeground(new java.awt.Color(102, 102, 102));
        jLabel_trans_type1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        trans_descrip_TA.setColumns(20);
        trans_descrip_TA.setLineWrap(true);
        trans_descrip_TA.setRows(5);
        trans_descrip_TA.setText("\nlm\n\n\n");
        trans_descrip_TA.setWrapStyleWord(true);
        jScrollPane10.setViewportView(trans_descrip_TA);

        ref_tf.setEnabled(false);
        ref_tf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ref_tfActionPerformed(evt);
            }
        });

        jLabel78.setText("Payee");

        jLabel70.setText("Transaction Category");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel72, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel73, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel70, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel71))
                            .addComponent(jLabel78, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(receiv_acc_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jLabel21)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(balance_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addComponent(search_contra_acc2)
                                                .addGap(18, 18, 18)
                                                .addComponent(jLabel_recv_pay1, javax.swing.GroupLayout.PREFERRED_SIZE, 279, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(trans_acc, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel_transaction1, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addComponent(doc_vouch_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jLabel75, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(trans_amnt_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(doc_type_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jL_doc1, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                                .addGap(219, 219, 219)
                                                .addComponent(reference_combo1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                                .addComponent(jRadioButton_off_acc)
                                                .addGap(27, 27, 27)
                                                .addComponent(jRadioButton_own_acc)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jLabel_trans_type1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(jRadioButton34)))
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addGap(4, 4, 4)
                                                .addComponent(jRadioButton35))
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel31)
                                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                                        .addGap(38, 38, 38)
                                                        .addComponent(jLabel_sno1, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addComponent(ref_dscrptn_lbl1, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jCheckBox_debtor)
                                    .addComponent(dp1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel76)
                                .addGap(73, 73, 73)
                                .addComponent(ref_tf))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel69, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel67, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel68, javax.swing.GroupLayout.Alignment.LEADING)))
                                .addGap(33, 33, 33)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(prop_id_tf3)
                                    .addComponent(contact_id_tf3, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel19)
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel74, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel77)
                                .addComponent(jLabel13))
                            .addGap(64, 64, 64)
                            .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(401, 401, 401))
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addComponent(jLabel_contact1, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(275, 275, 275))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel_sno1, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel_contact1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(contact_id_tf3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel67)))
                    .addComponent(jLabel31))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(prop_id_tf3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel68))
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ref_dscrptn_lbl1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel76)
                        .addComponent(ref_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(reference_combo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel19)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(dp1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel69))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel70)
                    .addComponent(jCheckBox_debtor))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jRadioButton_own_acc)
                            .addComponent(jLabel78)
                            .addComponent(jRadioButton_off_acc))
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addComponent(jLabel_trans_type1, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(9, 9, 9)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jRadioButton34)
                            .addComponent(jRadioButton35))
                        .addGap(3, 3, 3)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel_transaction1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(trans_acc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel71)))
                .addGap(14, 14, 14)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(trans_amnt_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel72))
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(balance_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel21))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(receiv_acc_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel73))
                            .addComponent(search_contra_acc2)))
                    .addComponent(jLabel_recv_pay1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel74)
                        .addComponent(doc_vouch_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel75)
                        .addComponent(doc_type_combo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jL_doc1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel77)
                        .addGap(0, 0, 0)
                        .addComponent(jLabel13))
                    .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        jasperviewer.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(255, 0, 0), null));
        jasperviewer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jasperviewerMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jasperviewerLayout = new javax.swing.GroupLayout(jasperviewer);
        jasperviewer.setLayout(jasperviewerLayout);
        jasperviewerLayout.setHorizontalGroup(
            jasperviewerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jasperviewerLayout.setVerticalGroup(
            jasperviewerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout receipts_panelLayout = new javax.swing.GroupLayout(receipts_panel);
        receipts_panel.setLayout(receipts_panelLayout);
        receipts_panelLayout.setHorizontalGroup(
            receipts_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(receipts_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(receipts_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(receipts_panelLayout.createSequentialGroup()
                        .addGroup(receipts_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator7, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 1717, Short.MAX_VALUE))
                        .addContainerGap())
                    .addGroup(receipts_panelLayout.createSequentialGroup()
                        .addGroup(receipts_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(receipts_panelLayout.createSequentialGroup()
                                .addComponent(jToolBar6, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(receipts_panelLayout.createSequentialGroup()
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jasperviewer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(10, 10, 10))))
        );
        receipts_panelLayout.setVerticalGroup(
            receipts_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(receipts_panelLayout.createSequentialGroup()
                .addGroup(receipts_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jasperviewer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator7, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jToolBar6, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 525, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("     Receipts     ", receipts_panel);

        jLabel45.setText("Contact ID");

        contact_id_tf2.setEditable(false);

        property_id_tf2.setEditable(false);

        jLabel46.setText("Property ID");

        jLabel47.setText("Transaction Date");

        jLabel48.setText("Transaction Category");

        Beneficiary_buttonGroup2.add(jRB_owner2);
        jRB_owner2.setText("Owner A/c");
        jRB_owner2.setToolTipText("Credit");
        jRB_owner2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRB_owner2ActionPerformed(evt);
            }
        });

        jLabel49.setText("Transaction Account");

        transaction_acc_tf2.setEditable(false);

        jLabel50.setText("Transaction Amount");

        transaction_amnt_tf2.setToolTipText("Enter Transaction Amount");
        transaction_amnt_tf2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                transaction_amnt_tf2KeyTyped(evt);
            }
        });

        buttonGroup_in_out2.add(jRB_receive2);
        jRB_receive2.setText("Reverse/IN");
        jRB_receive2.setToolTipText("Debit");
        jRB_receive2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRB_receive2ActionPerformed(evt);
            }
        });

        buttonGroup_in_out2.add(jRB_out2);
        jRB_out2.setSelected(true);
        jRB_out2.setText("Pay/OUT");
        jRB_out2.setToolTipText("Credit");
        jRB_out2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRB_out2ActionPerformed(evt);
            }
        });

        jLabel51.setText("Paying Account");

        pay_acc_tf2.setEditable(false);

        jLabel52.setText("Document/Voucher");

        jLabel53.setText("Doc/Voucher Type");

        jCombo_document2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCombo_document2ActionPerformed(evt);
            }
        });

        jLabel54.setText("Reference");

        reference_tf2.setEnabled(false);

        jLabel55.setText("Transaction ");

        jTextArea_trans_desp2.setColumns(20);
        jTextArea_trans_desp2.setLineWrap(true);
        jTextArea_trans_desp2.setRows(5);
        jTextArea_trans_desp2.setWrapStyleWord(true);
        jScrollPane6.setViewportView(jTextArea_trans_desp2);

        jLabel79.setText("Payer");

        Beneficiary_buttonGroup2.add(jRB_office2);
        jRB_office2.setSelected(true);
        jRB_office2.setText("Office A/c");
        jRB_office2.setToolTipText("Credit");
        jRB_office2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRB_office2ActionPerformed(evt);
            }
        });

        dp2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        javax.swing.GroupLayout dp2Layout = new javax.swing.GroupLayout(dp2);
        dp2.setLayout(dp2Layout);
        dp2Layout.setHorizontalGroup(
            dp2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 176, Short.MAX_VALUE)
        );
        dp2Layout.setVerticalGroup(
            dp2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 33, Short.MAX_VALUE)
        );

        jLabel15.setText("Reference Type");

        reference_combo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reference_comboActionPerformed(evt);
            }
        });

        jCheckBox_creditor_pay.setSelected(true);
        jCheckBox_creditor_pay.setText("Creditor Payment");
        jCheckBox_creditor_pay.setEnabled(false);

        jLabel16.setText("Description");

        payments_table.setAutoCreateRowSorter(true);
        payments_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        payments_table.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        payments_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                payments_tableMouseClicked(evt);
            }
        });
        jScrollPane11.setViewportView(payments_table);

        TA_property2.setEditable(false);
        TA_property2.setBackground(new java.awt.Color(240, 240, 240));
        TA_property2.setColumns(20);
        TA_property2.setLineWrap(true);
        TA_property2.setRows(5);
        TA_property2.setWrapStyleWord(true);
        jScrollPane7.setViewportView(TA_property2);

        jLabel_transaction3.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                jLabel_transaction3ComponentResized(evt);
            }
        });

        jLabel_trans_type2.setForeground(new java.awt.Color(102, 102, 102));
        jLabel_trans_type2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        ref_dscrptn_lbl2.setForeground(new java.awt.Color(60, 63, 65));

        jL_doc2.setForeground(new java.awt.Color(102, 102, 102));

        jLabel23.setText("Balance ");

        jLabel30.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel30.setText("S.No:");

        jToolBar7.setRollover(true);

        jLabel34.setText("Search By:    ");
        jToolBar7.add(jLabel34);

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "All", "Contact ID", "Property ID", "Lease ID" }));
        jToolBar7.add(jComboBox3);

        serch_tf4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                serch_tf4KeyReleased(evt);
            }
        });
        jToolBar7.add(serch_tf4);

        search_contra_acc3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        search_contra_acc3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                search_contra_acc3MouseClicked(evt);
            }
        });

        jSeparator9.setOrientation(javax.swing.SwingConstants.VERTICAL);

        javax.swing.GroupLayout payments_panelLayout = new javax.swing.GroupLayout(payments_panel);
        payments_panel.setLayout(payments_panelLayout);
        payments_panelLayout.setHorizontalGroup(
            payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(payments_panelLayout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jScrollPane11, javax.swing.GroupLayout.DEFAULT_SIZE, 1721, Short.MAX_VALUE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, payments_panelLayout.createSequentialGroup()
                .addContainerGap(1730, Short.MAX_VALUE)
                .addComponent(jSeparator5)
                .addGap(6, 6, 6))
            .addGroup(payments_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jSeparator3)
                .addContainerGap())
            .addGroup(payments_panelLayout.createSequentialGroup()
                .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(payments_panelLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(payments_panelLayout.createSequentialGroup()
                                .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jLabel50, javax.swing.GroupLayout.DEFAULT_SIZE, 122, Short.MAX_VALUE)
                                        .addComponent(jLabel51, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel47, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel49))
                                    .addComponent(jLabel79, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel48, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(payments_panelLayout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(payments_panelLayout.createSequentialGroup()
                                                .addComponent(jRB_office2)
                                                .addGap(29, 29, 29)
                                                .addComponent(jRB_owner2)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jLabel_trans_type2, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(jRB_receive2)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jRB_out2))
                                            .addGroup(payments_panelLayout.createSequentialGroup()
                                                .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addComponent(pay_acc_tf2, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                        .addComponent(transaction_amnt_tf2, javax.swing.GroupLayout.DEFAULT_SIZE, 120, Short.MAX_VALUE)
                                                        .addComponent(transaction_acc_tf2)))
                                                .addGap(18, 18, 18)
                                                .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(payments_panelLayout.createSequentialGroup()
                                                        .addComponent(search_contra_acc3)
                                                        .addGap(18, 18, 18)
                                                        .addComponent(jLabel_recv_pay2, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                        .addComponent(jLabel_transaction3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, payments_panelLayout.createSequentialGroup()
                                                            .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                            .addComponent(jLabel23)
                                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                            .addComponent(balance_lbl1, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                                    .addGroup(payments_panelLayout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jCheckBox_creditor_pay)
                                            .addComponent(dp2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addGroup(payments_panelLayout.createSequentialGroup()
                                .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel55)
                                    .addComponent(jLabel16))
                                .addGap(61, 61, 61)
                                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(payments_panelLayout.createSequentialGroup()
                                .addComponent(jLabel52, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(document_tf2, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel53)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jCombo_document2, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jL_doc2, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(payments_panelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(payments_panelLayout.createSequentialGroup()
                                .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel45, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel54, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(reference_tf2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 126, Short.MAX_VALUE)
                                    .addComponent(contact_id_tf2, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(property_id_tf2, javax.swing.GroupLayout.Alignment.LEADING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(payments_panelLayout.createSequentialGroup()
                                        .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(payments_panelLayout.createSequentialGroup()
                                                .addComponent(jLabel15)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(reference_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(ref_dscrptn_lbl2, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(7, 7, 7))
                                            .addGroup(payments_panelLayout.createSequentialGroup()
                                                .addComponent(jLabel_contact2, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(jSeparator9, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(42, 42, 42)))
                                        .addComponent(jLabel30)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel_sno, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addComponent(jToolBar7, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        payments_panelLayout.setVerticalGroup(
            payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(payments_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(contact_id_tf2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel45))
                    .addComponent(jLabel_contact2, javax.swing.GroupLayout.DEFAULT_SIZE, 148, Short.MAX_VALUE)
                    .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jSeparator9, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel_sno, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel30, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(property_id_tf2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel46))
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel54)
                        .addComponent(reference_tf2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel15)
                        .addComponent(reference_combo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(ref_dscrptn_lbl2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(payments_panelLayout.createSequentialGroup()
                        .addComponent(jLabel47)
                        .addGap(33, 33, 33))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, payments_panelLayout.createSequentialGroup()
                        .addComponent(dp2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel48)
                    .addComponent(jCheckBox_creditor_pay))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel_trans_type2, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jRB_office2)
                        .addComponent(jRB_owner2)
                        .addComponent(jLabel79))
                    .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jRB_receive2)
                        .addComponent(jRB_out2)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(payments_panelLayout.createSequentialGroup()
                        .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(transaction_acc_tf2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel49))
                        .addGap(8, 8, 8)
                        .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(payments_panelLayout.createSequentialGroup()
                                .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(transaction_amnt_tf2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel50))
                                    .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel51)
                                        .addComponent(pay_acc_tf2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel_recv_pay2, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(search_contra_acc3))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel52)
                                        .addComponent(document_tf2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel53)
                                        .addComponent(jCombo_document2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jL_doc2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(payments_panelLayout.createSequentialGroup()
                                        .addComponent(jLabel55)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel16)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(payments_panelLayout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addGroup(payments_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(balance_lbl1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(5, 5, 5)
                        .addComponent(jToolBar7, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane11, javax.swing.GroupLayout.DEFAULT_SIZE, 413, Short.MAX_VALUE)
                        .addGap(12, 12, 12))
                    .addGroup(payments_panelLayout.createSequentialGroup()
                        .addComponent(jLabel_transaction3, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );

        jTabbedPane1.addTab("    Payments    ", payments_panel);

        disbursements_table.setAutoCreateRowSorter(true);
        disbursements_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        disbursements_table.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        disbursements_table.setEnabled(false);
        disbursements_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                disbursements_tableMouseClicked(evt);
            }
        });
        jScrollPane9.setViewportView(disbursements_table);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        dp3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        javax.swing.GroupLayout dp3Layout = new javax.swing.GroupLayout(dp3);
        dp3.setLayout(dp3Layout);
        dp3Layout.setHorizontalGroup(
            dp3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 176, Short.MAX_VALUE)
        );
        dp3Layout.setVerticalGroup(
            dp3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 33, Short.MAX_VALUE)
        );

        owner_tf.setEditable(false);
        owner_tf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                owner_tfActionPerformed(evt);
            }
        });

        searchBeneficiary.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        searchBeneficiary.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchBeneficiaryMouseClicked(evt);
            }
        });

        jLabel56.setText("Beneficiary");

        jLabel63.setText("Document/Voucher");

        TA_property3.setEditable(false);
        TA_property3.setBackground(new java.awt.Color(240, 240, 240));
        TA_property3.setColumns(20);
        TA_property3.setLineWrap(true);
        TA_property3.setRows(5);
        TA_property3.setWrapStyleWord(true);
        jScrollPane12.setViewportView(TA_property3);

        jLabel61.setText("Transaction Amount");

        jLabel66.setText("Transaction Description ");

        dis_ref_tf.setEditable(false);
        dis_ref_tf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dis_ref_tfActionPerformed(evt);
            }
        });

        jLabel60.setText("Transaction Account");

        contact_tf.setEditable(false);
        contact_tf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contact_tfActionPerformed(evt);
            }
        });

        owner_paymnt.setSelected(true);
        owner_paymnt.setText("Owner Payment");
        owner_paymnt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                owner_paymntActionPerformed(evt);
            }
        });

        jLabel57.setText("Property ID");

        dis_doc_tf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dis_doc_tfActionPerformed(evt);
            }
        });

        jLabel65.setText("Reference");

        searchProperty.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        searchProperty.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchPropertyMouseClicked(evt);
            }
        });

        jLabel58.setText("Transaction Date");

        rec_pay_acc.setEditable(false);
        rec_pay_acc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rec_pay_accActionPerformed(evt);
            }
        });

        jLabel59.setText("Transaction Category");

        jLabel80.setText("Owner ID");

        searchOwner.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        searchOwner.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchOwnerMouseClicked(evt);
            }
        });

        jRadioButton29.setText("Receive/IN");
        jRadioButton29.setToolTipText("Debit");
        jRadioButton29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton29ActionPerformed(evt);
            }
        });

        property_tf.setEditable(false);
        property_tf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                property_tfActionPerformed(evt);
            }
        });

        jLabel64.setText("Doc/Voucher Type");

        jRadioButton30.setText("Pay/OUT");
        jRadioButton30.setToolTipText("Credit");
        jRadioButton30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton30ActionPerformed(evt);
            }
        });

        dis_TA.setColumns(20);
        dis_TA.setLineWrap(true);
        dis_TA.setRows(5);
        dis_TA.setText("\nlm\n\n\n");
        dis_TA.setWrapStyleWord(true);
        jScrollPane8.setViewportView(dis_TA);

        trn_amt_tf.setToolTipText("Enter Transaction Amount");
        trn_amt_tf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                trn_amt_tfActionPerformed(evt);
            }
        });

        trn_acc_tf.setEditable(false);
        trn_acc_tf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                trn_acc_tfActionPerformed(evt);
            }
        });

        jLabel62.setText("Receiving/Pay Account");

        jSeparator8.setOrientation(javax.swing.SwingConstants.VERTICAL);

        Load_owner_Trans.setText("Load Due Payments");
        Load_owner_Trans.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Load_owner_TransActionPerformed(evt);
            }
        });

        searchContra_acc1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        searchContra_acc1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchContra_acc1MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel65)
                    .addComponent(jLabel59, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel58, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel57)
                    .addComponent(jLabel56)
                    .addComponent(jLabel80))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(owner_paymnt))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dis_ref_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(contact_tf)
                                    .addComponent(property_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(searchProperty)
                                    .addComponent(searchBeneficiary, javax.swing.GroupLayout.Alignment.TRAILING))))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel_beneficiary, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(owner_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(searchOwner)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel_owner, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(dp3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32)
                        .addComponent(Load_owner_Trans)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator8, javax.swing.GroupLayout.PREFERRED_SIZE, 6, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel63, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel61, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel62)
                            .addComponent(jLabel60))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(trn_amt_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(rec_pay_acc, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(54, 54, 54)
                                        .addComponent(contra_label, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(dis_doc_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(dis_doc_type, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(17, 17, 17)
                                .addComponent(trn_acc_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(89, 89, 89)
                                        .addComponent(jRadioButton29)
                                        .addGap(18, 18, 18)
                                        .addComponent(jRadioButton30))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(searchContra_acc1)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(Trans_Acc_desc, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addComponent(jLabel66)
                    .addComponent(jLabel64))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel80)
                                    .addComponent(owner_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(searchOwner, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel_owner, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel56)
                                            .addComponent(contact_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(searchBeneficiary, javax.swing.GroupLayout.Alignment.TRAILING))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                                            .addComponent(searchProperty)
                                            .addComponent(property_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(2, 2, 2)
                                        .addComponent(jLabel_beneficiary, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(53, 53, 53)
                                .addComponent(jLabel57)))
                        .addGap(7, 7, 7)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Load_owner_Trans))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel65)
                            .addComponent(dis_ref_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dp3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel58))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel59)
                            .addComponent(owner_paymnt)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(trn_acc_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel60))
                                .addComponent(Trans_Acc_desc, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(searchContra_acc1))
                        .addGap(11, 11, 11)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(trn_amt_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel61)
                            .addComponent(jRadioButton29)
                            .addComponent(jRadioButton30))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel62)
                                .addComponent(rec_pay_acc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(contra_label, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel63)
                            .addComponent(dis_doc_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel64)
                            .addComponent(dis_doc_type, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel66)
                            .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jSeparator8, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout disbursements_panelLayout = new javax.swing.GroupLayout(disbursements_panel);
        disbursements_panel.setLayout(disbursements_panelLayout);
        disbursements_panelLayout.setHorizontalGroup(
            disbursements_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(disbursements_panelLayout.createSequentialGroup()
                .addGroup(disbursements_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator4, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(disbursements_panelLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(disbursements_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jSeparator6)
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jScrollPane9))
                        .addGap(25, 25, 25)))
                .addContainerGap())
        );
        disbursements_panelLayout.setVerticalGroup(
            disbursements_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(disbursements_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 11, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jSeparator6, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("    Disbursements    ", disbursements_panel);

        jToolBar1.setBackground(new java.awt.Color(255, 255, 255));
        jToolBar1.setRollover(true);

        new_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/new.PNG"))); // NOI18N
        new_btn.setToolTipText("Create New");
        new_btn.setFocusable(false);
        new_btn.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        new_btn.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        new_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                new_btnActionPerformed(evt);
            }
        });
        jToolBar1.add(new_btn);

        update_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Actions-document-save-all-icon2.png"))); // NOI18N
        update_btn.setToolTipText("Save");
        update_btn.setFocusable(false);
        update_btn.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        update_btn.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        update_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_btnActionPerformed(evt);
            }
        });
        jToolBar1.add(update_btn);

        clear_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/clear - Copy.png"))); // NOI18N
        clear_btn.setToolTipText("Clear");
        clear_btn.setFocusable(false);
        clear_btn.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        clear_btn.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jToolBar1.add(clear_btn);

        delete_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/delete02.png"))); // NOI18N
        delete_btn.setToolTipText("Delete");
        delete_btn.setFocusable(false);
        delete_btn.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        delete_btn.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        delete_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete_btnActionPerformed(evt);
            }
        });
        jToolBar1.add(delete_btn);

        export_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/excel_icon.jpg"))); // NOI18N
        export_btn.setToolTipText("Export  to Excel");
        export_btn.setFocusable(false);
        export_btn.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        export_btn.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jToolBar1.add(export_btn);

        refresh_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/refresh2 - Copy.png"))); // NOI18N
        refresh_btn.setToolTipText("Refresh");
        refresh_btn.setFocusable(false);
        refresh_btn.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        refresh_btn.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        refresh_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refresh_btnActionPerformed(evt);
            }
        });
        jToolBar1.add(refresh_btn);

        delete_me.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/refresh2 - Copy.png"))); // NOI18N
        delete_me.setToolTipText("Refresh");
        delete_me.setFocusable(false);
        delete_me.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        delete_me.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        delete_me.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete_meActionPerformed(evt);
            }
        });
        jToolBar1.add(delete_me);

        error_msg_lbl.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        error_msg_lbl.setForeground(new java.awt.Color(204, 0, 0));
        error_msg_lbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jToolBar1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(error_msg_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addComponent(jTabbedPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jToolBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(error_msg_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jRB_incomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRB_incomeActionPerformed
        // TODO add your handling code here:
        trans_cat();
    }//GEN-LAST:event_jRB_incomeActionPerformed

    private void jRB_expenseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRB_expenseActionPerformed
        // TODO add your handling code here:
        trans_cat();
    }//GEN-LAST:event_jRB_expenseActionPerformed

    private void jRB_officeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRB_officeActionPerformed
        // TODO add your handling code here:
        trans_cat();
    }//GEN-LAST:event_jRB_officeActionPerformed

    private void jRB_receive2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRB_receive2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRB_receive2ActionPerformed

    private void jRB_out2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRB_out2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRB_out2ActionPerformed

    private void contact_tfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contact_tfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_contact_tfActionPerformed

    private void property_tfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_property_tfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_property_tfActionPerformed

    private void trn_acc_tfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_trn_acc_tfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_trn_acc_tfActionPerformed

    private void trn_amt_tfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_trn_amt_tfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_trn_amt_tfActionPerformed

    private void jRadioButton29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton29ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton29ActionPerformed

    private void jRadioButton30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton30ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton30ActionPerformed

    private void rec_pay_accActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rec_pay_accActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rec_pay_accActionPerformed

    private void dis_doc_tfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dis_doc_tfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dis_doc_tfActionPerformed

    private void dis_ref_tfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dis_ref_tfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dis_ref_tfActionPerformed

    private void jRB_ownerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRB_ownerActionPerformed
        // TODO add your handling code here:
        trans_cat();
    }//GEN-LAST:event_jRB_ownerActionPerformed

    private void jRB_office2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRB_office2ActionPerformed
        // TODO add your handling code here:
        trns_type = "EOF";
    }//GEN-LAST:event_jRB_office2ActionPerformed

    private void recurrents_jtableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_recurrents_jtableMouseClicked
        // TODO add your handling code here:


    }//GEN-LAST:event_recurrents_jtableMouseClicked

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        // TODO add your handling code here:
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String DATE = sdf.format(date);

        datePicker.getJFormattedTextField().setText(DATE);
        datePicker2.getJFormattedTextField().setText(DATE);
        datePicker3.getJFormattedTextField().setText(DATE);
        datePicker4.getJFormattedTextField().setText(DATE);

        dateP1();
        dateP2();
        dateP3();
        dateP4();
        trans_cat();
        recv_pay();
        selected_transaction_type();
        DBConnection.update_table(sql_recurrents_jtable, recurrents_jtable);
        DBConnection.update_table(sql_receipts_table, receive_table);
        DBConnection.update_table(sql_payments_table, payments_table);
        //DBConnection.update_table(sql_disbursements_table, disbursements_table);

        DBConnection.populateCombo("select description from list_control where reference_code = 'DOCUMENT_TYPES' and sub_code = '###'", jCombo_document);
        DBConnection.populateCombo("select description from list_control where reference_code = 'DOCUMENT_TYPES' and sub_code = '###'", doc_type_combo);
        DBConnection.populateCombo("select description from list_control where reference_code = 'DOCUMENT_TYPES' and sub_code = '###'", jCombo_document2);
        DBConnection.populateCombo("select description from list_control where reference_code = 'REFERENCE_TYPES' and sub_code = '###'", jCombo_reference);
        DBConnection.populateCombo("select description from list_control where reference_code = 'REFERENCE_TYPES' and sub_code = '###'", reference_combo1);
        DBConnection.populateCombo("select description from list_control where reference_code = 'REFERENCE_TYPES' and sub_code = '###'", reference_combo);

        recurrents_jtable.setDefaultRenderer(Object.class, new TableCellRendererColor());

        DBConnection.table_filter_without_specify(recurrents_jtable, serch_tf4.getText());
        DBConnection.table_filter_without_specify(receive_table, serch_tf4.getText());
        DBConnection.table_filter_without_specify(payments_table, serch_tf4.getText());

    }//GEN-LAST:event_formWindowOpened

    private void new_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_new_btnActionPerformed
        // TODO add your handling code here:
        if (create_inc_exp_panel.isShowing()) {
            if (!(reference_tf.getText().equals("") && transaction_acc_tf.getText().equals("") && property_id_tf.getText().equals("") && transaction_amnt_tf.getText().equals(""))) {
                post_tranctn_btn.setEnabled(true);
                jCheckBox_approved.setSelected(false);
                add_recurrent();
                printReceipts();
                
            } else {
                JOptionPane.showMessageDialog(null, "<html><b><font color='red'>Error creating new!</font></b><br><br>check that <i>Contact ID,property ID,Transaction Account</i><br>and <i>Amount</i> fields are filled", "Adding Error(Transactions- MaliPlus)", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_new_btnActionPerformed

    private void update_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_btnActionPerformed
        // TODO add your handling code here:
        if (create_inc_exp_panel.isShowing()) {
            if (!contact_id_tf.getText().equals("") && !property_id_tf.getText().equals("") && !transaction_acc_tf.getText().equals("") && !pay_acc_tf.getText().equals("")) {

                update_recurrents();
                error_msg_lbl.setText("");

            } else {
                error_msg_lbl.setForeground(Color.red);
                error_msg_lbl.setText("Incomplete fields!");
            }
        }

        if (receipts_panel.isShowing()) {

            if (!contact_id_tf3.getText().equals("") && !prop_id_tf3.getText().equals("") && !trans_acc.getText().equals("") && !receiv_acc_tf.getText().equals("")) {

                if (!trans_amnt_tf.getText().equals("")) {

                    update_receipt();
                    error_msg_lbl.setText("");
                    jLabel24.setText("");
                } else {
                    jLabel24.setForeground(Color.red);
                    jLabel24.setText("Amount?");
                }

            } else {
                error_msg_lbl.setForeground(Color.red);
                error_msg_lbl.setText("Incomplete fields!");
            }
        }

        if (payments_panel.isShowing()) {

            if (!contact_id_tf2.getText().equals("") && !property_id_tf2.getText().equals("") && !transaction_acc_tf2.getText().equals("") && !pay_acc_tf2.getText().equals("")) {

                if (!transaction_amnt_tf2.getText().equals("")) {
                    update_payment();
                    error_msg_lbl.setText("");
                    jLabel24.setText("");

                } else {
                    jLabel25.setForeground(Color.red);
                    jLabel25.setText("Amount?");
                }
            } else {
                error_msg_lbl.setForeground(Color.red);
                error_msg_lbl.setText("Incomplete fields!");
            }
        }
    }//GEN-LAST:event_update_btnActionPerformed

    private void delete_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete_btnActionPerformed
        // TODO add your handling code here:
        if (create_inc_exp_panel.isShowing()) {

            delete_recurrent();

        }
        if (receipts_panel.isShowing()) {

            String delete_qry = "delete from ledger_transactions where reference_number='" + ref_tf.getText() + "'";

            try {
                conn = DBConnection.ConnectDB();
                pst = conn.prepareStatement(delete_qry);
                pst.execute();
                DBConnection.update_table(sql_receipts_table, receive_table);
                error_msg_lbl.setForeground(Color.blue);
                error_msg_lbl.setText("receipt removed");
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
        if (payments_panel.isShowing()) {

            String insert_qry = "delete from ledger_transactions where reference_number='" + reference_tf2.getText() + "'";

            try {
                conn = DBConnection.ConnectDB();
                pst = conn.prepareStatement(insert_qry);
                pst.execute();
                DBConnection.update_table(sql_payments_table, payments_table);
                error_msg_lbl.setForeground(Color.blue);
                error_msg_lbl.setText("payment removed");
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

    }//GEN-LAST:event_delete_btnActionPerformed

    private void post_tranctn_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_post_tranctn_btnActionPerformed
        // TODO add your handling code here:
        if (!(reference_tf.getText().equals("") && transaction_acc_tf.getText().equals("") && transaction_amnt_tf.getText().equals(""))) {
            int p = JOptionPane.showConfirmDialog(null, "Approve?", "Approve (inc./exp.)", JOptionPane.YES_NO_OPTION);
            if (p == 0) {
                String approved_qry = "update ledger_recurrents set approved = 'Y' where reference_number = '" + reference_tf.getText() + "'";
                try {
                    pst = conn.prepareStatement(approved_qry);
                    pst.execute();
                    DBConnection.update_table(sql_recurrents_jtable, recurrents_jtable);
                    DBConnection.update_table(sql_receipts_table, receive_table);
                    DBConnection.update_table(sql_payments_table, payments_table);
                    jCheckBox_approved.setSelected(true);
                    recurrents_jtable.setDefaultRenderer(Object.class, new TableCellRendererColor());
                    error_msg_lbl.setForeground(Color.blue);
                    if (jRB_income.isSelected()) {
                        error_msg_lbl.setText("Income Approved");
                    }
                    if (jRB_expense.isSelected()) {
                        error_msg_lbl.setText("Expense Approved");
                    }
                    post_tranctn_btn.setEnabled(false);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "<html><b><font color='red'>Error Approving new!</font></b><br><br>Click an entry in the entry table<br>to Approve", "Approving Error(Transactions- MaliPlus)", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_post_tranctn_btnActionPerformed

    private void jTabbedPane1PropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_jTabbedPane1PropertyChange
        // TODO add your handling code here:
    }//GEN-LAST:event_jTabbedPane1PropertyChange

    private void jCombo_documentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCombo_documentActionPerformed
        // TODO add your handling code here:
        jL_doc.setText(DBConnection.global_resultSet("select minor_code from list_control where description = '" + jCombo_document.getSelectedItem().toString() + "'"));
    }//GEN-LAST:event_jCombo_documentActionPerformed

    private void jLabel_transactionComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_jLabel_transactionComponentResized
        // TODO add your handling code here:
        String text = jLabel_transaction.getText();
        jTextArea_trans_desp.setText(text);
    }//GEN-LAST:event_jLabel_transactionComponentResized

    private void owner_paymntActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_owner_paymntActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_owner_paymntActionPerformed

    private void jRadioButton_otherActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton_otherActionPerformed
        // TODO add your handling code here:
        selected_transaction_type();
    }//GEN-LAST:event_jRadioButton_otherActionPerformed

    private void jRadioButton_leaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton_leaseActionPerformed
        // TODO add your handling code here:
        selected_transaction_type();
    }//GEN-LAST:event_jRadioButton_leaseActionPerformed

    private void jRadioButton_saleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton_saleActionPerformed
        // TODO add your handling code here:
        contact_id_tf.setText("");
        property_id_tf.setText("");
        reference_tf.setText("");
        transaction_amnt_tf.setText("");
        selected_transaction_type();
    }//GEN-LAST:event_jRadioButton_saleActionPerformed

    private void transaction_amnt_tfKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_transaction_amnt_tfKeyTyped
        // TODO add your handling code here:
        char keychar = evt.getKeyChar();
        if (!(Character.isDigit(keychar) || keychar == KeyEvent.VK_BACKSPACE || keychar == KeyEvent.VK_DELETE || keychar == KeyEvent.VK_DECIMAL)) {
            evt.consume();
        }
    }//GEN-LAST:event_transaction_amnt_tfKeyTyped

    private void jCombo_referenceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCombo_referenceActionPerformed
        // TODO add your handling code here:
        ref_dscrptn_lbl.setText(DBConnection.global_resultSet("select minor_code from list_control where description = '" + jCombo_reference.getSelectedItem() + "'"));
    }//GEN-LAST:event_jCombo_referenceActionPerformed

    private void jCheckBox_approvedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox_approvedActionPerformed
        // TODO add your handling code here:


    }//GEN-LAST:event_jCheckBox_approvedActionPerformed

    private void jRB_owner2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRB_owner2ActionPerformed
        // TODO add your handling code here:
        trns_type = "EOW";
    }//GEN-LAST:event_jRB_owner2ActionPerformed

    private void payments_tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_payments_tableMouseClicked
        // TODO add your handling code here:
        int click = evt.getClickCount();
        if (click == 1) {

            DefaultTableModel tmodel = (DefaultTableModel) payments_table.getModel();
            int row = payments_table.getSelectedRow();
            transaction_acc_tf2.setText(tmodel.getValueAt(payments_table.convertRowIndexToModel(row), 0).toString());
            contact_id_tf2.setText(tmodel.getValueAt(payments_table.convertRowIndexToModel(row), 1).toString());
            property_id_tf2.setText(tmodel.getValueAt(payments_table.convertRowIndexToModel(row), 13).toString());
            datePicker3.getJFormattedTextField().setText(tmodel.getValueAt(payments_table.convertRowIndexToModel(row), 2).toString());
            balance_lbl1.setText(tmodel.getValueAt(payments_table.convertRowIndexToModel(row), 14).toString());
            document_tf2.setText(tmodel.getValueAt(payments_table.convertRowIndexToModel(row), 3).toString());
            reference_tf2.setText(tmodel.getValueAt(payments_table.convertRowIndexToModel(row), 6).toString());
            pay_acc_tf2.setText(tmodel.getValueAt(payments_table.convertRowIndexToModel(row), 8).toString());
            jL_doc2.setText(tmodel.getValueAt(payments_table.convertRowIndexToModel(row), 4).toString());
            jTextArea_trans_desp2.setText(tmodel.getValueAt(payments_table.convertRowIndexToModel(row), 5).toString());
            ref_dscrptn_lbl2.setText(tmodel.getValueAt(payments_table.convertRowIndexToModel(row), 7).toString());
            jLabel_trans_type2.setText(tmodel.getValueAt(payments_table.convertRowIndexToModel(row), 9).toString());
            balance_lbl1.setText(tmodel.getValueAt(payments_table.convertRowIndexToModel(row), 14).toString());
            String payer = jLabel_trans_type2.getText();
            switch (payer) {
                case "EOF":
                    jRB_office2.setSelected(true);
                    break;
                case "EOW":
                    jRB_owner2.setSelected(true);
                    break;
            }

            TA_property2.setText(DBConnection.global_resultSet("select property_description from properties_table where property_id = '" + property_id_tf2.getText() + "'"));
            //trans_acc.setText(DBConnection.global_resultSet(""));
            //jLabel_transaction1.setText(DBConnection.global_resultSet(""));
            //jLabel_recv_pay1.setText(DBConnection.global_resultSet(""));
            reference_combo.setSelectedItem(DBConnection.global_resultSet("select description from list_control where reference_code = 'REFERENCE_TYPES' and minor_code = '" + ref_dscrptn_lbl2.getText() + "'"));
            jCombo_document2.setSelectedItem(DBConnection.global_resultSet("select description from list_control where reference_code = 'DOCUMENT_TYPES' and minor_code = '" + jL_doc2.getText() + "'"));
            jLabel_sno.setText(DBConnection.global_resultSet("select serial_number from ledger_recurrents where ledger_number = '" + contact_id_tf2.getText() + "' and reference_number = '" + reference_tf2.getText() + "' and account_number = '" + transaction_acc_tf2.getText() + "'"));
        }

    }//GEN-LAST:event_payments_tableMouseClicked

    private void jLabel_transaction3ComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_jLabel_transaction3ComponentResized
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel_transaction3ComponentResized

    private void refresh_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refresh_btnActionPerformed
        // TODO add your handling code here:
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String DATE = sdf.format(date);

        if (create_inc_exp_panel.isShowing()) {
            datePicker.getJFormattedTextField().setText(DATE);
            dateP1();
            trans_cat();
            DBConnection.update_table(sql_recurrents_jtable, recurrents_jtable);
            DBConnection.cleanCombo(jCombo_document);
            DBConnection.populateCombo("select minor_code from list_control where reference_code = 'DOCUMENT_TYPES' and sub_code = '###'", jCombo_document);
            DBConnection.cleanCombo(jCombo_reference);
            DBConnection.populateCombo("select minor_code from list_control where reference_code = 'REFERENCE_TYPES' and sub_code = '###'", jCombo_reference);
        }
        if (receipts_panel.isShowing()) {
            datePicker2.getJFormattedTextField().setText(DATE);
            dateP2();
            DBConnection.update_table(sql_receipts_table, receive_table);
            DBConnection.cleanCombo(doc_type_combo);
            DBConnection.populateCombo("select minor_code from list_control where reference_code = 'DOCUMENT_TYPES' and sub_code = '###'", doc_type_combo);
            DBConnection.cleanCombo(reference_combo1);
            DBConnection.populateCombo("select minor_code from list_control where reference_code = 'REFERENCE_TYPES' and sub_code = '###'", reference_combo1);
        }
        if (payments_panel.isShowing()) {
            datePicker3.getJFormattedTextField().setText(DATE);
            dateP3();
            DBConnection.update_table(sql_payments_table, payments_table);
            DBConnection.cleanCombo(jCombo_document2);
            DBConnection.populateCombo("select minor_code from list_control where reference_code = 'DOCUMENT_TYPES' and sub_code = '###'", jCombo_document2);
            DBConnection.cleanCombo(reference_combo);
            DBConnection.populateCombo("select minor_code from list_control where reference_code = 'REFERENCE_TYPES' and sub_code = '###'", reference_combo);

        }
        if (disbursements_panel.isShowing()) {
            datePicker4.getJFormattedTextField().setText(DATE);
            dateP4();
        }

        recv_pay();
        selected_transaction_type();


    }//GEN-LAST:event_refresh_btnActionPerformed

    private void reference_comboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reference_comboActionPerformed
        // TODO add your handling code here:
        ref_dscrptn_lbl2.setText(DBConnection.global_resultSet("select minor_code from list_control where description = '" + reference_combo.getSelectedItem() + "'"));
    }//GEN-LAST:event_reference_comboActionPerformed

    private void jCombo_document2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCombo_document2ActionPerformed
        // TODO add your handling code here:
        jL_doc2.setText(DBConnection.global_resultSet("select minor_code from list_control where description = '" + jCombo_document2.getSelectedItem().toString() + "'"));
    }//GEN-LAST:event_jCombo_document2ActionPerformed

    private void transaction_amnt_tf2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_transaction_amnt_tf2KeyTyped
        // TODO add your handling code here:
        char keychar = evt.getKeyChar();
        if (!(Character.isDigit(keychar) || keychar == KeyEvent.VK_BACKSPACE || keychar == KeyEvent.VK_DELETE || keychar == KeyEvent.VK_DECIMAL)) {
            evt.consume();
        }

        jLabel25.setText("");

    }//GEN-LAST:event_transaction_amnt_tf2KeyTyped

    private void reference_combo1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reference_combo1ActionPerformed
        // TODO add your handling code here:
        ref_dscrptn_lbl1.setText(DBConnection.global_resultSet("select minor_code from list_control where description = '" + reference_combo1.getSelectedItem() + "'"));
    }//GEN-LAST:event_reference_combo1ActionPerformed

    private void jLabel_transaction1ComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_jLabel_transaction1ComponentResized
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel_transaction1ComponentResized

    private void receive_tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_receive_tableMouseClicked
        // TODO add your handling code here:
        int click = evt.getClickCount();
        if (click == 1) {


            printReceipts();
            DBConnection.update_table(sql_receipts_table, receive_table);
        
        }
    }//GEN-LAST:event_receive_tableMouseClicked

    private void jRadioButton_off_accActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton_off_accActionPerformed
        // TODO add your handling code here:
        trns_type = "IOF";
    }//GEN-LAST:event_jRadioButton_off_accActionPerformed

    private void ref_tfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ref_tfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ref_tfActionPerformed

    private void doc_type_comboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_doc_type_comboActionPerformed
        // TODO add your handling code here:
        jL_doc1.setText(DBConnection.global_resultSet("select minor_code from list_control where description = '" + doc_type_combo.getSelectedItem().toString() + "'"));
    }//GEN-LAST:event_doc_type_comboActionPerformed

    private void doc_vouch_tfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_doc_vouch_tfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_doc_vouch_tfActionPerformed

    private void receiv_acc_tfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_receiv_acc_tfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_receiv_acc_tfActionPerformed

    private void jRadioButton35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton35ActionPerformed
        // TODO add your handling code here:
        recv_pay();
    }//GEN-LAST:event_jRadioButton35ActionPerformed

    private void jRadioButton34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton34ActionPerformed
        // TODO add your handling code here:
        recv_pay();
    }//GEN-LAST:event_jRadioButton34ActionPerformed

    private void trans_amnt_tfKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_trans_amnt_tfKeyTyped
        // TODO add your handling code here:
        char keychar = evt.getKeyChar();
        if (!(Character.isDigit(keychar) || keychar == KeyEvent.VK_BACKSPACE || keychar == KeyEvent.VK_DELETE || keychar == KeyEvent.VK_DECIMAL)) {
            evt.consume();
        }
        jLabel24.setText("");
    }//GEN-LAST:event_trans_amnt_tfKeyTyped

    private void trans_accActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_trans_accActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_trans_accActionPerformed

    private void jRadioButton_own_accActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton_own_accActionPerformed
        // TODO add your handling code here:
        trns_type = "IOW";
    }//GEN-LAST:event_jRadioButton_own_accActionPerformed

    private void prop_id_tf3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prop_id_tf3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_prop_id_tf3ActionPerformed

    private void contact_id_tf3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contact_id_tf3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_contact_id_tf3ActionPerformed

    private void serch_tf4KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_serch_tf4KeyReleased
        // TODO add your handling code here:
        switch (jComboBox3.getSelectedItem().toString()) {

            case "All":
                DBConnection.table_filter_without_specify(payments_table, serch_tf4.getText());
                break;
            case "Lease ID":
                DBConnection.table_filter_with_specify(payments_table, serch_tf4.getText(), 6);
                break;
            case "Contact ID":
                DBConnection.table_filter_with_specify(payments_table, serch_tf4.getText(), 1);
                break;
            case "Property ID":
                DBConnection.table_filter_with_specify(payments_table, serch_tf4.getText(), 13);
                break;
        }
    }//GEN-LAST:event_serch_tf4KeyReleased

    private void serch_tf3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_serch_tf3KeyReleased
        // TODO add your handling code here:
        switch (jComboBox2.getSelectedItem().toString()) {

            case "All":
                DBConnection.table_filter_without_specify(receive_table, serch_tf3.getText());
                break;
            case "Lease ID":
                DBConnection.table_filter_with_specify(receive_table, serch_tf3.getText(), 6);
                break;
            case "Contact ID":
                DBConnection.table_filter_with_specify(receive_table, serch_tf3.getText(), 1);
                break;
            case "Property ID":
                DBConnection.table_filter_with_specify(receive_table, serch_tf3.getText(), 13);
                break;
        }
    }//GEN-LAST:event_serch_tf3KeyReleased

    private void serch_tf2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_serch_tf2KeyReleased
        // TODO add your handling code here:
        switch (jComboBox1.getSelectedItem().toString()) {

            case "All":
                DBConnection.table_filter_without_specify(recurrents_jtable, serch_tf2.getText());
                break;
            case "Lease ID":
                DBConnection.table_filter_with_specify(recurrents_jtable, serch_tf2.getText(), 6);
                break;
            case "Contact ID":
                DBConnection.table_filter_with_specify(recurrents_jtable, serch_tf2.getText(), 1);
                break;
            case "Property ID":
                DBConnection.table_filter_with_specify(recurrents_jtable, serch_tf2.getText(), 16);
                break;
        }
    }//GEN-LAST:event_serch_tf2KeyReleased

    private void contact_id_tfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contact_id_tfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_contact_id_tfActionPerformed

    private void owner_tfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_owner_tfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_owner_tfActionPerformed

    private void disbursements_tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_disbursements_tableMouseClicked
        // TODO add your handling code here:

        try {
            DefaultTableModel tmodel = (DefaultTableModel) disbursements_table.getModel();
            int row = disbursements_table.convertRowIndexToModel(disbursements_table.getSelectedRow());

            owner_tf.setText(tmodel.getValueAt(row, 11).toString());
            contact_tf.setText(tmodel.getValueAt(row, 1).toString());
            property_tf.setText(tmodel.getValueAt(row, 12).toString());
            trn_acc_tf.setText(tmodel.getValueAt(row, 0).toString());
            trn_amt_tf.setText(tmodel.getValueAt(row, 13).toString());
            rec_pay_acc.setText(tmodel.getValueAt(row, 1).toString());
            dis_doc_tf.setText(tmodel.getValueAt(row, 4).toString());
            dis_ref_tf.setText(tmodel.getValueAt(row, 7).toString());
            dis_TA.setText(tmodel.getValueAt(row, 1).toString());
            dis_doc_type.setSelectedItem(tmodel.getValueAt(row, 5).toString());
        } catch (NullPointerException npe) {
        }
    }//GEN-LAST:event_disbursements_tableMouseClicked

    private void jTabbedPane1MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTabbedPane1MouseReleased
        // TODO add your handling code here:
        SingleSelectionModel tpmodel = jTabbedPane1.getModel();
        int stb = tpmodel.getSelectedIndex();
        DefaultTableModel tmodel = (DefaultTableModel) recurrents_jtable.getModel();

        switch (stb) {

            case 0:
                new_btn.setEnabled(true);

                try {
                    if (recurrents_jtable.convertRowIndexToModel(recurrents_jtable.getSelectedRow()) > -1) {
                        String apprv_status = tmodel.getValueAt(recurrents_jtable.convertRowIndexToModel(recurrents_jtable.getSelectedRow()), 15).toString();
                        if (apprv_status.equals("Y")) {
                            jCheckBox_approved.setSelected(true);
                            update_btn.setEnabled(false);
                            post_tranctn_btn.setEnabled(false);
                        } else {
                            jCheckBox_approved.setSelected(false);
                            update_btn.setEnabled(true);
                            post_tranctn_btn.setEnabled(true);
                        }
                    }
                } catch (Exception e) {
                }
                break;
            case 1:
                new_btn.setEnabled(false);
                update_btn.setEnabled(true);
                break;

            case 2:
                new_btn.setEnabled(false);
                update_btn.setEnabled(true);
                break;

            case 3:
                new_btn.setEnabled(false);
                update_btn.setEnabled(true);
                break;
        }
    }//GEN-LAST:event_jTabbedPane1MouseReleased

    private void jProgressBar1StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jProgressBar1StateChanged
        // TODO add your handling code here:

    }//GEN-LAST:event_jProgressBar1StateChanged

    private void recurrents_jtableMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_recurrents_jtableMouseReleased
        // TODO add your handling code here:

    }//GEN-LAST:event_recurrents_jtableMouseReleased

    private void recurrents_jtableMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_recurrents_jtableMousePressed
        // TODO add your handling code here:
        Thread X = new Thread(new jtable_action());
        System.out.println(X.getState());
        X.start();
    }//GEN-LAST:event_recurrents_jtableMousePressed

    private void searchBeneficiaryMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchBeneficiaryMouseClicked
        // TODO add your handling code here:
        DBConnection.dynamic_sql = "select contact_id,first_names||' '||last_name as Name from contacts";
        DBConnection.panel(new TableDetails_Panel2(), "Beneficiary (Disbursements)");
    }//GEN-LAST:event_searchBeneficiaryMouseClicked

    private void searchOwnerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchOwnerMouseClicked
        // TODO add your handling code here:
        // DBConnection.dynamic_sql = "select contacts.contact_id, contacts.first_names||' '||contacts.last_name as Name from contacts inner join properties_table on contacts.contact_id = properties_table.contact_id where contacts.is_landlord = 1";
        DBConnection.dynamic_sql = "select distinct contacts.contact_id, contacts.first_names as Name from contacts  where contacts.is_landlord = 1";
        DBConnection.panel(new TableDetails_Panel2(), "Owners (Disbursements)");
        contact_tf.setText(owner_tf.getText());
    }//GEN-LAST:event_searchOwnerMouseClicked

    private void searchPropertyMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchPropertyMouseClicked
        // TODO add your handling code here:
        if (!owner_tf.getText().equals("")) {
            DBConnection.dynamic_sql = "select property_id, property_description from properties_table where contact_id = '" + owner_tf.getText() + "'";
            DBConnection.panel(new TableDetails_Panel2(), "Properties (Disbursements)");
        } else {
            jLabel_owner.setText("Owner ID?");
            Toolkit.getDefaultToolkit().beep();
        }
    }//GEN-LAST:event_searchPropertyMouseClicked

    private void searchContactMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchContactMouseClicked
        // TODO add your handling code here:
        
        switch (selected_transaction_type()) {
            case "LEASE":
                //DBConnection.dynamic_sql = "select contact_idom contacts";
                DBConnection.dynamic_sql = " SELECT DISTINCT LEASE.CONTACT_ID, CONTACTS.FIRST_NAMES||' '||contacts.last_name as Name FROM LEASE INNER JOIN CONTACTS ON LEASE.CONTACT_ID = CONTACTS.CONTACT_ID";
                break;
            case "SALE":
                DBConnection.dynamic_sql = "SELECT DISTINCT LEASE.CONTACT_ID, CONTACTS.FIRST_NAMES||' '||contacts.last_name as Name FROM LEASE INNER JOIN CONTACTS ON LEASE.CONTACT_ID = CONTACTS.CONTACT_ID";

                break;
            case "OTHER":
                DBConnection.dynamic_sql = "SELECT CONTACT_ID, FIRST_NAMES||' '||last_name as NAME from contacts";
                break;
        }

        DBConnection.panel(new TableDetails_Panel2(), "Contact ID (Transactions)");
        property_id_tf.setText("");
        TA_property.setText("");
        reference_tf.setText("");
    }//GEN-LAST:event_searchContactMouseClicked

    private void searchProperty_inc_expMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchProperty_inc_expMouseClicked
        // TODO add your handling code here:
        if (!contact_id_tf.getText().isEmpty()) {
            // DBConnection.dynamic_sql = "select property_id, property_description from properties_table";
            DBConnection.dynamic_sql = "SELECT DISTINCT LEASE.PROPERTY_ID, PROPERTIES_TABLE.PROPERTY_DESCRIPTION FROM LEASE INNER JOIN PROPERTIES_TABLE ON LEASE.PROPERTY_ID = PROPERTIES_TABLE.PROPERTY_ID WHERE LEASE_STATUS = 'ACT' AND LEASE.CONTACT_ID = " + contact_id_tf.getText() + "";
            DBConnection.panel(new TableDetails_Panel2(), "Property ID");

            jCombo_reference.setSelectedItem(DBConnection.global_resultSet("select description from list_control where reference_code = 'REFERENCE_TYPES' and minor_code = 'LEA'"));
            ref_dscrptn_lbl.setText("LEA");
            reference_tf.setText(DBConnection.global_resultSet("select LEASE_ID from LEASE where PROPERTY_ID = '" + property_id_tf.getText() + "'"));

            //inbulit_functions("select property_id, property_description from properties_table", "Property ID", trans_cat_type);
        } else {
            jLabel_contact.setText("Contact ID?");
            Toolkit.getDefaultToolkit().beep();
        }
    }//GEN-LAST:event_searchProperty_inc_expMouseClicked

    private void search_trn_accMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_search_trn_accMouseClicked
        // TODO add your handling code here:
        DBConnection.dynamic_sql = "select  account_number,description from account_master where account_status = 'ACT' and inter_institution = 'Y'";

        DBConnection.panel(new TableDetails_Panel2(), "Transaction Account");
        // reference_tf.setText(ref_no());
        jTextArea_trans_desp.setText(jLabel_transaction.getText());
        // Transactions_Form.pay_acc_tf.setText(selected_code);
        pay_acc_tf.setText(DBConnection.global_resultSet("select contra_account from account_master where account_number = '" + transaction_acc_tf.getText() + "'"));
        jLabel_recv_pay.setText(DBConnection.global_resultSet("select description from account_master where contra_account = '" + pay_acc_tf.getText() + "'"));
    }//GEN-LAST:event_search_trn_accMouseClicked

    private void search_contra_accMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_search_contra_accMouseClicked
        // TODO add your handling code here:
        if (!transaction_amnt_tf.getText().isEmpty()) {
            DBConnection.dynamic_sql = "select contra_account, description from account_master where account_status = 'ACT'";

            DBConnection.panel(new TableDetails_Panel2(), "Receive/Pay Account (Inc./Exp.)");
        } else {
            jLabel22.setForeground(Color.red);
            jLabel22.setText("amount?");
        }
    }//GEN-LAST:event_search_contra_accMouseClicked

    private void search_contra_acc2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_search_contra_acc2MouseClicked
        // TODO add your handling code here:
        DBConnection.dynamic_sql = "select contra_account,DESCRIPTION from account_master where account_status = 'ACT'";

        DBConnection.panel(new TableDetails_Panel2(), "Receive/Pay Account (Receipts)");

    }//GEN-LAST:event_search_contra_acc2MouseClicked

    private void search_contra_acc3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_search_contra_acc3MouseClicked
        // TODO add your handling code here:
        DBConnection.dynamic_sql = "select contra_account, DESCRIPTION from account_master where account_status = 'ACT'";

        DBConnection.panel(new TableDetails_Panel2(), "Receive/Pay Account (Payments)");
    }//GEN-LAST:event_search_contra_acc3MouseClicked

    private void Load_owner_TransActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Load_owner_TransActionPerformed
        // TODO add your handling code here:
        String sql_disbursements_table = "SELECT account_number,ledger_number,ledger_type,transaction_date,document_number,document_type,description,reference_number,reference_type,transaction_type,transaction_status,owner_id,property_id,due_amount,due_date,collected_amount,collection_date,is_collected,collection_balance,post_flag1,post_flag2,post_flag3,post_flag4 from ledger_recurrents where is_collected ='N' AND owner_id = '" + owner_tf.getText() + "'";
        DBConnection.update_table(sql_disbursements_table, disbursements_table);
    }//GEN-LAST:event_Load_owner_TransActionPerformed

    private void jProgressBar1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jProgressBar1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jProgressBar1MouseClicked

    private void searchContra_acc1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchContra_acc1MouseClicked
        // TODO add your handling code here:
        DBConnection.dynamic_sql = "select  account_number,description from account_master where account_status = 'ACT' and inter_institution = 'Y'"
                + "";

        DBConnection.panel(new TableDetails_Panel2(), "Transaction Account (Disbursements)");
        // reference_tf.setText(ref_no());
        dis_TA.setText(Trans_Acc_desc.getText());
        // Transactions_Form.pay_acc_tf.setText(selected_code);
        rec_pay_acc.setText(DBConnection.global_resultSet("select contra_account from account_master where account_number = '" + trn_acc_tf.getText() + "'"));
        contra_label.setText(DBConnection.global_resultSet("select description from account_master where contra_account = '" + rec_pay_acc.getText() + "'"));

    }//GEN-LAST:event_searchContra_acc1MouseClicked

    private void delete_meActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete_meActionPerformed
        // TODO add your handling code here:
        printReceipts();
    }//GEN-LAST:event_delete_meActionPerformed

    private void jasperviewerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jasperviewerMouseClicked
        // TODO add your handling code here:\
      
           DefaultTableModel model = (DefaultTableModel) receive_table.getModel();
        String refcode = model.getValueAt(receive_table.getSelectedRow(),39).toString();
          try{
                conn = DBConnection.ConnectDB();
                JasperDesign jasperDesign= JRXmlLoader.load("receipts.jrxml");
                 String sql= "SELECT TRANSACTIONS_DETAIL.*, CONFIGURATIONS.FULL_NAME,CONFIGURATIONS.ADDRESS,CONFIGURATIONS.CITY,CONFIGURATIONS.EMAIL_ADDRESS,CONFIGURATIONS.TELEPHONES\n" +
                             "FROM TRANSACTIONS_DETAIL,  CONFIGURATIONS WHERE TRANSACTION_ID="+refcode+"";
                JRDesignQuery newQuery= new JRDesignQuery();
                newQuery.setText(sql);
                jasperDesign.setQuery(newQuery);
                JasperReport jasperReport= JasperCompileManager.compileReport(jasperDesign);
                JasperPrint jasperPrint= JasperFillManager.fillReport(jasperReport, null, conn);
                //JasperViewer.viewReport(jasperPrint,false);
                JasperViewer jv = new JasperViewer(jasperPrint, false);
                jv.setTitle("RECEIPTS");
                 ImageIcon icon = new ImageIcon("Mali_bg.png");
                 Image img = icon.getImage();
                jv.setIconImage(img);
                jv.setVisible(true);
            }
            catch(Exception e){
                JOptionPane.showMessageDialog(null, e);
            }  
        
               
        
         
    }//GEN-LAST:event_jasperviewerMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Transactions_Form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Transactions_Form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Transactions_Form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Transactions_Form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Transactions_Form().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup Beneficiary_buttonGroup;
    private javax.swing.ButtonGroup Beneficiary_buttonGroup2;
    private javax.swing.ButtonGroup Category_buttonGroup;
    private javax.swing.ButtonGroup Category_buttonGroup2;
    private javax.swing.JButton Load_owner_Trans;
    public static javax.swing.JTextArea TA_property;
    public static javax.swing.JTextArea TA_property1;
    public static javax.swing.JTextArea TA_property2;
    public static javax.swing.JTextArea TA_property3;
    public static javax.swing.JLabel Trans_Acc_desc;
    private javax.swing.JLabel balance_lbl;
    private javax.swing.JLabel balance_lbl1;
    private javax.swing.ButtonGroup buttonGroup_in_out;
    private javax.swing.ButtonGroup buttonGroup_in_out2;
    private javax.swing.ButtonGroup buttonGroup_in_out_rcpt;
    private javax.swing.ButtonGroup buttonGroup_payee;
    private javax.swing.ButtonGroup buttonGroup_srch_cat_pmnt;
    private javax.swing.ButtonGroup buttonGroup_srch_cat_rcpt;
    private javax.swing.JButton clear_btn;
    public static javax.swing.JTextField contact_id_tf;
    public static javax.swing.JTextField contact_id_tf2;
    public static javax.swing.JTextField contact_id_tf3;
    public static javax.swing.JTextField contact_tf;
    public static javax.swing.JLabel contra_label;
    public static javax.swing.JPanel create_inc_exp_panel;
    private javax.swing.JButton delete_btn;
    private javax.swing.JButton delete_me;
    private javax.swing.JTextArea dis_TA;
    private javax.swing.JTextField dis_doc_tf;
    private javax.swing.JComboBox<String> dis_doc_type;
    private javax.swing.JTextField dis_ref_tf;
    private javax.swing.JPanel disbursements_panel;
    public static javax.swing.JTable disbursements_table;
    private javax.swing.JComboBox<String> doc_type_combo;
    private javax.swing.JTextField doc_vouch_tf;
    private javax.swing.JTextField document_tf;
    private javax.swing.JTextField document_tf2;
    private javax.swing.JPanel dp;
    private javax.swing.JPanel dp1;
    private javax.swing.JPanel dp2;
    private javax.swing.JPanel dp3;
    private javax.swing.JLabel error_msg_lbl;
    private javax.swing.JButton export_btn;
    private javax.swing.JCheckBox jCheckBox_approved;
    private javax.swing.JCheckBox jCheckBox_creditor_pay;
    private javax.swing.JCheckBox jCheckBox_debtor;
    private javax.swing.JCheckBox jCheckBox_paid;
    private javax.swing.JCheckBox jCheckBox_recurring;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JComboBox jComboBox2;
    private javax.swing.JComboBox jComboBox3;
    private javax.swing.JComboBox<String> jCombo_document;
    private javax.swing.JComboBox<String> jCombo_document2;
    private javax.swing.JComboBox jCombo_reference;
    private javax.swing.JLabel jL_doc;
    private javax.swing.JLabel jL_doc1;
    private javax.swing.JLabel jL_doc2;
    private javax.swing.JLabel jL_ref;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel9;
    public static javax.swing.JLabel jLabel_beneficiary;
    public static javax.swing.JLabel jLabel_contact;
    public static javax.swing.JLabel jLabel_contact1;
    public static javax.swing.JLabel jLabel_contact2;
    public static javax.swing.JLabel jLabel_owner;
    public static javax.swing.JLabel jLabel_recv_pay;
    public static javax.swing.JLabel jLabel_recv_pay1;
    public static javax.swing.JLabel jLabel_recv_pay2;
    private javax.swing.JLabel jLabel_sno;
    private javax.swing.JLabel jLabel_sno1;
    private javax.swing.JLabel jLabel_sno2;
    private static javax.swing.JLabel jLabel_trans_type;
    private javax.swing.JLabel jLabel_trans_type1;
    private javax.swing.JLabel jLabel_trans_type2;
    public static javax.swing.JLabel jLabel_transaction;
    public static javax.swing.JLabel jLabel_transaction1;
    public static javax.swing.JLabel jLabel_transaction3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JProgressBar jProgressBar1;
    private static javax.swing.JRadioButton jRB_expense;
    private static javax.swing.JRadioButton jRB_income;
    private static javax.swing.JRadioButton jRB_office;
    private javax.swing.JRadioButton jRB_office2;
    private static javax.swing.JRadioButton jRB_out;
    private javax.swing.JRadioButton jRB_out2;
    private static javax.swing.JRadioButton jRB_owner;
    private javax.swing.JRadioButton jRB_owner2;
    private static javax.swing.JRadioButton jRB_receive;
    private javax.swing.JRadioButton jRB_receive2;
    private javax.swing.JRadioButton jRadioButton29;
    private javax.swing.JRadioButton jRadioButton30;
    private javax.swing.JRadioButton jRadioButton34;
    private javax.swing.JRadioButton jRadioButton35;
    private static javax.swing.JRadioButton jRadioButton_lease;
    private javax.swing.JRadioButton jRadioButton_off_acc;
    private static javax.swing.JRadioButton jRadioButton_other;
    private javax.swing.JRadioButton jRadioButton_own_acc;
    private static javax.swing.JRadioButton jRadioButton_sale;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JSeparator jSeparator9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextArea jTextArea_trans_desp;
    private javax.swing.JTextArea jTextArea_trans_desp2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JToolBar jToolBar5;
    private javax.swing.JToolBar jToolBar6;
    private javax.swing.JToolBar jToolBar7;
    private javax.swing.JPanel jasperviewer;
    private javax.swing.JButton new_btn;
    private javax.swing.JCheckBox owner_paymnt;
    public static javax.swing.JTextField owner_tf;
    public static javax.swing.JTextField pay_acc_tf;
    public static javax.swing.JTextField pay_acc_tf2;
    public static javax.swing.JPanel payments_panel;
    private static javax.swing.JTable payments_table;
    private javax.swing.JButton post_tranctn_btn;
    public static javax.swing.JTextField prop_id_tf3;
    public static javax.swing.JTextField property_id_tf;
    public static javax.swing.JTextField property_id_tf2;
    public static javax.swing.JTextField property_tf;
    public static javax.swing.JTextField rec_pay_acc;
    public static javax.swing.JPanel receipts_panel;
    public static javax.swing.JTextField receiv_acc_tf;
    private static javax.swing.JTable receive_table;
    private javax.swing.JTable recurrents_jtable;
    private javax.swing.JLabel ref_dscrptn_lbl;
    private javax.swing.JLabel ref_dscrptn_lbl1;
    private javax.swing.JLabel ref_dscrptn_lbl2;
    private javax.swing.JTextField ref_tf;
    private javax.swing.JComboBox<String> reference_combo;
    private javax.swing.JComboBox<String> reference_combo1;
    private javax.swing.JTextField reference_tf;
    public static javax.swing.JTextField reference_tf2;
    private javax.swing.JButton refresh_btn;
    private javax.swing.JLabel searchBeneficiary;
    private javax.swing.JLabel searchContact;
    private javax.swing.JLabel searchContra_acc1;
    private javax.swing.JLabel searchOwner;
    private javax.swing.JLabel searchProperty;
    private javax.swing.JLabel searchProperty_inc_exp;
    private javax.swing.JLabel search_contra_acc;
    private javax.swing.JLabel search_contra_acc2;
    private javax.swing.JLabel search_contra_acc3;
    private javax.swing.JLabel search_trn_acc;
    private javax.swing.JTextField serch_tf2;
    private javax.swing.JTextField serch_tf3;
    private javax.swing.JTextField serch_tf4;
    public static javax.swing.JTextField trans_acc;
    public static javax.swing.JTextField trans_amnt_tf;
    private javax.swing.JTextArea trans_descrip_TA;
    public static javax.swing.JTextField transaction_acc_tf;
    public static javax.swing.JTextField transaction_acc_tf2;
    private javax.swing.JTextField transaction_amnt_tf;
    private static javax.swing.JTextField transaction_amnt_tf2;
    private javax.swing.ButtonGroup transaction_categories;
    public static javax.swing.JTextField trn_acc_tf;
    private javax.swing.JTextField trn_amt_tf;
    private javax.swing.JButton update_btn;
    // End of variables declaration//GEN-END:variables

    public void add_recurrent() {

        String trns_dt = datePicker.getJFormattedTextField().getText();
        String amount = transaction_amnt_tf.getText();
        String LEDGER_TYPE = "ledger_type";
        switch(selected_transaction_type()){
            case "LEASE":
                LEDGER_TYPE = "LEA";
                break;
            case "SALE":
                LEDGER_TYPE = "SAL";
                break;
            case "OTHER":
                LEDGER_TYPE = "OTH";
                break;               
        }
        
        String insert_query = " insert into ledger_recurrents("
                + "ACCOUNT_NUMBER,"
                + "LEDGER_NUMBER,"
                + "LEDGER_TYPE,"
                + "TRANSACTION_DATE,"
                + "DOCUMENT_NUMBER,"
                + "DOCUMENT_TYPE,"
                + "DESCRIPTION,"
                + "REFERENCE_NUMBER,"
                + "REFERENCE_TYPE,"
                + "CONTRA_ACCOUNT,"
                + "TRANSACTION_TYPE,"
                + "TRANSACTION_STATUS,"
                + "AMOUNT,"
                + "RECEIVE_IN,"
                + "PAY_OUT,"
                + "IS_RECURRENT,"
                + "APPROVED,"
                + "property_id,"
                + "AMOUNT_VALUE"
                + ")"
                + "values("
                + "'" + transaction_acc_tf.getText() + "',"
                + "'" + contact_id_tf.getText() + "',"
                + "'" + LEDGER_TYPE + "',"
                + "'" + trns_dt + "',"
                + "'" + document_tf.getText() + "',"
                + "'" + jL_doc.getText() + "',"
                + "'" + jTextArea_trans_desp.getText() + "',"
                + "'" + reference_tf.getText() + "',"
                + "'" + ref_dscrptn_lbl.getText() + "',"
                + "'" + pay_acc_tf.getText() + "',"
                + "'" + jLabel_trans_type.getText() + "',"
                + "'" + checked_status(jCheckBox_paid) + "',"
                + "'" + amount + "',"
                // + "'" + amount + "'"
                + "'" + selected_status(jRB_receive) + "',"
                + "'" + selected_status(jRB_out) + "',"
                + "'" + checked_status(jCheckBox_recurring) + "',"
                + "'" + checked_status(jCheckBox_approved) + "',"
                + "'" + property_id_tf.getText() + "',"
                + "'" + amount + "'"
                + ")";

        String check_sql = "select * from ledger_recurrents where REFERENCE_NUMBER =?";
        DBConnection.check_if_exist(check_sql, reference_tf, insert_query, error_msg_lbl);

        DBConnection.update_table(sql_recurrents_jtable, recurrents_jtable);
    }

    public void update_recurrents() {
        String apprvd = DBConnection.global_resultSet("select approved from ledger_recurrents where reference_number = '" + reference_tf.getText() + "' and ledger_number = '" + contact_id_tf.getText() + "' and account_number = '" + transaction_acc_tf.getText() + "'");

        String trns_dt = datePicker.getJFormattedTextField().getText();

        String update_query = "update ledger_recurrents set "
                + "ledger_number = '" + contact_id_tf.getText() + "',"
                + "ledger_type = '" + selected_transaction_type() + "',"
                + "transaction_date = '" + trns_dt + "',"
                + "document_number = '" + document_tf.getText() + "',"
                + "document_type = '" + jL_doc.getText() + "',"
                + "description = '" + jTextArea_trans_desp.getText() + "',"
                + "reference_number = '" + reference_tf.getText() + "',"
                + "reference_type = '" + ref_dscrptn_lbl.getText() + "',"
                + "contra_account = '" + pay_acc_tf.getText() + "',"
                + "transaction_type = '" + jLabel_trans_type.getText() + "',"
                + "transaction_status = '" + checked_status(jCheckBox_paid) + "',"
                + "amount = " + transaction_amnt_tf.getText() + ","
                + "AMOUNT_VALUE = '" + transaction_amnt_tf.getText() + "',"
                + "receive_in = '" + selected_status(jRB_receive) + "',"
                + "pay_out = '" + selected_status(jRB_out) + "',"
                + "is_recurrent = '" + checked_status(jCheckBox_recurring) + "',"
                + "approved = '" + checked_status(jCheckBox_approved) + "',"
                + "property_id = '" + property_id_tf.getText() + "' where reference_number ='" + reference_tf.getText() + "'and ledger_number = '" + contact_id_tf.getText() + "' and account_number = '" + transaction_acc_tf.getText() + "'";

        if (apprvd.equals("N")) {
            try {
                pst = conn.prepareStatement(update_query);
                pst.execute();
                DBConnection.update_table(sql_recurrents_jtable, recurrents_jtable);
                error_msg_lbl.setForeground(Color.blue);

                if (jRB_income.isSelected()) {
                    error_msg_lbl.setText("Income updated");
                }
                if (jRB_expense.isSelected()) {
                    error_msg_lbl.setText("Expense updated");
                }

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e);

            }
        }

    }

    public void delete_recurrent() {

        String delete_query = " delete from ledger_recurrents where reference_number ='" + reference_tf.getText() + "' ";
        try {
            //JOptionPane.showMessageDialog(null,insert_query);
            pst = conn.prepareStatement(delete_query);
            pst.execute();
            DBConnection.update_table(sql_recurrents_jtable, recurrents_jtable);
            error_msg_lbl.setForeground(Color.blue);
            error_msg_lbl.setText("Income/Expense removed");

        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }

    }

    public void update_receipt() {

        String trns_dt = datePicker2.getJFormattedTextField().getText();

        if (jRadioButton_off_acc.isSelected()) {
            trans_type = "IOF";
        } else if (jRadioButton_own_acc.isSelected()) {
            trans_type = "IOW";
        }

        String balance = balance_checker(trans_amnt_tf, balance_lbl);

        double bal = Double.parseDouble(balance);

        try {
            Connection con = DBConnection.ConnectDB();
            try (Statement st = con.createStatement()) {

                if (bal == 0) {
                    st.addBatch("update ledger_recurrents set amount_value = '" + balance + "',due_amount = amount, is_paid = 'Y',COLLECTION_BALANCE = '" + balance + "', collected_amount = collected_amount + '" + trans_amnt_tf.getText() + "',collection_date = current_timestamp where serial_number = '"+jLabel_sno1.getText()+"'");

                } else {
                    st.addBatch("update ledger_recurrents set amount_value = '" + balance + "', due_amount = amount, COLLECTION_BALANCE = '" + balance + "', collected_amount = collected_amount + '" + trans_amnt_tf.getText() + "',collection_date = current_timestamp where serial_number = '"+jLabel_sno1.getText()+"'");
                }

                /**
                 * "SELECT
                 * account_number,ledger_number,ledger_type,transaction_date,document_number,document_type,description,reference_number,reference_type,transaction_type,transaction_status,owner_id,property_id,due_amount,due_date,collected_amount,collection_date,is_collected,collection_balance,post_flag1,post_flag2,post_flag3,post_flag4
                 * from ledger_recurrents"*
                 */
                st.addBatch("update ledger_recurrents set owner_id = (select properties_table.contact_id from PROPERTIES_TABLE inner join contacts on properties_table.contact_id = contacts.CONTACT_ID where contacts.is_landlord = '1' and properties_table.property_id = '" + prop_id_tf3.getText() + "') where ledger_number = '" + contact_id_tf3.getText() + "'");

                st.addBatch("insert into ledger_transactions ("
                        + "account_number,"
                        + "ledger_number,"
                        + "ledger_type,"
                        + "transaction_date,"
                        + "document_number,"
                        + "document_type,"
                        + "description,"
                        + "reference_number,"
                        + "reference_type,"
                        + "contra_account,"
                        + "transaction_type,"
                        + "transaction_status,"
                        + "amount,"
                        + "amount_value,"
                        + "journal_number,"
                        + "journal_type,"
                        + "approved,"
                        + "PROPERTY_ID"
                        + ") "
                        + "values("
                        + "'" + trans_acc.getText() + "',"
                        + "'" + contact_id_tf3.getText() + "',"
                        + "'LEA',"
                        + "current_timestamp,"
                        + "'" + doc_vouch_tf.getText() + "',"
                        + "'" + jL_doc1.getText() + "',"
                        + "'" + trans_descrip_TA.getText() + "',"
                        + "'" + ref_tf.getText() + "',"
                        + "'" + ref_dscrptn_lbl1.getText() + "',"
                        + "'" + receiv_acc_tf.getText() + "',"
                        + "'" + jLabel_trans_type.getText() + "',"
                        + "'" + checked_status(jCheckBox_paid) + "',"
                        + "'" + trans_amnt_tf.getText() + "',"
                        + "'" + balance_lbl.getText() + "',"
                        + "'" + jLabel_sno1.getText() + "',"
                        + "'REC',"
                        + "'Y',"
                        + "'" + prop_id_tf3.getText() + "')");

                st.executeBatch();
                con.commit();
                st.close();
                DBConnection.update_table(sql_receipts_table, receive_table);
                error_msg_lbl.setForeground(Color.blue);
                error_msg_lbl.setText("Receipt updated");
                JOptionPane.showMessageDialog(null, "Added to Transactions");
                
            }
        } catch (SQLException e) {
            e.getNextException().printStackTrace();
        }
    }

    public void update_payment() {
        String trns_dt = datePicker2.getJFormattedTextField().getText();
        if (jRadioButton_off_acc.isSelected()) {
            trans_type = "EOF";
        } else if (jRadioButton_own_acc.isSelected()) {
            trans_type = "EOW";
        }
        String balance = balance_checker(transaction_amnt_tf2, balance_lbl1);

        double bal = Double.parseDouble(balance);

        Connection con = DBConnection.ConnectDB();
        try {
            con.setAutoCommit(false);
            try (Statement st = con.createStatement()) {
                if (bal == 0) {

                    st.addBatch("update ledger_recurrents set amount_value = '" + balance + "', is_paid = 'Y',COLLECTION_BALANCE = '" + balance + "', collected_amount = collected_amount + '" + transaction_amnt_tf2.getText() + "',collection_date = current_timestamp where serial_number = '"+jLabel_sno.getText()+"'");
                } else {
                    st.addBatch("update ledger_recurrents set amount_value = '" + balance + "',COLLECTION_BALANCE = '" + balance + "', collected_amount = collected_amount + '" + transaction_amnt_tf2.getText() + "',collection_date = current_timestamp where serial_number = '"+jLabel_sno.getText()+"'");
                }

                st.addBatch("update ledger_recurrents set owner_id = (select properties_table.contact_id from PROPERTIES_TABLE inner join contacts on properties_table.contact_id = contacts.CONTACT_ID where contacts.is_landlord = '1' and properties_table.property_id = '" + property_id_tf2.getText() + "') where ledger_number = '" + contact_id_tf2.getText() + "'");

                st.addBatch("insert into ledger_transactions ("
                        + "account_number,"
                        + "ledger_number,"
                        + "ledger_type,"
                        + "transaction_date,"
                        + "document_number,"
                        + "document_type,"
                        + "description,"
                        + "reference_number,"
                        + "reference_type,"
                        + "contra_account,"
                        + "transaction_type,"
                        + "transaction_status,"
                        + "amount,"
                        + "amount_value,"
                        + "journal_number,"
                        + "journal_type,"
                        + "approved,"
                        + "PROPERTY_ID"
                        + ") "
                        + "values('" + transaction_acc_tf2.getText() + "',"
                        + "'" + contact_id_tf2.getText() + "',"
                        + "'LEA',"
                        + "'" + trns_dt + "',"
                        + "'" + document_tf2.getText() + "',"
                        + "'" + jL_doc2.getText() + "',"
                        + "'" + jTextArea_trans_desp2.getText() + "',"
                        + "'" + reference_tf2.getText() + "',"
                        + "'" + ref_dscrptn_lbl2.getText() + "',"
                        + "'" + pay_acc_tf2.getText() + "',"
                        + "'" + jLabel_trans_type2.getText() + "',"
                        + "'" + checked_status(jCheckBox_paid) + "',"
                        + "'" + transaction_amnt_tf2.getText() + "',"
                        + "'" + balance_lbl1.getText() + "',"
                        + "'" + jLabel_sno.getText() + "',"
                        + "'PAY',"
                        + "'Y',"
                        + "'" + property_id_tf2.getText() + "')");

                st.executeBatch();
                con.commit();
                st.close();

                DBConnection.update_table(sql_payments_table, payments_table);
                error_msg_lbl.setForeground(Color.blue);
                error_msg_lbl.setText("Payment updated");
                JOptionPane.showMessageDialog(null, "Added to Transactions");
            }
        } catch (SQLException e) {
            e.getNextException().printStackTrace();
        }

    }

    public void generate_ref_no() {
        SimpleDateFormat sdf = new SimpleDateFormat("YYMMddhhmmss");
        Date dt = new Date();
        String s_date = sdf.format(dt);
        String cont_id = contact_id_tf3.getText();
        String ref_id = s_date + cont_id;
        // serials_no.setText(ref_id);

    }

    public static void trans_cat() {
        if (jRB_income.isSelected() && jRB_office.isSelected()) {
            cat_status = "IOF";
            jRB_receive.setSelected(true);
        }
        if (jRB_expense.isSelected() && jRB_office.isSelected()) {
            cat_status = "EOF";
            jRB_out.setSelected(true);
        }
        if (jRB_income.isSelected() && jRB_owner.isSelected()) {
            cat_status = "IOW";
            jRB_receive.setSelected(true);
        }
        if (jRB_expense.isSelected() && jRB_owner.isSelected()) {
            cat_status = "EOW";
            jRB_out.setSelected(true);
        }
        jLabel_trans_type.setText(cat_status);
    }

    public static String selected_transaction_type() {

        if (jRadioButton_lease.isSelected()) {
            trans_cat_type = "LEA";

        } else if (jRadioButton_sale.isSelected()) {
            trans_cat_type = "SAL";
        } else if (jRadioButton_other.isSelected()) {
            trans_cat_type = "OTH";

        }

        return trans_cat_type;
    }

    public Character recv_pay() {
        if (jRB_receive.isSelected()) {
            IN_OUT = 'R';
        } else if (jRB_out.isSelected()) {
            IN_OUT = 'P';
        }
        return IN_OUT;
    }

    public void Check_recur_status(JCheckBox jcb, String sql) {
        recur_status = DBConnection.global_resultSet(sql);
        switch (recur_status) {

            case "Y":
                jcb.setSelected(true);
                break;
            case "N":
                jcb.setSelected(false);
                break;
        }
    }

    public static String ref_no() {
        String reslt = "non";
        if (!contact_id_tf.getText().isEmpty() && !property_id_tf.getText().isEmpty()) {
            switch (selected_transaction_type()) {
                case "lease":
                    reslt = DBConnection.global_resultSet("select lease_id from lease where contact_id = '" + contact_id_tf.getText() + "' and property_id = '" + property_id_tf.getText() + "'");
                    System.out.println(reslt);
                    break;
                case "sale":
                    break;
                case "others":
                    break;
            }
        }
        return reslt;
    }

    public static void account_category() {

        String acc_cat = DBConnection.global_resultSet("select account_group from account_master where account_number = '" + transaction_acc_tf.getText() + "' ");

        switch (acc_cat) {

            case "400":
                jRB_income.setSelected(true);
                break;
            case "500":
                jRB_expense.setSelected(true);
                break;
        }

    }

    public String balance_checker(JTextField tf, JLabel lbl) {

        double initial_amount = Double.parseDouble(lbl.getText());
        //"select amount from leder_reccurents where reference_number = '"+tf.getText()+"'"
        double payed_amount = Double.parseDouble(tf.getText());
        //"select amount from leder_reccurents where reference_number = '"+tf2.getText()+"'"
        double bal = initial_amount - payed_amount;

        cash = Double.toString(bal);

        return cash;
    }

    public static void filter_table_details() {

        if (payments_panel.isShowing()) {
            String payments_table_sql = "SELECT account_number,ledger_number,transaction_date,document_number,document_type,description,reference_number,reference_type,contra_account,transaction_type,transaction_status,amount,APPROVED,property_id,amount_value as Balance from ledger_recurrents where transaction_type = 'EOF' or transaction_type = 'EOW' and approved = 'Y' and is_paid = 'N' and ledger_number = '" + contact_id_tf2.getText() + "' ";
            DBConnection.update_table(payments_table_sql, payments_table);
        }
        if (receipts_panel.isShowing()) {
            String receipts_table_sql = "SELECT account_number,ledger_number,transaction_date,document_number,document_type,description,reference_number,reference_type,contra_account,transaction_type,transaction_status,amount,APPROVED,property_id,amount_value as Balance from ledger_recurrents where transaction_type = 'IOF' or transaction_type = 'IOW' and approved = 'Y' and is_paid = 'N' and ledger_number = '" + contact_id_tf3.getText() + "' ";
            DBConnection.update_table(receipts_table_sql, receive_table);
        }

    }

    public String value_at(JTable table, int selected_row) {

        return flag;
    }

    //SELECT LEASE.CONTACT_ID, FIRST_NAMES FROM LEASE INNER JOIN CONTACTS ON LEASE.CONTACT_ID = CONTACTS.CONTACT_ID;
    //SELECT PROPERTI_ID, DESCRIPTION FROM LEASE WHERE CONTACT_ID = 'contacts_textfield.getText()';{with cintact not empty condition}
    //SELECT LEASE_ID FROM LEASE WHERE PROPERTY_ID = 'properties_textfield().getText()';{with lease not empty condition}
    //RECUR_STATUS = SELECT RECURRENT_STATUS FROM LEDGER_RECURRENTS WHERE REFERENCE_NUMBER = 'refno.getText()'
    public class TableCellRendererColor extends DefaultTableCellRenderer {

        private Component components;

        TableColumnModel cmodel = recurrents_jtable.getColumnModel();

        @Override

        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            components = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column); //To change body of generated methods, choose Tools | Templates.
            components.setForeground(Color.black);
            String valueS = (String) recurrents_jtable.getValueAt(row, 15);

            if (valueS.equals("Y")) {

                components.setBackground(Color.green);

            }
            if (valueS.equals("N")) {
                components.setBackground(Color.white);
            }
            if (isSelected) {
                components.setBackground(new Color(75, 110, 175));
                components.setForeground(new Color(187, 187, 187));
            }

            return components;
        }
    }

    public class CustomTableModel extends DefaultTableModel {

        @Override
        public int getRowCount() {
            return recurrents_jtable.getRowCount();
        }

        @Override
        public int getColumnCount() {
            return recurrents_jtable.getColumnCount();
        }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
            return recurrents_jtable.getValueAt(rowIndex, columnIndex);
        }

        @Override
        public String getColumnName(int columnIndex) {
            return recurrents_jtable.getColumnName(columnIndex);
        }

        @Override
        public Class getColumnClass(int columnIndex) {
            if (columnIndex == 3) {
                return Boolean.class;
            } else {
                return Object.class;
            }
        }
    }

    public class jtable_action implements Runnable {

        @Override
        public void run() {
            recurrents_jtable.setEnabled(false);
            DefaultTableModel tmodel = (DefaultTableModel) recurrents_jtable.getModel();
            int row = recurrents_jtable.getSelectedRow();
            transaction_acc_tf.setText(tmodel.getValueAt(recurrents_jtable.convertRowIndexToModel(row), 0).toString());
            contact_id_tf.setText(tmodel.getValueAt(recurrents_jtable.convertRowIndexToModel(row), 1).toString());
            property_id_tf.setText(tmodel.getValueAt(recurrents_jtable.convertRowIndexToModel(row), 16).toString());
            datePicker.getJFormattedTextField().setText(tmodel.getValueAt(recurrents_jtable.convertRowIndexToModel(row), 2).toString());
            transaction_amnt_tf.setText(tmodel.getValueAt(recurrents_jtable.convertRowIndexToModel(row), 11).toString());
            pay_acc_tf.setText(tmodel.getValueAt(recurrents_jtable.convertRowIndexToModel(row), 8).toString());
            document_tf.setText(tmodel.getValueAt(recurrents_jtable.convertRowIndexToModel(row), 3).toString());
            reference_tf.setText(tmodel.getValueAt(recurrents_jtable.convertRowIndexToModel(row), 6).toString());
            jTextArea_trans_desp.setText(tmodel.getValueAt(recurrents_jtable.convertRowIndexToModel(row), 5).toString());
            ref_dscrptn_lbl.setText(tmodel.getValueAt(recurrents_jtable.convertRowIndexToModel(row), 7).toString());
            jL_doc.setText(tmodel.getValueAt(recurrents_jtable.convertRowIndexToModel(row), 4).toString());
            jLabel_contact.setText(DBConnection.global_resultSet("select first_names||' '||last_name from contacts where contact_id = '" + contact_id_tf.getText() + "'"));
            jLabel_trans_type.setText(tmodel.getValueAt(recurrents_jtable.convertRowIndexToModel(row), 9).toString());
            TA_property.setText(DBConnection.global_resultSet("select property_description from properties_table where property_id = '" + property_id_tf.getText() + "'"));
            //check on property id and desicription
            String trn_category = jLabel_trans_type.getText();
            switch (trn_category) {
                case "IOF":
                    jRB_income.setSelected(true);
                    jRB_office.setSelected(true);
                    break;
                case "IOW":
                    jRB_income.setSelected(true);
                    jRB_owner.setSelected(true);
                    break;
                case "EOW":
                    jRB_expense.setSelected(true);
                    jRB_owner.setSelected(true);
                    break;
                case "EOF":
                    jRB_expense.setSelected(true);
                    jRB_office.setSelected(true);
                    break;
            }
            String t_in_out = tmodel.getValueAt(recurrents_jtable.convertRowIndexToModel(row), 12).toString();
            if (t_in_out.equals("Y")) {
                jRB_receive.setSelected(true);
            } else {
                jRB_out.setSelected(true);
            }

            String paid_status = tmodel.getValueAt(recurrents_jtable.convertRowIndexToModel(row), 10).toString();
            if (paid_status.equals("Y")) {
                jCheckBox_paid.setSelected(true);
            } else {
                jCheckBox_paid.setSelected(false);
            }

            String apprv_status = tmodel.getValueAt(recurrents_jtable.convertRowIndexToModel(row), 15).toString();
            if (apprv_status.equals("Y")) {
                jCheckBox_approved.setSelected(true);
                update_btn.setEnabled(false);
                post_tranctn_btn.setEnabled(false);
            } else {
                jCheckBox_approved.setSelected(false);
                update_btn.setEnabled(true);
                post_tranctn_btn.setEnabled(true);
            }

            String recur_status = tmodel.getValueAt(recurrents_jtable.convertRowIndexToModel(row), 14).toString();
            if (recur_status.equals("Y")) {
                jCheckBox_recurring.setSelected(true);
            } else {
                jCheckBox_recurring.setSelected(false);
            }
            jCombo_reference.setSelectedItem(DBConnection.global_resultSet("select description from list_control where reference_code = 'REFERENCE_TYPES' and minor_code = '" + ref_dscrptn_lbl.getText() + "'"));
            jCombo_document.setSelectedItem(DBConnection.global_resultSet("select description from list_control where reference_code = 'DOCUMENT_TYPES' and minor_code = '" + jL_doc.getText() + "'"));
            jLabel_transaction.setText(DBConnection.global_resultSet("select description from account_master where account_number = '" + transaction_acc_tf.getText() + "'"));
            jLabel_recv_pay.setText(DBConnection.global_resultSet("select description from account_master where account_number = '" + pay_acc_tf.getText() + "'"));
            jTextArea_trans_desp.setText(jLabel_transaction.getText());
            error_msg_lbl.setText("");
            jLabel_sno2.setText(DBConnection.global_resultSet("select serial_number from ledger_recurrents where ledger_number = '" + contact_id_tf.getText() + "' and reference_number = '" + reference_tf.getText() + "' and account_number = '" + transaction_acc_tf.getText() + "'"));
            recurrents_jtable.setEnabled(true);
        }
    }

}
