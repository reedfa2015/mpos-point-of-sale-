/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus;

import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javax.swing.JFrame;
import javafx.scene.Parent;
import java.awt.Toolkit;

import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import com.jfoenix.controls.JFXButton;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javax.swing.SwingUtilities;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.util.Duration;
import org.controlsfx.control.Notifications;

public class loadReports implements Initializable {
 private static loadReports lr = null;  
static Parent  root5;
JFrame frame;

 public static loadReports getobj(){
    
        if(lr == null){
        
            lr = new loadReports();
        }
        return lr;
    }

    @FXML
    private AnchorPane report_pane;
    
       @FXML
    private JFXCheckBox first_names;

    @FXML
    private JFXCheckBox surname;

    @FXML
    private JFXCheckBox contact_id;

    @FXML
    private JFXCheckBox id_no;

    @FXML
    private JFXCheckBox country;

    @FXML
    private JFXCheckBox pin;

    @FXML
    private JFXTextField first_names2;

    @FXML
    private JFXTextField surname2;

    @FXML
    private JFXTextField contact_id2;

    @FXML
    private JFXTextField id_no2;

    @FXML
    private JFXTextField country2;

    @FXML
    private JFXTextField pin2;

    @FXML
    private JFXCheckBox contact_type;

    @FXML
    private JFXCheckBox status;

    @FXML
    private JFXCheckBox gender;

    @FXML
    private JFXCheckBox occupation;

    @FXML
    private JFXCheckBox source_of_income;

    @FXML
    private JFXTextField source_of_income2;

        @FXML
    private JFXTextField business_name2;

    @FXML
    private JFXTextField business_branch2;

    @FXML
    private JFXTextField location2;

    @FXML
    private JFXTextField current_city2;

    @FXML
    private JFXTextField website2;

    @FXML
    private JFXTextField county2;
    
        @FXML
    private JFXCheckBox business_name;

    @FXML
    private JFXCheckBox business_branch;

    @FXML
    private JFXCheckBox location;

    @FXML
    private JFXCheckBox current_city;

    @FXML
    private JFXCheckBox website;

    @FXML
    private JFXCheckBox county;
    @FXML
    private JFXComboBox<String> contact_type2;
    ObservableList<String> contact_type22 = 
    FXCollections.observableArrayList(
        "Individual",
        "Company",
        "Association"
        
    );

    @FXML
    private JFXComboBox<String> status2;
    ObservableList<String> status22 = 
    FXCollections.observableArrayList(
        "Active",
        "Inactive"
        
    );

    @FXML
    private JFXComboBox<String> gender2;
    ObservableList<String> gender22 = 
    FXCollections.observableArrayList(
        "F",
        "M"
        
    );

    @FXML
    private  JFXComboBox<String> occupation2;
    ObservableList<String> occupation22 = 
    FXCollections.observableArrayList(
        "SOFTWARE DEVELOPER",
        "SOLDIER"
        
    );

    @FXML
    private JFXCheckBox bank_name;

    @FXML
    private JFXCheckBox bank_acc_no;

    @FXML
    private JFXCheckBox bank_branch;

    @FXML
    private JFXTextField bank_name2;

    @FXML
    private JFXTextField bank_acc_no2;

    @FXML
    private JFXTextField bank_branch2; 
 
    
   @FXML
    private JFXButton ok;

    @FXML
    private Button clear_fields;

      @FXML
    private AnchorPane report_viewer_pane;

    @FXML
    private JFXButton back;

    @FXML
    private Pane Report_Viewer;

        @FXML
    private Pane container;

    @FXML
    private Label display;
    
    @FXML
    private JFXComboBox<String> window;
     ObservableList<String> window22 = 
    FXCollections.observableArrayList(
        "Contact Details",
        "Properties",
        "Chart of Accounts",
        "Leasing"
        
    );
     
      private void loadComboBoxes(){
       
         contact_type2.setItems(contact_type22);
          status2.setItems(status22);
           occupation2.setItems(occupation22);
            gender2.setItems(gender22);
            window.setItems(window22);
    }
    public  void initAndShowGUI() {
        // This method is invoked on the EDT thread
       

        JFrame frame = new JFrame("Report Viewer");
        JFXPanel fxPanel = new JFXPanel();
        frame.add(fxPanel);
        frame.setSize(1054, 750);
        frame.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/images_/mali2.png")));
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                initFX(fxPanel);
               // loadComboBoxes();
            }
       });
    }

    private  void initFX(JFXPanel fxPanel) {
        // This method is invoked on the JavaFX thread
      try {
          root5 = FXMLLoader.load(getClass().getResource("Search_Report_Engine.fxml"));
           Scene scene2 = new Scene(root5, 1054, 750);
            scene2.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
            fxPanel.setScene(scene2);
           
        } catch (IOException exc) {
            exc.printStackTrace();
            System.exit(1);
        }
    }
     private void loadFilterReport() throws IOException{
          Stage primarystage;
             primarystage = (Stage) back.getScene().getWindow();   
           Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("Search_Report_Engine.fxml"));
           primarystage.setScene(new Scene(mainPane));
           primarystage.setTitle("Search Reports ");
        primarystage.getIcons().add(new Image("/images_/mali2.png"));
        mainPane.getStylesheets().addAll(this.getClass().getResource("style.css").toExternalForm()); 
        primarystage.show();
        //loadComboBoxes();
            
    }
     @FXML
    void actionPerformed(ActionEvent event) throws IOException {
         
        
        
        if(event.getSource()==back){
             try { 
                 loadFilterReport();
             } catch (IOException ex) {
                 Logger.getLogger(Search_Report.class.getName()).log(Level.SEVERE, null, ex);
             }
    }   if(event.getSource()==first_names){
        if(first_names.isSelected()==true){ 
       first_names2.setDisable(false);
    }
    else{
        first_names2.setDisable(true);
        first_names2.setText("");
    }   
       }
       
       else
           if(event.getSource()==surname){
          if(surname.isSelected()==true){ 
       surname2.setDisable(false);
    }
    else{
        surname2.setDisable(true);
        surname2.setText("");
    }     
           }
       
       else
        
        if(event.getSource()==contact_id){
           if(contact_id.isSelected()==true){ 
       contact_id2.setDisable(false);
    }
    else{
        contact_id2.setDisable(true);
        contact_id2.setText("");
    }  
        }

       else
         if(event.getSource()==id_no){
         if(id_no.isSelected()==true){ 
       id_no2.setDisable(false);
    }
    else{
        id_no2.setDisable(true);
        id_no2.setText("");
    }    
         } 
       
         else
        if(event.getSource()==country){
      if(country.isSelected()==true){ 
       country2.setDisable(false);
    }
    else{
        country2.setDisable(true);
        country2.setText("");
    }      
        } 
       
       else
            if(event.getSource()==pin){
     if(pin.isSelected()==true){ 
       pin2.setDisable(false);
    }
    else{
        pin2.setDisable(true);
        pin2.setText("");
    }           
            }
       
       if(event.getSource()==contact_type){
         if(contact_type.isSelected()==true){ 
       contact_type2.setDisable(false);
    }
    else{
        contact_type2.setDisable(true);
        contact_type2.setValue("");
    }  
       }
       if(event.getSource()==status){
        if(status.isSelected()==true){ 
       status2.setDisable(false);
    }
    else{
        status2.setDisable(true);
        status2.setValue("");
    }   
       }
       else
           if(event.getSource()==gender){
             if(gender.isSelected()==true){ 
       gender2.setDisable(false);
    }
    else{
        gender2.setDisable(true);
        gender2.setValue("");
    }   
           }
       else
               if(event.getSource()==occupation){
              if(occupation.isSelected()==true){ 
       occupation2.setDisable(false);
    }
    else{
        occupation2.setDisable(true);
        occupation2.setValue("");
    }      
               }
       else
        
                   if(event.getSource()==source_of_income){
             
    if(source_of_income.isSelected()==true){ 
       source_of_income2.setDisable(false);
    }
    else{
        source_of_income2.setDisable(true);
        source_of_income2.setText("");
    }
                
                   }
       
       else
           if(event.getSource()==business_name){
             if(business_name.isSelected()==true){ 
       business_name2.setDisable(false);
    }
    else{
        business_name2.setDisable(true);
        business_name2.setText("");
    }  
           }
       else
               if(event.getSource()==business_branch){
                if(business_branch.isSelected()==true){ 
       business_branch2.setDisable(false);
    }
    else{
        business_branch2.setDisable(true);
        business_branch2.setText("");
    }   
               }
       
       else
                   if(event.getSource()==location){
             if(location.isSelected()==true){ 
       location2.setDisable(false);
    }
    else{
        location2.setDisable(true);
        location2.setText("");
    }           
                   }
   else
          if(event.getSource()==current_city){
            if(current_city.isSelected()==true){ 
       current_city2.setDisable(false);
    }
    else{
        current_city2.setDisable(true);
        current_city2.setText("");
    }   
          }
       
       else
      if(event.getSource()==website){
       if(website.isSelected()==true){ 
       website2.setDisable(false);
    }
    else{
        website2.setDisable(true);
        website2.setText("");
    }   
      }
    
    else
          if(event.getSource()==county){
          if(county.isSelected()==true){ 
       county2.setDisable(false);
    }
    else{
        county2.setDisable(true);
        county2.setText("");
    }     
          }
       else
       if(event.getSource()==bank_name){
        if(bank_name.isSelected()==true){ 
       bank_name2.setDisable(false);
    }
    else{
        bank_name2.setDisable(true);
        bank_name2.setText("");
    }   
       }
       else
       if(event.getSource()==bank_acc_no){
        if(bank_acc_no.isSelected()==true){ 
       bank_acc_no2.setDisable(false);
    }
    else{
        bank_acc_no2.setDisable(true);
        bank_acc_no2.setText("");
    }   
       } 
       
       else
           if(event.getSource()==bank_branch){
            if(bank_branch.isSelected()==true){ 
       bank_branch2.setDisable(false);
    }
    else{
        bank_branch2.setDisable(true);
        bank_branch2.setText("");
    }    
           }
         else
             
       if(event.getSource()==first_names){
        if(first_names.isSelected()==true){ 
       first_names2.setDisable(false);
    }
    else{
        first_names2.setDisable(true);
        first_names2.setText("");
    }   
       }
       
       else
           if(event.getSource()==surname){
          if(surname.isSelected()==true){ 
       surname2.setDisable(false);
    }
    else{
        surname2.setDisable(true);
        surname2.setText("");
    }     
           }
       
       else
        
        if(event.getSource()==contact_id){
           if(contact_id.isSelected()==true){ 
       contact_id2.setDisable(false);
    }
    else{
        contact_id2.setDisable(true);
        contact_id2.setText("");
    }  
        }

       else
         if(event.getSource()==id_no){
         if(id_no.isSelected()==true){ 
       id_no2.setDisable(false);
    }
    else{
        id_no2.setDisable(true);
        id_no2.setText("");
    }    
         } 
       
         else
        if(event.getSource()==country){
      if(country.isSelected()==true){ 
       country2.setDisable(false);
    }
    else{
        country2.setDisable(true);
        country2.setText("");
    }      
        } 
       
       else
            if(event.getSource()==pin){
     if(pin.isSelected()==true){ 
       pin2.setDisable(false);
    }
    else{
        pin2.setDisable(true);
        pin2.setText("");
    }           
            }
       
       if(event.getSource()==contact_type){
         if(contact_type.isSelected()==true){ 
       contact_type2.setDisable(false);
    }
    else{
        contact_type2.setDisable(true);
        contact_type2.setValue("");
    }  
       }
       if(event.getSource()==status){
        if(status.isSelected()==true){ 
       status2.setDisable(false);
    }
    else{
        status2.setDisable(true);
        status2.setValue("");
    }   
       }
       else
           if(event.getSource()==gender){
             if(gender.isSelected()==true){ 
       gender2.setDisable(false);
    }
    else{
        gender2.setDisable(true);
        gender2.setValue("");
    }   
           }
       else
               if(event.getSource()==occupation){
              if(occupation.isSelected()==true){ 
       occupation2.setDisable(false);
    }
    else{
        occupation2.setDisable(true);
        occupation2.setValue("");
    }      
               }
       else
        
                   if(event.getSource()==source_of_income){
             
    if(source_of_income.isSelected()==true){ 
       source_of_income2.setDisable(false);
    }
    else{
        source_of_income2.setDisable(true);
        source_of_income2.setText("");
    }
                
                   }
       
       else
           if(event.getSource()==business_name){
             if(business_name.isSelected()==true){ 
       business_name2.setDisable(false);
    }
    else{
        business_name2.setDisable(true);
        business_name2.setText("");
    }  
           }
       else
               if(event.getSource()==business_branch){
                if(business_branch.isSelected()==true){ 
       business_branch2.setDisable(false);
    }
    else{
        business_branch2.setDisable(true);
        business_branch2.setText("");
    }   
               }
       
       else
                   if(event.getSource()==location){
             if(location.isSelected()==true){ 
       location2.setDisable(false);
    }
    else{
        location2.setDisable(true);
        location2.setText("");
    }           
                   }
   else
          if(event.getSource()==current_city){
            if(current_city.isSelected()==true){ 
       current_city2.setDisable(false);
    }
    else{
        current_city2.setDisable(true);
        current_city2.setText("");
    }   
          }
       
       else
      if(event.getSource()==website){
       if(website.isSelected()==true){ 
       website2.setDisable(false);
    }
    else{
        website2.setDisable(true);
        website2.setText("");
    }   
      }
    
    else
          if(event.getSource()==county){
          if(county.isSelected()==true){ 
       county2.setDisable(false);
    }
    else{
        county2.setDisable(true);
        county2.setText("");
    }     
          }
       else
       if(event.getSource()==bank_name){
        if(bank_name.isSelected()==true){ 
       bank_name2.setDisable(false);
    }
    else{
        bank_name2.setDisable(true);
        bank_name2.setText("");
    }   
       }
       else
       if(event.getSource()==bank_acc_no){
        if(bank_acc_no.isSelected()==true){ 
       bank_acc_no2.setDisable(false);
    }
    else{
        bank_acc_no2.setDisable(true);
        bank_acc_no2.setText("");
    }   
       } 
       
       else
           if(event.getSource()==bank_branch){
            if(bank_branch.isSelected()==true){ 
       bank_branch2.setDisable(false);
    }
    else{
        bank_branch2.setDisable(true);
        bank_branch2.setText("");
    }    
           }
    
   
    
   
    
    }

        @FXML
    void mouseClicked(ActionEvent event) {
        if(window.getValue()!=null){
          searchReports.main(null);
        }
        else{
        //container.setStyle("-fx-background-color: yellow;");
       // display.setStyle(" -fx-font-size: 14px;");
       // display.setStyle("-fx-text-fill: red;");
      //  display.setText("Please select a window before proceeding!!");
      Image img = new Image("/images_/warning2.png");
      Notifications displayError = Notifications.create()
                        .title("Warning!!")
                        .text("Please select a window before proceeding!!")
                        .graphic(new ImageView(img))
                        .hideAfter(Duration.seconds(5))
                        .position(Pos.TOP_LEFT)
                        .onAction((ActionEvent event1) -> {
                        //System.out.println("Clicked on notification!");
            });  
            displayError.darkStyle();
            displayError.show();
          
        }
       
    }
    
          @Override
    public void initialize(URL url, ResourceBundle rb) {
         loadComboBoxes();
   
         
    }
         public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
              
                loadReports test = new loadReports();
                SwingUtilities.invokeLater(() -> test.initAndShowGUI() );
               
                
            }
        });
    }
   
    

}
