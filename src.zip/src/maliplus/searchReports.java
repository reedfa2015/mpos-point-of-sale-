/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import java.awt.Color;
import java.awt.Dimension;
import java.io.IOException;
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import java.awt.Toolkit;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingNode;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.util.Duration;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import static maliplus.Dynamic1.conn;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JRViewer;
import org.controlsfx.control.Notifications;

public class searchReports implements Initializable{
public static JFrame frame;
public static Scene scene2;
static Parent  root5;
//public static Parent root;
    @FXML
    private AnchorPane report_pane;
    
       @FXML
    private JFXCheckBox first_names;

    @FXML
    private JFXCheckBox surname;

    @FXML
    private JFXCheckBox contact_id;

    @FXML
    private JFXCheckBox id_no;

    @FXML
    private JFXCheckBox country;

    @FXML
    private JFXCheckBox pin;

    @FXML
    private JFXTextField first_names2;

    @FXML
    private JFXTextField surname2;

    @FXML
    private JFXTextField contact_id2;

    @FXML
    private JFXTextField id_no2;

    @FXML
    private JFXTextField country2;

    @FXML
    private JFXTextField pin2;

    @FXML
    private JFXCheckBox contact_type;

    @FXML
    private JFXCheckBox status;

    @FXML
    private JFXCheckBox gender;

    @FXML
    private JFXCheckBox occupation;

    @FXML
    private JFXCheckBox source_of_income;

    @FXML
    private JFXTextField source_of_income2;

        @FXML
    private JFXTextField business_name2;

    @FXML
    private JFXTextField business_branch2;

    @FXML
    private JFXTextField location2;

    @FXML
    private JFXTextField current_city2;

    @FXML
    private JFXTextField website2;

    @FXML
    private JFXTextField county2;
    
        @FXML
    private JFXCheckBox business_name;

    @FXML
    private JFXCheckBox business_branch;

    @FXML
    private JFXCheckBox location;

    @FXML
    private JFXCheckBox current_city;

    @FXML
    private JFXCheckBox website;

    @FXML
    private JFXCheckBox county;
    @FXML
    private JFXComboBox<String> contact_type2;
    ObservableList<String> contact_type22 = 
    FXCollections.observableArrayList(
        "Individual",
        "Company",
        "Association"
        
    );

    @FXML
    private JFXComboBox<String> status2;
    ObservableList<String> status22 = 
    FXCollections.observableArrayList(
        "Active",
        "Inactive"
        
    );

    @FXML
    private JFXComboBox<String> gender2;
    ObservableList<String> gender22 = 
    FXCollections.observableArrayList(
        "F",
        "M"
        
    );

    @FXML
    private  JFXComboBox<String> occupation2;
    ObservableList<String> occupation22 = 
    FXCollections.observableArrayList(
        "SOFTWARE DEVELOPER",
        "SOLDIER"
        
    );

    @FXML
    private JFXCheckBox bank_name;

    @FXML
    private JFXCheckBox bank_acc_no;

    @FXML
    private JFXCheckBox bank_branch;

    @FXML
    private JFXTextField bank_name2;

    @FXML
    private JFXTextField bank_acc_no2;

    @FXML
    private JFXTextField bank_branch2; 
 
    
   @FXML
    private JFXButton ok;

    @FXML
    private Button clear_fields;

      @FXML
    private AnchorPane report_viewer_pane;

    @FXML
    private JFXButton back;

    @FXML
    private Pane Report_Viewer;

        @FXML
    private Pane container;

    @FXML
    private Label display;
    
    @FXML
    private JFXComboBox<String> window;
     ObservableList<String> window22 = 
    FXCollections.observableArrayList(
        "Contact Details",
        "Properties",
        "Chart of Accounts",
        "Leasing"
        
    );
     
      private void loadComboBoxes(){
       
         contact_type2.setItems(contact_type22);
          status2.setItems(status22);
           occupation2.setItems(occupation22);
            gender2.setItems(gender22);
            window.setItems(window22);
    }
       public static JFXPanel fxPanel = new JFXPanel();
       public  void initAndShowGUI() {
        // This method is invoked on the EDT thread
       
        try{
          frame = new JFrame("Report Viewer");
        frame.add(fxPanel);
        frame.setSize(1054, 750);
        
        //frame.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("../images_/mali_bg.png")));
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);  
        }
        catch(Exception e){
            e.printStackTrace();
        }
        
        
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                initFX(fxPanel);
               // loadComboBoxes();
            }
       });
    }
        public static Button fxbutton;
     public void generateReport(String sql) throws JRException {
          String window3 = window.getValue();
         
    try {
        BorderPane Pane2 = new BorderPane();
        conn = DBConnection.ConnectDB();
        final SwingNode swingNode = new SwingNode();
        TitledBorder border = new TitledBorder(""+window.getValue()+"");
        border.setTitleJustification(TitledBorder.CENTER);
        border.setTitlePosition(TitledBorder.TOP);
        border.setTitleColor(Color.BLUE);
        JPanel panel = new JPanel();
        JRViewer jv;
        JRDesignQuery newQuery= new JRDesignQuery();
        newQuery.setText(sql);
         JasperDesign jasperDesign;
         JasperReport jasperReport;
         JasperPrint jasperPrint;
         Dimension preferredSize;
        String showReport1,showReport2,showReport3,showReport4;
        showReport1="contacts.jrxml";
        showReport2="property_details.jrxml";
        showReport3="account_master.jrxml";
        showReport4="leasing.jrxml";
        switch (window3) {
                case "Contact Details":
                     jasperDesign= JRXmlLoader.load(""+showReport1+"");
        jasperDesign.setQuery(newQuery);
        jasperReport= JasperCompileManager.compileReport(jasperDesign);
        jasperPrint= JasperFillManager.fillReport(jasperReport, null, conn);
        jv=new JRViewer(jasperPrint);
        preferredSize= new Dimension(1054,800);
        jv.setPreferredSize(preferredSize);
        jv.setBorder(border);
        panel.add(jv);
        panel.setSize(1054, 800);
        swingNode.setContent(panel);  
                    
                    break;
                            case"Properties":
           jasperDesign= JRXmlLoader.load(""+showReport2+"");
        jasperDesign.setQuery(newQuery);
        jasperReport= JasperCompileManager.compileReport(jasperDesign);
        jasperPrint= JasperFillManager.fillReport(jasperReport, null, conn);
        jv=new JRViewer(jasperPrint);
        preferredSize= new Dimension(1054,800);
        jv.setPreferredSize(preferredSize);
        jv.setBorder(border);
        panel.add(jv);
        panel.setSize(1054, 800);
        swingNode.setContent(panel);                       
                     break; 
                            case"Chart of Accounts":
           jasperDesign= JRXmlLoader.load(""+showReport3+"");
        jasperDesign.setQuery(newQuery);
        jasperReport= JasperCompileManager.compileReport(jasperDesign);
        jasperPrint= JasperFillManager.fillReport(jasperReport, null, conn);
        jv=new JRViewer(jasperPrint);
        preferredSize= new Dimension(1054,800);
        jv.setPreferredSize(preferredSize);
        jv.setBorder(border);
        panel.add(jv);
        panel.setSize(1054, 800);
        swingNode.setContent(panel);                       
                     break;  
        
                     case"Leasing":
           jasperDesign= JRXmlLoader.load(""+showReport4+"");
        jasperDesign.setQuery(newQuery);
        jasperReport= JasperCompileManager.compileReport(jasperDesign);
        jasperPrint= JasperFillManager.fillReport(jasperReport, null, conn);
        jv=new JRViewer(jasperPrint);
        preferredSize= new Dimension(1054,800);
        jv.setPreferredSize(preferredSize);
        jv.setBorder(border);
        panel.add(jv);
        panel.setSize(1054, 800);
        swingNode.setContent(panel);                       
                     break;  
                                    }
        
     
        
        // Stage primarystage;
               //primarystage = (Stage) ok.getScene().getWindow();   
              scene2=new Scene(Pane2,1054,800);
              //primarystage.setResizable(false);
             // primarystage.setTitle("View Reports ");
            //  primarystage.getIcons().add(new Image("/images_/mali2.png"));
              scene2.getStylesheets().addAll(this.getClass().getResource("style.css").toExternalForm()); 
              Pane2.setCenter(swingNode);
              Pane2.setTop(fxbutton);
              fxPanel.setScene(scene2); 
              Dimension preferredSize2= new Dimension(1054,800);
              fxPanel.setSize(preferredSize2);
              frame.setSize(1054, 750);
              frame.setMaximumSize(preferredSize2);
              frame.setResizable(true);
              frame.setExtendedState( frame.getExtendedState()|JFrame.MAXIMIZED_BOTH );
               
        // try {
        //  root5 = FXMLLoader.load(getClass().getResource("Search_Report_Engine.fxml"));
        //   scene2 = new Scene(root5, 1054, 750);
         //   scene2.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
        //    fxPanel.setScene(scene2);
           
       // } catch (IOException exc) {
         //   exc.printStackTrace();
          //  System.exit(1);
      //  }       
       

     
    } catch (JRException ex) {
        Logger.getLogger(searchReports.class.getName()).log(Level.SEVERE, null, ex);
    }
    }

   
      public   String sql,sql2,sql3,sql4,sql5,sql6,sql7,sql8,sql9,sql10,sql11,sql12,sql13,sql14,sql15,sql16,sql17,sql18,sql19,sql20;        
     public     Pane pane = new Pane();

     private  Scene createScene() throws IOException {
        pane = FXMLLoader.load(getClass().getResource("Search_Report_Engine.fxml"));
               // report_pane.getChildren().setAll(pane);
              // scene3.getRoot().setVisible(true); 
              Scene scene3 = new Scene(pane, 1400, 992);
              scene3.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
              fxPanel.setScene(scene3);
              
              return(scene3);
    }
        private void loadReport() throws IOException{
         
         TitledBorder border = new TitledBorder("REPORT VIEWER");
         border.setTitleJustification(TitledBorder.CENTER);
         border.setTitlePosition(TitledBorder.TOP);
         border.setTitleColor(Color.BLUE);
       
         Image fxButtonIcon = new Image(
        getClass().getResourceAsStream("/images_/back - Copy.png"));

        fxbutton = new Button("Back", new ImageView(fxButtonIcon));
          fxbutton.setTooltip(
           new Tooltip("Goes back to the report filter form when clicked."));
            fxbutton.setStyle("-fx-font: 12 arial; -fx-base: #cce6ff;");
         
            if(window.getValue().equals("Contact Details")){
             String temp = "%" + first_names2.getText().toUpperCase() + "%";
            String temp2 = "%" + surname2.getText().toUpperCase() + "%";
            String temp3 = "%" + contact_id2.getText() + "%";
            String temp4 = "%" + id_no2.getText().toUpperCase() + "%";
            String temp5 = "%" + country2.getText().toUpperCase() + "%";
            String temp6 = "%" + contact_type2.getValue() + "%";
            String temp7 = "%" + status2.getValue() + "%";
            String temp8 = "%" + gender2.getValue() + "%";
            String temp9 = "%" + occupation2.getValue() + "%";
            String temp10 = "%" + source_of_income2.getText().toUpperCase() + "%";
            String temp11 = "%" + business_name2.getText().toUpperCase() + "%";
            String temp12 = "%" + business_branch2.getText().toUpperCase() + "%";
            String temp13 = "%" + location2.getText().toUpperCase() + "%";
            String temp14 = "%" + current_city2.getText().toUpperCase() + "%";
            String temp15 = "%" + website2.getText() + "%";
            String temp16 = "%" + county2.getText().toUpperCase() + "%";
            String temp17 = "%" + bank_name2.getText().toUpperCase() + "%";
            String temp18 = "%" + bank_acc_no2.getText().toUpperCase() + "%";
            String temp19 = "%" + bank_branch2.getText().toUpperCase() + "%";
            String temp20="%" + pin2.getText().toUpperCase() +"%";
           
            
            
             sql= "SELECT * FROM CONTACTS WHERE FIRST_NAMES LIKE '"+temp+"'";
             sql2= "SELECT * FROM CONTACTS WHERE LAST_NAME LIKE '"+temp2+"'";  
             sql3= "SELECT * FROM CONTACTS WHERE CONTACT_ID LIKE '"+temp3+"'";
             sql4= "SELECT * FROM CONTACTS WHERE NATIONAL_ID LIKE '"+temp4+"'";
             sql5= "SELECT * FROM CONTACTS WHERE COUNTRY LIKE '"+temp5+"'";
             sql6= "SELECT * FROM CONTACTS WHERE PIN LIKE '"+temp20+"'";
             sql7= "SELECT * FROM CONTACTS WHERE CONTACT_TYPE LIKE '"+temp6+"'";
             sql8= "SELECT * FROM CONTACTS WHERE STATUS LIKE '"+temp7+"'";  
             sql9= "SELECT * FROM CONTACTS WHERE GENDER LIKE '"+temp8+"'"; 
             sql10= "SELECT * FROM CONTACTS WHERE OCCUPATION LIKE '"+temp9+"'"; 
             sql11= "SELECT * FROM CONTACTS WHERE SOURCE_OF_INCOME LIKE '"+temp10+"'";
             sql12= "SELECT * FROM CONTACTS WHERE COMPANY_NAME LIKE '"+temp11+"'";
             sql13= "SELECT * FROM CONTACTS WHERE COMPANY_BRANCH LIKE '"+temp12+"'";
             sql14= "SELECT * FROM CONTACTS WHERE LOCATION LIKE '"+temp13+"'";
             sql15= "SELECT * FROM CONTACTS WHERE CURRENT_CITY LIKE '"+temp14+"'";
             sql16= "SELECT * FROM CONTACTS WHERE WEBSITE LIKE '"+temp15+"'";
             sql17= "SELECT * FROM CONTACTS WHERE COUNTY LIKE '"+temp16+"'";
             sql18= "SELECT * FROM CONTACTS WHERE BANK_NAME LIKE '"+temp17+"'";
             sql19= "SELECT * FROM CONTACTS WHERE BANK_ACC_NO LIKE '"+temp18+"'";
             sql20= "SELECT * FROM CONTACTS WHERE BANK_BRANCH LIKE '"+temp19+"'";   
            }
            
            else
                if(window.getValue().equals("Properties")){
               String temp = "%" + first_names2.getText()+ "%";
            String temp2 = "%" + surname2.getText().toUpperCase() + "%";
            String temp3 = "%" + contact_id2.getText() + "%";
            String temp4 = "%" + id_no2.getText().toUpperCase() + "%";
            String temp5 = "%" + country2.getText() + "%";
            String temp6 = "%" + contact_type2.getValue() + "%";
            String temp7 = "%" + status2.getValue() + "%";
            String temp8 = "%" + gender2.getValue() + "%";
            String temp9 = "%" + occupation2.getValue() + "%";
            String temp10 = "%" + source_of_income2.getText().toUpperCase() + "%";
            String temp11 = "%" + business_name2.getText().toUpperCase() + "%";
            String temp12 = "%" + business_branch2.getText().toUpperCase() + "%";
            String temp13 = "%" + location2.getText().toUpperCase() + "%";
            String temp14 = "%" + current_city2.getText().toUpperCase() + "%";
            String temp15 = "%" + website2.getText() + "%";
            String temp16 = "%" + county2.getText().toUpperCase() + "%";
            String temp17 = "%" + bank_name2.getText().toUpperCase() + "%";
            String temp18 = "%" + bank_acc_no2.getText().toUpperCase() + "%";
            String temp19 = "%" + bank_branch2.getText().toUpperCase() + "%";
            String temp20 = "%" + pin2.getText().toUpperCase() + "%";
            
            
             sql= "SELECT * FROM  PROPERTIES_TABLE WHERE PROPERTY_ID LIKE '"+temp+"'";
             sql2= "SELECT * FROM PROPERTIES_TABLE WHERE PARENT_PROPERTY LIKE '"+temp2+"'";  
             sql3= "SELECT * FROM PROPERTIES_TABLE WHERE CONTACT_ID LIKE '"+temp3+"'";
             sql4= "SELECT * FROM PROPERTIES_TABLE WHERE CONTACT_ID LIKE '"+temp4+"'";
             sql5= "SELECT * FROM PROPERTIES_TABLE WHERE PROPERTY_VALUE LIKE '"+temp5+"'";
             sql6= "SELECT * FROM PROPERTIES_TABLE WHERE PURCHASE_PRICE LIKE '"+temp20+"'";
             sql7= "SELECT * FROM PROPERTIES_TABLE WHERE VALUATION_DATE LIKE '"+temp6+"'";
             sql8= "SELECT * FROM PROPERTIES_TABLE WHERE PROPERTY_STATUS LIKE '"+temp7+"'";  
             sql9= "SELECT * FROM PROPERTIES_TABLE WHERE ZONE LIKE '"+temp8+"'"; 
             sql10= "SELECT * FROM PROPERTIES_TABLE WHERE COUNTRY LIKE '"+temp9+"'"; 
             sql11= "SELECT * FROM PROPERTIES_TABLE WHERE SALE_DATE LIKE '"+temp10+"'";
             sql12= "SELECT * FROM PROPERTIES_TABLE WHERE SALE_VALUE LIKE '"+temp11+"'";
             sql13= "SELECT * FROM PROPERTIES_TABLE WHERE ASKING_VALUE LIKE '"+temp12+"'";
             sql14= "SELECT * FROM PROPERTIES_TABLE WHERE CITY LIKE '"+temp13+"'";
             sql15= "SELECT * FROM PROPERTIES_TABLE WHERE SURBURB LIKE '"+temp14+"'";
             sql16= "SELECT * FROM PROPERTIES_TABLE WHERE PROPERTY_GPRS LIKE '"+temp15+"'";
             sql17= "SELECT * FROM PROPERTIES_TABLE WHERE PROPERTY_TYPE LIKE '"+temp16+"'";
             sql18= "SELECT * FROM PROPERTIES_TABLE WHERE BANK_NAME LIKE '"+temp17+"'";
             sql19= "SELECT * FROM PROPERTIES_TABLE WHERE BANK_ACCOUNT LIKE '"+temp18+"'";
             sql20= "SELECT * FROM PROPERTIES_TABLE WHERE BANK_BRANCH LIKE '"+temp19+"'";    
                    
                    
                    
                    
                }
            else
                    if(window.getValue().equals("Chart of Accounts")){
                   String temp = "%" + first_names2.getText().toUpperCase() + "%";
            String temp2 = "%" + surname2.getText() + "%";
            String temp3 = "%" + contact_id2.getText() + "%";
            String temp4 = "%" + id_no2.getText() + "%";
            String temp5 = "%" + country2.getText().toUpperCase() + "%";
            String temp6 = "%" + contact_type2.getValue() + "%";
            String temp7 = "%" + status2.getValue() + "%";
            String temp8 = "%" + gender2.getValue() + "%";
            String temp9 = "%" + occupation2.getValue() + "%";
            String temp10 = "%" + source_of_income2.getText() + "%";
            String temp11 = "%" + business_name2.getText().toUpperCase() + "%";
            String temp12 = "%" + business_branch2.getText().toUpperCase() + "%";
            String temp13 = "%" + location2.getText().toUpperCase() + "%";
            String temp14 = "%" + current_city2.getText().toUpperCase() + "%";
            String temp15 = "%" + website2.getText().toUpperCase() + "%";
            String temp16 = "%" + county2.getText().toUpperCase() + "%";
            String temp17 = "%" + bank_name2.getText().toUpperCase() + "%";
            String temp18 = "%" + bank_acc_no2.getText().toUpperCase() + "%";
            String temp19 = "%" + bank_branch2.getText().toUpperCase() + "%";
            String temp20="%" + pin2.getText().toUpperCase() +"%";
           
            
            
             sql= "SELECT * FROM ACCOUNT_MASTER WHERE ACCOUNT_GROUP LIKE '"+temp+"'";
             sql2= "SELECT * FROM ACCOUNT_MASTER WHERE COST_CENTRE LIKE '"+temp2+"'";  
             sql3= "SELECT * FROM ACCOUNT_MASTER WHERE MAIN_ACCOUNT LIKE '"+temp3+"'";
             sql4= "SELECT * FROM ACCOUNT_MASTER WHERE SUB_ACCOUNT LIKE '"+temp4+"'";
             sql5= "SELECT * FROM ACCOUNT_MASTER WHERE ACCOUNT_STATUS LIKE '"+temp5+"'";
             sql6= "SELECT * FROM ACCOUNT_MASTER WHERE DESCRIPTION LIKE '"+temp20+"'";
             sql7= "SELECT * FROM ACCOUNT_MASTER WHERE MAIN_CATEGORY LIKE '"+temp6+"'";
             sql8= "SELECT * FROM ACCOUNT_MASTER WHERE SUB_CATEGORY LIKE '"+temp7+"'";  
             sql9= "SELECT * FROM ACCOUNT_MASTER WHERE SUB_CATEG_TYPE LIKE '"+temp8+"'"; 
             sql10= "SELECT * FROM ACCOUNT_MASTER WHERE CONTRA_ACCOUNT LIKE '"+temp9+"'"; 
             sql11= "SELECT * FROM ACCOUNT_MASTER WHERE ACCOUNT_NUMBER LIKE '"+temp10+"'";
             sql12= "SELECT * FROM ACCOUNT_MASTER WHERE ACCOUNT_TYPE LIKE '"+temp11+"'";
             sql13= "SELECT * FROM ACCOUNT_MASTER WHERE MUST_BUDGET LIKE '"+temp12+"'";
             sql14= "SELECT * FROM ACCOUNT_MASTER WHERE CHECK_BUDGET LIKE '"+temp13+"'";
             sql15= "SELECT * FROM ACCOUNT_MASTER WHERE RECONCILE LIKE '"+temp14+"'";
             sql16= "SELECT * FROM ACCOUNT_MASTER WHERE POST_RESTRICTION LIKE '"+temp15+"'";
             sql17= "SELECT * FROM ACCOUNT_MASTER WHERE RESTRICTED LIKE '"+temp16+"'";
             sql18= "SELECT * FROM ACCOUNT_MASTER WHERE RECONCILE_GROUP LIKE '"+temp17+"'";
             sql19= "SELECT * FROM ACCOUNT_MASTER WHERE BUDGET_PATTERN LIKE '"+temp18+"'";
             sql20= "SELECT * FROM ACCOUNT_MASTER WHERE TRANSACTION_ACCOUNT LIKE '"+temp19+"'";          
                    }
                       else
                    if(window.getValue().equals("Leasing")){
            String temp = "%" + first_names2.getText()+ "%";
            String temp2 = "%" + surname2.getText() + "%";
            String temp3 = "%" + contact_id2.getText() + "%";
            String temp4 = "%" + id_no2.getText() + "%";
            String temp5 = "%" + country2.getText() + "%";
            String temp6 = "%" + contact_type2.getValue() + "%";
            String temp7 = "%" + status2.getValue() + "%";
            String temp8 = "%" + gender2.getValue() + "%";
            String temp9 = "%" + occupation2.getValue() + "%";
            String temp10 = "%" + source_of_income2.getText() + "%";
            String temp11 = "%" + business_name2.getText() + "%";
            String temp12 = "%" + business_branch2.getText() + "%";
            String temp13 = "%" + location2.getText()+ "%";
            String temp14 = "%" + current_city2.getText() + "%";
            String temp15 = "%" + website2.getText()+ "%";
            String temp16 = "%" + county2.getText() + "%";
            String temp17 = "%" + bank_name2.getText()+ "%";
            String temp18 = "%" + bank_acc_no2.getText() + "%";
            String temp19 = "%" + bank_branch2.getText().toUpperCase() + "%";
            String temp20="%" + pin2.getText()+"%";
           
            
            
             sql= "SELECT * FROM LEASE WHERE LEASE_ID LIKE '"+temp+"'";
             sql2= "SELECT * FROM LEASE WHERE PROPERTY_ID LIKE '"+temp2+"'";  
             sql3= "SELECT * FROM LEASE WHERE END_LEASE_DATE LIKE '"+temp3+"'";
             sql4= "SELECT * FROM LEASE WHERE CONTACT_ID LIKE '"+temp4+"'";
             sql5= "SELECT * FROM LEASE WHERE LEASE_ACCOUNT LIKE '"+temp5+"'";
             sql6= "SELECT * FROM LEASE WHERE CURRENT_LEASE LIKE '"+temp20+"'";
             sql7= "SELECT * FROM LEASE WHERE START_LEASE_DATE LIKE '"+temp6+"'";
             sql8= "SELECT * FROM LEASE WHERE LEASE_STATUS LIKE '"+temp7+"'";  
             sql9= "SELECT * FROM LEASE WHERE LEASE_TYPES LIKE '"+temp8+"'"; 
             sql10= "SELECT * FROM LEASE WHERE LEASE_REVIEW_DATE LIKE '"+temp9+"'"; 
             sql11= "SELECT * FROM LEASE WHERE REFUNDABLE_DEPOSIT_ACCOUNT LIKE '"+temp10+"'";
             sql12= "SELECT * FROM LEASE WHERE NONE_REFUNDABLE_ACCOUNT LIKE '"+temp11+"'";
             sql13= "SELECT * FROM LEASE WHERE PENALTY_DATE LIKE '"+temp12+"'";
             sql14= "SELECT * FROM LEASE WHERE WATER_DEPOSIT_ACCOUNT LIKE '"+temp13+"'";
             sql15= "SELECT * FROM LEASE WHERE ELECTRICITY_DEPOSIT_ACCOUNT LIKE '"+temp14+"'";
             sql16= "SELECT * FROM LEASE WHERE SECURITY_CHARGES_ACCOUNT LIKE '"+temp15+"'";
             sql17= "SELECT * FROM LEASE WHERE UTILITY_CHARGES_ACCOUNT LIKE '"+temp16+"'";
             sql18= "SELECT * FROM LEASE WHERE SALESMAN_ID LIKE '"+temp17+"'";
             sql19= "SELECT * FROM LEASE WHERE SALESMAN_ACCOUNT LIKE '"+temp18+"'";
             sql20= "SELECT * FROM LEASE WHERE INSPECTOR_ID LIKE '"+temp19+"'";          
                    }
          
                  String window2 = window.getValue();
         switch (window2) {
                case "Contact Details":
                 try{    
               if(first_names.isSelected()==true){
                
              generateReport(sql);
             
               }
               
               else
                if(surname.isSelected()==true){   
                generateReport(sql2);
                
               }    
 
               else
                if(contact_id.isSelected()==true){
                generateReport(sql3);
                
               }
                else
                if(id_no.isSelected()==true){
               generateReport(sql4);
                
               }
                 else
                if(country.isSelected()==true){
               generateReport(sql5);
                
               }
                 else
                if(pin.isSelected()==true){
                generateReport(sql6);
                
               }
               
               else
                if(contact_type.isSelected()==true){
                generateReport(sql7);
                
               }
               else
                if(status.isSelected()==true){
                generateReport(sql8);
                
               }
               else
                if(gender.isSelected()==true){
                generateReport(sql9);
                
               }
               else
                if(occupation.isSelected()==true){
                generateReport(sql10);
                
               }
                else
                if(source_of_income.isSelected()==true){
                generateReport(sql11);
                
               }
               else
                if(business_name.isSelected()==true){
                generateReport(sql12);
                
               }
               else
                if(business_branch.isSelected()==true){
                generateReport(sql13);
                
               }
                else
                if(location.isSelected()==true){
                generateReport(sql14);
                
               }
               else
                if(current_city.isSelected()==true){
                generateReport(sql15);
                
               }
               else
                if(website.isSelected()==true){
                generateReport(sql16);
                
               }
               else
                if(county.isSelected()==true){
                generateReport(sql17);
                
               }
               else
                if(bank_name.isSelected()==true){
                generateReport(sql18);
                
               }
               else
                if(bank_acc_no.isSelected()==true){
                generateReport(sql19);
                
               }
               else
                if(bank_branch.isSelected()==true){
                generateReport(sql20);
                
               }
              fxbutton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                    
                       try {
                 //Stage primarystage = new Stage(); 
             
              //primarystage = (Stage) FXMLLoader.load(Search_Report.class.getResource("Search_Report_Engine.fxml"));
            //  primarystage = (Stage) fxbutton.getScene().getWindow();  
              Pane pane= (Pane) FXMLLoader.load(getClass().getResource("Search_Report_Engine.fxml"));
              scene2=new Scene(pane,1054,750);
              scene2.getStylesheets().addAll(this.getClass().getResource("style.css").toExternalForm());
            //  primarystage.setTitle("Search Reports ");
            //  primarystage.getIcons().add(new Image("/images_/mali2.png"));
            //  primarystage.setResizable(false);
             // primarystage.show(); 
             fxPanel.setScene(scene2);
             frame.setSize(1054, 750);
        //frame.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/images_/mali2.png")));
       // frame.setVisible(true);
      //  frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
          frame.setResizable(false);
          frame.setLocationRelativeTo(null);
           window.setValue("Contact Details");
                } catch (IOException ex) {
                    Logger.getLogger(searchReports.class.getName()).log(Level.SEVERE, null, ex);
                }
             
               
           
                 
             
            }
        });
                 
               
            }
                 
            catch(Exception e){
                e.printStackTrace();
            }
                 
                      break;
                      case "Properties":
               try{    
               if(first_names.isSelected()==true){
                
              generateReport(sql);
             
               }
               
               else
                if(surname.isSelected()==true){   
                generateReport(sql2);
                
               }    
 
               else
                if(contact_id.isSelected()==true){
                generateReport(sql3);
                
               }
                else
                if(id_no.isSelected()==true){
               generateReport(sql4);
                
               }
                 else
                if(country.isSelected()==true){
               generateReport(sql5);
                
               }
                 else
                if(pin.isSelected()==true){
                generateReport(sql6);
                
               }
               
               else
                if(contact_type.isSelected()==true){
                generateReport(sql7);
                
               }
               else
                if(status.isSelected()==true){
                generateReport(sql8);
                
               }
               else
                if(gender.isSelected()==true){
                generateReport(sql9);
                
               }
               else
                if(occupation.isSelected()==true){
                generateReport(sql10);
                
               }
                else
                if(source_of_income.isSelected()==true){
                generateReport(sql11);
                
               }
               else
                if(business_name.isSelected()==true){
                generateReport(sql12);
                
               }
               else
                if(business_branch.isSelected()==true){
                generateReport(sql13);
                
               }
                else
                if(location.isSelected()==true){
                generateReport(sql14);
                
               }
               else
                if(current_city.isSelected()==true){
                generateReport(sql15);
                
               }
               else
                if(website.isSelected()==true){
                generateReport(sql16);
                
               }
               else
                if(county.isSelected()==true){
                generateReport(sql17);
                
               }
               else
                if(bank_name.isSelected()==true){
                generateReport(sql18);
                
               }
               else
                if(bank_acc_no.isSelected()==true){
                generateReport(sql19);
                
               }
               else
                if(bank_branch.isSelected()==true){
                generateReport(sql20);
                
               }
              fxbutton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                   
                try {
                 //Stage primarystage = new Stage(); 
             
              //primarystage = (Stage) FXMLLoader.load(Search_Report.class.getResource("Search_Report_Engine.fxml"));
            //  primarystage = (Stage) fxbutton.getScene().getWindow();  
              Pane pane= (Pane) FXMLLoader.load(getClass().getResource("Search_Report_Engine.fxml"));
              scene2=new Scene(pane,1054,750);
              scene2.getStylesheets().addAll(this.getClass().getResource("style.css").toExternalForm());
            //  primarystage.setTitle("Search Reports ");
            //  primarystage.getIcons().add(new Image("/images_/mali2.png"));
            //  primarystage.setResizable(false);
             // primarystage.show(); 
             fxPanel.setScene(scene2);
             frame.setSize(1054, 750);
        //frame.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/images_/mali2.png")));
       // frame.setVisible(true);
      //  frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
          frame.setResizable(false);
          frame.setLocationRelativeTo(null);
                } catch (IOException ex) {
                    Logger.getLogger(searchReports.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
                 
               
            }
            catch(Exception e){
                e.printStackTrace();
            }   
                    break;
                case "Chart of Accounts":
                  try{    
               if(first_names.isSelected()==true){
                
              generateReport(sql);
             
               }
               
               else
                if(surname.isSelected()==true){   
                generateReport(sql2);
                
               }    
 
               else
                if(contact_id.isSelected()==true){
                generateReport(sql3);
                
               }
                else
                if(id_no.isSelected()==true){
               generateReport(sql4);
                
               }
                 else
                if(country.isSelected()==true){
               generateReport(sql5);
                
               }
                 else
                if(pin.isSelected()==true){
                generateReport(sql6);
                
               }
               
               else
                if(contact_type.isSelected()==true){
                generateReport(sql7);
                
               }
               else
                if(status.isSelected()==true){
                generateReport(sql8);
                
               }
               else
                if(gender.isSelected()==true){
                generateReport(sql9);
                
               }
               else
                if(occupation.isSelected()==true){
                generateReport(sql10);
                
               }
                else
                if(source_of_income.isSelected()==true){
                generateReport(sql11);
                
               }
               else
                if(business_name.isSelected()==true){
                generateReport(sql12);
                
               }
               else
                if(business_branch.isSelected()==true){
                generateReport(sql13);
                
               }
                else
                if(location.isSelected()==true){
                generateReport(sql14);
                
               }
               else
                if(current_city.isSelected()==true){
                generateReport(sql15);
                
               }
               else
                if(website.isSelected()==true){
                generateReport(sql16);
                
               }
               else
                if(county.isSelected()==true){
                generateReport(sql17);
                
               }
               else
                if(bank_name.isSelected()==true){
                generateReport(sql18);
                
               }
               else
                if(bank_acc_no.isSelected()==true){
                generateReport(sql19);
                
               }
               else
                if(bank_branch.isSelected()==true){
                generateReport(sql20);
                
               }
              fxbutton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                   
                try {
                 //Stage primarystage = new Stage(); 
             
              //primarystage = (Stage) FXMLLoader.load(Search_Report.class.getResource("Search_Report_Engine.fxml"));
            //  primarystage = (Stage) fxbutton.getScene().getWindow();  
              Pane pane= (Pane) FXMLLoader.load(getClass().getResource("Search_Report_Engine.fxml"));
              scene2=new Scene(pane,1054,750);
              scene2.getStylesheets().addAll(this.getClass().getResource("style.css").toExternalForm());
            //  primarystage.setTitle("Search Reports ");
            //  primarystage.getIcons().add(new Image("/images_/mali2.png"));
            //  primarystage.setResizable(false);
             // primarystage.show(); 
             fxPanel.setScene(scene2);
             frame.setSize(1054, 750);
        //frame.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/images_/mali2.png")));
       // frame.setVisible(true);
      //  frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
          frame.setResizable(false);
          frame.setLocationRelativeTo(null);
                } catch (IOException ex) {
                    Logger.getLogger(searchReports.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
                 
               
            }
            catch(Exception e){
                e.printStackTrace();
            } 
                       
                     
                break;
                case "Leasing":
                     try{    
               if(first_names.isSelected()==true){
                
              generateReport(sql);
             
               }
               
               else
                if(surname.isSelected()==true){   
                generateReport(sql2);
                
               }    
 
               else
                if(contact_id.isSelected()==true){
                generateReport(sql3);
                
               }
                else
                if(id_no.isSelected()==true){
               generateReport(sql4);
                
               }
                 else
                if(country.isSelected()==true){
               generateReport(sql5);
                
               }
                 else
                if(pin.isSelected()==true){
                generateReport(sql6);
                
               }
               
               else
                if(contact_type.isSelected()==true){
                generateReport(sql7);
                
               }
               else
                if(status.isSelected()==true){
                generateReport(sql8);
                
               }
               else
                if(gender.isSelected()==true){
                generateReport(sql9);
                
               }
               else
                if(occupation.isSelected()==true){
                generateReport(sql10);
                
               }
                else
                if(source_of_income.isSelected()==true){
                generateReport(sql11);
                
               }
               else
                if(business_name.isSelected()==true){
                generateReport(sql12);
                
               }
               else
                if(business_branch.isSelected()==true){
                generateReport(sql13);
                
               }
                else
                if(location.isSelected()==true){
                generateReport(sql14);
                
               }
               else
                if(current_city.isSelected()==true){
                generateReport(sql15);
                
               }
               else
                if(website.isSelected()==true){
                generateReport(sql16);
                
               }
               else
                if(county.isSelected()==true){
                generateReport(sql17);
                
               }
               else
                if(bank_name.isSelected()==true){
                generateReport(sql18);
                
               }
               else
                if(bank_acc_no.isSelected()==true){
                generateReport(sql19);
                
               }
               else
                if(bank_branch.isSelected()==true){
                generateReport(sql20);
                
               }
              fxbutton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                   
                try {
                 //Stage primarystage = new Stage(); 
             
              //primarystage = (Stage) FXMLLoader.load(Search_Report.class.getResource("Search_Report_Engine.fxml"));
            //  primarystage = (Stage) fxbutton.getScene().getWindow();  
              Pane pane= (Pane) FXMLLoader.load(getClass().getResource("Search_Report_Engine.fxml"));
              scene2=new Scene(pane,1054,750);
              scene2.getStylesheets().addAll(this.getClass().getResource("style.css").toExternalForm());
            //  primarystage.setTitle("Search Reports ");
            //  primarystage.getIcons().add(new Image("/images_/mali2.png"));
            //  primarystage.setResizable(false);
             // primarystage.show(); 
             fxPanel.setScene(scene2);
             frame.setSize(1054, 750);
        //frame.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/images_/mali2.png")));
       // frame.setVisible(true);
      //  frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
          frame.setResizable(false);
          frame.setLocationRelativeTo(null);
                } catch (IOException ex) {
                    Logger.getLogger(searchReports.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
                 
               
            }
            catch(Exception e){
                e.printStackTrace();
            }   
                break;    
               }   
        
                 
                 
         
            
    }
     
         @FXML
    void actionPerformed(ActionEvent event) throws IOException {
         
        
        
          if(event.getSource()==first_names){
        if(first_names.isSelected()==true){ 
       first_names2.setDisable(false);
    }
    else{
        first_names2.setDisable(true);
        first_names2.setText("");
    }   
       }
       
       else
           if(event.getSource()==surname){
          if(surname.isSelected()==true){ 
       surname2.setDisable(false);
    }
    else{
        surname2.setDisable(true);
        surname2.setText("");
    }     
           }
       
       else
        
        if(event.getSource()==contact_id){
           if(contact_id.isSelected()==true){ 
       contact_id2.setDisable(false);
    }
    else{
        contact_id2.setDisable(true);
        contact_id2.setText("");
    }  
        }

       else
         if(event.getSource()==id_no){
         if(id_no.isSelected()==true){ 
       id_no2.setDisable(false);
    }
    else{
        id_no2.setDisable(true);
        id_no2.setText("");
    }    
         } 
       
         else
        if(event.getSource()==country){
      if(country.isSelected()==true){ 
       country2.setDisable(false);
    }
    else{
        country2.setDisable(true);
        country2.setText("");
    }      
        } 
       
       else
            if(event.getSource()==pin){
     if(pin.isSelected()==true){ 
       pin2.setDisable(false);
    }
    else{
        pin2.setDisable(true);
        pin2.setText("");
    }           
            }
       
       if(event.getSource()==contact_type){
         if(contact_type.isSelected()==true){ 
       contact_type2.setDisable(false);
    }
    else{
        contact_type2.setDisable(true);
        contact_type2.setValue("");
    }  
       }
       if(event.getSource()==status){
        if(status.isSelected()==true){ 
       status2.setDisable(false);
    }
    else{
        status2.setDisable(true);
        status2.setValue("");
    }   
       }
       else
           if(event.getSource()==gender){
             if(gender.isSelected()==true){ 
       gender2.setDisable(false);
    }
    else{
        gender2.setDisable(true);
        gender2.setValue("");
    }   
           }
       else
               if(event.getSource()==occupation){
              if(occupation.isSelected()==true){ 
       occupation2.setDisable(false);
    }
    else{
        occupation2.setDisable(true);
        occupation2.setValue("");
    }      
               }
       else
        
                   if(event.getSource()==source_of_income){
             
    if(source_of_income.isSelected()==true){ 
       source_of_income2.setDisable(false);
    }
    else{
        source_of_income2.setDisable(true);
        source_of_income2.setText("");
    }
                
                   }
       
       else
           if(event.getSource()==business_name){
             if(business_name.isSelected()==true){ 
       business_name2.setDisable(false);
    }
    else{
        business_name2.setDisable(true);
        business_name2.setText("");
    }  
           }
       else
               if(event.getSource()==business_branch){
                if(business_branch.isSelected()==true){ 
       business_branch2.setDisable(false);
    }
    else{
        business_branch2.setDisable(true);
        business_branch2.setText("");
    }   
               }
       
       else
                   if(event.getSource()==location){
             if(location.isSelected()==true){ 
       location2.setDisable(false);
    }
    else{
        location2.setDisable(true);
        location2.setText("");
    }           
                   }
   else
          if(event.getSource()==current_city){
            if(current_city.isSelected()==true){ 
       current_city2.setDisable(false);
    }
    else{
        current_city2.setDisable(true);
        current_city2.setText("");
    }   
          }
       
       else
      if(event.getSource()==website){
       if(website.isSelected()==true){ 
       website2.setDisable(false);
    }
    else{
        website2.setDisable(true);
        website2.setText("");
    }   
      }
    
    else
          if(event.getSource()==county){
          if(county.isSelected()==true){ 
       county2.setDisable(false);
    }
    else{
        county2.setDisable(true);
        county2.setText("");
    }     
          }
       else
       if(event.getSource()==bank_name){
        if(bank_name.isSelected()==true){ 
       bank_name2.setDisable(false);
    }
    else{
        bank_name2.setDisable(true);
        bank_name2.setText("");
    }   
       }
       else
       if(event.getSource()==bank_acc_no){
        if(bank_acc_no.isSelected()==true){ 
       bank_acc_no2.setDisable(false);
    }
    else{
        bank_acc_no2.setDisable(true);
        bank_acc_no2.setText("");
    }   
       } 
       
       else
           if(event.getSource()==bank_branch){
            if(bank_branch.isSelected()==true){ 
       bank_branch2.setDisable(false);
    }
    else{
        bank_branch2.setDisable(true);
        bank_branch2.setText("");
    }    
           }
         else
             
       if(event.getSource()==first_names){
        if(first_names.isSelected()==true){ 
       first_names2.setDisable(false);
    }
    else{
        first_names2.setDisable(true);
        first_names2.setText("");
    }   
       }
       
       else
           if(event.getSource()==surname){
          if(surname.isSelected()==true){ 
       surname2.setDisable(false);
    }
    else{
        surname2.setDisable(true);
        surname2.setText("");
    }     
           }
       
       else
        
        if(event.getSource()==contact_id){
           if(contact_id.isSelected()==true){ 
       contact_id2.setDisable(false);
    }
    else{
        contact_id2.setDisable(true);
        contact_id2.setText("");
    }  
        }

       else
         if(event.getSource()==id_no){
         if(id_no.isSelected()==true){ 
       id_no2.setDisable(false);
    }
    else{
        id_no2.setDisable(true);
        id_no2.setText("");
    }    
         } 
       
         else
        if(event.getSource()==country){
      if(country.isSelected()==true){ 
       country2.setDisable(false);
    }
    else{
        country2.setDisable(true);
        country2.setText("");
    }      
        } 
       
       else
            if(event.getSource()==pin){
     if(pin.isSelected()==true){ 
       pin2.setDisable(false);
    }
    else{
        pin2.setDisable(true);
        pin2.setText("");
    }           
            }
       
       if(event.getSource()==contact_type){
         if(contact_type.isSelected()==true){ 
       contact_type2.setDisable(false);
    }
    else{
        contact_type2.setDisable(true);
        contact_type2.setValue("");
    }  
       }
       if(event.getSource()==status){
        if(status.isSelected()==true){ 
       status2.setDisable(false);
    }
    else{
        status2.setDisable(true);
        status2.setValue("");
    }   
       }
       else
           if(event.getSource()==gender){
             if(gender.isSelected()==true){ 
       gender2.setDisable(false);
    }
    else{
        gender2.setDisable(true);
        gender2.setValue("");
    }   
           }
       else
               if(event.getSource()==occupation){
              if(occupation.isSelected()==true){ 
       occupation2.setDisable(false);
    }
    else{
        occupation2.setDisable(true);
        occupation2.setValue("");
    }      
               }
       else
        
                   if(event.getSource()==source_of_income){
             
    if(source_of_income.isSelected()==true){ 
       source_of_income2.setDisable(false);
    }
    else{
        source_of_income2.setDisable(true);
        source_of_income2.setText("");
    }
                
                   }
       
       else
           if(event.getSource()==business_name){
             if(business_name.isSelected()==true){ 
       business_name2.setDisable(false);
    }
    else{
        business_name2.setDisable(true);
        business_name2.setText("");
    }  
           }
       else
               if(event.getSource()==business_branch){
                if(business_branch.isSelected()==true){ 
       business_branch2.setDisable(false);
    }
    else{
        business_branch2.setDisable(true);
        business_branch2.setText("");
    }   
               }
       
       else
                   if(event.getSource()==location){
             if(location.isSelected()==true){ 
       location2.setDisable(false);
    }
    else{
        location2.setDisable(true);
        location2.setText("");
    }           
                   }
   else
          if(event.getSource()==current_city){
            if(current_city.isSelected()==true){ 
       current_city2.setDisable(false);
    }
    else{
        current_city2.setDisable(true);
        current_city2.setText("");
    }   
          }
       
       else
      if(event.getSource()==website){
       if(website.isSelected()==true){ 
       website2.setDisable(false);
    }
    else{
        website2.setDisable(true);
        website2.setText("");
    }   
      }
    
    else
          if(event.getSource()==county){
          if(county.isSelected()==true){ 
       county2.setDisable(false);
    }
    else{
        county2.setDisable(true);
        county2.setText("");
    }     
          }
       else
       if(event.getSource()==bank_name){
        if(bank_name.isSelected()==true){ 
       bank_name2.setDisable(false);
    }
    else{
        bank_name2.setDisable(true);
        bank_name2.setText("");
    }   
       }
       else
       if(event.getSource()==bank_acc_no){
        if(bank_acc_no.isSelected()==true){ 
       bank_acc_no2.setDisable(false);
    }
    else{
        bank_acc_no2.setDisable(true);
        bank_acc_no2.setText("");
    }   
       } 
       
       else
           if(event.getSource()==bank_branch){
            if(bank_branch.isSelected()==true){ 
       bank_branch2.setDisable(false);
    }
    else{
        bank_branch2.setDisable(true);
        bank_branch2.setText("");
    }    
           }
       
       else
               if(event.getSource()==window){
      if(window.getValue().equals("Properties")){
        first_names.setText("Property Id:"); 
        surname.setText("Parent Property:");
        contact_id.setText("Property Quantity:");
        id_no.setText("Owner:");
        country.setText("Property Value:");
        pin.setText("Purchase Price:");
        contact_type.setText("Valuation Date:");
        status.setText("Property Status:");
        gender.setText("Zone:");
        occupation.setText("Country:");
        source_of_income.setText("Sale Date:");
        business_name.setText("Sale Value:");
        business_branch.setText("lease_value:");
        location.setText("City:");
        current_city.setText("Suburb:");
        website.setText("Property G.P.R.S:");
        county.setText("Property Type:");
        bank_name.setText("Bank_Name:");
        bank_acc_no.setText("Bank Account Number:");
        bank_branch.setText("Bank Branch");
      } 
      else
       if(window.getValue().equals("Chart of Accounts")){
         first_names.setText("Account Group:"); 
        surname.setText("Cost Centre/Fund Unit:");
        contact_id.setText("Main Account Code:");
        id_no.setText("Sub Account Code:");
        country.setText("Account Status:");
        pin.setText("Account Description:");
        contact_type.setText("Main Category:");
        status.setText("Sub Category:");
        gender.setText("Sub Category Type:");
        occupation.setText("Contra Account:");
        source_of_income.setText("Account Number:");
        business_name.setText("Account/Fund Type:");
        business_branch.setText("Must Budget:");
        location.setText("Check Budget:");
        current_city.setText("Reconcile Account:");
        website.setText("Restrict Posting:");
        county.setText("Restrict to Owner:"); 
        bank_name.setText("Reconcile Group");
        bank_acc_no.setText("Budget Pattern");
        bank_branch.setText("Transaction Account");
        
       }
       else
           if(window.getValue().equals("Leasing")){
             first_names.setText("Lease Id:"); 
        surname.setText("Property Id:");
        contact_id.setText("End date:");
        id_no.setText("Contact Id:");
        country.setText("Lease Account:");
        pin.setText("Current lease/Rent:");
        contact_type.setText("Start Date:");
        status.setText("Lease Status:");
        gender.setText("Lease Type:");
        occupation.setText("Lease/Rent review date:");
        source_of_income.setText("Refundable Account:");
        business_name.setText("Non Refundable Account:");
        business_branch.setText("Penalty Date:");
        location.setText("Water Deposit Account:");
        current_city.setText("Electricity Deposit Account:");
        website.setText("Security Charges Account:");
        county.setText("Utility Charges Account:"); 
        bank_name.setText("Salesman Id");
        bank_acc_no.setText("Salesman Account:");
        bank_branch.setText("Default Inspector(Staff):");   
           }
       else{
           if(window.getValue().equals("Contact Details")){
        first_names.setText("First Names:"); 
        surname.setText("Surname:");
        contact_id.setText("Contact Id:");
        id_no.setText("Id No:");
        country.setText("Country:");
        pin.setText("Kra Pin:");
        contact_type.setText("Contact Type:");
        status.setText("Status:");
        gender.setText("Gender:");
        occupation.setText("Occupation:");
        source_of_income.setText("Source of Income:");
        business_name.setText("Business Name:");
        business_branch.setText("Business Branch:");
        location.setText("Location:");
        current_city.setText("Current City:");
        website.setText("Website:");
        county.setText("County:"); 
        bank_name.setText("Bank Name:");
        bank_acc_no.setText("Bank acc no:");
        bank_branch.setText("Bank Branch:");
           }
              
       }
               }
    
   
    
   
    
    }
         private  void initFX(JFXPanel fxPanel) {
        // This method is invoked on the JavaFX thread
      
         //  Scene scene = createScene();
          // fxPanel.setScene(scene);
     try {
          root5 = FXMLLoader.load(getClass().getResource("Search_Report_Engine.fxml"));
           scene2 = new Scene(root5, 1054, 750);
            scene2.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
            fxPanel.setScene(scene2);
           
        } catch (IOException exc) {
            exc.printStackTrace();
            System.exit(1);
        }
        
      
      
    }
         
            private  void initFX2() throws IOException {
        // This method is invoked on the JavaFX thread
      
          Scene scene4 = createScene();
          fxPanel.setScene(scene4);
  
        
      
      
    }
          @FXML
    void mouseClicked(ActionEvent event) throws IOException {
        if(window.getValue()!=null){
          
           loadReport();
            
            
            
        }
        else{
        //container.setStyle("-fx-background-color: yellow;");
       // display.setStyle(" -fx-font-size: 14px;");
       // display.setStyle("-fx-text-fill: red;");
      //  display.setText("Please select a window before proceeding!!");
      Image img = new Image("/images_/warning2.png");
      Notifications displayError = Notifications.create()
                        .title("Warning!!")
                        .text("Please select a window before proceeding!!")
                        .graphic(new ImageView(img))
                        .hideAfter(Duration.seconds(5))
                        .position(Pos.TOP_LEFT)
                        .onAction((ActionEvent event1) -> {
                        //System.out.println("Clicked on notification!");
            });  
            displayError.darkStyle();
            displayError.show();
          
        }
       
    }
    
     private static searchReports lr = null;  

 public static searchReports getobj(){
    
        if(lr == null){
        
            lr = new searchReports();
        }
        return lr;
    }
    
          @Override
    public void initialize(URL url, ResourceBundle rb) {
         loadComboBoxes();
   
         
    }
    
           public static void main(String[] args) {
         SwingUtilities.invokeLater(new Runnable() {
             @Override
            public void run() {
              
                searchReports test = new searchReports();
                test.initAndShowGUI();
                
                
                
               
                
            }
        });
        
         
    }
}
