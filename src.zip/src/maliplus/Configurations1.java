/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JSpinner.DefaultEditor;
import javax.swing.tree.TreePath;
import maliplus.detailsPanels.General_Message;
import maliplus.detailsPanels.Receipt_footer;
import maliplus.detailsPanels.TableDetails_Panel;
import net.sourceforge.jdatepicker.impl.JDatePanelImpl;
import net.sourceforge.jdatepicker.impl.JDatePickerImpl;
import net.sourceforge.jdatepicker.impl.UtilDateModel;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
//import static maliplus.Dynamic1.jTabbedPane1;
/**
 *
 * @author PSL-STUFF
 */
public class Configurations1 extends javax.swing.JFrame {
private static Configurations1 df=null;
public static JDialog jd9 = new JDialog(new JFrame(), true);
public static JDialog jd10 = new JDialog(new JFrame(), true);
static Connection conn = null;
static ResultSet rs = null;
static PreparedStatement pst = null;
static String selectedValue = null;
public   TreePath[] paths;    
 DefaultTreeModel treeModel;

     
    String update_configurations_table="Select "
            + "FULL_NAME,"
            + "ADDRESS,"
            + "CITY,"
            + "EMAIL_ADDRESS,"
            + "BUSINESS_TYPE,"
            + "TELEPHONES,"
            + "DEF_LOCATION,"
            + "COUNTRY_CODE,"
            + "CURRENCY_CODE,"
            + "C_AUTONUMBER,"
            + "S_AUTONUMBER,"
            + "RESET_ANNUALLY,"
            + "CUSTOMER_FORMAT,"
            + "CURRENT_CNUMBER,"
            + "CURRENT_SNUMBER,"
            + "SUPPLIER_FORMAT,"
            + "DATE_FORMAT,"
            + "TIME_FORMAT,"
            + "PERIOD_STATUS"
            + " from CONFIGURATIONS";
    
    
    
      String update_settings_table="Select "
              + "SETTING,"
              + "SETTING_NAME,"
              + "DATA_VALUE,"
              + "DATA_TYPE,"
              + "DATA_LENGTH,"
              + "LIST_ORDER,"
              + "CHECK_OPTION"
            + " from CONFIG_SETTINGS";
      
    
    public final void pop_tree() {
        try {
                
            try {
                conn = DBConnection.ConnectDB();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            
            ArrayList list = new ArrayList();
            list.add("MALIPLUS SETTINGS");
            String sql = "SELECT DESCRIPTION FROM SETTINGS_CODE_LIST";
 
            ResultSet rs = pst.executeQuery(sql);
 
            while (rs.next()) {
                Object value[] = {rs.getString(1)};
                list.add(value);
            }
            Object hierarchy[] = list.toArray();
            DefaultMutableTreeNode root = processHierarchy(hierarchy);
 
            DefaultTreeModel treeModel = new DefaultTreeModel(root);
            settings_tree.setModel(treeModel);
        } catch (Exception e) {
        }
 
    }
    
      @SuppressWarnings("CallToThreadDumpStack")
    public DefaultMutableTreeNode processHierarchy(Object[] hierarchy) {
        DefaultMutableTreeNode node = new DefaultMutableTreeNode(hierarchy[0]);
        try {
            int ctrow = 0;
            int i = 0;
            try {
 
                 try {
                    conn = DBConnection.ConnectDB();
                 
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                String sql = "SELECT DESCRIPTION from SETTINGS_CODE_LIST";
                ResultSet rs = pst.executeQuery(sql);
 
                while (rs.next()) {
                    ctrow = rs.getRow();
                }
                String L1Nam[] = new String[ctrow];
                String L1Id[] = new String[ctrow];
                ResultSet rs1 = pst.executeQuery(sql);
                while (rs1.next()) {
                    L1Nam[i] = rs1.getString("DESCRIPTION");
                    //L1Id[i] = rs1.getString("catid");
                    i++;
                }
              //  DefaultMutableTreeNode child, grandchild;
                //for (int childIndex = 0; childIndex < L1Nam.length; childIndex++) {
                  //  child = new DefaultMutableTreeNode(L1Nam[childIndex]);
                //    node.add(child);//add each created child to root
                //    String sql2 = "SELECT scatname from subcategory where catid= '" + L1Id[childIndex] + "' ";
                //    ResultSet rs3 = pst.executeQuery(sql2);
                  //  while (rs3.next()) {
                    ////    grandchild = new DefaultMutableTreeNode(rs3.getString("scatname"));
                 //       child.add(grandchild);//add each grandchild to each child
                 //   }
               // }
 
            } catch (Exception ex) {
                ex.printStackTrace();
            }
 
        } catch (Exception e) {
        }
 
        return (node);
    }
 
    void spinner_isnot_editable(){
      ((DefaultEditor) amount_dec_position.getEditor()).getTextField().setEditable(false);
       ((DefaultEditor) plu_code_start_position.getEditor()).getTextField().setEditable(false);
        ((DefaultEditor) plu_price_start_position.getEditor()).getTextField().setEditable(false);
         ((DefaultEditor) plu_decimal_position.getEditor()).getTextField().setEditable(false);
          ((DefaultEditor) plu_code_length.getEditor()).getTextField().setEditable(false);
           ((DefaultEditor) plu_price_length.getEditor()).getTextField().setEditable(false);
            ((DefaultEditor) current_period_year.getEditor()).getTextField().setEditable(false);
             ((DefaultEditor) current_period_month.getEditor()).getTextField().setEditable(false);
              ((DefaultEditor) end_year_month.getEditor()).getTextField().setEditable(false);
               ((DefaultEditor) default_sales_margin.getEditor()).getTextField().setEditable(false);
                ((DefaultEditor) max_sales_discount.getEditor()).getTextField().setEditable(false);
                 ((DefaultEditor) loyalty_point_amount.getEditor()).getTextField().setEditable(false);
                  ((DefaultEditor) loyalty_redeem_value.getEditor()).getTextField().setEditable(false);
    }
    
    void set_company_details_when_window_is_opened(){
        
        int row=configuration_table.getSelectedRow();
       // fullname.setText(configuration_table.getModel().getValueAt(row, 0).toString());
       // postal_address.setText(configuration_table.getModel().getValueAt(row, 1).toString());
      //  city.setSelectedItem(configuration_table.getModel().getValueAt(row, 2).toString());
      //  email_address.setText(configuration_table.getModel().getValueAt(row, 3).toString());
      //  business_type.setText(configuration_table.getModel().getValueAt(row, 4).toString());
      //  telephone_number.setText(configuration_table.getModel().getValueAt(row, 5).toString());
     //   default_location_code.setText(configuration_table.getModel().getValueAt(row,6).toString());
     //   country_code.setText(configuration_table.getModel().getValueAt(row,7).toString());
     //   local_currency.setText(configuration_table.getModel().getValueAt(row,8).toString());
     //   auto_customer_number.setText(configuration_table.getModel().getValueAt(row,9).toString());
        //auto_supplier_number.setText(configuration_table.getModel().getValueAt(row,10).toString());
        //reset_at_year_end.setText(configuration_table.getModel().getValueAt(row,11).toString());
       // customer_number_format.setText(configuration_table.getModel().getValueAt(row,12).toString()); 
      //  customer_current_start_number.setText(configuration_table.getModel().getValueAt(row,13).toString()); 
     //   supplier_current_start_number.setText(configuration_table.getModel().getValueAt(row,14).toString()); 
       // supplier_number_format.setText(configuration_table.getModel().getValueAt(row,15).toString());
     //   date_format.setText(configuration_table.getModel().getValueAt(row,16).toString());
      //  time_format.setText(configuration_table.getModel().getValueAt(row,17).toString());
      //  period_status.setText(configuration_table.getModel().getValueAt(row,18).toString());
        
      
        String check_status1 = DBConnection.global_resultSet("select plucode_start from configurations where full_name = '"+configuration_table.getValueAt(row, 0)+"'");
        plu_code_start_position.setValue(Integer.valueOf(check_status1));
        
        String check_status2 = DBConnection.global_resultSet("select plucode_length from configurations where full_name = '"+configuration_table.getValueAt(row, 0)+"'");
        plu_code_length.setValue(Integer.valueOf(check_status2));
        
        String check_status3 = DBConnection.global_resultSet("select pluprice_start from configurations where full_name = '"+configuration_table.getValueAt(row, 0)+"'");
        plu_price_start_position.setValue(Integer.valueOf(check_status3));
        
        String check_status4 = DBConnection.global_resultSet("select pluprice_length from configurations where full_name = '"+configuration_table.getValueAt(row, 0)+"'");
        plu_price_length.setValue(Integer.valueOf(check_status4));
        
        String check_status5 = DBConnection.global_resultSet("select decimal_positions from configurations where full_name = '"+configuration_table.getValueAt(row, 0)+"'");
        amount_dec_position.setValue(Integer.valueOf(check_status5));
        
        String check_status6 = DBConnection.global_resultSet("select plucode_prefix from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        plu_prefix.setText(check_status6);
        
         String check_status7 = DBConnection.global_resultSet("select sms_number from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        sms_mobile_number.setText(check_status7);
        
        String check_status8 = DBConnection.global_resultSet("select pin_code from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        pin_number.setText(check_status8);
        
        String check_status9 = DBConnection.global_resultSet("select vat_number from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        vat_number.setText(check_status9);
        
        String check_status10 = DBConnection.global_resultSet("select reg_number from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        registration_number.setText(check_status10);
        
        String check_status11 = DBConnection.global_resultSet("select barcode_type from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        default_barcode_type.setText(check_status11);
        
        String check_status12 = DBConnection.global_resultSet("select barcode_isitem from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        barcode_isitem.setText(check_status12);
        
         String check_status13 = DBConnection.global_resultSet("select general_text from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        general_message.setText(check_status13);
        
         String check_status14 = DBConnection.global_resultSet("select receipt_text from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        receipt_footer.setText(check_status14);
        
        
        String check_status15 = DBConnection.global_resultSet("select end_year_month from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        end_year_month.setValue(Integer.valueOf(15));
        
        String check_status16 = DBConnection.global_resultSet("select fiscal_year from configurations where full_name = '"+configuration_table.getValueAt(row, 0)+"'");
        current_period_year.setValue(Integer.valueOf(check_status16));
        
        String check_status17 = DBConnection.global_resultSet("select fiscal_month from configurations where full_name = '"+configuration_table.getValueAt(row, 0)+"'");
        current_period_month.setValue(Integer.valueOf(check_status17));
        
        String check_status18 = DBConnection.global_resultSet("select fiscal_start_date from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        datePicker.getJFormattedTextField().setText(check_status18);
        
        String check_status19 = DBConnection.global_resultSet("select fiscal_end_date from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        datePicker2.getJFormattedTextField().setText(check_status19);
        
         String check_status20 = DBConnection.global_resultSet("select next_fiscal_start from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        datePicker3.getJFormattedTextField().setText(check_status20);
        
        String check_status21 = DBConnection.global_resultSet("select next_fiscal_end from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        datePicker4.getJFormattedTextField().setText(check_status21);
        
       automatically_select_check_box_values();
    }
    
     static void automatically_select_check_box_values(){
     int row=configuration_table.getSelectedRow();
      String check_status = DBConnection.global_resultSet("select c_autonumber from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
       if(check_status.equals("Y")){ 
       
       auto_customer_number.setSelected(true);
       auto_customer_number.setText("Y");
       }
       else {
           auto_customer_number.setSelected(false);
            auto_customer_number.setText("N");
        }
       
       String check_status2 = DBConnection.global_resultSet("select s_autonumber from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
       if(check_status2.equals("Y")){ 
       
      auto_supplier_number.setSelected(true);
      auto_supplier_number.setText("Y");
       }
       else {
           auto_supplier_number.setSelected(false);
            auto_supplier_number.setText("N");
        }
       
       String check_status3 = DBConnection.global_resultSet("select reset_annually from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        if(check_status3.equals("Y")){ 
       
      reset_at_year_end.setSelected(true);
      reset_at_year_end.setText("Y");
       }
       else {
           reset_at_year_end.setSelected(false);
            reset_at_year_end.setText("N");
        }
        
        String check_status4 = DBConnection.global_resultSet("select barcode_isitem from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        if(check_status4.equals("Y")){ 
       
      barcode_isitem.setSelected(true);
      barcode_isitem.setText("Y");
       }
       else {
          barcode_isitem.setSelected(false);
          barcode_isitem.setText("N");
        }
        
       
     }
    /**
     * Creates new form Configurations1
     */
    public UtilDateModel model = new UtilDateModel();
    public UtilDateModel mode2 = new UtilDateModel();
    public UtilDateModel mode3 = new UtilDateModel();
    public UtilDateModel mode4 = new UtilDateModel();
    
    public JDatePanelImpl datePanel = new JDatePanelImpl(model);
    public JDatePanelImpl datePane2 = new JDatePanelImpl(mode2);
    public JDatePanelImpl datePane3 = new JDatePanelImpl(mode3);
    public JDatePanelImpl datePane4 = new JDatePanelImpl(mode4);
    
    public JDatePickerImpl datePicker = new JDatePickerImpl(datePanel, new DateLabelFormatter1());
    public JDatePickerImpl datePicker2 = new JDatePickerImpl(datePane2, new DateLabelFormatter1());
    public JDatePickerImpl datePicker3 = new JDatePickerImpl(datePane3, new DateLabelFormatter1());
    public JDatePickerImpl datePicker4 = new JDatePickerImpl(datePane4, new DateLabelFormatter1());
    
     public static void FillCombo(){
     String cities = "CITIES";
        String sub_code = "###";
            
       
       String sql2=  "SELECT DESCRIPTION from list_control where reference_code = '"+ cities +"' AND sub_code='"+sub_code+"'";
           
    try{
        pst=conn.prepareStatement(sql2);
        rs=pst.executeQuery();
        while(rs.next()){
            String nme =rs.getString("DESCRIPTION");
            city.addItem(nme);
        }
    }
        catch (Exception e){
         JOptionPane.showMessageDialog(null,e);
       
    } 
    }
       public void dateP1() {
        try {

            period_start_date.setLayout(new java.awt.BorderLayout());
            period_start_date.add(datePicker);
            period_start_date.revalidate();
            period_start_date.repaint();
            //System.out.println(datePicker.getComponentListeners());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public void dateP2() {
        try {

           period_end_date.setLayout(new java.awt.BorderLayout());
            period_end_date.add(datePicker2);
           period_end_date.revalidate();
            period_end_date.repaint();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public void dateP3() {

        try {

            next_start_date.setLayout(new java.awt.BorderLayout());
            next_start_date.add(datePicker3);
            next_start_date.revalidate();
            next_start_date.repaint();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public void dateP4() {

        try {

            next_end_date.setLayout(new java.awt.BorderLayout());
            next_end_date.add(datePicker4);
            next_end_date.revalidate();
            next_end_date.repaint();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
 public static Configurations1 getObj() {

        if (df == null) {

            df = new Configurations1();
        }
        return df;

    }
 

 

    public Configurations1() {
        initComponents();
        jTabbedPane1.setSelectedIndex(2);
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jToolBar1 = new javax.swing.JToolBar();
        save = new javax.swing.JButton();
        update = new javax.swing.JButton();
        search = new javax.swing.JButton();
        export = new javax.swing.JButton();
        clear = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        codelist = new javax.swing.JButton();
        go_back = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        fullname = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        postal_address = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        city = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        business_type = new javax.swing.JTextField();
        telephone_number = new javax.swing.JTextField();
        email_address = new javax.swing.JTextField();
        default_location_code = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        country_code = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        local_currency = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        customer_number_format = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        customer_current_start_number = new javax.swing.JTextField();
        supplier_current_start_number = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        supplier_number_format = new javax.swing.JTextField();
        number_pattern = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        reset_at_year_end = new javax.swing.JCheckBox();
        jLabel17 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        digit_year_number = new javax.swing.JCheckBox();
        auto_supplier_number = new javax.swing.JCheckBox();
        jLabel15 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        auto_customer_number = new javax.swing.JCheckBox();
        jPanel7 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        period_status = new javax.swing.JTextField();
        current_period_year = new javax.swing.JSpinner();
        current_period_month = new javax.swing.JSpinner();
        end_year_month = new javax.swing.JSpinner();
        jLabel31 = new javax.swing.JLabel();
        date_format = new javax.swing.JTextField();
        jPanel9 = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        time_format = new javax.swing.JTextField();
        period_start_date = new javax.swing.JPanel();
        period_end_date = new javax.swing.JPanel();
        next_start_date = new javax.swing.JPanel();
        next_end_date = new javax.swing.JPanel();
        jSeparator2 = new javax.swing.JSeparator();
        jPanel10 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        sms_mobile_number = new javax.swing.JTextField();
        pin_number = new javax.swing.JTextField();
        vat_number = new javax.swing.JTextField();
        registration_number = new javax.swing.JTextField();
        receipt_footer = new javax.swing.JTextField();
        general_message = new javax.swing.JTextField();
        amount_dec_position = new javax.swing.JSpinner();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        barcode_isitem = new javax.swing.JCheckBox();
        default_barcode_type = new javax.swing.JTextField();
        jPanel13 = new javax.swing.JPanel();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        use_plu = new javax.swing.JCheckBox();
        plu_code_start_position = new javax.swing.JSpinner();
        plu_price_start_position = new javax.swing.JSpinner();
        plu_decimal_position = new javax.swing.JSpinner();
        jLabel53 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        plu_code_length = new javax.swing.JSpinner();
        plu_price_length = new javax.swing.JSpinner();
        plu_prefix = new javax.swing.JTextField();
        jPanel14 = new javax.swing.JPanel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        price_include_tax = new javax.swing.JCheckBox();
        discount_input_in_atm = new javax.swing.JCheckBox();
        use_last_buy_price = new javax.swing.JCheckBox();
        default_sales_margin = new javax.swing.JSpinner();
        max_sales_discount = new javax.swing.JSpinner();
        loyalty_point_amount = new javax.swing.JSpinner();
        loyalty_redeem_value = new javax.swing.JSpinner();
        jLabel63 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        settings_panel = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        settings_tree = new javax.swing.JTree();
        icon_changer = new javax.swing.JLabel();
        display = new javax.swing.JTextField();
        display_label = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        settings_table = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;}
        };
        configuration_table_panel = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        configuration_table = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;}
        };
        display_message = new javax.swing.JLabel();
        setting_name = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Configuration Form");
        setMinimumSize(new java.awt.Dimension(11400, 1000));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jToolBar1.setRollover(true);

        save.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/new.PNG"))); // NOI18N
        save.setToolTipText("Insert new record");
        save.setFocusable(false);
        save.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        save.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        save.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                saveMouseClicked(evt);
            }
        });
        jToolBar1.add(save);

        update.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Actions-document-save-all-icon2.png"))); // NOI18N
        update.setToolTipText("Update Record");
        update.setFocusable(false);
        update.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        update.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        update.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                updateMouseClicked(evt);
            }
        });
        jToolBar1.add(update);

        search.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        search.setToolTipText("Search record");
        search.setFocusable(false);
        search.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        search.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jToolBar1.add(search);

        export.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/excel_icon.jpg"))); // NOI18N
        export.setToolTipText("Export to excel");
        export.setFocusable(false);
        export.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        export.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jToolBar1.add(export);

        clear.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/issue_returns_icon.png"))); // NOI18N
        clear.setToolTipText("Clear fields ");
        clear.setFocusable(false);
        clear.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        clear.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearActionPerformed(evt);
            }
        });
        jToolBar1.add(clear);

        delete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/delete3.png"))); // NOI18N
        delete.setToolTipText("Delete");
        delete.setFocusable(false);
        delete.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        delete.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });
        jToolBar1.add(delete);

        codelist.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/code_list_icon.jpg"))); // NOI18N
        codelist.setToolTipText("Configurations code list");
        codelist.setFocusable(false);
        codelist.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        codelist.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        codelist.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                codelistActionPerformed(evt);
            }
        });
        jToolBar1.add(codelist);

        go_back.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/back_icon.PNG"))); // NOI18N
        go_back.setToolTipText("Go back one page");
        go_back.setFocusable(false);
        go_back.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        go_back.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        go_back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                go_backActionPerformed(evt);
            }
        });
        jToolBar1.add(go_back);

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, new java.awt.Color(255, 255, 51), null));
        jPanel2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jPanel2FocusLost(evt);
            }
        });

        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(51, 0, 255), null));

        jLabel1.setText("Full Name:");

        fullname.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                fullnameMouseClicked(evt);
            }
        });

        jLabel2.setText("Postal Address:");

        postal_address.setColumns(20);
        postal_address.setRows(5);
        jScrollPane1.setViewportView(postal_address);

        jLabel3.setText("City/Town:");

        city.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                cityPopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(21, 21, 21)))
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(fullname, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(city, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(0, 16, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(fullname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(city, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(30, Short.MAX_VALUE))
        );

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 0, 204), null));

        jLabel4.setText("Business Type:");

        jLabel5.setText("Telephone Number:");

        jLabel6.setText("Email Address:");

        jLabel7.setText("Default Location Code");

        jLabel8.setText("Country Code:");

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel9MouseClicked(evt);
            }
        });

        default_location_code.setText("INVENTORY");

        jLabel10.setText("INVENTORY will be used if left blank.");

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel11MouseClicked(evt);
            }
        });

        country_code.setText("AFR");

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        jLabel12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel12MouseClicked(evt);
            }
        });

        local_currency.setText("USD");

        jLabel13.setText("Local Currency:");

        jLabel14.setText("INTL. Codes");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 118, Short.MAX_VALUE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(business_type)
                            .addComponent(telephone_number)
                            .addComponent(email_address)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(default_location_code, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(country_code, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(local_currency, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(telephone_number, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(email_address, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(business_type, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(default_location_code, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(country_code, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel12)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(local_currency, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, new java.awt.Color(51, 255, 255), null), "", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(0, 0, 204))); // NOI18N

        jPanel6.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 0, 255), null));

        customer_number_format.setText("PLAIN");

        jLabel24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        jLabel24.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel24MouseClicked(evt);
            }
        });

        jLabel20.setText("Customer No format:");

        jLabel23.setText("Current/Start Number:");

        customer_current_start_number.setText("1");

        supplier_current_start_number.setText("1");

        jLabel19.setText("Current/Start Number:");

        jLabel21.setText("Supplier No Format:");

        jLabel25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        jLabel25.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel25MouseClicked(evt);
            }
        });

        jLabel22.setText("Number pattern # or 0:");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel24))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel19, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel21, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel22, javax.swing.GroupLayout.Alignment.LEADING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel25)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(supplier_number_format, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(number_pattern, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(customer_number_format, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(customer_current_start_number, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(supplier_current_start_number, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(customer_number_format, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel24))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(supplier_current_start_number, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(supplier_number_format, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(number_pattern, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabel25)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(customer_current_start_number, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(97, 97, 97)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 0, 153), null), "NUMBERING:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(0, 0, 153))); // NOI18N

        reset_at_year_end.setText("N");
        reset_at_year_end.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reset_at_year_endActionPerformed(evt);
            }
        });

        jLabel17.setText("Reset at Year End:");

        jLabel16.setText("Use 2 Digit Year Number");

        digit_year_number.setText("N");
        digit_year_number.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                digit_year_numberActionPerformed(evt);
            }
        });

        auto_supplier_number.setText("N");
        auto_supplier_number.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                auto_supplier_numberActionPerformed(evt);
            }
        });

        jLabel15.setText("Auto Supplier Number:");

        jLabel18.setText("Auto Customer Number:");

        auto_customer_number.setText("N");
        auto_customer_number.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                auto_customer_numberActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jLabel15, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel16, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel17, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(digit_year_number)
                    .addComponent(reset_at_year_end)
                    .addComponent(auto_customer_number)
                    .addComponent(auto_supplier_number))
                .addContainerGap(25, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(auto_customer_number))
                .addGap(4, 4, 4)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(auto_supplier_number))
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(digit_year_number))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(reset_at_year_end))
                .addGap(0, 95, Short.MAX_VALUE))
        );

        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 0, 153), null), "ACCOUNTING:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(51, 0, 204))); // NOI18N

        jLabel26.setText("Current Period Year:");

        jLabel27.setText("Current Period Month:");

        jLabel28.setText("End Year Month:");

        jLabel29.setText("Period Status:");

        jLabel30.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        jLabel30.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel30MouseClicked(evt);
            }
        });

        period_status.setText("OPN");

        jLabel31.setText("Date Format:");

        date_format.setText("dd/MM/YY");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel27)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(current_period_month))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel30)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(period_status, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(current_period_year)
                            .addComponent(date_format)))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(end_year_month)))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel31)
                    .addComponent(date_format, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(current_period_year, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(current_period_month, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(end_year_month, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel30)
                    .addComponent(period_status, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(66, Short.MAX_VALUE))
        );

        jPanel9.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 51, 204), null));

        jLabel32.setText("Time Format:");

        time_format.setText("hh:mm:ss:tt");

        period_start_date.setBorder(javax.swing.BorderFactory.createTitledBorder("Period Start Date"));
        period_start_date.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                period_start_dateMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout period_start_dateLayout = new javax.swing.GroupLayout(period_start_date);
        period_start_date.setLayout(period_start_dateLayout);
        period_start_dateLayout.setHorizontalGroup(
            period_start_dateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        period_start_dateLayout.setVerticalGroup(
            period_start_dateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        period_end_date.setBorder(javax.swing.BorderFactory.createTitledBorder("Period End Date"));
        period_end_date.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                period_end_dateMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout period_end_dateLayout = new javax.swing.GroupLayout(period_end_date);
        period_end_date.setLayout(period_end_dateLayout);
        period_end_dateLayout.setHorizontalGroup(
            period_end_dateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        period_end_dateLayout.setVerticalGroup(
            period_end_dateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        next_start_date.setBorder(javax.swing.BorderFactory.createTitledBorder("Next Start Date"));
        next_start_date.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                next_start_dateMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout next_start_dateLayout = new javax.swing.GroupLayout(next_start_date);
        next_start_date.setLayout(next_start_dateLayout);
        next_start_dateLayout.setHorizontalGroup(
            next_start_dateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        next_start_dateLayout.setVerticalGroup(
            next_start_dateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 12, Short.MAX_VALUE)
        );

        next_end_date.setBorder(javax.swing.BorderFactory.createTitledBorder("Next End Date"));
        next_end_date.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                next_end_dateMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout next_end_dateLayout = new javax.swing.GroupLayout(next_end_date);
        next_end_date.setLayout(next_end_dateLayout);
        next_end_dateLayout.setHorizontalGroup(
            next_end_dateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        next_end_dateLayout.setVerticalGroup(
            next_end_dateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(next_start_date, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(period_end_date, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(period_start_date, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(time_format, javax.swing.GroupLayout.DEFAULT_SIZE, 235, Short.MAX_VALUE))
                    .addComponent(next_end_date, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(time_format, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(period_start_date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(period_end_date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(next_start_date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(next_end_date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(115, 115, 115))
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, 235, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel10.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 0, 204), null));

        jPanel11.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 0, 204), null), "Operations Configurations:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(0, 0, 153))); // NOI18N
        jPanel11.setForeground(new java.awt.Color(0, 0, 204));

        jLabel37.setText("SMS Mobile Number:");

        jLabel38.setText("Pin Number:");

        jLabel39.setText("VAT Number:");

        jLabel40.setText("Registration Number:");

        jLabel41.setText("Amount Dec Position");

        jLabel42.setText("Receipt Footer:");

        jLabel43.setText("General Message:");

        receipt_footer.setEditable(false);

        general_message.setEditable(false);

        jLabel44.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/ledger_accounts_icon.jpg"))); // NOI18N
        jLabel44.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel44MouseClicked(evt);
            }
        });

        jLabel45.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/ledger_accounts_icon.jpg"))); // NOI18N
        jLabel45.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel45MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addComponent(jLabel43, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel45))
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addComponent(jLabel42, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel44)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(general_message)
                            .addComponent(receipt_footer)))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jLabel41, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel40, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE))
                            .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(27, 27, 27)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(sms_mobile_number)
                            .addComponent(pin_number)
                            .addComponent(vat_number)
                            .addComponent(registration_number)
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addComponent(amount_dec_position, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addGap(10, 10, 10))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel37)
                    .addComponent(sms_mobile_number, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel38)
                    .addComponent(pin_number, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel39)
                    .addComponent(vat_number, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel40)
                    .addComponent(registration_number, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel41)
                    .addComponent(amount_dec_position, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel42)
                    .addComponent(receipt_footer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel44))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel43)
                    .addComponent(general_message, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel45))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        jPanel12.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 0, 204), null), "Barcodes:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(0, 0, 204))); // NOI18N

        jLabel46.setText("Default Barcode Type:");

        jLabel47.setText("Barcode and Item are the same:");

        jLabel48.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        jLabel48.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel48MouseClicked(evt);
            }
        });

        barcode_isitem.setText("N");
        barcode_isitem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                barcode_isitemActionPerformed(evt);
            }
        });

        default_barcode_type.setText("EAN 13");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addComponent(jLabel47, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(barcode_isitem))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel48)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(default_barcode_type, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 47, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel48, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel46, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(default_barcode_type, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel47, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(barcode_isitem))
                .addGap(0, 8, Short.MAX_VALUE))
        );

        jPanel13.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 0, 204), null), "Price Look Up:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(0, 0, 204))); // NOI18N

        jLabel49.setText("Use price look up(PLU):");

        jLabel50.setText("Price Look up Code start position:");

        jLabel51.setText("Price look up Decimal position:");

        jLabel52.setText("Price Look up Value start position:");

        use_plu.setText("N");
        use_plu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                use_pluActionPerformed(evt);
            }
        });

        jLabel53.setText("Length:");

        jLabel54.setText("Length:");

        jLabel55.setText("PLU Prefix:");

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addComponent(jLabel49, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(use_plu))
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addComponent(jLabel51, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(plu_decimal_position))
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addComponent(jLabel50, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(plu_code_start_position, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addComponent(jLabel52, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(plu_price_start_position)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel55)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(plu_prefix, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel13Layout.createSequentialGroup()
                                        .addComponent(jLabel53)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(plu_code_length))
                                    .addGroup(jPanel13Layout.createSequentialGroup()
                                        .addComponent(jLabel54)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(plu_price_length, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addGap(0, 44, Short.MAX_VALUE))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel49, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(use_plu))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel50, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(plu_code_start_position, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel53)
                    .addComponent(plu_code_length, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel52, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(plu_price_start_position, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel54)
                    .addComponent(plu_price_length, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(plu_decimal_position, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel51, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel55)
                    .addComponent(plu_prefix, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel14.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 0, 204), null), "Extra Information:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(51, 0, 153))); // NOI18N

        jLabel56.setText("Price Include Tax:");

        jLabel57.setText("Discount Input in ATM:");

        jLabel58.setText("Default sales margin:");

        jLabel59.setText("Use last Buy price:");

        jLabel60.setText("Max sales discount %:");

        jLabel61.setText("Loyalty point amount:");

        jLabel62.setText("Loyalty redeem value:");

        price_include_tax.setText("N");
        price_include_tax.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                price_include_taxActionPerformed(evt);
            }
        });

        discount_input_in_atm.setText("N");
        discount_input_in_atm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                discount_input_in_atmActionPerformed(evt);
            }
        });

        use_last_buy_price.setText("N");
        use_last_buy_price.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                use_last_buy_priceActionPerformed(evt);
            }
        });

        jLabel63.setText("Input/Display");

        jLabel64.setText("In Average Costing");

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addComponent(jLabel58)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(default_sales_margin, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel62, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel61, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel60, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(max_sales_discount, javax.swing.GroupLayout.DEFAULT_SIZE, 64, Short.MAX_VALUE)
                            .addComponent(loyalty_point_amount)
                            .addComponent(loyalty_redeem_value)))
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel57)
                            .addComponent(jLabel59, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel56, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(use_last_buy_price, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(discount_input_in_atm, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(price_include_tax, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel63, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel64, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 179, Short.MAX_VALUE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel56)
                    .addComponent(price_include_tax))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel57)
                    .addComponent(discount_input_in_atm)
                    .addComponent(jLabel63))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel59)
                    .addComponent(use_last_buy_price)
                    .addComponent(jLabel64))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel58)
                    .addComponent(default_sales_margin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel60)
                    .addComponent(max_sales_discount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel61)
                    .addComponent(loyalty_point_amount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel62)
                    .addComponent(loyalty_redeem_value, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel10Layout.createSequentialGroup()
                        .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(0, 25, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jSeparator2)
                    .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Details", jPanel2);

        settings_panel.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                settings_panelFocusGained(evt);
            }
        });

        jPanel15.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 0, 153), null));
        jPanel15.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jPanel15FocusGained(evt);
            }
        });

        javax.swing.tree.DefaultMutableTreeNode treeNode1 = new javax.swing.tree.DefaultMutableTreeNode("MALIPLUS SETTINGS");
        javax.swing.tree.DefaultMutableTreeNode treeNode2 = new javax.swing.tree.DefaultMutableTreeNode("Expire Username");
        treeNode1.add(treeNode2);
        treeNode2 = new javax.swing.tree.DefaultMutableTreeNode("Allow predated accounting fiscal periods");
        treeNode1.add(treeNode2);
        treeNode2 = new javax.swing.tree.DefaultMutableTreeNode("Disable remove of assets from register");
        treeNode1.add(treeNode2);
        treeNode2 = new javax.swing.tree.DefaultMutableTreeNode("Sale Orders");
        treeNode1.add(treeNode2);
        treeNode2 = new javax.swing.tree.DefaultMutableTreeNode("Ledger Accounts");
        treeNode1.add(treeNode2);
        treeNode2 = new javax.swing.tree.DefaultMutableTreeNode("Customer ledger records should not be deleted");
        treeNode1.add(treeNode2);
        treeNode2 = new javax.swing.tree.DefaultMutableTreeNode("Expire Password on Reset");
        treeNode1.add(treeNode2);
        treeNode2 = new javax.swing.tree.DefaultMutableTreeNode("Expire Username on reset");
        treeNode1.add(treeNode2);
        treeNode2 = new javax.swing.tree.DefaultMutableTreeNode("Reset employee Records");
        treeNode1.add(treeNode2);
        treeNode2 = new javax.swing.tree.DefaultMutableTreeNode("Reset ledgers");
        treeNode1.add(treeNode2);
        settings_tree.setModel(new javax.swing.tree.DefaultTreeModel(treeNode1));
        settings_tree.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        settings_tree.addTreeSelectionListener(new javax.swing.event.TreeSelectionListener() {
            public void valueChanged(javax.swing.event.TreeSelectionEvent evt) {
                settings_treeValueChanged(evt);
            }
        });
        jScrollPane2.setViewportView(settings_tree);

        icon_changer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N

        display.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                displayMouseClicked(evt);
            }
        });
        display.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                displayKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                displayKeyTyped(evt);
            }
        });

        display_label.setFont(new java.awt.Font("Utsaah", 1, 24)); // NOI18N

        jPanel16.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, new java.awt.Color(0, 51, 204), null));

        settings_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        settings_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                settings_tableMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                settings_tableMousePressed(evt);
            }
        });
        jScrollPane3.setViewportView(settings_table);

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 827, Short.MAX_VALUE)
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 702, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(icon_changer)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(display, javax.swing.GroupLayout.PREFERRED_SIZE, 331, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(display_label, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(icon_changer)
                            .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(display, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(display_label, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 732, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout settings_panelLayout = new javax.swing.GroupLayout(settings_panel);
        settings_panel.setLayout(settings_panelLayout);
        settings_panelLayout.setHorizontalGroup(
            settings_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(settings_panelLayout.createSequentialGroup()
                .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        settings_panelLayout.setVerticalGroup(
            settings_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(settings_panelLayout.createSequentialGroup()
                .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Settings", settings_panel);

        configuration_table_panel.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                configuration_table_panelFocusGained(evt);
            }
        });

        configuration_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        configuration_table.setMinimumSize(new java.awt.Dimension(1500, 800));
        configuration_table.setPreferredSize(new java.awt.Dimension(1500, 800));
        configuration_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                configuration_tableMousePressed(evt);
            }
        });
        jScrollPane5.setViewportView(configuration_table);

        javax.swing.GroupLayout configuration_table_panelLayout = new javax.swing.GroupLayout(configuration_table_panel);
        configuration_table_panel.setLayout(configuration_table_panelLayout);
        configuration_table_panelLayout.setHorizontalGroup(
            configuration_table_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(configuration_table_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 1129, Short.MAX_VALUE)
                .addContainerGap())
        );
        configuration_table_panelLayout.setVerticalGroup(
            configuration_table_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(configuration_table_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 649, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Configuration Table", configuration_table_panel);

        display_message.setFont(new java.awt.Font("DialogInput", 1, 18)); // NOI18N
        display_message.setForeground(new java.awt.Color(51, 0, 204));

        setting_name.setEnabled(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jToolBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(display_message, javax.swing.GroupLayout.PREFERRED_SIZE, 712, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(setting_name, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(jTabbedPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jToolBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(display_message, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(setting_name, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void updateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updateMouseClicked
        // TODO add your handling code here:
        if(jPanel2.isShowing()==true){
            int row=configuration_table.getSelectedRow();
            String sql="update configurations set"
                    + " FULL_NAME='"+fullname.getText()+"',"
                    + "ADDRESS='"+postal_address.getText()+"',"
                    + "CITY='"+city.getSelectedItem()+"',"
                    + "EMAIL_ADDRESS='"+email_address.getText()+"',"
                    + "BUSINESS_TYPE='"+business_type.getText()+"',"
                    + "TELEPHONES='"+telephone_number.getText()+"',"
                    + "DEF_LOCATION='"+default_location_code.getText()+"',"
                    + "COUNTRY_CODE='"+country_code.getText()+"',"
                    + "CURRENCY_CODE='"+local_currency.getText()+"',"
                    + "C_AUTONUMBER='"+auto_customer_number.getText()+"',"
                    + "S_AUTONUMBER='"+auto_supplier_number.getText()+"',"
                    + "RESET_ANNUALLY='"+reset_at_year_end.getText()+"',"
                    + "CUSTOMER_FORMAT='"+customer_number_format.getText()+"',"
                    + "CURRENT_CNUMBER='"+customer_current_start_number.getText()+"',"
                    + "CURRENT_SNUMBER='"+supplier_current_start_number.getText()+"',"
                    + "SUPPLIER_FORMAT='"+supplier_number_format.getText()+"',"
                    + "DATE_FORMAT='"+date_format.getText()+"',"
                    + "TIME_FORMAT='"+time_format.getText()+"',"
                    + "PERIOD_STATUS='"+period_status.getText()+"',"
                    + "PLUCODE_START='"+plu_code_start_position.getValue()+"',"
                    + "PLUCODE_LENGTH='"+plu_code_length.getValue()+"',"
                    + "PLUPRICE_START='"+plu_price_start_position.getValue()+"',"
                    + "PLUPRICE_LENGTH='"+plu_price_length.getValue()+"',"
                    + "PLUPRICE_DECIMALS='"+plu_decimal_position.getValue()+"',"
                    + "DECIMAL_POSITIONS='"+amount_dec_position.getValue()+"',"
                    + "PLUCODE_PREFIX='"+plu_prefix.getText()+"',"
                    + "SMS_NUMBER='"+sms_mobile_number.getText()+"',"
                    + "PIN_CODE='"+pin_number.getText()+"',"
                    + "VAT_NUMBER='"+vat_number.getText()+"',"
                    + "REG_NUMBER='"+registration_number.getText()+"',"
                    + "BARCODE_TYPE='"+default_barcode_type.getText()+"',"
                    + "BARCODE_ISITEM='"+barcode_isitem.getText()+"',"
                    + "GENERAL_TEXT='"+general_message.getText()+"',"
                    + "RECEIPT_TEXT='"+receipt_footer.getText()+"',"
                    + "END_YEAR_MONTH='"+end_year_month.getValue()+"',"
                    + "FISCAL_YEAR='"+current_period_year.getValue()+"',"
                    + "FISCAL_MONTH='"+current_period_month.getValue()+"',"
                    + "FISCAL_START_DATE='"+datePicker.getJFormattedTextField().getText()+"',"
                    + "FISCAL_END_DATE='"+datePicker2.getJFormattedTextField().getText()+"',"
                    + "NEXT_FISCAL_START='"+datePicker3.getJFormattedTextField().getText()+"',"
                    + "NEXT_FISCAL_END='"+datePicker4.getJFormattedTextField().getText()+"' WHERE full_name = '"+fullname.getText()+"'";
           
           try{
               pst=conn.prepareStatement(sql);
               pst.execute();
               DBConnection.update_table(update_configurations_table, configuration_table);
               display_message.setForeground(java.awt.Color.BLUE);
               display_message.setText("Record updated successfully!!");
           }
           catch(Exception e){
               e.printStackTrace();
                display_message.setForeground(java.awt.Color.RED);
               display_message.setText("Record not updated successfully!!");
           }
        }
  
    }//GEN-LAST:event_updateMouseClicked

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        // TODO add your handling code here:
        
        
        conn = DBConnection.ConnectDB();
        FillCombo();
        dateP1();
        dateP2();
        dateP3();
        dateP4();
       
       DBConnection.update_table(update_configurations_table, configuration_table);
       DBConnection.update_table(update_settings_table, settings_table);
       spinner_isnot_editable();
       maliplus.DisplayCategory.main(null);
       
      
    }//GEN-LAST:event_formWindowOpened

    private void next_end_dateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_next_end_dateMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_next_end_dateMouseClicked

    private void next_start_dateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_next_start_dateMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_next_start_dateMouseClicked

    private void period_end_dateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_period_end_dateMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_period_end_dateMouseClicked

    private void period_start_dateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_period_start_dateMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_period_start_dateMouseClicked

    private void auto_customer_numberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_auto_customer_numberActionPerformed
        // TODO add your handling code here:
        if(auto_customer_number.isSelected()==true){
            auto_customer_number.setText("Y");
        }
        else{
            auto_customer_number.setText("N"); 
        }
    }//GEN-LAST:event_auto_customer_numberActionPerformed

    private void saveMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_saveMouseClicked
        // TODO add your handling code here:
        if(evt.getSource()==save){
            if(jPanel2.isShowing()==true){
             if(!"".equals(fullname.getText())){
                String sql="insert into configurations("
                + "FULL_NAME,"
                + "ADDRESS,"
                + "CITY,"
                + "EMAIL_ADDRESS,"
                + "BUSINESS_TYPE,"
                + "TELEPHONES,"
                + "DEF_LOCATION,"
                + "COUNTRY_CODE,"
                + "CURRENCY_CODE,"
                + "C_AUTONUMBER,"
                + "S_AUTONUMBER,"
                + "RESET_ANNUALLY,"
                + "CUSTOMER_FORMAT,"
                + "CURRENT_CNUMBER,"
                + "CURRENT_SNUMBER,"
                + "SUPPLIER_FORMAT,"
                + "DATE_FORMAT,"
                + "TIME_FORMAT,"
                + "PERIOD_STATUS,"
                + "PLUCODE_START,"
                + "PLUCODE_LENGTH,"
                + "PLUPRICE_START,"
                + "PLUPRICE_LENGTH,"
                + "PLUPRICE_DECIMALS,"
                + "DECIMAL_POSITIONS,"
                + "PLUCODE_PREFIX,"
                + "SMS_NUMBER,"
                + "PIN_CODE,"
                + "VAT_NUMBER,"
                + "REG_NUMBER,"
                + "BARCODE_TYPE,"
                + "BARCODE_ISITEM,"
                + "GENERAL_TEXT,"
                + "RECEIPT_TEXT,"
                + "END_YEAR_MONTH,"
                + "FISCAL_YEAR,"
                + "FISCAL_MONTH,"
                + "FISCAL_START_DATE,"
                + "FISCAL_END_DATE,"
                + "NEXT_FISCAL_START,"
                + "NEXT_FISCAL_END)"                   
                +"values("
                + "'"+fullname.getText()+"',"
                + "'"+postal_address.getText()+"',"
                + "'"+city.getSelectedItem()+"',"
                + "'"+email_address.getText()+"',"
                + "'"+business_type.getText()+"',"
                + "'"+telephone_number.getText()+"',"
                + "'"+default_location_code.getText()+"',"
                + "'"+country_code.getText()+"',"
                + "'"+local_currency.getText()+"',"
                + "'"+auto_customer_number.getText()+"',"
                + "'"+auto_supplier_number.getText()+"',"
                + "'"+reset_at_year_end.getText()+"',"
                + "'"+customer_number_format.getText()+"',"
                + ""+customer_current_start_number.getText()+","
                + ""+supplier_current_start_number.getText()+","
                + "'"+supplier_number_format.getText()+"',"
                + "'"+date_format.getText()+"',"
                + "'"+time_format.getText()+"',"
                + "'"+period_status.getText()+"',"
                + ""+plu_code_start_position.getValue()+","
                + ""+plu_code_length.getValue()+","
                + ""+plu_price_start_position.getValue()+","
                + ""+plu_price_length.getValue()+","
                + ""+plu_decimal_position.getValue()+","
                + ""+amount_dec_position.getValue()+","
                + "'"+plu_prefix.getText()+"',"
                + "'"+sms_mobile_number.getText()+"',"
                + "'"+pin_number.getText()+"',"
                + "'"+vat_number.getText()+"',"
                + "'"+registration_number.getText()+"',"
                + "'"+default_barcode_type.getText()+"',"
                + "'"+barcode_isitem.getText()+"',"
                + "'"+general_message.getText()+"',"
                + "'"+receipt_footer.getText()+"',"
                + ""+end_year_month.getValue()+","
                + ""+current_period_year.getValue()+","
                + ""+current_period_month.getValue()+","
                + "'"+datePicker.getJFormattedTextField().getText()+"',"
                + "'"+datePicker2.getJFormattedTextField().getText()+"',"
                + "'"+datePicker3.getJFormattedTextField().getText()+"',"
                + "'"+datePicker4.getJFormattedTextField().getText()+"')";
         
        try{
            pst=conn.prepareStatement(sql);
            pst.execute();
            DBConnection.update_table(update_configurations_table, configuration_table);
            display_message.setForeground(java.awt.Color.BLUE);
            display_message.setText("Record saved successfully!!");
        }
        catch(Exception e){
            e.printStackTrace();
            display_message.setForeground(java.awt.Color.RED);
            display_message.setText("Record not saved!!");
        }
             }
             else{
                 fullname.setBackground(java.awt.Color.RED);
                 fullname.setForeground(java.awt.Color.WHITE);
                 fullname.setText("Required!!Cannot be empty!!");
                 display_message.setForeground(java.awt.Color.RED);
                 display_message.setText("Full Name field cannot be empty!!");  
             }
        
             
                }   
            
            
           if(jPanel15.isShowing()==true){
               if(!"".equals(display.getText())){
             String sql="insert into CONFIG_SETTINGS("
              + "SETTING_NAME,"
              + "DATA_VALUE)"
              + "values('"+display_label.getText()+"','"+display.getText()+"')";
                       
              try{
              pst=conn.prepareStatement(sql);
                pst.execute();
               // DBConnection.update_table(update_settings_table, settings_table);
               //display_label.setForeground(java.awt.Color.BLUE);
               // display_label.setText("Setting saved Successfully!!");
               DBConnection.update_table(update_settings_table, settings_table);
              }
      
             
               catch(Exception e){
                  e.printStackTrace();
                display_label.setForeground(java.awt.Color.RED);
                display_label.setText("Setting not saved Successfully!!");
              } 
              
          String  sql2="update config_settings set "
                  + "setting  = (select config_settings.SETTING_NAME "
                  + "from CONFIG_SETTINGS inner join"
                  + " SETTINGS_CODE_LIST on "
                  + "config_settings.SETTING_NAME = settings_code_list.DESCRIPTION"
                  + " where settings_code_list.DESCRIPTION  = '"+display_label.getText()+"') "
                  + "where config_settings.SETTING_NAME =(select config_settings.SETTING_NAME "
                  + "from CONFIG_SETTINGS inner join SETTINGS_CODE_LIST on"
                  + " config_settings.SETTING_NAME = settings_code_list.DESCRIPTION "
                  + "where settings_code_list.DESCRIPTION  = '"+display_label.getText()+"')";
                    
          
                 
    
               // sql="update CONFIG_SETTINGS set CONFIG_SETTINGS.SETTING_NAME=SETTINGS_CODE_LIST.KEY_WORD FROM CONFIG_SETTINGS INNER JOIN SETTINGS_CODE_LIST ON  "+setting_name.getText()+"=SETTINGS_CODE_LIST.KEY_WORD ";
    
               try{
                    pst=conn.prepareStatement(sql2);
                    pst.execute();
                DBConnection.update_table(update_settings_table, settings_table);
                display_label.setForeground(java.awt.Color.BLUE);
                display_label.setText("Setting saved Successfully!!");  
               }
               catch(Exception e){
                   e.printStackTrace();
                   display_label.setForeground(java.awt.Color.RED);
                display_label.setText("Setting not saved Successfully!!");        
               }
        
             }
             else{
             display.setBackground(java.awt.Color.RED);
             display.setText("??");
             display.setForeground(java.awt.Color.WHITE);
                display_label.setForeground(java.awt.Color.RED);
                display_label.setText("Either Y or N required!!");   
               }
               
           }
        }
     
    
        
    }//GEN-LAST:event_saveMouseClicked

    private void auto_supplier_numberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_auto_supplier_numberActionPerformed
        // TODO add your handling code here:
        if(auto_supplier_number.isSelected()==true){
            auto_supplier_number.setText("Y");
        }
        else{
            auto_supplier_number.setText("N"); 
        }
    }//GEN-LAST:event_auto_supplier_numberActionPerformed

    private void digit_year_numberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_digit_year_numberActionPerformed
        // TODO add your handling code here:
        if(digit_year_number.isSelected()==true){
            digit_year_number.setText("Y");
        }
        else{
            digit_year_number.setText("N"); 
        }
    }//GEN-LAST:event_digit_year_numberActionPerformed

    private void reset_at_year_endActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reset_at_year_endActionPerformed
        // TODO add your handling code here:
        if(reset_at_year_end.isSelected()==true){
            reset_at_year_end.setText("Y");
        }
        else{
            reset_at_year_end.setText("N"); 
        }
    }//GEN-LAST:event_reset_at_year_endActionPerformed

    private void barcode_isitemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_barcode_isitemActionPerformed
        // TODO add your handling code here:
        if(barcode_isitem.isSelected()==true){
            barcode_isitem.setText("Y");
        }
        else{
            barcode_isitem.setText("N"); 
        }
    }//GEN-LAST:event_barcode_isitemActionPerformed

    private void use_pluActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_use_pluActionPerformed
        // TODO add your handling code here:
        if(use_plu.isSelected()==true){
            use_plu.setText("Y");
        }
        else{
            use_plu.setText("N"); 
        }
    }//GEN-LAST:event_use_pluActionPerformed

    private void price_include_taxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_price_include_taxActionPerformed
        // TODO add your handling code here:
        if(price_include_tax.isSelected()==true){
            price_include_tax.setText("Y");
        }
        else{
            price_include_tax.setText("N"); 
        }
    }//GEN-LAST:event_price_include_taxActionPerformed

    private void discount_input_in_atmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_discount_input_in_atmActionPerformed
        // TODO add your handling code here:
        if(discount_input_in_atm.isSelected()==true){
            discount_input_in_atm.setText("Y");
        }
        else{
            discount_input_in_atm.setText("N"); 
        }
    }//GEN-LAST:event_discount_input_in_atmActionPerformed

    private void use_last_buy_priceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_use_last_buy_priceActionPerformed
        // TODO add your handling code here:
        if(use_last_buy_price.isSelected()==true){
            use_last_buy_price.setText("Y");
        }
        else{
            use_last_buy_price.setText("N"); 
        }
    }//GEN-LAST:event_use_last_buy_priceActionPerformed

    private void cityPopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_cityPopupMenuWillBecomeInvisible
        // TODO add your handling code here:
         String cities = "CITIES";
        String sub_code= "###";
         try{
            conn=DBConnection.ConnectDB();
            String sql2=  "SELECT description from list_control where reference_code = '"+ cities+"' AND sub_code='"+sub_code+"'";

            pst=conn.prepareStatement(sql2);
            rs=pst.executeQuery();
            
        }
         catch (Exception e){
                    JOptionPane.showMessageDialog(null, e);
                    
                    } 
    }//GEN-LAST:event_cityPopupMenuWillBecomeInvisible

    private void jLabel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseClicked
        // TODO add your handling code here:
        String user_group= "BUSINESS TYPES";
        String sub_code = "###";
         
            DBConnection.dynamic_sql = "select description as DESCRIPTION from list_control where reference_code='"+ user_group +"' AND sub_code='"+sub_code+"'";
        DBConnection.panel(new TableDetails_Panel(), "Business Type");
    }//GEN-LAST:event_jLabel9MouseClicked

    private void jLabel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseClicked
        // TODO add your handling code here:
        String user_group= "COUNTRY CODE";
        String sub_code = "###";
         
            DBConnection.dynamic_sql = "select key_word as  LIST_CODE, description as DESCRIPTION from list_control where reference_code='"+ user_group +"' AND sub_code='"+sub_code+"'";
        DBConnection.panel(new TableDetails_Panel(), "Country Code");
    }//GEN-LAST:event_jLabel11MouseClicked

    private void jLabel12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel12MouseClicked
        // TODO add your handling code here:
        String user_group= "CURRENCY CODE";
        String sub_code = "###";
         
            DBConnection.dynamic_sql = "select key_word as LIST_CODE,description as DESCRIPTION from list_control where reference_code='"+ user_group +"' AND sub_code='"+sub_code+"'";
        DBConnection.panel(new TableDetails_Panel(), "Currency Code");
    }//GEN-LAST:event_jLabel12MouseClicked

    private void jLabel24MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel24MouseClicked
        // TODO add your handling code here:
         String user_group= "CUSTOMER NO.FORMAT";
        String sub_code = "###";
         
            DBConnection.dynamic_sql = "select description as DESCRIPTION from list_control where reference_code='"+ user_group +"' AND sub_code='"+sub_code+"'";
        DBConnection.panel(new TableDetails_Panel(), "Customer No.Format");
    }//GEN-LAST:event_jLabel24MouseClicked

    private void jLabel25MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel25MouseClicked
        // TODO add your handling code here:
         String user_group= "SUPPLIER NO.FORMAT";
        String sub_code = "###";
         
            DBConnection.dynamic_sql = "select description as DESCRIPTION from list_control where reference_code='"+ user_group +"' AND sub_code='"+sub_code+"'";
        DBConnection.panel(new TableDetails_Panel(), "Supplier No.Format");
    }//GEN-LAST:event_jLabel25MouseClicked

    private void jLabel30MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel30MouseClicked
        // TODO add your handling code here:
         String user_group= "PERIOD STATUS";
        String sub_code = "###";
         
            DBConnection.dynamic_sql = "select key_word as LIST_CODE,description as DESCRIPTION from list_control where reference_code='"+ user_group +"' AND sub_code='"+sub_code+"'";
        DBConnection.panel(new TableDetails_Panel(), "Period Status");
    }//GEN-LAST:event_jLabel30MouseClicked

    private void jLabel48MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel48MouseClicked
        // TODO add your handling code here:
           String user_group= "BARCODES";
        String sub_code = "###";
         
            DBConnection.dynamic_sql = "select description as DESCRIPTION from list_control where reference_code='"+ user_group +"' AND sub_code='"+sub_code+"'";
        DBConnection.panel(new TableDetails_Panel(), "Barcodes");
    }//GEN-LAST:event_jLabel48MouseClicked

    private void fullnameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_fullnameMouseClicked
        // TODO add your handling code here:
                
    }//GEN-LAST:event_fullnameMouseClicked

    private void settings_panelFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_settings_panelFocusGained
        // TODO add your handling code here:
       
    }//GEN-LAST:event_settings_panelFocusGained

    private void configuration_table_panelFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_configuration_table_panelFocusGained
        // TODO add your handling code here:
        
    }//GEN-LAST:event_configuration_table_panelFocusGained

    private void jPanel2FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jPanel2FocusLost
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jPanel2FocusLost

    private void jPanel15FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jPanel15FocusGained
        // TODO add your handling code here:

    }//GEN-LAST:event_jPanel15FocusGained

    private void configuration_tableMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_configuration_tableMousePressed
        // TODO add your handling code here:
         int click = evt.getClickCount();
         int row = configuration_table.getSelectedRow();
    if(click ==2){ 
        fullname.setEditable(false);
        fullname.setFocusable(false);
        
        fullname.setText(configuration_table.getModel().getValueAt(row, 0).toString());
        postal_address.setText(configuration_table.getModel().getValueAt(row, 1).toString());
        city.setSelectedItem(configuration_table.getModel().getValueAt(row, 2).toString());
        email_address.setText(configuration_table.getModel().getValueAt(row, 3).toString());
        business_type.setText(configuration_table.getModel().getValueAt(row, 4).toString());
        telephone_number.setText(configuration_table.getModel().getValueAt(row, 5).toString());
        default_location_code.setText(configuration_table.getModel().getValueAt(row,6).toString());
        country_code.setText(configuration_table.getModel().getValueAt(row,7).toString());
        local_currency.setText(configuration_table.getModel().getValueAt(row,8).toString());
        auto_customer_number.setText(configuration_table.getModel().getValueAt(row,9).toString());
        auto_supplier_number.setText(configuration_table.getModel().getValueAt(row,10).toString());
        reset_at_year_end.setText(configuration_table.getModel().getValueAt(row,11).toString());
        customer_number_format.setText(configuration_table.getModel().getValueAt(row,12).toString()); 
        customer_current_start_number.setText(configuration_table.getModel().getValueAt(row,13).toString()); 
        supplier_current_start_number.setText(configuration_table.getModel().getValueAt(row,14).toString()); 
        supplier_number_format.setText(configuration_table.getModel().getValueAt(row,15).toString());
        date_format.setText(configuration_table.getModel().getValueAt(row,16).toString());
        time_format.setText(configuration_table.getModel().getValueAt(row,17).toString());
        period_status.setText(configuration_table.getModel().getValueAt(row,18).toString());
        
      
        String check_status1 = DBConnection.global_resultSet("select plucode_start from configurations where full_name = '"+configuration_table.getValueAt(row, 0)+"'");
        plu_code_start_position.setValue(Integer.valueOf(check_status1));
        
        String check_status2 = DBConnection.global_resultSet("select plucode_length from configurations where full_name = '"+configuration_table.getValueAt(row, 0)+"'");
        plu_code_length.setValue(Integer.valueOf(check_status2));
        
        String check_status3 = DBConnection.global_resultSet("select pluprice_start from configurations where full_name = '"+configuration_table.getValueAt(row, 0)+"'");
        plu_price_start_position.setValue(Integer.valueOf(check_status3));
        
        String check_status4 = DBConnection.global_resultSet("select pluprice_length from configurations where full_name = '"+configuration_table.getValueAt(row, 0)+"'");
        plu_price_length.setValue(Integer.valueOf(check_status4));
        
        String check_status5 = DBConnection.global_resultSet("select decimal_positions from configurations where full_name = '"+configuration_table.getValueAt(row, 0)+"'");
        amount_dec_position.setValue(Integer.valueOf(check_status5));
        
        String check_status6 = DBConnection.global_resultSet("select plucode_prefix from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        plu_prefix.setText(check_status6);
        
         String check_status7 = DBConnection.global_resultSet("select sms_number from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        sms_mobile_number.setText(check_status7);
        
        String check_status8 = DBConnection.global_resultSet("select pin_code from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        pin_number.setText(check_status8);
        
        String check_status9 = DBConnection.global_resultSet("select vat_number from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        vat_number.setText(check_status9);
        
        String check_status10 = DBConnection.global_resultSet("select reg_number from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        registration_number.setText(check_status10);
        
        String check_status11 = DBConnection.global_resultSet("select barcode_type from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        default_barcode_type.setText(check_status11);
        
        String check_status12 = DBConnection.global_resultSet("select barcode_isitem from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        barcode_isitem.setText(check_status12);
        
         String check_status13 = DBConnection.global_resultSet("select general_text from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        general_message.setText(check_status13);
        
         String check_status14 = DBConnection.global_resultSet("select receipt_text from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        receipt_footer.setText(check_status14);
        
        
        String check_status15 = DBConnection.global_resultSet("select end_year_month from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        end_year_month.setValue(Integer.valueOf(15));
        
        String check_status16 = DBConnection.global_resultSet("select fiscal_year from configurations where full_name = '"+configuration_table.getValueAt(row, 0)+"'");
        current_period_year.setValue(Integer.valueOf(check_status16));
        
        String check_status17 = DBConnection.global_resultSet("select fiscal_month from configurations where full_name = '"+configuration_table.getValueAt(row, 0)+"'");
        current_period_month.setValue(Integer.valueOf(check_status17));
        
        String check_status18 = DBConnection.global_resultSet("select fiscal_start_date from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        datePicker.getJFormattedTextField().setText(check_status18);
        
        String check_status19 = DBConnection.global_resultSet("select fiscal_end_date from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        datePicker2.getJFormattedTextField().setText(check_status19);
        
         String check_status20 = DBConnection.global_resultSet("select next_fiscal_start from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        datePicker3.getJFormattedTextField().setText(check_status20);
        
        String check_status21 = DBConnection.global_resultSet("select next_fiscal_end from configurations where full_name = '"+configuration_table.getValueAt(row, 0).toString()+"'");
        datePicker4.getJFormattedTextField().setText(check_status21);
        
       automatically_select_check_box_values();
  
        jTabbedPane1.setSelectedIndex(0);
    
    }
    }//GEN-LAST:event_configuration_tableMousePressed

    private void jLabel44MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel44MouseClicked
        // TODO add your handling code here:
            jd9.setTitle("Receipt Footer Text");
            jd9.setContentPane(new Receipt_footer());
            jd9.setLocation(200, 200);
            jd9.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            jd9.pack();
            jd9.setVisible(true);
    }//GEN-LAST:event_jLabel44MouseClicked

    private void jLabel45MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel45MouseClicked
        // TODO add your handling code here:
        jd10.setTitle("General Message Text");
            jd10.setContentPane(new General_Message());
            jd10.setLocation(200, 200);
            jd10.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            jd10.pack();
            jd10.setVisible(true);
    }//GEN-LAST:event_jLabel45MouseClicked

    private void settings_treeValueChanged(javax.swing.event.TreeSelectionEvent evt) {//GEN-FIRST:event_settings_treeValueChanged
        // TODO add your handling code here:
            paths = settings_tree.getSelectionPaths();  
        int row=settings_table.getSelectedRow();
        	// Iterate through all affected nodes
		for (int i=0; i<paths.length; i++) {
		 
                     if (evt.isAddedPath(i)) {
				// This node has been selected
                                
				System.out.println(paths[i].getLastPathComponent().toString());
                              // if(settings_table.getValueAt(row, 2).equals("Y")){
                  
                                display_label.setText(""+paths[i].getLastPathComponent().toString()+"");
                                //setting_name.setVisible(true);
                                
                              // }
                              //else{
                                   //     display.setText("N");
                               // icon_changer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/x2 - Copy.png")));  
                                   
                              // }
                                
                                break;
			}  
                 	
                   else {
				// This node has been deselected
                            
                                
                                    
				break;
			}
		}
	

        
    }//GEN-LAST:event_settings_treeValueChanged

    private void settings_tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_settings_tableMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_settings_tableMouseClicked

    private void displayKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_displayKeyTyped
        // TODO add your handling code here:
        //put on keytyped event
      if(display.getText().length()==1){
          evt.consume();
      }
            
            
        
        
                                
    }//GEN-LAST:event_displayKeyTyped

    private void displayMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_displayMouseClicked
        // TODO add your handling code here:
         if(display.getText().equals("??")){
           display.setText("");
           display.setForeground(java.awt.Color.black);
           display.setBackground(java.awt.Color.white);
           display_label.setText("");
           display_label.setForeground(java.awt.Color.blue);
       }
    }//GEN-LAST:event_displayMouseClicked

    private void displayKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_displayKeyReleased
        // TODO add your handling code here:
         String text = display.getText();
            if (Character.isLowerCase(text.charAt(text.length() - 1))) {
                display.setText(text.toUpperCase());
        if(display.getText().equals("Y")){
            
            icon_changer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/tick3.png")));  
        }
       
        else
        if(display.getText().equals("N")){
           icon_changer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/x2 - Copy.png")));    
        
        }
       else
        if(     !"Y".equals(display.getText())){
         icon_changer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.jpg")));    
         
        }
       else
        if(     !"N".equals(display.getText())){
         icon_changer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.jpg")));    
         
        }
        else
            if(display.getText().equals("")){
         icon_changer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.jpg")));    
         
        }
            }
    }//GEN-LAST:event_displayKeyReleased

    private void codelistActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_codelistActionPerformed
        // TODO add your handling code here:
       Configuration_CodeList_Form.getObj().setVisible(true);
    }//GEN-LAST:event_codelistActionPerformed

    private void settings_tableMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_settings_tableMousePressed
        // TODO add your handling code here:
        int click = evt.getClickCount();
        if(click == 2){
            DefaultTableModel model = (DefaultTableModel) settings_table.getModel();
            int row= settings_table.getSelectedRow();
             display.setText(settings_table.getValueAt(row, 2).toString());
        if(display.getText().equals("Y")){
            
            icon_changer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/tick3.png")));  
        }
       
        else
        if(display.getText().equals("N")){
           icon_changer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/x2 - Copy.png")));    
        
        }
       else
        if(     !"Y".equals(display.getText())){
         icon_changer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.jpg")));    
         
        }
       else
        if(     !"N".equals(display.getText())){
         icon_changer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.jpg")));    
         
        }
        else
            if(display.getText().equals("")){
         icon_changer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.jpg")));    
         
        }
           display_label.setText(model.getValueAt(settings_table.getSelectedRow(),0).toString());
        
        }
    }//GEN-LAST:event_settings_tableMousePressed

    private void clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearActionPerformed
        // TODO add your handling code here:
        if(jPanel15.isShowing()==true){
           display.setText("");
           maliplus.DisplayCategory.main(null);
           DBConnection.update_table(update_settings_table, settings_table);
        }
        
        else
            if(jPanel2.isShowing()==true){
             fullname.setText("");
             postal_address.setText("");
             city.setSelectedIndex(0);
             business_type.setText("");
             telephone_number.setText("");
             email_address.setText("");
             default_location_code.setText("INVENTORY");
             country_code.setText("AFR");
             local_currency.setText("USD");
             auto_customer_number.setSelected(false);
             auto_supplier_number.setSelected(false);
             digit_year_number.setSelected(false);
             reset_at_year_end.setSelected(false);
             customer_number_format.setText("PLAIN");
             customer_current_start_number.setText("1");
             supplier_current_start_number.setText("1");
             supplier_number_format.setText("");
             number_pattern.setText("");
             date_format.setText("dd/MM/YY");
             current_period_year.setValue(0);
             current_period_month.setValue(0);
             end_year_month.setValue(0);
             period_status.setText("OPN");
             time_format.setText("hh:mm:ss:tt");
             datePicker.getJFormattedTextField().setText("");
             datePicker2.getJFormattedTextField().setText("");
             datePicker3.getJFormattedTextField().setText("");
             datePicker4.getJFormattedTextField().setText("");
             sms_mobile_number.setText("");
             pin_number.setText("");
             vat_number.setText("");
             registration_number.setText("");
             amount_dec_position.setValue(0);
             receipt_footer.setText("");
             general_message.setText("");
             default_barcode_type.setText("EAN 13");
             barcode_isitem.setSelected(false);
             use_plu.setSelected(false);
             plu_code_start_position.setValue(0);
             plu_price_start_position.setValue(0);
             plu_decimal_position.setValue(0);
             plu_code_length.setValue(0);
             plu_price_length.setValue(0);
             plu_prefix.setText("");
             price_include_tax.setSelected(false);
             discount_input_in_atm.setSelected(false);
             use_last_buy_price.setSelected(false);
             default_sales_margin.setValue(0);
             max_sales_discount.setValue(0);
             loyalty_point_amount.setValue(0);
             loyalty_redeem_value.setValue(0);
             DBConnection.update_table(update_configurations_table, configuration_table);
 
            }
    }//GEN-LAST:event_clearActionPerformed

    private void go_backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_go_backActionPerformed
        this.dispose();
    }//GEN-LAST:event_go_backActionPerformed

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        // TODO add your handling code here:
           if(jPanel15.isShowing()){
             int result=
            JOptionPane.showConfirmDialog(rootPane,"Are you sure you want to Delete '"+display_label.getText()+"',setting from the list? ","Delete Configuration Setting?",JOptionPane.YES_NO_CANCEL_OPTION);
            if(result==JOptionPane.YES_OPTION){
              

                String sql2 = "delete from CONFIG_SETTINGS where SETTING_NAME= '"+display_label.getText()+"'";
            try{              
                          conn=DBConnection.ConnectDB(); 
                          pst=conn.prepareStatement(sql2);
                          pst.execute();
                          display_label.setForeground(java.awt.Color.BLUE);
                          display_label.setText("Setting entry removed successfully!!");
                          DBConnection.update_table(update_settings_table, settings_table);
                          icon_changer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.jpg"))); 
                          display.setText("");
            }
            catch(SQLException | HeadlessException e){ e.printStackTrace(); }
            
                     
            }
          
        
        
        }
    }//GEN-LAST:event_deleteActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Configurations1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Configurations1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Configurations1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Configurations1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
         //new ModelJTree();
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Configurations1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JSpinner amount_dec_position;
    public static javax.swing.JCheckBox auto_customer_number;
    public static javax.swing.JCheckBox auto_supplier_number;
    public static javax.swing.JCheckBox barcode_isitem;
    public static javax.swing.JTextField business_type;
    private static javax.swing.JComboBox<String> city;
    private javax.swing.JButton clear;
    private javax.swing.JButton codelist;
    public static javax.swing.JTable configuration_table;
    private javax.swing.JPanel configuration_table_panel;
    public static javax.swing.JTextField country_code;
    private javax.swing.JSpinner current_period_month;
    private javax.swing.JSpinner current_period_year;
    private javax.swing.JTextField customer_current_start_number;
    public static javax.swing.JTextField customer_number_format;
    private javax.swing.JTextField date_format;
    public static javax.swing.JTextField default_barcode_type;
    private javax.swing.JTextField default_location_code;
    private javax.swing.JSpinner default_sales_margin;
    private javax.swing.JButton delete;
    public static javax.swing.JCheckBox digit_year_number;
    public static javax.swing.JCheckBox discount_input_in_atm;
    private javax.swing.JTextField display;
    private javax.swing.JLabel display_label;
    private javax.swing.JLabel display_message;
    private javax.swing.JTextField email_address;
    private javax.swing.JSpinner end_year_month;
    private javax.swing.JButton export;
    private javax.swing.JTextField fullname;
    public static javax.swing.JTextField general_message;
    private javax.swing.JButton go_back;
    private javax.swing.JLabel icon_changer;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JToolBar jToolBar1;
    public static javax.swing.JTextField local_currency;
    private javax.swing.JSpinner loyalty_point_amount;
    private javax.swing.JSpinner loyalty_redeem_value;
    private javax.swing.JSpinner max_sales_discount;
    public static javax.swing.JPanel next_end_date;
    public static javax.swing.JPanel next_start_date;
    private javax.swing.JTextField number_pattern;
    public static javax.swing.JPanel period_end_date;
    public static javax.swing.JPanel period_start_date;
    public static javax.swing.JTextField period_status;
    private javax.swing.JTextField pin_number;
    private javax.swing.JSpinner plu_code_length;
    private javax.swing.JSpinner plu_code_start_position;
    private javax.swing.JSpinner plu_decimal_position;
    private javax.swing.JTextField plu_prefix;
    private javax.swing.JSpinner plu_price_length;
    private javax.swing.JSpinner plu_price_start_position;
    private javax.swing.JTextArea postal_address;
    public static javax.swing.JCheckBox price_include_tax;
    public static javax.swing.JTextField receipt_footer;
    private javax.swing.JTextField registration_number;
    public static javax.swing.JCheckBox reset_at_year_end;
    private javax.swing.JButton save;
    private javax.swing.JButton search;
    private javax.swing.JLabel setting_name;
    private javax.swing.JPanel settings_panel;
    public static javax.swing.JTable settings_table;
    public static javax.swing.JTree settings_tree;
    private javax.swing.JTextField sms_mobile_number;
    private javax.swing.JTextField supplier_current_start_number;
    public static javax.swing.JTextField supplier_number_format;
    private javax.swing.JTextField telephone_number;
    private javax.swing.JTextField time_format;
    private javax.swing.JButton update;
    public static javax.swing.JCheckBox use_last_buy_price;
    public static javax.swing.JCheckBox use_plu;
    private javax.swing.JTextField vat_number;
    // End of variables declaration//GEN-END:variables
}
