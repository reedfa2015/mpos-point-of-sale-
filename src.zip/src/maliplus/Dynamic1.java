
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus;

import AppPackage.AnimationClass;
import com.sun.glass.events.KeyEvent;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.HeadlessException;
import java.awt.Image;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import net.sf.jasperreports.engine.design.*;
import net.sf.jasperreports.view.JasperViewer;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sourceforge.jdatepicker.impl.JDatePanelImpl;
import net.sourceforge.jdatepicker.impl.JDatePickerImpl;
import net.sourceforge.jdatepicker.impl.UtilDateModel;
import net.proteanit.sql.DbUtils;
import java.util.Vector;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import javax.swing.JCheckBox;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.table.DefaultTableCellRenderer;
import maliplus.detailsPanels.Charges_Panel;
import maliplus.detailsPanels.costspanel;
import maliplus.detailsPanels.import_export_panel;
import static maliplus.DBConnection.jd;
import static maliplus.Dynamic1.main_acc_code;
import static maliplus.Search_Report.fxbutton;
import maliplus.detailsPanels.TableDetails_Panel;
import maliplus.detailsPanels.TableDetails_Panel2;
import maliplus.detailsPanels.propertyattributes;

/**
 *
 * @author PSL-STUFF
 */
public final class Dynamic1 extends javax.swing.JFrame implements java.io.Serializable {

          
    private static Dynamic1 df = null;

    static Connection conn = null;
    static ResultSet rs = null;
    static PreparedStatement pst = null;
    static String selectedValue = null;

    String aprv_status = "N";

    Timer tm;
    public int x = 0;

    AnimationClass AC = new AnimationClass();

    public static void autogenerate_lease_id() {
        lease_id_tf.setText("NEW");
        lease_id_tf.setBackground(Color.yellow);
    }

    public static void Insert_Timestamp() {

        if (contactdetails_panel.isShowing() == true) {
            Calendar calendar = Calendar.getInstance();
            java.sql.Timestamp ourJavaTimestampObject = new java.sql.Timestamp(calendar.getTime().getTime());

            // (3) create a java timestamp insert statement
            String sqlTimestampInsertStatement = "Update contacts set created_date = ? where PIN='" + pin_TF.getText() + "' or NATIONAL_ID='" + id_TF.getText() + "'";
            try (PreparedStatement preparedStatement = conn.prepareStatement(sqlTimestampInsertStatement)) {
                preparedStatement.setTimestamp(1, ourJavaTimestampObject);

                // (4) execute the sql timestamp insert statement, then shut everything down
                preparedStatement.executeUpdate();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (lease_panel.isShowing() == true) {
            Calendar calendar = Calendar.getInstance();
            java.sql.Timestamp ourJavaTimestampObject = new java.sql.Timestamp(calendar.getTime().getTime());

            // (3) create a java timestamp insert statement
            String sqlTimestampInsertStatement = "Update lease set created_date = ? where LEASE_ID='" + lease_id_tf.getText() + "'";
            try (PreparedStatement preparedStatement = conn.prepareStatement(sqlTimestampInsertStatement)) {
                preparedStatement.setTimestamp(1, ourJavaTimestampObject);

                // (4) execute the sql timestamp insert statement, then shut everything down
                preparedStatement.executeUpdate();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

    }

    public static void Insert_Timestamp2() {
        if (contactdetails_panel.isShowing() == true) {
            Calendar calendar = Calendar.getInstance();
            java.sql.Timestamp ourJavaTimestampObject = new java.sql.Timestamp(calendar.getTime().getTime());

            // (3) create a java timestamp insert statement
            String sqlTimestampInsertStatement = "Update contacts set modified_date = ? where PIN='" + pin_TF.getText() + "' or NATIONAL_ID='" + id_TF.getText() + "'";
            try (PreparedStatement preparedStatement = conn.prepareStatement(sqlTimestampInsertStatement)) {
                preparedStatement.setTimestamp(1, ourJavaTimestampObject);

                // (4) execute the sql timestamp insert statement, then shut everything down
                preparedStatement.executeUpdate();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (lease_panel.isShowing() == true) {
            Calendar calendar = Calendar.getInstance();
            java.sql.Timestamp ourJavaTimestampObject = new java.sql.Timestamp(calendar.getTime().getTime());

            String sqlTimestampInsertStatement2 = "Update lease set modified_date = ? where LEASE_ID='" + lease_id_tf.getText() + "'";
            try (PreparedStatement preparedStatement = conn.prepareStatement(sqlTimestampInsertStatement2)) {
                preparedStatement.setTimestamp(1, ourJavaTimestampObject);

                // (4) execute the sql timestamp insert statement, then shut everything down
                preparedStatement.executeUpdate();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    public void show_image() {

        int width = pic.getWidth();
        int height = pic.getHeight();
        ImageIcon II = new ImageIcon(getClass().getResource("/maliplus/f1.jpg"));
        Image img = II.getImage();
        pic.setIcon(new ImageIcon(img.getScaledInstance(width, height, Image.SCALE_AREA_AVERAGING)));

    }
    
    void printReport(){
        if(contactdetails_panel.isShowing()==true){
         try{      
               conn = DBConnection.ConnectDB();
                JasperDesign jasperDesign= JRXmlLoader.load("contacts.jrxml");
                 String sql= "SELECT * FROM CONTACTS WHERE FIRST_NAMES='"+fname_TF.getText()+"'";
                JRDesignQuery newQuery= new JRDesignQuery();
                newQuery.setText(sql);
                jasperDesign.setQuery(newQuery);
                JasperReport jasperReport= JasperCompileManager.compileReport(jasperDesign);
                JasperPrint jasperPrint= JasperFillManager.fillReport(jasperReport, null, conn);
                JasperViewer.viewReport(jasperPrint,false);
               
                
                
                 
               
            }
            catch(Exception e){
                e.printStackTrace();
            }   
        }
        else
            if(propertyInfo_panel.isShowing()==true){
        try{
            conn = DBConnection.ConnectDB();
                JasperDesign jasperDesign= JRXmlLoader.load("property_details.jrxml");
                 String sql= "select * from properties_table ";
                JRDesignQuery newQuery= new JRDesignQuery();
                newQuery.setText(sql);
                jasperDesign.setQuery(newQuery);
                JasperReport jasperReport= JasperCompileManager.compileReport(jasperDesign);
                JasperPrint jasperPrint= JasperFillManager.fillReport(jasperReport, null, conn);
               JasperViewer.viewReport(jasperPrint,false); 
            }
        catch(Exception e){
       e.printStackTrace();
        }
    }
        
        else
           
            if(lease_panel.isShowing()==true){
        try{
                 conn = DBConnection.ConnectDB();
                JasperDesign jasperDesign= JRXmlLoader.load("leasing.jrxml");
                 String sql= "select * from lease ";
                JRDesignQuery newQuery= new JRDesignQuery();
                newQuery.setText(sql);
                jasperDesign.setQuery(newQuery);
                JasperReport jasperReport= JasperCompileManager.compileReport(jasperDesign);
                JasperPrint jasperPrint= JasperFillManager.fillReport(jasperReport, null, conn);
               JasperViewer.viewReport(jasperPrint,false); 
            }
        catch(Exception e){
       e.printStackTrace();
        }
    }
            else
            if(ChartOfAccount_pane.isShowing()==true){
        try{
                 conn = DBConnection.ConnectDB();
                JasperDesign jasperDesign= JRXmlLoader.load("account_master.jrxml");
                 String sql= "select * from account_master ";
                JRDesignQuery newQuery= new JRDesignQuery();
                newQuery.setText(sql);
                jasperDesign.setQuery(newQuery);
                JasperReport jasperReport= JasperCompileManager.compileReport(jasperDesign);
                JasperPrint jasperPrint= JasperFillManager.fillReport(jasperReport, null, conn);
               JasperViewer.viewReport(jasperPrint,false); 
            }
        catch(Exception e){
       e.printStackTrace();
        }
    }
        
    }

    public static void FillCombo15() {

        DBConnection.MY_CODE_REFERENCE = "PROPERTY TYPES";
        DBConnection.MY_SUB_CODE = "###";

        try {
            String sql = "SELECT DESCRIPTION from list_control where reference_code = '" + DBConnection.MY_CODE_REFERENCE + "' AND sub_code='" + DBConnection.MY_SUB_CODE + "'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
                String add = rs.getString("DESCRIPTION");
                property_type.removeAll();
                property_type.addItem(add);

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void FillCombo1() {
        DBConnection.MY_CODE_REFERENCE = "COUNTRIES";
        DBConnection.MY_SUB_CODE = "###";

        String sql = "SELECT DESCRIPTION from list_control where reference_code = '" + DBConnection.MY_CODE_REFERENCE + "' AND sub_code='" + DBConnection.MY_SUB_CODE + "'";

        try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
                String nme = rs.getString("DESCRIPTION");
                country_sel.removeAll();
                country_sel.addItem(nme);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }
    }

    public static void FillCombo() {

        DBConnection.MY_CODE_REFERENCE = "COUNTRIES";
        DBConnection.MY_SUB_CODE = "###";

        String sql = "SELECT DESCRIPTION from list_control where reference_code = '" + DBConnection.MY_CODE_REFERENCE + "' AND sub_code='" + DBConnection.MY_SUB_CODE + "'";

        try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
                String nme = rs.getString("DESCRIPTION");
                country_sel.addItem(nme);
                country.addItem(nme);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }

    }

    public static void FillCombo21() {
        DBConnection.MY_CODE_REFERENCE = "OCCUPATION";
        DBConnection.MY_SUB_CODE = "###";

        String sql2 = "SELECT DESCRIPTION from list_control where reference_code = '" + DBConnection.MY_CODE_REFERENCE + "' AND sub_code='" + DBConnection.MY_SUB_CODE + "'";

        try {
            pst = conn.prepareStatement(sql2);
            rs = pst.executeQuery();
            while (rs.next()) {
                String nme = rs.getString("DESCRIPTION");
                occupation2.removeAll();
                occupation2.addItem(nme);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }
    }

    public static void FillCombo2() {
        DBConnection.MY_CODE_REFERENCE = "OCCUPATION";
        DBConnection.MY_SUB_CODE = "###";

        String sql2 = "SELECT DESCRIPTION from list_control where reference_code = '" + DBConnection.MY_CODE_REFERENCE + "' AND sub_code='" + DBConnection.MY_SUB_CODE + "'";

        try {
            pst = conn.prepareStatement(sql2);
            rs = pst.executeQuery();
            while (rs.next()) {
                String nme = rs.getString("DESCRIPTION");
                if (country_sel.getSelectedItem().equals("KENYA")) {
                    citzn_combo.setSelectedItem("Kenyan");
                } else {
                    occupation2.addItem(nme);
                    citzn_combo.setSelectedItem("Non-Kenyan");
                }

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }
    }

    public void insert_and_update() {
        String sql3 = "update contacts set status='" + status.getSelectedItem() + "',citizenship='" + citzn_combo.getSelectedItem() + "',country='" + country_sel.getSelectedItem() + "' where PIN='" + pin_TF.getText() + "' or NATIONAL_ID='" + id_TF.getText() + "'";
        try {
            pst = conn.prepareStatement(sql3);
            pst.execute();
            Update_contact_details();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void FillCombo3() {
        DBConnection.MY_CODE_REFERENCE = "BANKS";
        DBConnection.MY_SUB_CODE = "###";

        String sql2 = "SELECT DESCRIPTION from list_control where reference_code = '" + DBConnection.MY_CODE_REFERENCE + "' AND sub_code='" + DBConnection.MY_SUB_CODE + "'";

        try {
            pst = conn.prepareStatement(sql2);
            rs = pst.executeQuery();
            while (rs.next()) {
                String nme = rs.getString("DESCRIPTION");
                bank_name2.addItem(nme);
                bank_name1.addItem(nme);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }
    }

    public static void FillCombo31() {
        DBConnection.MY_CODE_REFERENCE = "BANKS";
        DBConnection.MY_SUB_CODE = "###";

        String sql2 = "SELECT DESCRIPTION from list_control where reference_code = '" + DBConnection.MY_CODE_REFERENCE + "' AND sub_code='" + DBConnection.MY_SUB_CODE + "'";

        try {
            pst = conn.prepareStatement(sql2);
            rs = pst.executeQuery();
            while (rs.next()) {
                String nme = rs.getString("DESCRIPTION");
                bank_name2.removeAll();
                bank_name2.addItem(nme);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }
    }

    public static void FillCombo4() {
        DBConnection.MY_CODE_REFERENCE = "BANK_BRANCH";
        DBConnection.MY_SUB_CODE = "###";

        String sql2 = "SELECT DESCRIPTION from list_control where reference_code = '" + DBConnection.MY_CODE_REFERENCE + "' AND sub_code='" + DBConnection.MY_SUB_CODE + "'";

        try {
            pst = conn.prepareStatement(sql2);
            rs = pst.executeQuery();
            while (rs.next()) {
                String nme = rs.getString("DESCRIPTION");
                bank_branch.addItem(nme);
                bank_branch1.addItem(nme);
                company_branch_tf.addItem(nme);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }
    }

    public static void FillCombo5() {
        DBConnection.MY_CODE_REFERENCE = "PROPERTY TYPES";
        DBConnection.MY_SUB_CODE = "###";

        String sql2 = "SELECT DESCRIPTION from list_control where reference_code = '" + DBConnection.MY_CODE_REFERENCE + "' AND sub_code='" + DBConnection.MY_SUB_CODE + "'";

        try {
            pst = conn.prepareStatement(sql2);
            rs = pst.executeQuery();
            while (rs.next()) {
                String nme = rs.getString("DESCRIPTION");
                property_type.addItem(nme);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }
    }

    public static void FillCombo6() {
        DBConnection.MY_CODE_REFERENCE = "CITIES";
        DBConnection.MY_SUB_CODE = "###";

        String sql2 = "SELECT DESCRIPTION from list_control where reference_code = '" + DBConnection.MY_CODE_REFERENCE + "' AND sub_code='" + DBConnection.MY_SUB_CODE + "'";

        try {
            pst = conn.prepareStatement(sql2);
            rs = pst.executeQuery();
            while (rs.next()) {
                String nme = rs.getString("DESCRIPTION");
                city.addItem(nme);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }
    }

    public static void FillCombo7() {
        DBConnection.MY_CODE_REFERENCE = "SURBURB";
        DBConnection.MY_SUB_CODE = "###";

        String sql2 = "SELECT DESCRIPTION from list_control where reference_code = '" + DBConnection.MY_CODE_REFERENCE + "' AND sub_code='" + DBConnection.MY_SUB_CODE + "'";

        try {
            pst = conn.prepareStatement(sql2);
            rs = pst.executeQuery();
            while (rs.next()) {
                String nme = rs.getString("DESCRIPTION");
                surburb.addItem(nme);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }
    }

    public static void FillCombo8() {
        DBConnection.MY_CODE_REFERENCE = "ZONES";
        DBConnection.MY_SUB_CODE = "###";

        String sql2 = "SELECT DESCRIPTION from list_control where reference_code = '" + DBConnection.MY_CODE_REFERENCE + "' AND sub_code='" + DBConnection.MY_SUB_CODE + "'";

        try {
            pst = conn.prepareStatement(sql2);
            rs = pst.executeQuery();
            while (rs.next()) {
                String nme = rs.getString("DESCRIPTION");
                zones.addItem(nme);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }
    }

    public static void FillCombo9() {
        DBConnection.MY_CODE_REFERENCE = "LEASE_TYPES";
        DBConnection.MY_SUB_CODE = "###";

        String sql2 = "SELECT DESCRIPTION from list_control where reference_code = '" + DBConnection.MY_CODE_REFERENCE + "' AND sub_code='" + DBConnection.MY_SUB_CODE + "'";

        try {
            pst = conn.prepareStatement(sql2);
            rs = pst.executeQuery();
            while (rs.next()) {
                String nme = rs.getString("DESCRIPTION");
                jCombo_lease_types.addItem(nme);

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }
    }

    public static Vector headers = new Vector();

    public static DefaultTableModel models = null;
    public static Vector data = new Vector();

    public static void Update_jtbl_Accounts_Master() {
        String sql = "SELECT ACCOUNT_GROUP, COST_CENTRE, MAIN_ACCOUNT, SUB_ACCOUNT, ACCOUNT_STATUS, DESCRIPTION,SUB_CATEGORY, CONTRA_ACCOUNT, MUST_BUDGET, RECONCILE, POST_RESTRICTION, RESTRICTED, RECONCILE_GROUP, BUDGET_PATTERN, TRANSACTION_ACCOUNT,ACCOUNT_NUMBER,MAIN_CATEGORY, SUB_CATEG_TYPE, ACC_FUND_TYPE, CHECK_BUDGET  from account_master";

        DBConnection.update_table(sql, jtbl_Accounts_Master);
    }

    public void Update_contact_information() {
        String sql = "SELECT * from contact_information WHERE CONTACT_ID = " + contact_id_no.getText() + "";

        DBConnection.update_table(sql, contact_information);
    }

    public static void Update_Property_attributes_table() {

        String sql = "select ATTRIBUTE , STATUS, UNIT_QUANTITY as QTY,CHARGES AS UNIT_CHARGE,(UNIT_QUANTITY * CHARGES) AS TOTAL from property_attributes where property_id = '" + property_id.getText() + "'";

        DBConnection.update_table(sql, property_attributes);
    }

    public void Update_properties_table() {

        String sql = "SELECT * from properties_table where CONTACT_ID=" + contact_id_no.getText() + "";

        DBConnection.update_table(sql, properties_table);
    }

    public void Update_contact_details() {
        String sql = "SELECT * from contacts";

        DBConnection.update_table(sql, contact_details);

    }

    public static void Update_costs_table() {
        String sql = "SELECT * from property_cost_table where PROPERTY_ID=" + owner.getText() + "";

        DBConnection.update_table(sql, costspanel.cost_table);
    }

    public UtilDateModel model = new UtilDateModel();
    public UtilDateModel mode2 = new UtilDateModel();
    public UtilDateModel mode3 = new UtilDateModel();
    public static UtilDateModel mode4 = new UtilDateModel();
    public UtilDateModel mode5 = new UtilDateModel();
    public UtilDateModel mode6 = new UtilDateModel();
    public UtilDateModel mode7 = new UtilDateModel();
    public UtilDateModel mode8 = new UtilDateModel();
    public UtilDateModel mode9 = new UtilDateModel();
    public UtilDateModel mode10 = new UtilDateModel();
    public UtilDateModel mode11 = new UtilDateModel();
    public JDatePanelImpl datePanel = new JDatePanelImpl(model);
    public JDatePanelImpl datePane2 = new JDatePanelImpl(mode2);
    public JDatePanelImpl datePane3 = new JDatePanelImpl(mode3);
    public static JDatePanelImpl datePane4 = new JDatePanelImpl(mode4);
    public JDatePanelImpl datePane5 = new JDatePanelImpl(mode5);
    public JDatePanelImpl datePane6 = new JDatePanelImpl(mode6);
    public JDatePanelImpl datePane7 = new JDatePanelImpl(mode7);
    public JDatePanelImpl datePane8 = new JDatePanelImpl(mode8);
    public JDatePanelImpl datePane9 = new JDatePanelImpl(mode9);
    public JDatePanelImpl datePane10 = new JDatePanelImpl(mode10);
    public JDatePanelImpl datePane11 = new JDatePanelImpl(mode11);
    public JDatePickerImpl datePicker = new JDatePickerImpl(datePanel, new DateLabelFormatter1());
    public JDatePickerImpl datePicker2 = new JDatePickerImpl(datePane2, new DateLabelFormatter1());
    public JDatePickerImpl datePicker3 = new JDatePickerImpl(datePane3, new DateLabelFormatter1());
    public static JDatePickerImpl datePicker4 = new JDatePickerImpl(datePane4, new DateLabelFormatter1());
    public JDatePickerImpl datePicker5 = new JDatePickerImpl(datePane5, new DateLabelFormatter1());
    public JDatePickerImpl datePicker6 = new JDatePickerImpl(datePane6, new DateLabelFormatter1());
    public JDatePickerImpl datePicker7 = new JDatePickerImpl(datePane7, new DateLabelFormatter1());
    public JDatePickerImpl datePicker8 = new JDatePickerImpl(datePane8, new DateLabelFormatter1());
    public JDatePickerImpl datePicker9 = new JDatePickerImpl(datePane9, new DateLabelFormatter1());
    public JDatePickerImpl datePicker10 = new JDatePickerImpl(datePane10, new DateLabelFormatter1());
    public JDatePickerImpl datePicker11 = new JDatePickerImpl(datePane11, new DateLabelFormatter1());

    public void dateP1() {
        try {

            dp.setLayout(new java.awt.BorderLayout());
            dp.add(datePicker);
            dp.revalidate();
            dp.repaint();
            //System.out.println(datePicker.getComponentListeners());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public void dateP2() {
        try {

            dp1.setLayout(new java.awt.BorderLayout());
            dp1.add(datePicker2);
            dp1.revalidate();
            dp1.repaint();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public void dateP3() {

        try {

            dp2.setLayout(new java.awt.BorderLayout());
            dp2.add(datePicker3);
            dp2.revalidate();
            dp2.repaint();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public void dateP4() {

        try {

            dp3.setLayout(new java.awt.BorderLayout());
            dp3.add(datePicker4);
            dp3.revalidate();
            dp3.repaint();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public void dateP5() {

        try {

            dp4.setLayout(new java.awt.BorderLayout());
            dp4.add(datePicker5);
            dp4.revalidate();
            dp4.repaint();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public void dateP6() {

        try {

            dp5.setLayout(new java.awt.BorderLayout());
            dp5.add(datePicker6);
            dp5.revalidate();
            dp5.repaint();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public void dateP7() {

        try {

            dp6.setLayout(new java.awt.BorderLayout());
            dp6.add(datePicker7);
            dp6.revalidate();
            dp6.repaint();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public void dateP8() {

        try {

            dp7.setLayout(new java.awt.BorderLayout());
            dp7.add(datePicker8);
            dp7.revalidate();
            dp7.repaint();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public void dateP9() {

        try {

            dp8.setLayout(new java.awt.BorderLayout());
            dp8.add(datePicker9);
            dp8.revalidate();
            dp8.repaint();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public void dateP10() {

        try {

            dp9.setLayout(new java.awt.BorderLayout());
            dp9.add(datePicker10);
            dp9.revalidate();
            dp9.repaint();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public void display_photo() {

        try {
            String sql = "select photo from contacts where FIRST_NAMES='" + fname_TF.getText() + "'";

            try {
                conn = DBConnection.ConnectDB();
                pst = conn.prepareStatement(sql);
                rs = pst.executeQuery();

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);

            }
            byte[] imgbytes = null;
            if (rs.next()) {
                imgbytes = rs.getBytes(1);
            }

            if (imgbytes != null) {

                ImageIcon icon = new ImageIcon(imgbytes);
                JLabel label = new JLabel(icon);
                jPanel5.add(label);
                userImage.setIcon(new ImageIcon(imgbytes));
                jPanel5.setLayout(new java.awt.BorderLayout());
                userImage.setPreferredSize(new java.awt.Dimension(200, 200));
                jPanel5.add(userImage, BorderLayout.CENTER);
                userImage.setVisible(true);
            }
        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public void insert_photo() {
        try {
            JFileChooser fc = new JFileChooser();
            fc.setDialogTitle("Choose image");
            fc.showOpenDialog(this);
            fc.setMultiSelectionEnabled(false);
            File f = fc.getSelectedFile();

            String filename = f.getAbsolutePath();
            pathTF.setText(filename);

            int width = userImage.getWidth();
            int height = userImage.getHeight();
            ImageIcon icon = new ImageIcon(filename);
            Image img = icon.getImage();
            userImage.setIcon(new ImageIcon(img.getScaledInstance(width, height, Image.SCALE_AREA_AVERAGING)));

            String sql = "delete *from contacts where PHOTO='" + fname_TF.getText() + "'";
            try {
                pst = conn.prepareStatement(sql);
                pst.execute();

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }

            FileInputStream in = new FileInputStream(f.getPath());

            PreparedStatement ps = conn.prepareStatement("insert into contacts (PHOTO) values(?);");
            ps.setString(1, fname_TF.getText());
            ps.setBinaryStream(2, in, (int) f.length());
            ps.execute();
            ps.close();
        } catch (HeadlessException | FileNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public static void update_photo() {
        try {
            FileInputStream in = new FileInputStream(new File(pathTF.getText()));
            PreparedStatement pst = conn.prepareStatement("Update contacts set PHOTO = ? where PIN='" + pin_TF.getText() + "'");
            pst.setBlob(1, in);
            pst.executeUpdate();
            pst.close();
        } catch (Exception e) {
            // JOptionPane.showMessageDialog(null, "The image you want to upload is too large.only 25kb or less images allowed here for upload.");
            e.printStackTrace();
        }
    }

    public void contact_detailsMouseClicked_action_performed() {
        int row = contact_details.getSelectedRow();
        contact_id_no.setText(contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(contact_details.convertRowIndexToModel(row)), 0).toString());
        contact_ref_no.setText(contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 1).toString());
        contact_type.setSelectedItem(contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 2).toString());
        fname_TF.setText(contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 3).toString());
        lname_TF.setText(contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 4).toString());
        id_TF.setText(contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 5).toString());
        pin_TF.setText(contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 6).toString());
        gender.setSelectedItem(contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 7).toString());
        occupation.setText(contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 8).toString());
        occupation2.setSelectedItem(contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 8).toString());
        source_of_income.setText(contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 9).toString());
        company_name.setText(contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 10).toString());
        company_branch.setText(contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 11).toString());
        location.setText(contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 12).toString());
        current_city.setText(contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 13).toString());
        website.setText(contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 14).toString());
        county.setText(contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 15).toString());
        bank_name.setText(contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 16).toString());
        bank_name2.setSelectedItem(contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 16).toString());
        bank_acc_no.setText(contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 17).toString());
        bank_branch.setSelectedItem(contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 18).toString());
        status.setSelectedItem(contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 24).toString());
        citzn_combo.setSelectedItem(contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 25).toString());
        country_sel.setSelectedItem(contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 26).toString());

        if (contact_type.getSelectedItem().equals("Individual")) {
            lname_TF.setEnabled(true);
            jLabel4.setText("First Name:");
            lname_TF.setBackground(Color.white);
            id_TF.setEnabled(true);
            id_TF.setBackground(Color.white);

        } else if (contact_type.getSelectedItem().equals("Company")) {
            lname_TF.setEnabled(false);
            jLabel4.setText("Company Name:");
            lname_TF.setBackground(Color.lightGray);
            id_TF.setEnabled(false);
            id_TF.setBackground(Color.lightGray);
        } else if (contact_type.getSelectedItem().equals("Association")) {
            lname_TF.setEnabled(false);
            jLabel4.setText("Association Name:");
            lname_TF.setBackground(Color.lightGray);
            id_TF.setEnabled(false);
            id_TF.setBackground(Color.lightGray);
        }
        if (contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 19).equals(1)) {
            tenant_CheckBox.setSelected(true);

        } else {
            tenant_CheckBox.setSelected(false);
        }

        if (contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 20).equals(1)) {
            landlord_CheckBox.setSelected(true);
        } else {
            landlord_CheckBox.setSelected(false);
        }

        if (contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 21).equals(1)) {
            agent_CheckBox.setSelected(true);
        } else {
            agent_CheckBox.setSelected(false);
        }
        if (contact_details.getModel().getValueAt(contact_details.convertRowIndexToModel(row), 22).equals(1)) {
            buyer_CheckBox.setSelected(true);
        } else {
            buyer_CheckBox.setSelected(false);
        }

    }

    public void properties_table_selected() {
        int row = properties_table.getSelectedRow();
        property_id.setText(properties_table.getModel().getValueAt(properties_table.convertRowIndexToModel(row), 0).toString());
        contact_id_no.setText(properties_table.getModel().getValueAt(properties_table.convertRowIndexToModel(row), 1).toString());
        owner.setText(properties_table.getModel().getValueAt(properties_table.convertRowIndexToModel(row), 1).toString());
        property_status.setSelectedItem(properties_table.getModel().getValueAt(properties_table.convertRowIndexToModel(row), 2).toString());
        property_type.setSelectedItem(properties_table.getModel().getValueAt(properties_table.convertRowIndexToModel(row), 3).toString());
        parent_property.setText(properties_table.getModel().getValueAt(properties_table.convertRowIndexToModel(row), 4).toString());
        property_quantity.setText(properties_table.getModel().getValueAt(properties_table.convertRowIndexToModel(row), 5).toString());
        property_category.setText(properties_table.getModel().getValueAt(properties_table.convertRowIndexToModel(row), 6).toString());
        bank_name1.setSelectedItem(properties_table.getModel().getValueAt(properties_table.convertRowIndexToModel(row), 7).toString());
        bank_acc.setText(properties_table.getModel().getValueAt(properties_table.convertRowIndexToModel(row), 8).toString());
        bank_branch1.setSelectedItem(properties_table.getModel().getValueAt(properties_table.convertRowIndexToModel(row), 9).toString());
        tax_code1.setText(properties_table.getModel().getValueAt(properties_table.convertRowIndexToModel(row), 10).toString());
        gprs.setText(properties_table.getModel().getValueAt(properties_table.convertRowIndexToModel(row), 11).toString());
        country.setSelectedItem(properties_table.getModel().getValueAt(properties_table.convertRowIndexToModel(row), 12).toString());
        city.setSelectedItem(properties_table.getModel().getValueAt(properties_table.convertRowIndexToModel(row), 13).toString());
        surburb.setSelectedItem(properties_table.getModel().getValueAt(properties_table.convertRowIndexToModel(row), 14).toString());
        zones.setSelectedItem(properties_table.getModel().getValueAt(properties_table.convertRowIndexToModel(row), 15).toString());
        property_description.setText(properties_table.getModel().getValueAt(properties_table.convertRowIndexToModel(row), 16).toString());
        property_value.setText(properties_table.getModel().getValueAt(properties_table.convertRowIndexToModel(row), 17).toString());
        bank_name2.setSelectedItem(properties_table.getModel().getValueAt(properties_table.convertRowIndexToModel(row), 7).toString());
        sale_value.setText(properties_table.getModel().getValueAt(properties_table.convertRowIndexToModel(row), 18).toString());
        purchase_price.setText(properties_table.getModel().getValueAt(properties_table.convertRowIndexToModel(row), 19).toString());
        asking_value.setText(properties_table.getModel().getValueAt(properties_table.convertRowIndexToModel(row), 20).toString());
        datePicker3.getJFormattedTextField().setText(properties_table.getModel().getValueAt(properties_table.convertRowIndexToModel(row), 21).toString());
        datePicker2.getJFormattedTextField().setText(properties_table.getModel().getValueAt(properties_table.convertRowIndexToModel(row), 22).toString());
        datePicker.getJFormattedTextField().setText(properties_table.getModel().getValueAt(properties_table.convertRowIndexToModel(row), 23).toString());
    }

    public int checked_status(JCheckBox checkbox) {
        int state = 0;

        if (checkbox.isSelected()) {
            state = 1;
        }
        return state;
    }

    public void Select_checkboxes() {

        String sql_update = "update contacts set "
                + "is_tenant = " + checked_status(agent_CheckBox) + ","
                + " is_landlord = " + checked_status(landlord_CheckBox) + ", "
                + "is_agent = " + checked_status(tenant_CheckBox) + ", "
                + "is_buyer = " + checked_status(buyer_CheckBox) + ", "
                + "is_employee = " + checked_status(employee_CheckBox) + ","
                + "is_supplier = " + checked_status(supplier_CheckBox) + ""
                + "where contact_id = '" + contact_id_no.getText() + "'";

        try {

            conn = DBConnection.ConnectDB();
            pst = conn.prepareStatement(sql_update);
            pst.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Creates new form Dynamic_Frame1
     */
    public Dynamic1() {
        initComponents();
        setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);
    }

    public static Dynamic1 getObj() {

        if (df == null) {

            df = new Dynamic1();
        }
        return df;

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        buttonGroup4 = new javax.swing.ButtonGroup();
        buttonGroup_lease_status = new javax.swing.ButtonGroup();
        buttonGroup_penalty = new javax.swing.ButtonGroup();
        buttonGroup_commission = new javax.swing.ButtonGroup();
        buttonGroup_lease_fee = new javax.swing.ButtonGroup();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        contactdetails_panel = new javax.swing.JPanel();
        id_TF = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        tenant_CheckBox = new javax.swing.JCheckBox();
        pin_TF = new javax.swing.JTextField();
        fname_TF = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        landlord_CheckBox = new javax.swing.JCheckBox();
        agent_CheckBox = new javax.swing.JCheckBox();
        jLabel5 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        citzn_combo = new javax.swing.JComboBox();
        jSeparator1 = new javax.swing.JSeparator();
        jPanel5 = new javax.swing.JPanel();
        userImage = new javax.swing.JLabel();
        brwsBtn = new javax.swing.JButton();
        pathTF = new javax.swing.JTextField();
        lname_TF = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        status = new javax.swing.JComboBox();
        jSeparator2 = new javax.swing.JSeparator();
        jScrollPane3 = new javax.swing.JScrollPane();
        contact_details = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;}
        };
        jSeparator3 = new javax.swing.JSeparator();
        contact_type = new javax.swing.JComboBox();
        buyer_CheckBox = new javax.swing.JCheckBox();
        country_sel = new javax.swing.JComboBox();
        jLabel17 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        gender = new javax.swing.JComboBox();
        jLabel51 = new javax.swing.JLabel();
        source_of_income = new javax.swing.JTextField();
        jLabel53 = new javax.swing.JLabel();
        occupation2 = new javax.swing.JComboBox();
        jPanel2 = new javax.swing.JPanel();
        bank_name2 = new javax.swing.JComboBox();
        jLabel47 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        bank_acc_no = new javax.swing.JTextField();
        jLabel45 = new javax.swing.JLabel();
        bank_name = new javax.swing.JTextField();
        bank_branch = new javax.swing.JComboBox<>();
        jPanel15 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        website = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        current_city = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        company_name = new javax.swing.JTextField();
        company_branch = new javax.swing.JTextField();
        jLabel41 = new javax.swing.JLabel();
        county = new javax.swing.JTextField();
        location = new javax.swing.JTextField();
        jLabel104 = new javax.swing.JLabel();
        jLabel107 = new javax.swing.JLabel();
        jLabel131 = new javax.swing.JLabel();
        employee_CheckBox = new javax.swing.JCheckBox();
        jLabel98 = new javax.swing.JLabel();
        jLabel99 = new javax.swing.JLabel();
        jLabel100 = new javax.swing.JLabel();
        jLabel102 = new javax.swing.JLabel();
        occupation = new javax.swing.JTextField();
        jSeparator15 = new javax.swing.JSeparator();
        supplier_CheckBox = new javax.swing.JCheckBox();
        update_successful = new javax.swing.JLabel();
        contactInfo_panel = new javax.swing.JPanel();
        contact_info_pane = new javax.swing.JPanel();
        jSeparator9 = new javax.swing.JSeparator();
        jSeparator10 = new javax.swing.JSeparator();
        jPanel9 = new javax.swing.JPanel();
        jLabel65 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        postal_address = new javax.swing.JTextField();
        city_town = new javax.swing.JComboBox<>();
        jLabel62 = new javax.swing.JLabel();
        relationship = new javax.swing.JComboBox<>();
        contact_priority = new javax.swing.JTextField();
        national_id_no = new javax.swing.JTextField();
        last_name = new javax.swing.JTextField();
        jLabel60 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        first_name = new javax.swing.JTextField();
        jPanel10 = new javax.swing.JPanel();
        jLabel66 = new javax.swing.JLabel();
        telephone5 = new javax.swing.JTextField();
        email4 = new javax.swing.JTextField();
        email5 = new javax.swing.JTextField();
        jLabel68 = new javax.swing.JLabel();
        jLabel71 = new javax.swing.JLabel();
        residential_address = new javax.swing.JTextField();
        telephone4 = new javax.swing.JTextField();
        jLabel70 = new javax.swing.JLabel();
        jLabel67 = new javax.swing.JLabel();
        physical_address = new javax.swing.JTextField();
        jLabel69 = new javax.swing.JLabel();
        jLabel135 = new javax.swing.JLabel();
        contact_ref2 = new javax.swing.JTextField();
        jSeparator14 = new javax.swing.JSeparator();
        jScrollPane2 = new javax.swing.JScrollPane();
        contact_information = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;}
        };
        jSeparator8 = new javax.swing.JSeparator();
        propertyInfo_panel = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        sale_value = new javax.swing.JTextField();
        jLabel54 = new javax.swing.JLabel();
        property_value = new javax.swing.JTextField();
        jLabel52 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        purchase_price = new javax.swing.JTextField();
        dp1 = new javax.swing.JPanel();
        dp = new javax.swing.JPanel();
        jLabel40 = new javax.swing.JLabel();
        asking_value = new javax.swing.JTextField();
        costs = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        country = new javax.swing.JComboBox();
        surburb = new javax.swing.JComboBox();
        jLabel57 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        city = new javax.swing.JComboBox();
        zones = new javax.swing.JComboBox();
        jLabel58 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        bank_name1 = new javax.swing.JComboBox();
        jLabel129 = new javax.swing.JLabel();
        bank_branch1 = new javax.swing.JComboBox<>();
        jLabel38 = new javax.swing.JLabel();
        bank_acc = new javax.swing.JTextField();
        jLabel39 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        property_description = new javax.swing.JTextArea();
        gprs = new javax.swing.JTextField();
        jLabel32 = new javax.swing.JLabel();
        jSeparator5 = new javax.swing.JSeparator();
        jSeparator6 = new javax.swing.JSeparator();
        jSeparator7 = new javax.swing.JSeparator();
        jPanel8 = new javax.swing.JPanel();
        dp2 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        property_attributes = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;}
        };
        jButton1 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        property_status = new javax.swing.JComboBox();
        property_type = new javax.swing.JComboBox();
        jLabel36 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        property_quantity = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        property_category = new javax.swing.JTextField();
        owner = new javax.swing.JTextField();
        jLabel34 = new javax.swing.JLabel();
        jLabel109 = new javax.swing.JLabel();
        jLabel87 = new javax.swing.JLabel();
        tax_code1 = new javax.swing.JTextField();
        property_idlbl = new javax.swing.JLabel();
        parent_property = new javax.swing.JTextField();
        property_id = new javax.swing.JTextField();
        jlblowner = new javax.swing.JLabel();
        jlblsearch_parent = new javax.swing.JLabel();
        jButton9 = new javax.swing.JButton();
        jlblowner1 = new javax.swing.JLabel();
        TAX_LBL = new javax.swing.JLabel();
        jPanel21 = new javax.swing.JPanel();
        pic = new javax.swing.JLabel();
        brws2 = new javax.swing.JButton();
        pathTf2 = new javax.swing.JTextField();
        jScrollPane8 = new javax.swing.JScrollPane();
        properties_table = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;}
        };
        ChartOfAccount_pane = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jtxt_Account_Group = new javax.swing.JTextField();
        jbl_account_code = new javax.swing.JLabel();
        jLabel91 = new javax.swing.JLabel();
        jLabel92 = new javax.swing.JLabel();
        jLabel93 = new javax.swing.JLabel();
        jLabel94 = new javax.swing.JLabel();
        jLabel95 = new javax.swing.JLabel();
        jtxt_Cost_Center = new javax.swing.JTextField();
        jtxt_Account_Description = new javax.swing.JTextField();
        jlbl_Main_Account = new javax.swing.JLabel();
        jlbl_Sub_Account = new javax.swing.JLabel();
        jlbl_Account_Status = new javax.swing.JLabel();
        jtxt_Main_Category = new javax.swing.JTextField();
        jLabel101 = new javax.swing.JLabel();
        jlbl_Sub_Category = new javax.swing.JLabel();
        jtxt_Sub_Category = new javax.swing.JTextField();
        jLabel103 = new javax.swing.JLabel();
        jlbl_Subcategory_Type = new javax.swing.JLabel();
        jtxt_subcategory_Type = new javax.swing.JTextField();
        jtxt_Account_Status = new javax.swing.JTextField();
        jtxt_Main_Account = new javax.swing.JTextField();
        jtxt_Sub_Account = new javax.swing.JTextField();
        jLabel105 = new javax.swing.JLabel();
        jLabel106 = new javax.swing.JLabel();
        jtxt_Contra_Account = new javax.swing.JTextField();
        jlbl_Contra_Account = new javax.swing.JLabel();
        jLabel108 = new javax.swing.JLabel();
        jlbl_Sub_Category_Edit = new javax.swing.JLabel();
        jLabel110 = new javax.swing.JLabel();
        jLabel111 = new javax.swing.JLabel();
        jLabel112 = new javax.swing.JLabel();
        jlbl_AccountFund_Type = new javax.swing.JLabel();
        jtxt_AccountFund_Type = new javax.swing.JTextField();
        jchk_Check_Budget = new javax.swing.JCheckBox();
        jLabel114 = new javax.swing.JLabel();
        jchk_Must_Budget = new javax.swing.JCheckBox();
        jchk_reconcile_Account = new javax.swing.JCheckBox();
        jLabel115 = new javax.swing.JLabel();
        jchk_Restrict_Posting = new javax.swing.JCheckBox();
        jLabel116 = new javax.swing.JLabel();
        jchk_Restrict_Owner = new javax.swing.JCheckBox();
        jLabel117 = new javax.swing.JLabel();
        jLabel118 = new javax.swing.JLabel();
        jlbl_Reconcile_Group = new javax.swing.JLabel();
        jtxt_Reconcile_Group = new javax.swing.JTextField();
        jlbl_Budget_Pattern = new javax.swing.JLabel();
        jtxt_Budget_Pattern = new javax.swing.JTextField();
        jScrollPane6 = new javax.swing.JScrollPane();
        jtbl_Accounts_Master = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;}
        };
        jSeparator18 = new javax.swing.JSeparator();
        jSeparator17 = new javax.swing.JSeparator();
        jLabel96 = new javax.swing.JLabel();
        jlbl_Account_Group = new javax.swing.JLabel();
        main_acc_code = new javax.swing.JLabel();
        sub_acc_code = new javax.swing.JLabel();
        account_status = new javax.swing.JLabel();
        acc_fund_type = new javax.swing.JLabel();
        main_category = new javax.swing.JLabel();
        sub_category = new javax.swing.JLabel();
        sub_categ_type = new javax.swing.JLabel();
        contra_acc = new javax.swing.JLabel();
        reconcile_group = new javax.swing.JLabel();
        budget_pattern = new javax.swing.JLabel();
        jlbl_Account_Group12 = new javax.swing.JLabel();
        jlbl_Account_Group13 = new javax.swing.JLabel();
        jSeparator26 = new javax.swing.JSeparator();
        jSeparator27 = new javax.swing.JSeparator();
        jLabel79 = new javax.swing.JLabel();
        Account_No_tf = new javax.swing.JTextField();
        jLabel130 = new javax.swing.JLabel();
        jCheckBox4 = new javax.swing.JCheckBox();
        jLabel14 = new javax.swing.JLabel();
        contra_acc_lbl = new javax.swing.JLabel();
        fund_unit_icon = new javax.swing.JLabel();
        lease_panel = new javax.swing.JPanel();
        jLabel72 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        lease_id_tf = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jRadioButton_active = new javax.swing.JRadioButton();
        jRadioButton_closed = new javax.swing.JRadioButton();
        dp3 = new javax.swing.JPanel();
        dp5 = new javax.swing.JPanel();
        jLabel84 = new javax.swing.JLabel();
        contact_id_tf = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        lease_table = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;}
        };
        jSeparator16 = new javax.swing.JSeparator();
        current_lease_tf = new javax.swing.JTextField();
        jLabel90 = new javax.swing.JLabel();
        jRadioButton_onhold = new javax.swing.JRadioButton();
        jLabel77 = new javax.swing.JLabel();
        jCombo_lease_types = new javax.swing.JComboBox();
        lease_acc_tf = new javax.swing.JTextField();
        jLabel113 = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        lease_frequency_combo = new javax.swing.JComboBox();
        jLabel75 = new javax.swing.JLabel();
        jSpinner_lease_prd = new javax.swing.JSpinner();
        dp4 = new javax.swing.JPanel();
        dp7 = new javax.swing.JPanel();
        dp6 = new javax.swing.JPanel();
        dp8 = new javax.swing.JPanel();
        jLabel80 = new javax.swing.JLabel();
        tax_code = new javax.swing.JTextField();
        jPanel11 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jLabel119 = new javax.swing.JLabel();
        refund_depst_tf = new javax.swing.JTextField();
        non_refund_dpst_tf = new javax.swing.JTextField();
        jLabel82 = new javax.swing.JLabel();
        jCheckBox1 = new javax.swing.JCheckBox();
        jCheckBox2 = new javax.swing.JCheckBox();
        jLabel44 = new javax.swing.JLabel();
        jLabel85 = new javax.swing.JLabel();
        refundable_deposit_account = new javax.swing.JTextField();
        non_refundable_deposit_account = new javax.swing.JTextField();
        ref_dep = new javax.swing.JLabel();
        nonref_dep = new javax.swing.JLabel();
        other_depst_btn = new javax.swing.JButton();
        jLabel88 = new javax.swing.JLabel();
        water_depst_tf = new javax.swing.JTextField();
        jLabel83 = new javax.swing.JLabel();
        elect_depst_tf = new javax.swing.JTextField();
        jLabel120 = new javax.swing.JLabel();
        water_depst_acc_tf = new javax.swing.JTextField();
        jLabel86 = new javax.swing.JLabel();
        elect_depst_acc_tf = new javax.swing.JTextField();
        water_dep = new javax.swing.JLabel();
        electricty_dep = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        jLabel81 = new javax.swing.JLabel();
        security_charges_tf = new javax.swing.JTextField();
        jLabel78 = new javax.swing.JLabel();
        utility_charges_tf = new javax.swing.JTextField();
        jLabel121 = new javax.swing.JLabel();
        utility_charges_acc = new javax.swing.JTextField();
        more_charges_btn = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        securitycharges_acc = new javax.swing.JTextField();
        security_charge = new javax.swing.JLabel();
        utility_charge = new javax.swing.JLabel();
        jSeparator22 = new javax.swing.JSeparator();
        jSeparator23 = new javax.swing.JSeparator();
        jPanel18 = new javax.swing.JPanel();
        jLabel122 = new javax.swing.JLabel();
        inspector_tf = new javax.swing.JTextField();
        jSpinner_insp_prd = new javax.swing.JSpinner();
        jLabel123 = new javax.swing.JLabel();
        jLabel124 = new javax.swing.JLabel();
        salesman_id_tf = new javax.swing.JTextField();
        jLabel125 = new javax.swing.JLabel();
        jLabel126 = new javax.swing.JLabel();
        jCombo_insp_freq = new javax.swing.JComboBox();
        jTextField38 = new javax.swing.JTextField();
        jPanel19 = new javax.swing.JPanel();
        salesAmnt_TF = new javax.swing.JTextField();
        jSpinner_salecommission = new javax.swing.JSpinner();
        jRadioButton15 = new javax.swing.JRadioButton();
        jRadioButton16 = new javax.swing.JRadioButton();
        jLabel127 = new javax.swing.JLabel();
        salesman_acc_tf = new javax.swing.JTextField();
        jSeparator24 = new javax.swing.JSeparator();
        salesman_id = new javax.swing.JLabel();
        salesman_name = new javax.swing.JLabel();
        salesman_acc = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        inspector = new javax.swing.JLabel();
        jLabel133 = new javax.swing.JLabel();
        jLabel134 = new javax.swing.JLabel();
        inspector_id = new javax.swing.JTextField();
        jPanel13 = new javax.swing.JPanel();
        penaltyAmnt_TF = new javax.swing.JTextField();
        jSpinner_penalty_percent = new javax.swing.JSpinner();
        dp9 = new javax.swing.JPanel();
        jRadioButton17 = new javax.swing.JRadioButton();
        jRadioButton18 = new javax.swing.JRadioButton();
        jLabel128 = new javax.swing.JLabel();
        jCheck_pen_status = new javax.swing.JCheckBox();
        jCheckBox3 = new javax.swing.JCheckBox();
        jLabel73 = new javax.swing.JLabel();
        p_id = new javax.swing.JLabel();
        property_id_combo = new javax.swing.JTextField();
        pro_id_search = new javax.swing.JLabel();
        c_id2 = new javax.swing.JLabel();
        l_id = new javax.swing.JLabel();
        company_branch_tf = new javax.swing.JComboBox<>();
        jLabel89 = new javax.swing.JLabel();
        jLabel132 = new javax.swing.JLabel();
        lease_fee_amount = new javax.swing.JTextField();
        lease_percent2 = new javax.swing.JSpinner();
        jRadioButton20 = new javax.swing.JRadioButton();
        jRadioButton19 = new javax.swing.JRadioButton();
        jLabel18 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        contact_name_lbl = new javax.swing.JLabel();
        lease_acc_desc = new javax.swing.JLabel();
        l_id1 = new javax.swing.JLabel();
        tax_desc = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jCheckBx_aprv_lease = new javax.swing.JCheckBox();
        jSeparator4 = new javax.swing.JSeparator();
        jButton4 = new javax.swing.JButton();
        lease_fee_accnt_tf = new javax.swing.JTextField();
        lease_fee_srch = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jToolBar1 = new javax.swing.JToolBar();
        jButton3 = new javax.swing.JButton();
        save_btn = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jSeparator19 = new javax.swing.JToolBar.Separator();
        refresh_btn = new javax.swing.JButton();
        jSeparator20 = new javax.swing.JToolBar.Separator();
        export_to_excel = new javax.swing.JButton();
        reports = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        contact_ref_no = new javax.swing.JTextField();
        contact_id_no = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jToolBar2 = new javax.swing.JToolBar();
        import_from_excel = new javax.swing.JButton();
        jSeparator21 = new javax.swing.JToolBar.Separator();
        show_path = new javax.swing.JTextField();
        jToolBar3 = new javax.swing.JToolBar();
        jLabel97 = new javax.swing.JLabel();
        searchrecord_tf = new javax.swing.JTextField();
        msg_lbl = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jTabbedPane1.setBackground(new java.awt.Color(255, 255, 255));
        jTabbedPane1.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);
        jTabbedPane1.setToolTipText("Add/viewcontact details, view tenant details, view property details, view contact info");
        jTabbedPane1.setAutoscrolls(true);
        jTabbedPane1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTabbedPane1FocusGained(evt);
            }
        });
        jTabbedPane1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTabbedPane1MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jTabbedPane1MousePressed(evt);
            }
        });

        contactdetails_panel.setBackground(new java.awt.Color(255, 255, 255));
        contactdetails_panel.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Contact Details", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(0, 51, 255))); // NOI18N

        id_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                id_TFActionPerformed(evt);
            }
        });
        id_TF.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                id_TFKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                id_TFKeyTyped(evt);
            }
        });

        jLabel19.setText("National ID:");

        jLabel16.setText("PIN:");

        tenant_CheckBox.setBackground(new java.awt.Color(255, 255, 255));
        tenant_CheckBox.setText("Tenant");

        pin_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pin_TFActionPerformed(evt);
            }
        });
        pin_TF.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                pin_TFKeyReleased(evt);
            }
        });

        fname_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fname_TFActionPerformed(evt);
            }
        });
        fname_TF.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                fname_TFKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                fname_TFKeyTyped(evt);
            }
        });

        jLabel11.setText("Citizenship:");

        landlord_CheckBox.setBackground(new java.awt.Color(255, 255, 255));
        landlord_CheckBox.setText("Landlord/Owner");

        agent_CheckBox.setBackground(new java.awt.Color(255, 255, 255));
        agent_CheckBox.setSelected(true);
        agent_CheckBox.setText("Agent");
        agent_CheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agent_CheckBoxActionPerformed(evt);
            }
        });

        jLabel5.setText("Surname:");

        jLabel2.setText("Contact Type:");

        jLabel4.setText("First Name:");

        citzn_combo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Kenyan", "Non-Kenyan" }));
        citzn_combo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                citzn_comboActionPerformed(evt);
            }
        });

        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        userImage.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        userImage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/maliplus/user-default.png"))); // NOI18N

        brwsBtn.setBackground(new java.awt.Color(255, 255, 255));
        brwsBtn.setText("Browse");
        brwsBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                brwsBtnActionPerformed(evt);
            }
        });

        pathTF.setEditable(false);
        pathTF.setEnabled(false);
        pathTF.setFocusable(false);
        pathTF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pathTFActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(brwsBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pathTF, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(userImage, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(11, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(userImage, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(brwsBtn)
                    .addComponent(pathTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        lname_TF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lname_TFActionPerformed(evt);
            }
        });
        lname_TF.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                lname_TFKeyReleased(evt);
            }
        });

        jLabel10.setText("Status:");

        status.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Active", "Inactive" }));

        jSeparator2.setOrientation(javax.swing.SwingConstants.VERTICAL);

        contact_details.setAutoCreateRowSorter(true);
        contact_details.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        contact_details.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        contact_details.setEditingColumn(0);
        contact_details.setEditingRow(0);
        contact_details.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                contact_detailsMousePressed(evt);
            }
        });
        contact_details.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                contact_detailsKeyPressed(evt);
            }
        });
        jScrollPane3.setViewportView(contact_details);

        contact_type.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Individual", "Company", "Association" }));
        contact_type.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                contact_typePopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        contact_type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contact_typeActionPerformed(evt);
            }
        });

        buyer_CheckBox.setBackground(new java.awt.Color(255, 255, 255));
        buyer_CheckBox.setText("Buyer");

        country_sel.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                country_selPopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        country_sel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                country_selActionPerformed(evt);
            }
        });

        jLabel17.setText("Country:");

        jLabel48.setText("Gender:");

        gender.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "F", "M", "" }));

        jLabel51.setText("Occupation:");

        source_of_income.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                source_of_incomeKeyReleased(evt);
            }
        });

        jLabel53.setText("Source of income:");

        occupation2.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                occupation2PopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        occupation2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                occupation2ActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED), "Banking Information Details:"));

        bank_name2.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                bank_name2PopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        bank_name2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bank_name2ActionPerformed(evt);
            }
        });
        bank_name2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                bank_name2KeyReleased(evt);
            }
        });

        jLabel47.setText("Bank Branch:");

        jLabel46.setText("Bank acc no.");

        jLabel45.setText("Bank name:");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel47, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel46, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel45, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(16, 16, 16)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(bank_branch, 0, 161, Short.MAX_VALUE)
                    .addComponent(bank_name, javax.swing.GroupLayout.DEFAULT_SIZE, 161, Short.MAX_VALUE)
                    .addComponent(bank_acc_no))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bank_name2, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel45)
                    .addComponent(bank_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bank_name2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel46)
                    .addComponent(bank_acc_no, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(3, 3, 3)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel47)
                    .addComponent(bank_branch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel15.setBackground(new java.awt.Color(255, 255, 255));
        jPanel15.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED), "Business Details"));
        jPanel15.setEnabled(false);

        jLabel13.setText("Current city:");

        website.setEnabled(false);
        website.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                websiteKeyReleased(evt);
            }
        });

        jLabel33.setText("Website:");

        current_city.setEnabled(false);
        current_city.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                current_cityKeyReleased(evt);
            }
        });

        jLabel8.setText("Business Branch:");

        jLabel9.setText("Business name:");

        jLabel76.setText("Location:");

        company_name.setEnabled(false);
        company_name.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                company_nameKeyReleased(evt);
            }
        });

        company_branch.setEnabled(false);
        company_branch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                company_branchKeyReleased(evt);
            }
        });

        jLabel41.setText("County:");

        county.setEnabled(false);
        county.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                countyKeyReleased(evt);
            }
        });

        location.setEnabled(false);
        location.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                locationKeyReleased(evt);
            }
        });

        jLabel104.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        jLabel104.setFocusable(false);
        jLabel104.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel104MouseClicked(evt);
            }
        });

        jLabel107.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        jLabel107.setFocusable(false);
        jLabel107.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel107MouseClicked(evt);
            }
        });

        jLabel131.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        jLabel131.setFocusable(false);
        jLabel131.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel131MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel41)
                    .addComponent(jLabel33)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addComponent(jLabel76)
                    .addComponent(jLabel13))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(website, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(company_branch, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(company_name, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(location, javax.swing.GroupLayout.DEFAULT_SIZE, 138, Short.MAX_VALUE)
                    .addComponent(current_city)
                    .addComponent(county))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel104)
                    .addComponent(jLabel107)
                    .addComponent(jLabel131))
                .addContainerGap(73, Short.MAX_VALUE))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(company_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(company_branch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel76)
                            .addComponent(location, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(8, 8, 8)
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(current_city, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(jLabel104)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel107, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel33)
                            .addComponent(website, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel41)
                            .addComponent(county, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel131, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        employee_CheckBox.setBackground(new java.awt.Color(255, 255, 255));
        employee_CheckBox.setText("Employee");

        jLabel98.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        jLabel98.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel98MouseClicked(evt);
            }
        });

        jLabel99.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        jLabel99.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel99MouseClicked(evt);
            }
        });

        jLabel100.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        jLabel100.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel100MouseClicked(evt);
            }
        });

        jLabel102.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        jLabel102.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel102MouseClicked(evt);
            }
        });

        occupation.setEditable(false);
        occupation.setBackground(new java.awt.Color(255, 255, 255));
        occupation.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                occupationKeyReleased(evt);
            }
        });

        jSeparator15.setOrientation(javax.swing.SwingConstants.VERTICAL);

        supplier_CheckBox.setBackground(new java.awt.Color(255, 255, 255));
        supplier_CheckBox.setText("Supplier");
        supplier_CheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                supplier_CheckBoxActionPerformed(evt);
            }
        });

        update_successful.setFont(new java.awt.Font("Vrinda", 1, 24)); // NOI18N
        update_successful.setForeground(new java.awt.Color(51, 0, 153));

        javax.swing.GroupLayout contactdetails_panelLayout = new javax.swing.GroupLayout(contactdetails_panel);
        contactdetails_panel.setLayout(contactdetails_panelLayout);
        contactdetails_panelLayout.setHorizontalGroup(
            contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(contactdetails_panelLayout.createSequentialGroup()
                .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jSeparator3)
                    .addGroup(contactdetails_panelLayout.createSequentialGroup()
                        .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(contactdetails_panelLayout.createSequentialGroup()
                                .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel53, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel51, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel48, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel16, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel19, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(contactdetails_panelLayout.createSequentialGroup()
                                        .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(status, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(contactdetails_panelLayout.createSequentialGroup()
                                                .addComponent(fname_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jLabel98)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jLabel5)))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lname_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel99))
                                    .addGroup(contactdetails_panelLayout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(contact_type, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(contactdetails_panelLayout.createSequentialGroup()
                                                .addComponent(agent_CheckBox)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(landlord_CheckBox)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(tenant_CheckBox)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(buyer_CheckBox)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(employee_CheckBox)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(supplier_CheckBox))
                                            .addGroup(contactdetails_panelLayout.createSequentialGroup()
                                                .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addComponent(pin_TF, javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(id_TF, javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(citzn_combo, 0, 145, Short.MAX_VALUE)
                                                    .addComponent(occupation))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel102)
                                                    .addGroup(contactdetails_panelLayout.createSequentialGroup()
                                                        .addComponent(jLabel17)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                        .addComponent(country_sel, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                    .addComponent(occupation2, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel100)))
                                            .addComponent(gender, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(source_of_income, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addComponent(update_successful, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane3))
                .addGap(18, 18, 18)
                .addComponent(jSeparator15, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        contactdetails_panelLayout.setVerticalGroup(
            contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(contactdetails_panelLayout.createSequentialGroup()
                .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jSeparator15, javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(contactdetails_panelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(contactdetails_panelLayout.createSequentialGroup()
                                .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel2)
                                    .addComponent(contact_type, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(agent_CheckBox)
                                    .addComponent(landlord_CheckBox)
                                    .addComponent(tenant_CheckBox)
                                    .addComponent(buyer_CheckBox)
                                    .addComponent(employee_CheckBox)
                                    .addComponent(supplier_CheckBox))
                                .addGap(13, 13, 13)
                                .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel10)
                                    .addComponent(status, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel4)
                                        .addComponent(fname_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel5)
                                        .addComponent(lname_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel99)
                                    .addComponent(jLabel98))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel11)
                                    .addGroup(contactdetails_panelLayout.createSequentialGroup()
                                        .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(citzn_combo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(country_sel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel17))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(id_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel19))
                                            .addComponent(jLabel100))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(pin_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel16))
                                            .addComponent(jLabel102))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel48)
                                    .addComponent(gender, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(occupation2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel51)
                                        .addComponent(occupation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel53)
                                    .addComponent(source_of_income, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(update_successful, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jSeparator2)
                            .addGroup(contactdetails_panelLayout.createSequentialGroup()
                                .addGroup(contactdetails_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(contactdetails_panelLayout.createSequentialGroup()
                                        .addGap(11, 11, 11)
                                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(contactdetails_panelLayout.createSequentialGroup()
                                        .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 7, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        jTabbedPane1.addTab("   Contact Details   ", contactdetails_panel);

        contactInfo_panel.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(51, 51, 255))); // NOI18N
        contactInfo_panel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                contactInfo_panelMousePressed(evt);
            }
        });

        contact_info_pane.setBackground(new java.awt.Color(255, 255, 255));
        contact_info_pane.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED), "Other contact details:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(51, 51, 255))); // NOI18N

        jSeparator9.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jSeparator10.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));
        jPanel9.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel65.setText("City/Town:");

        jLabel64.setText("Postal Address:");

        jLabel61.setText("Last Name:");

        city_town.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Nairobi", "Eldoret", "Kisumu", "Mombasa", " " }));
        city_town.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                city_townPopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });

        jLabel62.setText("Relationship:");

        relationship.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Father", "Mother", "Brother", "Sister", "Other" }));
        relationship.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                relationshipPopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });

        jLabel60.setText("First Name:");

        jLabel59.setText("Contact Priority:");

        jLabel63.setText("National ID no.");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel59)
                    .addComponent(jLabel60)
                    .addComponent(jLabel61)
                    .addComponent(jLabel62)
                    .addComponent(jLabel63)
                    .addComponent(jLabel64)
                    .addComponent(jLabel65))
                .addGap(10, 10, 10)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(postal_address)
                    .addComponent(last_name)
                    .addComponent(first_name)
                    .addComponent(national_id_no)
                    .addComponent(contact_priority)
                    .addComponent(relationship, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(city_town, 0, 155, Short.MAX_VALUE))
                .addContainerGap(96, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel59)
                    .addComponent(contact_priority, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel60)
                    .addComponent(first_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel61)
                    .addComponent(last_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel62)
                    .addComponent(relationship, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel63)
                    .addComponent(national_id_no, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel64)
                    .addComponent(postal_address, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel65)
                    .addComponent(city_town, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));
        jPanel10.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel66.setText("Physical Address/Location:");

        jLabel68.setText("Telephone 1:");

        jLabel71.setText("Email 2:");

        jLabel70.setText("Email 1:");

        jLabel67.setText("Residential Address:");

        jLabel69.setText("Telephone 2:");

        jLabel135.setText("Contact Ref:");

        contact_ref2.setEditable(false);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel66)
                    .addComponent(jLabel67)
                    .addComponent(jLabel70)
                    .addComponent(jLabel71)
                    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jLabel69, javax.swing.GroupLayout.DEFAULT_SIZE, 98, Short.MAX_VALUE)
                        .addComponent(jLabel68, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(email4)
                    .addComponent(telephone5)
                    .addComponent(telephone4)
                    .addComponent(residential_address)
                    .addComponent(physical_address)
                    .addComponent(email5, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addComponent(jLabel135)
                .addGap(10, 10, 10)
                .addComponent(contact_ref2, javax.swing.GroupLayout.DEFAULT_SIZE, 203, Short.MAX_VALUE)
                .addGap(327, 327, 327))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel135)
                        .addComponent(contact_ref2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel66)
                        .addComponent(physical_address, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel67)
                    .addComponent(residential_address, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel68)
                    .addComponent(telephone4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel69)
                    .addComponent(telephone5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel70)
                    .addComponent(email4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel71)
                    .addComponent(email5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        contact_information.setAutoCreateRowSorter(true);
        contact_information.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        contact_information.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                contact_informationMousePressed(evt);
            }
        });
        jScrollPane2.setViewportView(contact_information);

        javax.swing.GroupLayout contact_info_paneLayout = new javax.swing.GroupLayout(contact_info_pane);
        contact_info_pane.setLayout(contact_info_paneLayout);
        contact_info_paneLayout.setHorizontalGroup(
            contact_info_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(contact_info_paneLayout.createSequentialGroup()
                .addGroup(contact_info_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(contact_info_paneLayout.createSequentialGroup()
                        .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jSeparator9, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jSeparator14)
                    .addComponent(jScrollPane2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator10, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        contact_info_paneLayout.setVerticalGroup(
            contact_info_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator10)
            .addGroup(contact_info_paneLayout.createSequentialGroup()
                .addGroup(contact_info_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jSeparator9, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel9, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator14, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 427, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout contactInfo_panelLayout = new javax.swing.GroupLayout(contactInfo_panel);
        contactInfo_panel.setLayout(contactInfo_panelLayout);
        contactInfo_panelLayout.setHorizontalGroup(
            contactInfo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(contactInfo_panelLayout.createSequentialGroup()
                .addGroup(contactInfo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jSeparator8, javax.swing.GroupLayout.DEFAULT_SIZE, 1368, Short.MAX_VALUE)
                    .addComponent(contact_info_pane, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        contactInfo_panelLayout.setVerticalGroup(
            contactInfo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(contactInfo_panelLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jSeparator8, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(contact_info_pane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("    Contact Info   ", contactInfo_panel);

        propertyInfo_panel.setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED), "Property Values", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(51, 51, 255))); // NOI18N

        sale_value.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sale_valueActionPerformed(evt);
            }
        });

        jLabel54.setText("Sale Value:");

        property_value.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                property_valueActionPerformed(evt);
            }
        });

        jLabel52.setText("Propery value:");

        jLabel49.setText("Purchase price:");

        purchase_price.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                purchase_priceActionPerformed(evt);
            }
        });

        dp1.setBackground(new java.awt.Color(255, 255, 255));
        dp1.setBorder(javax.swing.BorderFactory.createTitledBorder("Sale Date"));
        dp1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dp1MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout dp1Layout = new javax.swing.GroupLayout(dp1);
        dp1.setLayout(dp1Layout);
        dp1Layout.setHorizontalGroup(
            dp1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 182, Short.MAX_VALUE)
        );
        dp1Layout.setVerticalGroup(
            dp1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 11, Short.MAX_VALUE)
        );

        dp.setBackground(new java.awt.Color(255, 255, 255));
        dp.setBorder(javax.swing.BorderFactory.createTitledBorder("Valuation Date"));
        dp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dpMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout dpLayout = new javax.swing.GroupLayout(dp);
        dp.setLayout(dpLayout);
        dpLayout.setHorizontalGroup(
            dpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 179, Short.MAX_VALUE)
        );
        dpLayout.setVerticalGroup(
            dpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 14, Short.MAX_VALUE)
        );

        jLabel40.setText("Lease value:");

        costs.setBackground(new java.awt.Color(255, 255, 255));
        costs.setText("Cost Table");
        costs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                costsActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(sale_value, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dp1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(asking_value, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(purchase_price, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(property_value, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(costs, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel54)
                    .addComponent(jLabel40)
                    .addComponent(jLabel52)
                    .addComponent(jLabel49))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(dp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(property_value, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel52, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel49)
                    .addComponent(purchase_price, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(dp1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel54)
                    .addComponent(sale_value, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel40)
                    .addComponent(asking_value, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(costs)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED), " Location Details", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(51, 51, 255))); // NOI18N

        country.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                countryPopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        country.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                countryActionPerformed(evt);
            }
        });

        surburb.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                surburbPopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        surburb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                surburbActionPerformed(evt);
            }
        });

        jLabel57.setText("Surburb:");

        jLabel55.setText("Country:");

        jLabel56.setText("City:");

        city.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                cityPopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
                cityPopupMenuWillBecomeVisible(evt);
            }
        });
        city.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cityActionPerformed(evt);
            }
        });

        zones.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                zonesPopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        zones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                zonesActionPerformed(evt);
            }
        });

        jLabel58.setText("Zone:");

        jLabel37.setText("Bank Name:");

        bank_name1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { " " }));
        bank_name1.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                bank_name1PopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        bank_name1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bank_name1ActionPerformed(evt);
            }
        });
        bank_name1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                bank_name1KeyReleased(evt);
            }
        });

        jLabel129.setText("Bank branch:");

        bank_branch1.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                bank_branch1PopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });

        jLabel38.setText("Bank account:");

        jLabel39.setText("Property Description:");

        property_description.setColumns(20);
        property_description.setLineWrap(true);
        property_description.setRows(5);
        property_description.setWrapStyleWord(true);
        jScrollPane4.setViewportView(property_description);

        jLabel32.setText("Property GPRS:");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel32)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(gprs, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel56, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel55, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(country, 0, 100, Short.MAX_VALUE)
                            .addComponent(city, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(jLabel57)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(surburb, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(jLabel58)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(zones, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(jLabel37)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(bank_name1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(jLabel129)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(bank_branch1, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel38)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bank_acc, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32)
                        .addComponent(jLabel39)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(surburb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel37)
                                .addComponent(bank_name1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(bank_acc, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel38)
                                .addComponent(jLabel39))
                            .addComponent(jLabel57)
                            .addComponent(country, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel55))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel58)
                                .addComponent(zones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel129)
                                .addComponent(bank_branch1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(city, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel56))))
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(gprs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel32))
                .addContainerGap())
        );

        jSeparator5.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));
        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED), "Property Attributes", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(51, 51, 255))); // NOI18N

        dp2.setBackground(new java.awt.Color(255, 255, 255));
        dp2.setBorder(javax.swing.BorderFactory.createTitledBorder("Date Available"));
        dp2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dp2MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout dp2Layout = new javax.swing.GroupLayout(dp2);
        dp2.setLayout(dp2Layout);
        dp2Layout.setHorizontalGroup(
            dp2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 153, Short.MAX_VALUE)
        );
        dp2Layout.setVerticalGroup(
            dp2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        property_attributes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        property_attributes.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jScrollPane7.setViewportView(property_attributes);

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setText("More Attributes");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton1MousePressed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addComponent(dp2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addGap(5, 5, 5))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(dp2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED), "Property Details", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(51, 51, 255))); // NOI18N

        property_status.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "OPEN", "CLOSED", "" }));
        property_status.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                property_statusActionPerformed(evt);
            }
        });

        property_type.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                property_typePopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        property_type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                property_typeActionPerformed(evt);
            }
        });

        jLabel36.setText("Owner:");

        jLabel31.setText("Property Status:");

        jLabel35.setText("Parent property:");

        jLabel20.setText("Property Id:");

        jLabel27.setText("Property category:");

        jLabel23.setText("Property quantity:");

        property_category.setEditable(false);

        owner.setEditable(false);
        owner.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ownerKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                ownerKeyTyped(evt);
            }
        });

        jLabel34.setText("Property Type:");

        jLabel109.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        jLabel109.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel109MouseClicked(evt);
            }
        });

        jLabel87.setText("Tax Code:");

        tax_code1.setEditable(false);

        property_idlbl.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N

        parent_property.setEditable(false);
        parent_property.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                parent_propertyKeyTyped(evt);
            }
        });

        property_id.setEditable(false);

        jlblowner.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        jlblowner.setToolTipText("Change Owner");
        jlblowner.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlblownerMouseClicked(evt);
            }
        });

        jlblsearch_parent.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        jlblsearch_parent.setToolTipText("Search Parent Property");
        jlblsearch_parent.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlblsearch_parentMouseClicked(evt);
            }
        });

        jButton9.setBackground(new java.awt.Color(255, 255, 255));
        jButton9.setText("Add new");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jlblowner1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        jlblowner1.setToolTipText("Change Owner");
        jlblowner1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlblowner1MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel20)
                    .addComponent(jLabel31)
                    .addComponent(jLabel34)
                    .addComponent(jLabel35)
                    .addComponent(jLabel23)
                    .addComponent(jLabel27)
                    .addComponent(jLabel36)
                    .addComponent(jLabel87))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(parent_property, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(property_category, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(property_quantity, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(property_type, javax.swing.GroupLayout.Alignment.LEADING, 0, 0, Short.MAX_VALUE)
                            .addComponent(property_status, javax.swing.GroupLayout.Alignment.LEADING, 0, 0, Short.MAX_VALUE)
                            .addComponent(owner, javax.swing.GroupLayout.Alignment.LEADING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel109)
                            .addComponent(jlblsearch_parent)
                            .addComponent(jlblowner))
                        .addGap(70, 70, 70))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(property_id)
                                    .addComponent(jButton9, javax.swing.GroupLayout.DEFAULT_SIZE, 105, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(property_idlbl, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(tax_code1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jlblowner1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(TAX_LBL, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(6, 6, 6)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jButton9)
                .addGap(12, 12, 12)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(property_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel20))
                    .addComponent(property_idlbl, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel31)
                            .addComponent(property_status, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel34)
                            .addComponent(property_type, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel35)
                                .addComponent(parent_property, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jlblsearch_parent))
                        .addGap(9, 9, 9)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel23)
                            .addComponent(property_quantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel27)
                                .addComponent(property_category, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel109))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel36)
                                .addComponent(owner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jlblowner))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel87)
                                    .addComponent(tax_code1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addComponent(TAX_LBL, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addComponent(jlblowner1))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel21.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED), "Slide Show"));
        jPanel21.setPreferredSize(new java.awt.Dimension(400, 200));

        pic.setBackground(new java.awt.Color(255, 255, 255));
        pic.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Mali_bg.png"))); // NOI18N
        pic.setMaximumSize(new java.awt.Dimension(400, 200));
        pic.setMinimumSize(new java.awt.Dimension(400, 200));
        pic.setPreferredSize(new java.awt.Dimension(400, 200));
        pic.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                picMouseClicked(evt);
            }
        });

        brws2.setBackground(new java.awt.Color(255, 255, 255));
        brws2.setText("Browse");
        brws2.setToolTipText("You can select upto 3 (three) images of your choice.");
        brws2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                brws2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pic, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel21Layout.createSequentialGroup()
                        .addComponent(brws2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(pathTf2, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addComponent(pic, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(brws2)
                    .addComponent(pathTf2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        properties_table.setAutoCreateRowSorter(true);
        properties_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        properties_table.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        properties_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                properties_tableMouseClicked(evt);
            }
        });
        jScrollPane8.setViewportView(properties_table);

        javax.swing.GroupLayout propertyInfo_panelLayout = new javax.swing.GroupLayout(propertyInfo_panel);
        propertyInfo_panel.setLayout(propertyInfo_panelLayout);
        propertyInfo_panelLayout.setHorizontalGroup(
            propertyInfo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(propertyInfo_panelLayout.createSequentialGroup()
                .addGroup(propertyInfo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator6, javax.swing.GroupLayout.PREFERRED_SIZE, 1422, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(propertyInfo_panelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(propertyInfo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jSeparator7)
                            .addGroup(propertyInfo_panelLayout.createSequentialGroup()
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, 424, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane8, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addGap(38, 38, 38))
        );
        propertyInfo_panelLayout.setVerticalGroup(
            propertyInfo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(propertyInfo_panelLayout.createSequentialGroup()
                .addGroup(propertyInfo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 279, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, 308, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(propertyInfo_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jSeparator6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator7, javax.swing.GroupLayout.PREFERRED_SIZE, 7, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
                .addGap(42, 42, 42))
        );

        jTabbedPane1.addTab("   Properties   ", propertyInfo_panel);

        ChartOfAccount_pane.setBackground(new java.awt.Color(255, 255, 255));

        jLabel3.setText("Account Group:");

        jtxt_Account_Group.setEditable(false);
        jtxt_Account_Group.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxt_Account_GroupActionPerformed(evt);
            }
        });

        jbl_account_code.setText("<- Select account group");

        jLabel91.setText("Main account code:");

        jLabel92.setText("Sub account code:");

        jLabel93.setText("Account Status:");

        jLabel94.setText("Account Description:");

        jLabel95.setText("Cost Center or fund unit:");

        jtxt_Cost_Center.setEditable(false);
        jtxt_Cost_Center.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxt_Cost_CenterActionPerformed(evt);
            }
        });

        jtxt_Account_Description.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxt_Account_DescriptionActionPerformed(evt);
            }
        });

        jtxt_Main_Category.setEditable(false);
        jtxt_Main_Category.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxt_Main_CategoryActionPerformed(evt);
            }
        });

        jLabel101.setText("Sub Category:");

        jtxt_Sub_Category.setEditable(false);
        jtxt_Sub_Category.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxt_Sub_CategoryActionPerformed(evt);
            }
        });

        jLabel103.setText("Reconcile A/c?");

        jtxt_subcategory_Type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxt_subcategory_TypeActionPerformed(evt);
            }
        });

        jtxt_Account_Status.setEditable(false);
        jtxt_Account_Status.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxt_Account_StatusActionPerformed(evt);
            }
        });

        jtxt_Main_Account.setEditable(false);
        jtxt_Main_Account.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxt_Main_AccountActionPerformed(evt);
            }
        });

        jtxt_Sub_Account.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxt_Sub_AccountActionPerformed(evt);
            }
        });

        jLabel105.setText("Contra Account:");

        jtxt_Contra_Account.setEditable(false);
        jtxt_Contra_Account.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxt_Contra_AccountActionPerformed(evt);
            }
        });

        jLabel110.setText("Account/Fund Type:");

        jLabel111.setText("Must Budget?");

        jLabel112.setText("Check Budget?");

        jtxt_AccountFund_Type.setEditable(false);
        jtxt_AccountFund_Type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxt_AccountFund_TypeActionPerformed(evt);
            }
        });

        jLabel114.setText("Sub Categ Type:");

        jLabel115.setText("Restrict Posting?");

        jchk_Restrict_Posting.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jchk_Restrict_PostingActionPerformed(evt);
            }
        });

        jLabel116.setText("Restrict to Owner");

        jLabel117.setText("Reconcile Group");

        jLabel118.setText("Budget Pattern");

        jtxt_Reconcile_Group.setEditable(false);
        jtxt_Reconcile_Group.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxt_Reconcile_GroupActionPerformed(evt);
            }
        });

        jtxt_Budget_Pattern.setEditable(false);
        jtxt_Budget_Pattern.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxt_Budget_PatternActionPerformed(evt);
            }
        });

        jtbl_Accounts_Master.setAutoCreateRowSorter(true);
        jtbl_Accounts_Master.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jtbl_Accounts_Master.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jtbl_Accounts_Master.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jtbl_Accounts_MasterMousePressed(evt);
            }
        });
        jScrollPane6.setViewportView(jtbl_Accounts_Master);

        jLabel96.setText("Main Category:");

        jlbl_Account_Group.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        jlbl_Account_Group.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlbl_Account_GroupMouseClicked(evt);
            }
        });

        main_acc_code.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        main_acc_code.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                main_acc_codeMouseClicked(evt);
            }
        });

        sub_acc_code.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        sub_acc_code.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sub_acc_codeMouseClicked(evt);
            }
        });

        account_status.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        account_status.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                account_statusMouseClicked(evt);
            }
        });

        acc_fund_type.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        acc_fund_type.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                acc_fund_typeMouseClicked(evt);
            }
        });

        main_category.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        main_category.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                main_categoryMouseClicked(evt);
            }
        });

        sub_category.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        sub_category.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sub_categoryMouseClicked(evt);
            }
        });

        sub_categ_type.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        sub_categ_type.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sub_categ_typeMouseClicked(evt);
            }
        });

        contra_acc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        contra_acc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                contra_accMouseClicked(evt);
            }
        });

        reconcile_group.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        reconcile_group.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                reconcile_groupMouseClicked(evt);
            }
        });

        budget_pattern.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        budget_pattern.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                budget_patternMouseClicked(evt);
            }
        });

        jlbl_Account_Group12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/edit.JPG"))); // NOI18N
        jlbl_Account_Group12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlbl_Account_Group12MouseClicked(evt);
            }
        });

        jlbl_Account_Group13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/edit.JPG"))); // NOI18N
        jlbl_Account_Group13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlbl_Account_Group13MouseClicked(evt);
            }
        });

        jSeparator27.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jLabel79.setText("Account Number");

        Account_No_tf.setEditable(false);

        jLabel130.setText("Transaction Account:");

        jCheckBox4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox4ActionPerformed(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 51, 51));

        fund_unit_icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Capture.JPG"))); // NOI18N
        fund_unit_icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                fund_unit_iconMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                fund_unit_iconMouseEntered(evt);
            }
        });

        javax.swing.GroupLayout ChartOfAccount_paneLayout = new javax.swing.GroupLayout(ChartOfAccount_pane);
        ChartOfAccount_pane.setLayout(ChartOfAccount_paneLayout);
        ChartOfAccount_paneLayout.setHorizontalGroup(
            ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel94)
                                            .addComponent(jLabel91)
                                            .addComponent(jLabel92)
                                            .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                                .addComponent(jLabel95)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(fund_unit_icon)))
                                        .addGap(4, 4, 4)
                                        .addComponent(jtxt_Cost_Center, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                        .addComponent(jLabel93)
                                        .addGap(281, 281, 281)
                                        .addComponent(contra_acc))
                                    .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addGap(18, 18, 18)
                                        .addComponent(jlbl_Account_Group)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jtxt_Account_Group, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jbl_account_code)
                                        .addGap(432, 432, 432)
                                        .addComponent(jLabel79)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel110)
                                            .addComponent(jLabel111))
                                        .addGap(18, 18, 18)
                                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                                .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jchk_Check_Budget, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jchk_Must_Budget))
                                                .addGap(266, 266, 266)
                                                .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                                        .addComponent(jLabel116)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(jchk_Restrict_Owner))
                                                    .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                        .addComponent(jchk_reconcile_Account)
                                                        .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                                            .addComponent(jLabel115)
                                                            .addGap(18, 18, 18)
                                                            .addComponent(jchk_Restrict_Posting)))))
                                            .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                                .addComponent(acc_fund_type)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jtxt_AccountFund_Type, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(87, 87, 87)
                                                .addComponent(jLabel103))))
                                    .addComponent(jLabel112))
                                .addGap(117, 117, 117)
                                .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel117)
                                            .addComponent(jLabel118))
                                        .addGap(18, 18, 18)
                                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                                .addComponent(reconcile_group)
                                                .addGap(18, 18, 18)
                                                .addComponent(jtxt_Reconcile_Group))
                                            .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                                .addComponent(budget_pattern)
                                                .addGap(18, 18, 18)
                                                .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jCheckBox4)
                                                    .addComponent(jtxt_Budget_Pattern, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                    .addComponent(jLabel130)))))
                    .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                        .addGap(155, 155, 155)
                        .addComponent(jlbl_Sub_Account)
                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                .addGap(78, 78, 78)
                                .addComponent(jLabel108))
                            .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jtxt_Account_Description, javax.swing.GroupLayout.PREFERRED_SIZE, 552, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(318, 318, 318)
                                .addComponent(jlbl_Reconcile_Group))))
                    .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jSeparator17, javax.swing.GroupLayout.DEFAULT_SIZE, 1228, Short.MAX_VALUE)
                                    .addComponent(jSeparator26)
                                    .addComponent(jSeparator18)))
                            .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 1228, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jlbl_AccountFund_Type)
                            .addComponent(jlbl_Main_Account)
                            .addComponent(jlbl_Account_Status)))
                    .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                        .addGap(151, 151, 151)
                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(main_acc_code)
                            .addComponent(sub_acc_code)
                            .addComponent(account_status))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jtxt_Main_Account, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jtxt_Account_Status, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                .addComponent(jtxt_Sub_Account, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jlbl_Account_Group13)))
                        .addGap(18, 18, 18)
                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel96, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel105, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel114, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel101, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(9, 9, 9)
                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(sub_categ_type)
                            .addComponent(sub_category)
                            .addComponent(main_category))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                        .addGap(427, 427, 427)
                                        .addComponent(jlbl_Subcategory_Type))
                                    .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                        .addComponent(jtxt_Main_Category, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                                .addGap(399, 399, 399)
                                                .addComponent(jlbl_Sub_Category_Edit))
                                            .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jLabel106)))))
                                .addGap(552, 552, 552)
                                .addComponent(Account_No_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                .addGap(37, 37, 37)
                                .addComponent(jlbl_Sub_Category))
                            .addComponent(jtxt_Sub_Category, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jtxt_subcategory_Type, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jtxt_Contra_Account, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jlbl_Account_Group12)
                                    .addComponent(contra_acc_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator27, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jlbl_Budget_Pattern, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jlbl_Contra_Account, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        ChartOfAccount_paneLayout.setVerticalGroup(
            ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(jlbl_Contra_Account)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                            .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel79)
                            .addComponent(jbl_account_code)
                            .addComponent(jtxt_Account_Group, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jlbl_Account_Group)
                            .addComponent(jLabel3))
                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                .addGap(41, 41, 41)
                                .addComponent(jlbl_Sub_Category_Edit))
                            .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                        .addGap(183, 183, 183)
                                        .addComponent(jlbl_Reconcile_Group)
                                        .addGap(30, 30, 30)
                                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jSeparator26, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jlbl_Budget_Pattern, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                                            .addComponent(jLabel110)
                                            .addComponent(jtxt_AccountFund_Type, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(acc_fund_type)
                                            .addComponent(jLabel103)
                                            .addComponent(jchk_reconcile_Account)
                                            .addComponent(jLabel117)
                                            .addComponent(jtxt_Reconcile_Group, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(reconcile_group))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                                            .addComponent(jLabel111)
                                            .addComponent(jchk_Must_Budget)
                                            .addComponent(jLabel115)
                                            .addComponent(jLabel118)
                                            .addComponent(budget_pattern)
                                            .addComponent(jtxt_Budget_Pattern, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jchk_Restrict_Posting)))
                                    .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                                            .addComponent(jLabel95)
                                            .addComponent(jtxt_Main_Category, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(main_category)
                                            .addComponent(fund_unit_icon))
                                        .addGap(18, 18, 18)
                                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                                            .addComponent(jLabel101, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel91)
                                            .addComponent(jtxt_Sub_Category, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(main_acc_code)
                                            .addComponent(sub_category))
                                        .addGap(18, 18, 18)
                                        .addComponent(jlbl_Main_Account)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                                            .addComponent(jLabel92, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel114)
                                            .addComponent(jtxt_subcategory_Type, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(sub_acc_code)
                                            .addComponent(sub_categ_type)
                                            .addComponent(jlbl_Account_Group12)
                                            .addComponent(jlbl_Account_Group13))
                                        .addGap(18, 18, 18)
                                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                                                .addComponent(jLabel93)
                                                .addComponent(jLabel105)
                                                .addComponent(jtxt_Contra_Account, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(account_status)
                                                .addComponent(contra_acc)
                                                .addComponent(contra_acc_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(jlbl_Subcategory_Type))
                                        .addGap(18, 18, 18)
                                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jLabel94)
                                            .addComponent(jtxt_Account_Description, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                                    .addComponent(jLabel112)
                                    .addComponent(jchk_Check_Budget)
                                    .addComponent(jLabel116)
                                    .addComponent(jchk_Restrict_Owner)
                                    .addComponent(jLabel130)
                                    .addComponent(jCheckBox4)))
                            .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jSeparator17, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                        .addGap(11, 11, 11)
                                        .addComponent(jlbl_Sub_Category))
                                    .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                        .addGap(2, 2, 2)
                                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jtxt_Cost_Center, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel96))
                                        .addGap(18, 18, 18)
                                        .addComponent(jtxt_Main_Account, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(24, 24, 24)
                                        .addComponent(jtxt_Sub_Account, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jtxt_Account_Status, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(23, 23, 23)
                                        .addComponent(jLabel108))))
                            .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel106, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addComponent(jSeparator18, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jlbl_Sub_Account)
                        .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addGroup(ChartOfAccount_paneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jlbl_Account_Status)
                                    .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                        .addGap(66, 66, 66)
                                        .addComponent(jlbl_AccountFund_Type)))
                                .addGap(0, 174, Short.MAX_VALUE))
                            .addGroup(ChartOfAccount_paneLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))))
                    .addComponent(jSeparator27)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ChartOfAccount_paneLayout.createSequentialGroup()
                        .addContainerGap(14, Short.MAX_VALUE)
                        .addComponent(Account_No_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(639, 639, 639)))
                .addContainerGap())
        );

        jTabbedPane1.addTab("   Chart of Accounts   ", ChartOfAccount_pane);

        lease_panel.setBackground(new java.awt.Color(255, 255, 255));
        lease_panel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Leasing", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(51, 51, 255))); // NOI18N
        lease_panel.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                lease_panelFocusLost(evt);
            }
        });

        jLabel72.setText("Lease Type");

        jLabel6.setText("Lease ID");

        lease_id_tf.setEditable(false);
        lease_id_tf.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                lease_id_tfKeyTyped(evt);
            }
        });

        jLabel7.setText("Property ID ");

        jRadioButton_active.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup_lease_status.add(jRadioButton_active);
        jRadioButton_active.setSelected(true);
        jRadioButton_active.setText("Active");
        jRadioButton_active.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton_activeActionPerformed(evt);
            }
        });

        jRadioButton_closed.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup_lease_status.add(jRadioButton_closed);
        jRadioButton_closed.setText("Closed");
        jRadioButton_closed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton_closedActionPerformed(evt);
            }
        });

        dp3.setBackground(new java.awt.Color(255, 255, 255));
        dp3.setBorder(javax.swing.BorderFactory.createTitledBorder("Start Date"));
        dp3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dp3MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout dp3Layout = new javax.swing.GroupLayout(dp3);
        dp3.setLayout(dp3Layout);
        dp3Layout.setHorizontalGroup(
            dp3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 175, Short.MAX_VALUE)
        );
        dp3Layout.setVerticalGroup(
            dp3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 12, Short.MAX_VALUE)
        );

        dp5.setBackground(new java.awt.Color(255, 255, 255));
        dp5.setBorder(javax.swing.BorderFactory.createTitledBorder("End Date"));
        dp5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dp5MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout dp5Layout = new javax.swing.GroupLayout(dp5);
        dp5.setLayout(dp5Layout);
        dp5Layout.setHorizontalGroup(
            dp5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 175, Short.MAX_VALUE)
        );
        dp5Layout.setVerticalGroup(
            dp5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 12, Short.MAX_VALUE)
        );

        jLabel84.setText("Contact ID");

        contact_id_tf.setEditable(false);
        contact_id_tf.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                contact_id_tfKeyTyped(evt);
            }
        });

        lease_table.setAutoCreateRowSorter(true);
        lease_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        lease_table.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        lease_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lease_tableMousePressed(evt);
            }
        });
        jScrollPane5.setViewportView(lease_table);

        current_lease_tf.setText("0");
        current_lease_tf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                current_lease_tfActionPerformed(evt);
            }
        });
        current_lease_tf.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                current_lease_tfKeyTyped(evt);
            }
        });

        jLabel90.setText("Current Lease/Rent");

        jRadioButton_onhold.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup_lease_status.add(jRadioButton_onhold);
        jRadioButton_onhold.setText("On Hold");
        jRadioButton_onhold.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton_onholdActionPerformed(evt);
            }
        });

        jLabel77.setText("Lease Status");

        jCombo_lease_types.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                jCombo_lease_typesPopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });

        lease_acc_tf.setEditable(false);

        jLabel113.setText("Lease Account");

        jLabel74.setText("Frequency");

        lease_frequency_combo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Not selected", "Daily", "Weekly", "Monthly", "Yearly" }));
        lease_frequency_combo.setEnabled(false);
        lease_frequency_combo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lease_frequency_comboActionPerformed(evt);
            }
        });

        jLabel75.setText("Period");

        jSpinner_lease_prd.setEnabled(false);
        jSpinner_lease_prd.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSpinner_lease_prdStateChanged(evt);
            }
        });

        dp4.setBackground(new java.awt.Color(255, 255, 255));
        dp4.setBorder(javax.swing.BorderFactory.createTitledBorder("Lease-due-date"));
        dp4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dp4MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout dp4Layout = new javax.swing.GroupLayout(dp4);
        dp4.setLayout(dp4Layout);
        dp4Layout.setHorizontalGroup(
            dp4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 175, Short.MAX_VALUE)
        );
        dp4Layout.setVerticalGroup(
            dp4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 12, Short.MAX_VALUE)
        );

        dp7.setBackground(new java.awt.Color(255, 255, 255));
        dp7.setBorder(javax.swing.BorderFactory.createTitledBorder("Next Lease/Rent Period Start"));
        dp7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dp7MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout dp7Layout = new javax.swing.GroupLayout(dp7);
        dp7.setLayout(dp7Layout);
        dp7Layout.setHorizontalGroup(
            dp7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 175, Short.MAX_VALUE)
        );
        dp7Layout.setVerticalGroup(
            dp7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 12, Short.MAX_VALUE)
        );

        dp6.setBackground(new java.awt.Color(255, 255, 255));
        dp6.setBorder(javax.swing.BorderFactory.createTitledBorder("Lease/Rent-change-date"));
        dp6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dp6MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout dp6Layout = new javax.swing.GroupLayout(dp6);
        dp6.setLayout(dp6Layout);
        dp6Layout.setHorizontalGroup(
            dp6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 175, Short.MAX_VALUE)
        );
        dp6Layout.setVerticalGroup(
            dp6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 12, Short.MAX_VALUE)
        );

        dp8.setBackground(new java.awt.Color(255, 255, 255));
        dp8.setBorder(javax.swing.BorderFactory.createTitledBorder("Lease/Rent-review-date"));
        dp8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dp8MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout dp8Layout = new javax.swing.GroupLayout(dp8);
        dp8.setLayout(dp8Layout);
        dp8Layout.setHorizontalGroup(
            dp8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 175, Short.MAX_VALUE)
        );
        dp8Layout.setVerticalGroup(
            dp8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 12, Short.MAX_VALUE)
        );

        jLabel80.setText("Tax Code ");

        tax_code.setEditable(false);
        tax_code.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tax_codeActionPerformed(evt);
            }
        });

        jPanel11.setBackground(new java.awt.Color(255, 255, 255));
        jPanel11.setBorder(javax.swing.BorderFactory.createTitledBorder("Deposits"));

        jPanel16.setBackground(new java.awt.Color(255, 255, 255));
        jPanel16.setBorder(javax.swing.BorderFactory.createTitledBorder("Lease Deposits"));

        jLabel119.setText("Refundable");

        refund_depst_tf.setEditable(false);
        refund_depst_tf.setText("0");
        refund_depst_tf.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                refund_depst_tfFocusLost(evt);
            }
        });

        non_refund_dpst_tf.setEditable(false);
        non_refund_dpst_tf.setText("0");
        non_refund_dpst_tf.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                non_refund_dpst_tfFocusLost(evt);
            }
        });

        jLabel82.setText("Non Refundable/prepayment");

        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });

        jCheckBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox2ActionPerformed(evt);
            }
        });

        jLabel44.setText("Refundable A/c");

        jLabel85.setText("Non refundable A/c");

        refundable_deposit_account.setEditable(false);

        non_refundable_deposit_account.setEditable(false);

        ref_dep.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        ref_dep.setFocusable(false);
        ref_dep.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ref_depMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ref_depMouseEntered(evt);
            }
        });

        nonref_dep.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        nonref_dep.setFocusable(false);
        nonref_dep.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nonref_depMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                nonref_depMouseEntered(evt);
            }
        });

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jLabel85, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel44, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel82, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel119, javax.swing.GroupLayout.Alignment.LEADING))
                .addGap(6, 6, 6)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCheckBox1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jCheckBox2, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(non_refund_dpst_tf, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 132, Short.MAX_VALUE)
                    .addComponent(non_refundable_deposit_account, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(refundable_deposit_account, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(refund_depst_tf))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ref_dep)
                    .addComponent(nonref_dep))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(nonref_dep, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(refund_depst_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel119)
                            .addComponent(jCheckBox1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(non_refund_dpst_tf, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel82))
                            .addComponent(jCheckBox2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel44)
                                .addComponent(refundable_deposit_account, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(ref_dep, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel85)
                            .addComponent(non_refundable_deposit_account, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );

        other_depst_btn.setBackground(new java.awt.Color(255, 255, 255));
        other_depst_btn.setText("Other Deposit");
        other_depst_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                other_depst_btnActionPerformed(evt);
            }
        });

        jLabel88.setText("Water Deposit");

        water_depst_tf.setText("0");
        water_depst_tf.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                water_depst_tfFocusLost(evt);
            }
        });

        jLabel83.setText("Electricity Deposit");

        elect_depst_tf.setText("0");
        elect_depst_tf.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                elect_depst_tfFocusLost(evt);
            }
        });

        jLabel120.setText("Water Deposit A/c");

        water_depst_acc_tf.setEditable(false);

        jLabel86.setText("Electricity Deposit A/c");

        elect_depst_acc_tf.setEditable(false);

        water_dep.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        water_dep.setFocusable(false);
        water_dep.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                water_depMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                water_depMouseEntered(evt);
            }
        });

        electricty_dep.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        electricty_dep.setFocusable(false);
        electricty_dep.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                electricty_depMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                electricty_depMouseEntered(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel83)
                            .addComponent(jLabel88)
                            .addComponent(jLabel120)
                            .addComponent(jLabel86))
                        .addGap(10, 10, 10)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(water_depst_tf, javax.swing.GroupLayout.DEFAULT_SIZE, 117, Short.MAX_VALUE)
                            .addComponent(elect_depst_tf)
                            .addComponent(water_depst_acc_tf)
                            .addComponent(elect_depst_acc_tf))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(water_dep)
                            .addComponent(electricty_dep))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(other_depst_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(water_depst_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel88))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(water_depst_acc_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel120))
                    .addComponent(water_dep, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel83)
                    .addComponent(elect_depst_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel86)
                        .addComponent(elect_depst_acc_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(electricty_dep, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(other_depst_btn))
        );

        jPanel17.setBackground(new java.awt.Color(255, 255, 255));
        jPanel17.setBorder(javax.swing.BorderFactory.createTitledBorder("Other Charges"));

        jLabel81.setText("Security Charges ");

        security_charges_tf.setText("0");
        security_charges_tf.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                security_charges_tfFocusLost(evt);
            }
        });

        jLabel78.setText("Services/Utility Charges");

        utility_charges_tf.setText("0");
        utility_charges_tf.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                utility_charges_tfFocusLost(evt);
            }
        });

        jLabel121.setText("Utility Charges A/c");

        utility_charges_acc.setEditable(false);

        more_charges_btn.setBackground(new java.awt.Color(255, 255, 255));
        more_charges_btn.setText("More Charges");
        more_charges_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                more_charges_btnActionPerformed(evt);
            }
        });

        jLabel15.setText("Security Charges A/c");

        securitycharges_acc.setEditable(false);

        security_charge.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        security_charge.setFocusable(false);
        security_charge.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                security_chargeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                security_chargeMouseEntered(evt);
            }
        });

        utility_charge.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        utility_charge.setFocusable(false);
        utility_charge.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                utility_chargeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                utility_chargeMouseEntered(evt);
            }
        });

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addComponent(jLabel81)
                        .addGap(10, 10, 10)
                        .addComponent(security_charges_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addComponent(jLabel121)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(utility_charges_acc, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel15)
                            .addComponent(jLabel78))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(utility_charges_tf, javax.swing.GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE)
                            .addComponent(securitycharges_acc))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(security_charge)
                    .addComponent(utility_charge))
                .addContainerGap(22, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel17Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(more_charges_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel81)
                    .addComponent(security_charges_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel15)
                        .addComponent(securitycharges_acc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(security_charge, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel78)
                    .addComponent(utility_charges_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel121)
                        .addComponent(utility_charges_acc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(utility_charge, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(more_charges_btn)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jSeparator22.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jSeparator23.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jPanel18.setBackground(new java.awt.Color(255, 255, 255));
        jPanel18.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jLabel122.setText("Frequency");

        inspector_tf.setEditable(false);

        jSpinner_insp_prd.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSpinner_insp_prdStateChanged(evt);
            }
        });

        jLabel123.setText("Salesman ID");

        jLabel124.setText("Last-statement-date");

        salesman_id_tf.setEditable(false);

        jLabel125.setText("Inspection Period");

        jLabel126.setText("Default Ispector (Staff) ");

        jCombo_insp_freq.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Daily", "Weekly", "Monthly", "Yearly" }));

        jTextField38.setEditable(false);

        jPanel19.setBackground(new java.awt.Color(255, 255, 255));
        jPanel19.setBorder(javax.swing.BorderFactory.createTitledBorder("Sales-man commission"));

        salesAmnt_TF.setText("0");
        salesAmnt_TF.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                salesAmnt_TFKeyTyped(evt);
            }
        });

        jSpinner_salecommission.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSpinner_salecommissionStateChanged(evt);
            }
        });

        jRadioButton15.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup_commission.add(jRadioButton15);
        jRadioButton15.setText("Amount");
        jRadioButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton15ActionPerformed(evt);
            }
        });

        jRadioButton16.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup_commission.add(jRadioButton16);
        jRadioButton16.setSelected(true);
        jRadioButton16.setText("%");
        jRadioButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton16ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addComponent(jRadioButton15)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(salesAmnt_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jRadioButton16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSpinner_salecommission, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jSpinner_salecommission, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(salesAmnt_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jRadioButton15)
                    .addComponent(jRadioButton16))
                .addContainerGap())
        );

        jLabel127.setText("Salesman A/c");

        salesman_acc_tf.setEditable(false);

        salesman_id.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        salesman_id.setFocusable(false);
        salesman_id.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                salesman_idMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                salesman_idMouseEntered(evt);
            }
        });

        salesman_name.setForeground(new java.awt.Color(0, 0, 204));

        salesman_acc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        salesman_acc.setFocusable(false);
        salesman_acc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                salesman_accMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                salesman_accMouseEntered(evt);
            }
        });

        jLabel43.setForeground(new java.awt.Color(0, 0, 204));

        inspector.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        inspector.setFocusable(false);
        inspector.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                inspectorMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                inspectorMouseEntered(evt);
            }
        });

        jLabel133.setText("Salesman Name:");

        jLabel134.setText("Inspector ID:");

        inspector_id.setEditable(false);

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel18Layout.createSequentialGroup()
                        .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel18Layout.createSequentialGroup()
                                .addComponent(jLabel133)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(salesman_name, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel18Layout.createSequentialGroup()
                                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel123)
                                    .addComponent(jLabel127))
                                .addGap(19, 19, 19)
                                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel18Layout.createSequentialGroup()
                                        .addComponent(salesman_acc_tf)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(salesman_acc))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel18Layout.createSequentialGroup()
                                        .addComponent(salesman_id_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(salesman_id)))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel43, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel18Layout.createSequentialGroup()
                        .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel126)
                            .addComponent(jLabel125)
                            .addComponent(jLabel124)
                            .addComponent(jLabel134))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField38, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel18Layout.createSequentialGroup()
                                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(inspector_tf, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel18Layout.createSequentialGroup()
                                        .addComponent(jCombo_insp_freq, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel122)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jSpinner_insp_prd, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(inspector)))
                            .addComponent(inspector_id, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jSeparator24)))
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(salesman_name, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel133))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel43, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel18Layout.createSequentialGroup()
                        .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel123)
                                .addComponent(salesman_id_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(salesman_id, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel127)
                                .addComponent(salesman_acc_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(salesman_acc, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(1, 1, 1)
                .addComponent(jSeparator24, javax.swing.GroupLayout.PREFERRED_SIZE, 4, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel134)
                    .addComponent(inspector_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel126)
                        .addComponent(inspector_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(inspector, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel125)
                    .addComponent(jCombo_insp_freq, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel122)
                    .addComponent(jSpinner_insp_prd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel124)
                    .addComponent(jTextField38, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel13.setBackground(new java.awt.Color(255, 255, 255));
        jPanel13.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED), "Penalty Charges"));

        penaltyAmnt_TF.setEditable(false);
        penaltyAmnt_TF.setText("0");
        penaltyAmnt_TF.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                penaltyAmnt_TFKeyTyped(evt);
            }
        });

        jSpinner_penalty_percent.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSpinner_penalty_percentStateChanged(evt);
            }
        });

        dp9.setBackground(new java.awt.Color(255, 255, 255));
        dp9.setBorder(javax.swing.BorderFactory.createTitledBorder("Penalty Date"));
        dp9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dp9MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout dp9Layout = new javax.swing.GroupLayout(dp9);
        dp9.setLayout(dp9Layout);
        dp9Layout.setHorizontalGroup(
            dp9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 207, Short.MAX_VALUE)
        );
        dp9Layout.setVerticalGroup(
            dp9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 12, Short.MAX_VALUE)
        );

        jRadioButton17.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup_penalty.add(jRadioButton17);
        jRadioButton17.setSelected(true);
        jRadioButton17.setText("%");
        jRadioButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton17ActionPerformed(evt);
            }
        });

        jRadioButton18.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup_penalty.add(jRadioButton18);
        jRadioButton18.setText("Amount");
        jRadioButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton18ActionPerformed(evt);
            }
        });

        jLabel128.setText("Status");

        jCheck_pen_status.setBackground(new java.awt.Color(255, 255, 255));
        jCheck_pen_status.setSelected(true);
        jCheck_pen_status.setText("Active");
        jCheck_pen_status.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheck_pen_statusActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addComponent(jRadioButton17)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSpinner_penalty_percent, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jRadioButton18)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(penaltyAmnt_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(dp9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel128)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCheck_pen_status)))
                .addGap(63, 63, 63))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jSpinner_penalty_percent, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jRadioButton17))
                    .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(penaltyAmnt_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jRadioButton18)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(dp9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel128, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jCheck_pen_status)))
                .addContainerGap())
        );

        jCheckBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox3ActionPerformed(evt);
            }
        });

        jLabel73.setText("Company Branch");

        property_id_combo.setEditable(false);
        property_id_combo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                property_id_comboKeyTyped(evt);
            }
        });

        pro_id_search.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        pro_id_search.setFocusable(false);
        pro_id_search.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pro_id_searchMouseClicked(evt);
            }
        });

        c_id2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        c_id2.setFocusable(false);
        c_id2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                c_id2MouseClicked(evt);
            }
        });

        l_id.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        l_id.setFocusable(false);
        l_id.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                l_idMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                l_idMouseEntered(evt);
            }
        });

        company_branch_tf.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                company_branch_tfPopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });

        jLabel89.setText("Company Branch");

        jLabel132.setText("Lease fee:");

        lease_fee_amount.setText("0");
        lease_fee_amount.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                lease_fee_amountKeyTyped(evt);
            }
        });

        lease_percent2.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                lease_percent2StateChanged(evt);
            }
        });

        jRadioButton20.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup_lease_fee.add(jRadioButton20);
        jRadioButton20.setText("Amount");
        jRadioButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton20ActionPerformed(evt);
            }
        });

        jRadioButton19.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup_lease_fee.add(jRadioButton19);
        jRadioButton19.setSelected(true);
        jRadioButton19.setText("%");
        jRadioButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton19ActionPerformed(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("Vrinda", 0, 14)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(51, 0, 153));

        jLabel21.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        contact_name_lbl.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        lease_acc_desc.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        l_id1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        l_id1.setFocusable(false);
        l_id1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                l_id1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                l_id1MouseEntered(evt);
            }
        });

        tax_desc.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        jButton2.setBackground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Create New");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jCheckBx_aprv_lease.setBackground(new java.awt.Color(255, 255, 255));
        jCheckBx_aprv_lease.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jCheckBx_aprv_lease.setForeground(new java.awt.Color(0, 0, 255));
        jCheckBx_aprv_lease.setText("Approve Lease");
        jCheckBx_aprv_lease.setToolTipText("approved lease cannot be updated");
        jCheckBx_aprv_lease.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBx_aprv_leaseActionPerformed(evt);
            }
        });

        jSeparator4.setBackground(new java.awt.Color(102, 102, 102));
        jSeparator4.setRequestFocusEnabled(false);
        jSeparator4.setVerifyInputWhenFocusTarget(false);

        jButton4.setBackground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Temp testing Button");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        lease_fee_accnt_tf.setEditable(false);

        lease_fee_srch.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search.JPG"))); // NOI18N
        lease_fee_srch.setFocusable(false);
        lease_fee_srch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lease_fee_srchMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lease_fee_srchMouseEntered(evt);
            }
        });

        jLabel22.setText("Lease Fee Account:");

        javax.swing.GroupLayout lease_panelLayout = new javax.swing.GroupLayout(lease_panel);
        lease_panel.setLayout(lease_panelLayout);
        lease_panelLayout.setHorizontalGroup(
            lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lease_panelLayout.createSequentialGroup()
                .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 1474, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(lease_panelLayout.createSequentialGroup()
                        .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(lease_panelLayout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(lease_panelLayout.createSequentialGroup()
                                        .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(jLabel74)
                                                .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel6)
                                                    .addComponent(jLabel7)
                                                    .addComponent(jLabel72)
                                                    .addComponent(jLabel77)
                                                    .addComponent(jLabel84)
                                                    .addComponent(jLabel113)
                                                    .addComponent(jLabel80)
                                                    .addComponent(jLabel90)))
                                            .addComponent(jLabel22))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, lease_panelLayout.createSequentialGroup()
                                                .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, lease_panelLayout.createSequentialGroup()
                                                            .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                                .addComponent(jCombo_lease_types, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, lease_panelLayout.createSequentialGroup()
                                                                    .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                                        .addComponent(lease_acc_tf, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addComponent(contact_id_tf, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                    .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                        .addComponent(c_id2)
                                                                        .addComponent(l_id))
                                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                    .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                        .addComponent(contact_name_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 262, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addComponent(lease_acc_desc, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                                            .addGap(6, 6, 6))
                                                        .addGroup(lease_panelLayout.createSequentialGroup()
                                                            .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                                .addComponent(lease_id_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGroup(lease_panelLayout.createSequentialGroup()
                                                                    .addComponent(property_id_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                    .addComponent(pro_id_search)))
                                                            .addGap(18, 18, 18)
                                                            .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                .addComponent(p_id, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGroup(lease_panelLayout.createSequentialGroup()
                                                                    .addComponent(jButton2)
                                                                    .addGap(18, 18, 18)
                                                                    .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                                        .addGroup(lease_panelLayout.createSequentialGroup()
                                                            .addComponent(jRadioButton_active)
                                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                            .addComponent(jRadioButton_closed)
                                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                            .addComponent(jRadioButton_onhold)))
                                                    .addGroup(lease_panelLayout.createSequentialGroup()
                                                        .addComponent(lease_fee_accnt_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                        .addComponent(lease_fee_srch)))
                                                .addComponent(jSeparator23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(current_lease_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(lease_panelLayout.createSequentialGroup()
                                                .addComponent(jCheckBox3)
                                                .addGap(11, 11, 11)
                                                .addComponent(lease_frequency_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jLabel75)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jSpinner_lease_prd, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(lease_panelLayout.createSequentialGroup()
                                                .addComponent(tax_code, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(l_id1)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(tax_desc, javax.swing.GroupLayout.PREFERRED_SIZE, 303, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGroup(lease_panelLayout.createSequentialGroup()
                                        .addComponent(dp3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(dp5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(lease_panelLayout.createSequentialGroup()
                                        .addComponent(dp4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(dp7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(lease_panelLayout.createSequentialGroup()
                                        .addComponent(dp6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(dp8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(lease_panelLayout.createSequentialGroup()
                                .addGap(58, 58, 58)
                                .addComponent(jLabel73)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(company_branch_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(lease_panelLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel132)
                                .addGap(13, 13, 13)
                                .addComponent(jRadioButton19)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lease_percent2, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jRadioButton20)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lease_fee_amount, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(lease_panelLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 488, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(lease_panelLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jPanel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, 408, Short.MAX_VALUE))
                                    .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(lease_panelLayout.createSequentialGroup()
                                .addGap(39, 39, 39)
                                .addComponent(jButton4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jCheckBx_aprv_lease))))
                    .addComponent(jSeparator16, javax.swing.GroupLayout.PREFERRED_SIZE, 1146, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
            .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(lease_panelLayout.createSequentialGroup()
                    .addGap(68, 68, 68)
                    .addComponent(jLabel89)
                    .addContainerGap(1348, Short.MAX_VALUE)))
        );
        lease_panelLayout.setVerticalGroup(
            lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lease_panelLayout.createSequentialGroup()
                .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(lease_panelLayout.createSequentialGroup()
                        .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jCheckBx_aprv_lease, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jSeparator22, javax.swing.GroupLayout.PREFERRED_SIZE, 439, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(lease_panelLayout.createSequentialGroup()
                        .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(lease_panelLayout.createSequentialGroup()
                        .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator23)
                            .addGroup(lease_panelLayout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel21, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel6)
                                        .addComponent(lease_id_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jButton2)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(p_id, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7)
                                    .addComponent(pro_id_search, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(property_id_combo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel72)
                                    .addComponent(jCombo_lease_types, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel77)
                                    .addComponent(jRadioButton_active)
                                    .addComponent(jRadioButton_closed)
                                    .addComponent(jRadioButton_onhold))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(lease_panelLayout.createSequentialGroup()
                                        .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(jLabel84)
                                                .addComponent(contact_id_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(c_id2, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(contact_name_lbl, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(lease_panelLayout.createSequentialGroup()
                                                .addGap(9, 9, 9)
                                                .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                    .addComponent(jLabel113)
                                                    .addComponent(lease_acc_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, lease_panelLayout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(lease_acc_desc, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                                    .addComponent(l_id, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(tax_code, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel80))
                                    .addComponent(l_id1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(tax_desc, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel90)
                                    .addComponent(current_lease_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel74)
                                        .addComponent(lease_frequency_combo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel75)
                                        .addComponent(jSpinner_lease_prd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jCheckBox3))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(dp3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(dp5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(dp4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(dp7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(dp6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(dp8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel73)
                                    .addComponent(company_branch_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(lease_percent2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jRadioButton19))
                                    .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(lease_fee_amount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jRadioButton20))
                                    .addComponent(jLabel132, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(lease_panelLayout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addComponent(lease_fee_srch, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(lease_panelLayout.createSequentialGroup()
                                        .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jLabel22)
                                            .addComponent(lease_fee_accnt_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(0, 0, Short.MAX_VALUE)))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addComponent(jSeparator16, javax.swing.GroupLayout.PREFERRED_SIZE, 1, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(102, 102, 102))
            .addGroup(lease_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, lease_panelLayout.createSequentialGroup()
                    .addContainerGap(458, Short.MAX_VALUE)
                    .addComponent(jLabel89, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(263, 263, 263)))
        );

        jTabbedPane1.addTab("   Leasing   ", lease_panel);

        jToolBar1.setBackground(new java.awt.Color(255, 255, 255));
        jToolBar1.setRollover(true);

        jButton3.setBackground(new java.awt.Color(255, 255, 255));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/new.PNG"))); // NOI18N
        jButton3.setToolTipText("Create New");
        jButton3.setFocusable(false);
        jButton3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton3.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jToolBar1.add(jButton3);

        save_btn.setBackground(new java.awt.Color(255, 255, 255));
        save_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Actions-document-save-all-icon2.png"))); // NOI18N
        save_btn.setToolTipText("Save");
        save_btn.setFocusable(false);
        save_btn.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        save_btn.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        save_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save_btnActionPerformed(evt);
            }
        });
        jToolBar1.add(save_btn);

        jButton5.setBackground(new java.awt.Color(255, 255, 255));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/clear - Copy.png"))); // NOI18N
        jButton5.setToolTipText("Clear");
        jButton5.setFocusable(false);
        jButton5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton5.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jToolBar1.add(jButton5);

        jButton6.setBackground(new java.awt.Color(255, 255, 255));
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/delete02.png"))); // NOI18N
        jButton6.setToolTipText("Delete");
        jButton6.setFocusable(false);
        jButton6.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton6.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jToolBar1.add(jButton6);
        jToolBar1.add(jSeparator19);

        refresh_btn.setBackground(new java.awt.Color(255, 255, 255));
        refresh_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/refresh2 - Copy.png"))); // NOI18N
        refresh_btn.setToolTipText("Refresh");
        refresh_btn.setFocusable(false);
        refresh_btn.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        refresh_btn.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        refresh_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refresh_btnActionPerformed(evt);
            }
        });
        jToolBar1.add(refresh_btn);
        jToolBar1.add(jSeparator20);

        export_to_excel.setBackground(new java.awt.Color(255, 255, 255));
        export_to_excel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/exel2.png"))); // NOI18N
        export_to_excel.setToolTipText("Export To Excel");
        export_to_excel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                export_to_excelActionPerformed(evt);
            }
        });
        jToolBar1.add(export_to_excel);

        reports.setBackground(new java.awt.Color(255, 255, 255));
        reports.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/reports3.jpg"))); // NOI18N
        reports.setToolTipText("View/Print Report");
        reports.setFocusable(false);
        reports.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        reports.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        reports.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reportsActionPerformed(evt);
            }
        });
        jToolBar1.add(reports);

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Ref No.");

        contact_ref_no.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contact_ref_noActionPerformed(evt);
            }
        });

        contact_id_no.setEditable(false);
        contact_id_no.setBackground(new java.awt.Color(255, 255, 255));

        jLabel12.setBackground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Contact Id:");

        jToolBar2.setRollover(true);

        import_from_excel.setBackground(new java.awt.Color(255, 255, 255));
        import_from_excel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/exel2.png"))); // NOI18N
        import_from_excel.setToolTipText("Import from Excel");
        import_from_excel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                import_from_excelActionPerformed(evt);
            }
        });
        jToolBar2.add(import_from_excel);
        jToolBar2.add(jSeparator21);

        show_path.setEditable(false);
        show_path.setBackground(new java.awt.Color(255, 255, 255));
        jToolBar2.add(show_path);

        jToolBar3.setBackground(new java.awt.Color(255, 255, 255));
        jToolBar3.setRollover(true);

        jLabel97.setText("Search");
        jToolBar3.add(jLabel97);

        searchrecord_tf.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                searchrecord_tfKeyTyped(evt);
            }
        });
        jToolBar3.add(searchrecord_tf);

        jMenuBar1.setBackground(new java.awt.Color(255, 255, 255));

        jMenu1.setBackground(new java.awt.Color(255, 255, 255));
        jMenu1.setText("File");
        jMenuBar1.add(jMenu1);

        jMenu2.setBackground(new java.awt.Color(255, 255, 255));
        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jToolBar1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(contact_ref_no, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(contact_id_no, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jToolBar3, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(msg_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jToolBar2, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1514, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jToolBar1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel12)
                                .addComponent(contact_id_no, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel1)
                                .addComponent(contact_ref_no, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jToolBar2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jToolBar3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(msg_lbl, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 712, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:

        if (ChartOfAccount_pane.isShowing() == true) {

            char Must_Budget;
            if (jchk_Must_Budget.isSelected()) {
                Must_Budget = 'Y';
            } else {
                Must_Budget = 'N';
            }
            char Check_Budget;
            if (jchk_Check_Budget.isSelected()) {
                Check_Budget = 'Y';
            } else {
                Check_Budget = 'N';
            }
            char reconcile_Account;
            if (jchk_reconcile_Account.isSelected()) {
                reconcile_Account = 'Y';
            } else {
                reconcile_Account = 'N';
            }
            char Restrict_Posting;
            if (jchk_Restrict_Posting.isSelected()) {
                Restrict_Posting = 'Y';
            } else {
                Restrict_Posting = 'N';
            }
            char Restrict_Owner;
            if (jchk_Restrict_Owner.isSelected()) {
                Restrict_Owner = 'Y';
            } else {
                Restrict_Owner = 'N';
            }
            char Transaction_Account;
            if (jCheckBox4.isSelected()) {
                Transaction_Account = 'Y';
            } else {
                Transaction_Account = 'N';
            }
            String acc_status = jtxt_Account_Status.getText();
            switch (acc_status) {
                case "Active":
                    acc_status = "ACT";
                    break;
                case "Inactive":
                    acc_status = "INC";
                    break;
                case "Closed":
                    acc_status = "CLS";
                    break;
            }
            String sql = "INSERT INTO account_master( "
                    + "ACCOUNT_GROUP, "
                    + "COST_CENTRE, "
                    + "MAIN_ACCOUNT, "
                    + "SUB_ACCOUNT,"
                    + " ACCOUNT_STATUS, "
                    + "DESCRIPTION, "
                    + "SUB_CATEGORY, "
                    + "CONTRA_ACCOUNT,"
                    + "MUST_BUDGET, "
                    + "RECONCILE,"
                    + "POST_RESTRICTION, "
                    + "RESTRICTED, "
                    + "RECONCILE_GROUP, "
                    + "BUDGET_PATTERN, "
                    + "TRANSACTION_ACCOUNT, "
                    + "ACCOUNT_NUMBER, "
                    + "MAIN_CATEGORY,"
                    + "SUB_CATEG_TYPE,"
                    + "ACC_FUND_TYPE,"
                    + "CHECK_BUDGET) "
                    + "values('" + jtxt_Account_Group.getText() + "',"
                    + "'" + jtxt_Cost_Center.getText() + "',"
                    + "'" + jtxt_Main_Account.getText() + "',"
                    + "'" + jtxt_Sub_Account.getText() + "',"
                    + "'" + acc_status + "',"
                    + "'" + jtxt_Account_Description.getText() + "',"
                    + "'" + jtxt_Sub_Category.getText() + "','" + jtxt_Contra_Account.getText() + "','" + Must_Budget + "','" + reconcile_Account + "','" + Restrict_Posting + "','" + Restrict_Owner + "','" + jtxt_Reconcile_Group.getText() + "',"
                    + "'" + jtxt_Budget_Pattern.getText() + "',"
                    + "'" + Transaction_Account + "','" + jtxt_Main_Account.getText() + jtxt_Sub_Account.getText() + "','" + jtxt_Main_Category.getText() + "',"
                    + "'" + jtxt_subcategory_Type.getText() + "','" + jtxt_AccountFund_Type.getText() + "',"
                    + "'" + Check_Budget + "')";
            try {
                //JOptionPane.showMessageDialog(null, sql);
                //conn = DBConnection.ConnectDB();
                pst = conn.prepareStatement(sql);
                pst.execute();
                Update_jtbl_Accounts_Master();
                jLabel14.setForeground(Color.BLUE);
                jLabel14.setText("Record saved Successfully!!");
                //into_recurrents();

            } catch (HeadlessException | SQLException e) {
                jLabel14.setForeground(Color.red);
                jLabel14.setText("Record already exists!!");
                Update_jtbl_Accounts_Master();

            }

            Update_jtbl_Accounts_Master();

        } else if (contactdetails_panel.isShowing() == true) {
            String sql2 = "INSERT INTO contacts( "
                    + "CONTACT_REF, "
                    + "CONTACT_TYPE, "
                    + "FIRST_NAMES, "
                    + "LAST_NAME,"
                    + " NATIONAL_ID, "
                    + "PIN, "
                    + "GENDER, "
                    + "OCCUPATION,"
                    + "SOURCE_OF_INCOME, "
                    + "COMPANY_NAME,"
                    + "COMPANY_BRANCH, "
                    + "LOCATION, "
                    + "CURRENT_CITY, "
                    + "WEBSITE, "
                    + "COUNTY, "
                    + "BANK_NAME, "
                    + "BANK_ACC_NO, "
                    + "BANK_BRANCH)"
                    + "values('" + contact_ref_no.getText() + "','" + contact_type.getSelectedItem() + "','" + fname_TF.getText() + "','" + lname_TF.getText() + "','" + id_TF.getText() + "','" + pin_TF.getText() + "','" + gender.getSelectedItem() + "','" + occupation.getText() + "','" + source_of_income.getText() + "','" + company_name.getText() + "','" + company_branch.getText() + "','" + location.getText() + "','" + current_city.getText() + "','" + website.getText() + "','" + county.getText() + "','" + bank_name.getText() + "','" + bank_acc_no.getText() + "','" + bank_branch.getSelectedItem() + "')";

            try {

                pst = conn.prepareStatement(sql2);
                pst.execute();
                update_photo();
                Select_checkboxes();

            } catch (Exception e) {
                e.printStackTrace();
            }

            String sql3 = "update contacts set status='" + status.getSelectedItem() + "',citizenship='" + citzn_combo.getSelectedItem() + "',country='" + country_sel.getSelectedItem() + "' where PIN='" + pin_TF.getText() + "' or NATIONAL_ID='" + id_TF.getText() + "'";
            try {
                pst = conn.prepareStatement(sql3);
                pst.execute();
                Insert_Timestamp();
                Update_contact_details();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (lease_panel.isShowing()) {

            String check_exist_sql = "select contact_id from lease where contact_id = ?";
            try {
                conn = DBConnection.ConnectDB();
                pst = conn.prepareStatement(check_exist_sql);
                pst.setString(1, contact_id_tf.getText());
                rs = pst.executeQuery();

                if (rs.next()) {
                    JOptionPane.showMessageDialog(this, "<html><b><font color=red>Error Adding Lease!</font></b><br>A lease entry for this Contact already exist", "Lease (Maliplus)", JOptionPane.ERROR_MESSAGE);
                } else {
                    add_lease();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (propertyInfo_panel.isShowing() == true) {
            String sql = " insert into properties_table("
                    + "CONTACT_ID,"
                    + "PROPERTY_STATUS,"
                    + "PROPERTY_TYPE,"
                    + "PARENT_PROPERTY,"
                    + "PROPERTY_QUANTITY,"
                    + "PROPERTY_CATEGORY,"
                    + "BANK_NAME,"
                    + "BANK_ACCOUNT,"
                    + "BANK_BRANCH,"
                    + "TAX_CODE,"
                    + "PROPERTY_GPRS,"
                    + "COUNTRY,"
                    + "CITY,"
                    + "SURBURB,"
                    + "ZONE,"
                    + "PROPERTY_DESCRIPTION,"
                    + "PROPERTY_VALUE,"
                    + "SALE_VALUE,"
                    + "PURCHASE_PRICE,"
                    + "ASKING_VALUE,"
                    + "DATE_AVAILABLE,"
                    + "SALE_DATE,"
                    + "VALUATION_DATE)"
                    + "values('" + contact_id_no.getText() + "','" + property_status.getSelectedItem() + "','" + property_type.getSelectedItem() + "','" + parent_property.getText() + "','" + property_quantity.getText() + "','" + property_category.getText() + "','" + bank_name1.getSelectedItem() + "','" + bank_acc.getText() + "','" + bank_branch1.getSelectedItem() + "','" + tax_code1.getText() + "','" + gprs.getText() + "','" + country.getSelectedItem() + "','" + city.getSelectedItem() + "','" + surburb.getSelectedItem() + "','" + zones.getSelectedItem() + "','" + property_description.getText() + "','" + property_value.getText() + "','" + sale_value.getText() + "','" + purchase_price.getText() + "','" + asking_value.getText() + "','" + datePicker3.getJFormattedTextField().getText() + "','" + datePicker2.getJFormattedTextField().getText() + "','" + datePicker.getJFormattedTextField().getText() + "')";
            try {
                pst = conn.prepareStatement(sql);
                pst.execute();

                Update_properties_table();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (contactInfo_panel.isShowing() == true) {
            String sql = "INSERT into contact_information ("
                    + "CONTACT_ID,"
                    + "CONTACT_PRIORITY,"
                    + "FIRST_NAME,"
                    + "LAST_NAME,"
                    + "RELATIONSHIP,"
                    + "NATIONAL_ID_NO,"
                    + "POSTAL_ADDRESS,"
                    + "CITY_TOWN,"
                    + "PHYSICAL_ADDRESS,"
                    + "RESIDENTIAL_ADDRESS,"
                    + "TELEPHONE_4,"
                    + "TELEPHONE_5,"
                    + "EMAIL_4,"
                    + "EMAIL_5)"
                    + "values(" + contact_id_no.getText() + ","
                    + "'" + contact_priority.getText() + "',"
                    + "'" + first_name.getText() + "',"
                    + "'" + last_name.getText() + "',"
                    + "'" + relationship.getSelectedItem() + "',"
                    + "'" + national_id_no.getText() + "',"
                    + "'" + postal_address.getText() + "',"
                    + "'" + city_town.getSelectedItem() + "',"
                    + "'" + physical_address.getText() + "',"
                    + "'" + residential_address.getText() + "',"
                    + "'" + telephone4.getText() + "',"
                    + "'" + telephone5.getText() + "',"
                    + "'" + email4.getText() + "',"
                    + "'" + email5.getText() + "')";
            try {
                pst = conn.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null, "Record saved successfully!!");
                Update_contact_information();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }


    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        if (contactdetails_panel.isShowing() == true) {
            refundable_deposit_account.setText("");
            non_refundable_deposit_account.setText("");
            lease_fee_accnt_tf.setText("");
            agent_CheckBox.setSelected(false);
            landlord_CheckBox.setSelected(false);
            tenant_CheckBox.setSelected(false);
            buyer_CheckBox.setSelected(false);
            employee_CheckBox.setSelected(false);
            contact_type.setSelectedIndex(0);
            status.setSelectedIndex(0);
            fname_TF.setText("");
            lname_TF.setText("");
            citzn_combo.setSelectedIndex(0);
            country_sel.setSelectedIndex(0);
            id_TF.setText("");
            pin_TF.setText("");
            gender.setSelectedIndex(0);
            occupation.setText("");
            occupation2.setSelectedIndex(0);
            source_of_income.setText("");
            contact_ref_no.setText("");
            contact_id_no.setText("");
            searchrecord_tf.setText("");
            company_name.setText("");
            company_branch.setText("");
            location.setText("");
            current_city.setText("");
            website.setText("");
            //refundable_deposit_account
            //non_refundable_deposit_account
            county.setText("");
            bank_name.setText("");
            bank_name2.setSelectedIndex(0);
            bank_acc_no.setText("");
            bank_branch.setSelectedItem("");
            pathTF.setText("");
            show_path.setText("");

            userImage.removeAll();
            userImage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/maliplus/user-default.png")));
            userImage.revalidate();
            userImage.repaint();

            Update_contact_details();
        }
        if (propertyInfo_panel.isShowing() == true) {
            owner.setText("");
            property_status.setSelectedIndex(0);
            property_type.setSelectedIndex(0);
            property_quantity.setText("");
            property_category.setText("");
            owner.setText("");
            bank_name1.setSelectedIndex(1);
            bank_acc.setText("");
            bank_branch1.setSelectedItem("");
            tax_code1.setText("");
            gprs.setText("");
            searchrecord_tf.setText("");
            show_path.setText("");
            property_value.setText("");
            purchase_price.setText("");
            sale_value.setText("");
            asking_value.setText("");
            pathTf2.setText("");
            country.setSelectedIndex(0);
            city.setSelectedIndex(0);
            surburb.setSelectedIndex(0);
            zones.setSelectedIndex(0);
            property_description.setText("");
            datePicker3.getJFormattedTextField().setText("");
            datePicker.getJFormattedTextField().setText("");
            datePicker2.getJFormattedTextField().setText("");

            owner.setBackground(Color.white);
            property_idlbl.setText("Cleared");
            property_idlbl.setForeground(Color.BLUE);

            pic.removeAll();
            pic.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Mali_bg.png")));
            pic.revalidate();
            pic.repaint();

            Update_properties_table();

        }
        if (lease_panel.isShowing() == true) {

            searchrecord_tf.setText("");
            lease_id_tf.setText("");
            property_id_combo.setText("");
            jCombo_lease_types.setSelectedIndex(0);
            jRadioButton_active.setSelected(false);
            jRadioButton_closed.setSelected(true);
            jRadioButton_onhold.setSelected(false);
            contact_id_tf.setText("");
            lease_acc_tf.setText("");
            tax_code.setText("");
            current_lease_tf.setText("");
            jCheckBox3.setSelected(false);
            lease_frequency_combo.setEnabled(false);
            lease_frequency_combo.setSelectedItem("Not selected");
            lease_frequency_combo.setSelectedIndex(0);
            jSpinner_lease_prd.setEnabled(false);
            jSpinner_lease_prd.setValue(0);
            datePicker4.getJFormattedTextField().setText("");
            datePicker5.getJFormattedTextField().setText("");
            datePicker6.getJFormattedTextField().setText("");
            datePicker8.getJFormattedTextField().setText("");
            datePicker7.getJFormattedTextField().setText("");
            datePicker9.getJFormattedTextField().setText("");
            company_branch_tf.setSelectedIndex(0);
            jCheckBox1.setSelected(false);
            refund_depst_tf.setEditable(false);
            refund_depst_tf.setText("");
            non_refund_dpst_tf.setEditable(false);
            non_refund_dpst_tf.setText("");
            jCheckBox2.setSelected(false);
            water_depst_tf.setText("");
            water_depst_acc_tf.setText("");
            elect_depst_tf.setText("");
            elect_depst_acc_tf.setText("");
            security_charges_tf.setText("");
            securitycharges_acc.setText("");
            utility_charges_tf.setText("");
            utility_charges_acc.setText("");
            jRadioButton17.setSelected(true);
            jSpinner_penalty_percent.setEnabled(true);
            penaltyAmnt_TF.setEditable(false);
            penaltyAmnt_TF.setText("");
            jRadioButton18.setSelected(false);
            jCheck_pen_status.setSelected(true);
            jCheck_pen_status.setText("Active");
            datePicker10.getJFormattedTextField().setText("");
            salesman_id_tf.setText("");
            salesman_acc_tf.setText("");
            jRadioButton15.setSelected(true);
            jSpinner_salecommission.setEnabled(false);
            salesAmnt_TF.setEditable(true);
            salesAmnt_TF.setText("");
            jRadioButton16.setSelected(false);
            inspector_tf.setText("");
            jCombo_insp_freq.setSelectedIndex(0);
            jSpinner_insp_prd.setEnabled(false);
            jSpinner_insp_prd.setValue(0);
            jSpinner_salecommission.setValue(0);
            jSpinner_penalty_percent.setValue(0);
            jSpinner_lease_prd.setValue(0);
            jTextField38.setText("");
            jLabel18.setText("");
            update_lease_table();

        }
        if (ChartOfAccount_pane.isShowing() == true) {
            jtxt_Account_Group.setText("");
            jtxt_Cost_Center.setText("");
            jtxt_Main_Category.setText("");
            jtxt_Main_Account.setText("");
            jtxt_Sub_Category.setText("");
            jtxt_Sub_Account.setText("");
            jtxt_subcategory_Type.setText("");
            jtxt_Account_Status.setText("");
            jtxt_Contra_Account.setText("");
            jtxt_Account_Description.setText("");
            jtxt_AccountFund_Type.setText("");
            jchk_Must_Budget.setSelected(false);
            jchk_Check_Budget.setSelected(false);
            jchk_reconcile_Account.setSelected(false);
            jchk_Restrict_Posting.setSelected(false);
            jchk_Restrict_Owner.setSelected(false);
            jtxt_Reconcile_Group.setText("");
            jtxt_Budget_Pattern.setText("");
            jCheckBox4.setSelected(false);
            Account_No_tf.setText("");
            Update_jtbl_Accounts_Master();
            jbl_account_code.setText("<- Select account group");

        }


    }//GEN-LAST:event_jButton5ActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        // TODO add your handling code here:
        dateP1();
        dateP2();
        dateP3();
        dateP4();
        dateP5();
        dateP6();
        dateP7();
        dateP8();
        dateP9();
        dateP10();
        agent_CheckBox.setSelected(true);
        conn = DBConnection.ConnectDB();
        Update_jtbl_Accounts_Master();
        Update_contact_details();
        // Update_properties_table();
        update_lease_table();
        // Update_Property_attributes_table();
        //Update_contact_information();
        jtbl_Accounts_Master.getTableHeader().setReorderingAllowed(false);
        lease_table.getTableHeader().setReorderingAllowed(false);
        properties_table.getTableHeader().setReorderingAllowed(false);
        contact_details.getTableHeader().setReorderingAllowed(false);
        contact_information.getTableHeader().setReorderingAllowed(false);
        property_attributes.getTableHeader().setReorderingAllowed(false);
        //autogenerate_lease_id();
        selected_value();

        FillCombo();
        FillCombo2();
        FillCombo3();
        FillCombo4();
        FillCombo5();
        FillCombo6();
        FillCombo7();
        FillCombo8();
        FillCombo9();

        lease_table.setDefaultRenderer(Object.class, new TableCellRendererColor());
    }//GEN-LAST:event_formWindowOpened

    private void relationshipPopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_relationshipPopupMenuWillBecomeInvisible
        // TODO add your handling code here:

    }//GEN-LAST:event_relationshipPopupMenuWillBecomeInvisible

    private void city_townPopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_city_townPopupMenuWillBecomeInvisible
        // TODO add your handling code here:

    }//GEN-LAST:event_city_townPopupMenuWillBecomeInvisible

    private void jtxt_Account_GroupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxt_Account_GroupActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxt_Account_GroupActionPerformed

    private void jtxt_Cost_CenterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxt_Cost_CenterActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxt_Cost_CenterActionPerformed

    private void jtxt_Account_DescriptionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxt_Account_DescriptionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxt_Account_DescriptionActionPerformed

    private void jtxt_Main_CategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxt_Main_CategoryActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxt_Main_CategoryActionPerformed

    private void jtxt_Sub_CategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxt_Sub_CategoryActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxt_Sub_CategoryActionPerformed

    private void jtxt_subcategory_TypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxt_subcategory_TypeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxt_subcategory_TypeActionPerformed

    private void jtxt_Account_StatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxt_Account_StatusActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxt_Account_StatusActionPerformed

    private void jtxt_Main_AccountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxt_Main_AccountActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxt_Main_AccountActionPerformed

    private void jtxt_Sub_AccountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxt_Sub_AccountActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxt_Sub_AccountActionPerformed

    private void jtxt_Contra_AccountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxt_Contra_AccountActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxt_Contra_AccountActionPerformed

    private void jtxt_AccountFund_TypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxt_AccountFund_TypeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxt_AccountFund_TypeActionPerformed

    private void jchk_Restrict_PostingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jchk_Restrict_PostingActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jchk_Restrict_PostingActionPerformed

    private void jtxt_Reconcile_GroupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxt_Reconcile_GroupActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxt_Reconcile_GroupActionPerformed

    private void jtxt_Budget_PatternActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxt_Budget_PatternActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxt_Budget_PatternActionPerformed

    private void save_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save_btnActionPerformed
        // TODO add your handling code here:

        if (contactdetails_panel.isShowing() == true) {
            if (!jtxt_Cost_Center.getText().isEmpty()) {
                String sql = "update contacts set "
                        + "contact_type='" + contact_type.getSelectedItem() + "',"
                        + "first_names='" + fname_TF.getText() + "',"
                        + "last_name='" + lname_TF.getText() + "',"
                        + "national_id='" + id_TF.getText() + "',"
                        + "pin='" + pin_TF.getText() + "',"
                        + "gender='" + gender.getSelectedItem() + "',"
                        + "occupation='" + occupation.getText() + "',"
                        + "source_of_income='" + source_of_income.getText() + "',"
                        + "company_name='" + company_name.getText() + "',"
                        + "company_branch='" + company_branch.getText() + "',"
                        + "location='" + location.getText() + "',"
                        + "current_city='" + city.getSelectedItem() + "',"
                        + "website='" + website.getText() + "',"
                        + "county='" + county.getText() + "',"
                        + "bank_name='" + bank_name.getText() + "',"
                        + "bank_acc_no='" + bank_acc_no.getText() + "',"
                        + "contact_ref='" + contact_ref_no.getText() + "',"
                        + "bank_branch='" + bank_branch.getSelectedItem() + "'where contact_id=" + contact_id_no.getText() + " ";
                try {

                    pst = conn.prepareStatement(sql);
                    pst.execute();
                    update_photo();
                    Select_checkboxes();
                    insert_and_update();
                    Insert_Timestamp2();
                    Update_contact_details();
                    contact_ref_no.setForeground(Color.black);
                    contact_ref_no.setBackground(Color.green);
                    contact_id_no.setForeground(Color.black);
                    contact_id_no.setBackground(Color.green);
                    update_successful.setText("" + fname_TF.getText() + " record updated successfully!!");

                } catch (Exception e) {
                    e.printStackTrace();

                }

                Select_checkboxes();
            } else {
            }
        }
        if (lease_panel.isShowing()) {
            update_lease();
        }
        if (ChartOfAccount_pane.isShowing() == true) {

            char Must_Budget;
            if (jchk_Must_Budget.isSelected()) {
                Must_Budget = 'Y';
            } else {
                Must_Budget = 'N';
            }
            char Check_Budget;
            if (jchk_Check_Budget.isSelected()) {
                Check_Budget = 'Y';
            } else {
                Check_Budget = 'N';
            }
            char reconcile_Account;
            if (jchk_reconcile_Account.isSelected()) {
                reconcile_Account = 'Y';
            } else {
                reconcile_Account = 'N';
            }
            char Restrict_Posting;
            if (jchk_Restrict_Posting.isSelected()) {
                Restrict_Posting = 'Y';
            } else {
                Restrict_Posting = 'N';
            }
            char Restrict_Owner;
            if (jchk_Restrict_Owner.isSelected()) {
                Restrict_Owner = 'Y';
            } else {
                Restrict_Owner = 'N';
            }
            char Transaction_Account;
            if (jCheckBox4.isSelected()) {
                Transaction_Account = 'Y';
            } else {
                Transaction_Account = 'N';
            }

            String sql = "UPDATE account_master set ACCOUNT_GROUP='" + jtxt_Account_Group.getText() + "',COST_CENTRE='" + jtxt_Cost_Center.getText() + "',MAIN_ACCOUNT='" + jtxt_Main_Account.getText() + "',SUB_ACCOUNT='" + jtxt_Sub_Account.getText() + "',ACCOUNT_STATUS='" + jtxt_Account_Status.getText() + "',DESCRIPTION='" + jtxt_Account_Description.getText() + "',SUB_CATEGORY='" + jtxt_Sub_Category.getText() + "',CONTRA_ACCOUNT='" + jtxt_Contra_Account.getText() + "',RECONCILE_GROUP='" + jtxt_Reconcile_Group.getText() + "',BUDGET_PATTERN='" + jtxt_Budget_Pattern.getText() + "',MAIN_CATEGORY='" + jtxt_Main_Category.getText() + "',SUB_CATEG_TYPE='" + jtxt_subcategory_Type.getText() + "',ACC_FUND_TYPE='" + jtxt_AccountFund_Type.getText() + "'where ACCOUNT_NUMBER='" + Account_No_tf.getText() + "'";

            try {
                //JOptionPane.showMessageDialog(null, update_sql);
                //  conn = DBConnection.ConnectDB();
                pst = conn.prepareStatement(sql);
                pst.execute();
                //JOptionPane.showMessageDialog(null,  "Account number "+Account_No_tf.getText()+" updated succcessfully!!");
                Update_jtbl_Accounts_Master();

            } catch (HeadlessException | SQLException e) {
                e.printStackTrace();

            }
            sql = "UPDATE account_master set MUST_BUDGET='" + Must_Budget + "', RECONCILE= '" + reconcile_Account + "', POST_RESTRICTION='" + Restrict_Posting + "', RESTRICTED='" + Restrict_Owner + "', TRANSACTION_Account='" + Transaction_Account + "',CHECK_BUDGET='" + Check_Budget + "' where ACCOUNT_NUMBER='" + Account_No_tf.getText() + "'";
            try {
                pst = conn.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null, "Account number " + Account_No_tf.getText() + " updated succcessfully!!");

            } catch (SQLException | HeadlessException ex) {
                ex.printStackTrace();
            }

            Update_jtbl_Accounts_Master();

        }

        if (contactInfo_panel.isShowing() == true) {
            String sql = "UPDATE contact_information set "
                    + "CONTACT_PRIORITY='" + contact_priority.getText() + "',"
                    + "FIRST_NAME='" + first_name.getText() + "',"
                    + "LAST_NAME='" + last_name.getText() + "',"
                    + "RELATIONSHIP='" + relationship.getSelectedItem() + "',"
                    + "NATIONAL_ID_NO='" + national_id_no.getText() + "',"
                    + "POSTAL_ADDRESS='" + postal_address.getText() + "',"
                    + "CITY_TOWN='" + city_town.getSelectedItem() + "',"
                    + "PHYSICAL_ADDRESS='" + physical_address.getText() + "',"
                    + "RESIDENTIAL_ADDRESS='" + residential_address.getText() + "',"
                    + "TELEPHONE_4='" + telephone4.getText() + "',"
                    + "TELEPHONE_5='" + telephone5.getText() + "',"
                    + "EMAIL_4='" + email4.getText() + "',EMAIL_5='" + email5.getText() + "' "
                    + "where CONTACT_ID=" + contact_id_no.getText() + " AND  CONTACT_REF_NO=" + contact_ref2.getText() + "";
            try {
                pst = conn.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(null, "" + fname_TF.getText() + "'s contact information records have been updated successfully!");
                Update_contact_information();
            } catch (SQLException | HeadlessException e) {
                e.printStackTrace();
            }
        }


    }//GEN-LAST:event_save_btnActionPerformed

    private void jlbl_Account_GroupMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlbl_Account_GroupMouseClicked
        // TODO add your handling code here:

        DBConnection.dynamic_sql = "select minor_code, description from list_control where reference_code = 'ACCOUNT_GROUP' and sub_code = '###'";
        DBConnection.panel(new TableDetails_Panel(), "Account Group");

    }//GEN-LAST:event_jlbl_Account_GroupMouseClicked

    private void main_categoryMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_main_categoryMouseClicked
        // TODO add your handling code here:

        DBConnection.dynamic_sql = "select minor_code, description from list_control where reference_code = 'MAIN_CATEGORY' and sub_code = '###'";
        DBConnection.panel(new TableDetails_Panel(), "Main Category");
    }//GEN-LAST:event_main_categoryMouseClicked

    private void sub_categoryMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sub_categoryMouseClicked
        // TODO add your handling code here:

        DBConnection.dynamic_sql = "select minor_code, description from list_control where reference_code = 'SUB_ACCOUNT' and sub_code = '###'";
        DBConnection.panel(new TableDetails_Panel(), "Sub Account");

    }//GEN-LAST:event_sub_categoryMouseClicked

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        if (contactdetails_panel.isShowing() == true) {
            String sql = "delete from contacts where PIN='" + pin_TF.getText() + "' AND FIRST_NAMES='" + fname_TF.getText() + "'";
            try {
                pst = conn.prepareStatement(sql);
                pst.execute();
                Update_contact_details();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (lease_panel.isShowing()) {
            delete_lease();
        }
        if (ChartOfAccount_pane.isShowing()) {
            String sql_delete = "delete from account_master where account_number='" + Account_No_tf.getText() + "'";
            try {
                pst = conn.prepareStatement(sql_delete);
                pst.execute();
                Update_jtbl_Accounts_Master();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void export_to_excelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_export_to_excelActionPerformed
        // TODO add your handling code here:
        import_export_panel.operation_type = "export";
        if (contactdetails_panel.isShowing()) {
            import_export_panel.title = "Export Users Details to excel";
            DBConnection.panel(new import_export_panel(), import_export_panel.title);
        }
        if (contact_info_pane.isShowing()) {
            import_export_panel.title = "Export Contact-Info Details to excel";
            DBConnection.panel(new import_export_panel(), import_export_panel.title);
        }
        if (propertyInfo_panel.isShowing()) {
            import_export_panel.title = "Export Property Details to excel";
            DBConnection.panel(new import_export_panel(), import_export_panel.title);
        }
        if (ChartOfAccount_pane.isShowing()) {
            import_export_panel.title = "Export Accounts Details to excel";
            DBConnection.panel(new import_export_panel(), import_export_panel.title);
        }
        if (lease_panel.isShowing()) {
            import_export_panel.title = "Export Leases Details to excel";
            DBConnection.panel(new import_export_panel(), import_export_panel.title);
        }
    }//GEN-LAST:event_export_to_excelActionPerformed

    private void import_from_excelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_import_from_excelActionPerformed
        // TODO add your handling code here:   

    }//GEN-LAST:event_import_from_excelActionPerformed

    private void jRadioButton_activeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton_activeActionPerformed
        // TODO add your handling code here:
        selected_value();

    }//GEN-LAST:event_jRadioButton_activeActionPerformed

    private void dp3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dp3MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_dp3MouseClicked

    private void dp5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dp5MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_dp5MouseClicked

    private void lease_frequency_comboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lease_frequency_comboActionPerformed
        // TODO add your handling code here:
        String selection = lease_frequency_combo.getSelectedItem().toString();
        int v1 = 0;
        if (selection.equals("Not selected")) {
            jSpinner_lease_prd.setValue(v1);
            jSpinner_lease_prd.setEnabled(false);
        } else {
            jSpinner_lease_prd.setEnabled(true);
        }
    }//GEN-LAST:event_lease_frequency_comboActionPerformed

    private void jSpinner_lease_prdStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSpinner_lease_prdStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_jSpinner_lease_prdStateChanged

    private void dp4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dp4MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_dp4MouseClicked

    private void dp7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dp7MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_dp7MouseClicked

    private void dp6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dp6MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_dp6MouseClicked

    private void dp8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dp8MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_dp8MouseClicked

    private void tax_codeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tax_codeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tax_codeActionPerformed

    private void jSpinner_insp_prdStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSpinner_insp_prdStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_jSpinner_insp_prdStateChanged

    private void jSpinner_salecommissionStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSpinner_salecommissionStateChanged
        // TODO add your handling code here:
        DBConnection.percentage_amount(jSpinner_salecommission, current_lease_tf, salesAmnt_TF);
    }//GEN-LAST:event_jSpinner_salecommissionStateChanged

    private void jRadioButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton15ActionPerformed
        // TODO add your handling code here:
        if (jRadioButton15.isSelected()) {
            jSpinner_salecommission.setEnabled(false);
            salesAmnt_TF.setEditable(true);
        }
    }//GEN-LAST:event_jRadioButton15ActionPerformed

    private void jRadioButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton16ActionPerformed
        // TODO add your handling code here:
        if (jRadioButton16.isSelected()) {
            jSpinner_salecommission.setEnabled(true);
            salesAmnt_TF.setEditable(false);
        }
    }//GEN-LAST:event_jRadioButton16ActionPerformed

    private void jSpinner_penalty_percentStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSpinner_penalty_percentStateChanged
        // TODO add your handling code here:
        DBConnection.percentage_amount(jSpinner_penalty_percent, current_lease_tf, penaltyAmnt_TF);
    }//GEN-LAST:event_jSpinner_penalty_percentStateChanged

    private void dp9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dp9MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_dp9MouseClicked

    private void jRadioButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton17ActionPerformed
        // TODO add your handling code here:
        if (jRadioButton17.isSelected()) {
            jSpinner_penalty_percent.setEnabled(true);
            penaltyAmnt_TF.setEditable(false);
        }
    }//GEN-LAST:event_jRadioButton17ActionPerformed

    private void jRadioButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton18ActionPerformed
        // TODO add your handling code here:
        if (jRadioButton18.isSelected()) {
            jSpinner_penalty_percent.setEnabled(false);
            penaltyAmnt_TF.setEditable(true);
        }
    }//GEN-LAST:event_jRadioButton18ActionPerformed

    private void other_depst_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_other_depst_btnActionPerformed
        // TODO add your handling code here:

        JDialog jd = new JDialog(new JFrame());
        if (!lease_id_tf.getText().equals("")) {
            jd.setContentPane(new maliplus.detailsPanels.Deposits_Panel());
            jd.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            jd.setLocation(300, 200);
            jd.pack();
            jd.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "No lease ID");
        }

    }//GEN-LAST:event_other_depst_btnActionPerformed

    private void more_charges_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_more_charges_btnActionPerformed
        // TODO add your handling code here:
        if (!lease_id_tf.getText().equals("")) {
            JDialog jd = new JDialog(new JFrame(), true);
            jd.setContentPane(new Charges_Panel());
            jd.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            jd.setLocation(300, 200);
            jd.pack();
            jd.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "No lease ID");
        }

    }//GEN-LAST:event_more_charges_btnActionPerformed

    private void jRadioButton_closedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton_closedActionPerformed
        // TODO add your handling code here:
        selected_value();
    }//GEN-LAST:event_jRadioButton_closedActionPerformed

    private void jRadioButton_onholdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton_onholdActionPerformed
        // TODO add your handling code here:
        selected_value();
    }//GEN-LAST:event_jRadioButton_onholdActionPerformed

    private void refresh_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refresh_btnActionPerformed
        // TODO add your handling code here:
        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        String date = sdf.format(d);

        if (contactdetails_panel.isShowing()) {
            Update_contact_details();
        }

        if (contact_info_pane.isShowing()) {
            Update_contact_information();
        }

        if (propertyInfo_panel.isShowing()) {
            Update_contact_information();
        }

        if (ChartOfAccount_pane.isShowing()) {
            Update_jtbl_Accounts_Master();
        }

        if (lease_panel.isShowing()) {
            datePicker.getJFormattedTextField().setText(date);
            datePicker2.getJFormattedTextField().setText(date);
            datePicker3.getJFormattedTextField().setText(date);
            datePicker4.getJFormattedTextField().setText(date);
            datePicker5.getJFormattedTextField().setText(date);
            datePicker6.getJFormattedTextField().setText(date);
            datePicker7.getJFormattedTextField().setText(date);
            datePicker8.getJFormattedTextField().setText(date);
            datePicker9.getJFormattedTextField().setText(date);

            update_lease_table();
            jCheckBx_aprv_lease.setSelected(false);
            jCheckBx_aprv_lease.setForeground(Color.blue);
            jCheckBx_aprv_lease.setText("Approve Lease");
        }

    }//GEN-LAST:event_refresh_btnActionPerformed

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        // TODO add your handling code here:
        if (jCheckBox1.isSelected()) {
            refund_depst_tf.setEditable(true);
        } else {
            refund_depst_tf.setEditable(false);
            refund_depst_tf.setText("0");

        }
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void jCheckBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox2ActionPerformed
        // TODO add your handling code here:
        if (jCheckBox2.isSelected()) {
            non_refund_dpst_tf.setEditable(true);
        } else {
            non_refund_dpst_tf.setEditable(false);
            non_refund_dpst_tf.setText("0");
        }

    }//GEN-LAST:event_jCheckBox2ActionPerformed

    private void jCheckBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox3ActionPerformed
        // TODO add your handling code here:
        if (jCheckBox3.isSelected()) {
            lease_frequency_combo.setEnabled(true);
            lease_frequency_combo.setSelectedItem("Daily");
            jSpinner_lease_prd.setEnabled(true);
        } else {
            lease_frequency_combo.setEnabled(false);
            lease_frequency_combo.setSelectedItem("Not selected");
            lease_frequency_combo.setSelectedIndex(0);
            jSpinner_lease_prd.setEnabled(false);
            jSpinner_lease_prd.setValue(0);
        }
    }//GEN-LAST:event_jCheckBox3ActionPerformed

    private void penaltyAmnt_TFKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_penaltyAmnt_TFKeyTyped
        // TODO add your handling code here:
        char keychar = evt.getKeyChar();
        if (!(Character.isDigit(keychar) || keychar == KeyEvent.VK_BACKSPACE || keychar == KeyEvent.VK_DELETE)) {
            evt.consume();
        }
    }//GEN-LAST:event_penaltyAmnt_TFKeyTyped

    private void salesAmnt_TFKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_salesAmnt_TFKeyTyped
        // TODO add your handling code here:
        char keychar = evt.getKeyChar();
        if (!(Character.isDigit(keychar) || keychar == KeyEvent.VK_BACKSPACE || keychar == KeyEvent.VK_DELETE)) {
            evt.consume();
        }
    }//GEN-LAST:event_salesAmnt_TFKeyTyped

    private void current_lease_tfKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_current_lease_tfKeyTyped
        // TODO add your handling code here:
        char keychar = evt.getKeyChar();
        if (!(Character.isDigit(keychar) || keychar == KeyEvent.VK_BACKSPACE || keychar == KeyEvent.VK_DELETE)) {
            evt.consume();
        }
    }//GEN-LAST:event_current_lease_tfKeyTyped

    private void current_lease_tfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_current_lease_tfActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_current_lease_tfActionPerformed

    private void searchrecord_tfKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchrecord_tfKeyTyped
        // TODO add your handling code here:
        if (lease_panel.isShowing()) {
            char keychar = evt.getKeyChar();
            if (Character.isLowerCase(keychar)) {
                evt.setKeyChar(Character.toUpperCase(keychar));
            }
            String temp = "%" + searchrecord_tf.getText() + "%";
            String sql = "select *from lease where lease_id like'" + temp + "' or properti_id like'" + temp + "' or contact_id like'" + temp + "' or salesman_id like'" + temp + "'";
            DBConnection.update_table(sql, lease_table);

        }
    }//GEN-LAST:event_searchrecord_tfKeyTyped

    private void jCheck_pen_statusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheck_pen_statusActionPerformed
        // TODO add your handling code here:
        if (jCheck_pen_status.isSelected()) {
            jCheck_pen_status.setText("Active");
        } else {
            jCheck_pen_status.setText("Inactive");
        }
    }//GEN-LAST:event_jCheck_pen_statusActionPerformed

    private void id_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_id_TFActionPerformed
        // TODO add your handling code here:

        String temp = "%" + id_TF.getText() + "%";
        String sql = "select *from contacts where NATIONAL_ID like'" + temp + "'";
        try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            contact_details.setModel(DbUtils.resultSetToTableModel(rs));

        } catch (Exception e) {
            // JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_id_TFActionPerformed

    private void id_TFKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_id_TFKeyReleased
        // TODO add your handling code here:
        if (evt.getSource() == id_TF) {
            String text = id_TF.getText();
            if (Character.isLowerCase(text.charAt(text.length() - 1))) {
                id_TF.setText(text.toUpperCase());
            }
        }
    }//GEN-LAST:event_id_TFKeyReleased

    private void id_TFKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_id_TFKeyTyped
        // TODO add your handling code here:

    }//GEN-LAST:event_id_TFKeyTyped

    private void pin_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pin_TFActionPerformed
        // TODO add your handling code here:
        String temp = "%" + pin_TF.getText() + "%";
        String sql = "select *from contacts where PIN like'" + temp + "'";
        try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            contact_details.setModel(DbUtils.resultSetToTableModel(rs));

        } catch (Exception e) {
            // JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_pin_TFActionPerformed

    private void pin_TFKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pin_TFKeyReleased
        // TODO add your handling code here:
        if (evt.getSource() == pin_TF) {
            String text = pin_TF.getText();
            if (Character.isLowerCase(text.charAt(text.length() - 1))) {
                pin_TF.setText(text.toUpperCase());
            }
        }
    }//GEN-LAST:event_pin_TFKeyReleased

    private void fname_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fname_TFActionPerformed
        // TODO add your handling code here:

        String temp = "%" + fname_TF.getText() + "%";
        String sql = "select *from contacts where FIRST_NAMES like'" + temp + "'";
        try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            contact_details.setModel(DbUtils.resultSetToTableModel(rs));

        } catch (Exception e) {
            // JOptionPane.showMessageDialog(null, e);
        }

    }//GEN-LAST:event_fname_TFActionPerformed

    private void fname_TFKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fname_TFKeyReleased
        // TODO add your handling code here:
        if (evt.getSource() == fname_TF) {
            String text = fname_TF.getText();
            if (Character.isLowerCase(text.charAt(text.length() - 1))) {
                fname_TF.setText(text.toUpperCase());
            }
        }
    }//GEN-LAST:event_fname_TFKeyReleased

    private void fname_TFKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fname_TFKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_fname_TFKeyTyped

    private void citzn_comboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_citzn_comboActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_citzn_comboActionPerformed

    private void brwsBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_brwsBtnActionPerformed

        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Choose image");
        fc.setMultiSelectionEnabled(false);
        fc.showOpenDialog(this);
        File f = fc.getSelectedFile();

        try {

            String filename = f.getAbsolutePath();
            pathTF.setText(filename);

            int width = userImage.getWidth();
            int height = userImage.getHeight();
            ImageIcon icon = new ImageIcon(filename);
            Image img = icon.getImage();
            userImage.setIcon(new ImageIcon(img.getScaledInstance(width, height, Image.SCALE_AREA_AVERAGING)));
        } catch (Exception e) {
        }

    }//GEN-LAST:event_brwsBtnActionPerformed

    private void pathTFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pathTFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pathTFActionPerformed

    private void lname_TFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lname_TFActionPerformed
        // TODO add your handling code here:

        String temp = "%" + lname_TF.getText() + "%";
        String sql = "select *from contacts where LAST_NAME like'" + temp + "'";
        DBConnection.update_table(sql, contact_details);

    }//GEN-LAST:event_lname_TFActionPerformed

    private void lname_TFKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_lname_TFKeyReleased
        // TODO add your handling code here:
        if (evt.getSource() == lname_TF) {
            String text = lname_TF.getText();
            if (Character.isLowerCase(text.charAt(text.length() - 1))) {
                lname_TF.setText(text.toUpperCase());
            }
        }
    }//GEN-LAST:event_lname_TFKeyReleased

    private void contact_detailsKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_contact_detailsKeyPressed
        // TODO add your handling code here:
        contact_detailsMouseClicked_action_performed();
        display_photo();
    }//GEN-LAST:event_contact_detailsKeyPressed

    private void contact_typePopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_contact_typePopupMenuWillBecomeInvisible
        // TODO add your handling code here:

        if (contact_type.getSelectedItem().equals("Company")) {
            lname_TF.setEnabled(false);
            jLabel4.setText("Company Name:");
            lname_TF.setBackground(Color.lightGray);
            id_TF.setEnabled(false);
            id_TF.setBackground(Color.lightGray);
            occupation.setEnabled(false);
            occupation.setBackground(Color.lightGray);
            occupation2.setEnabled(false);
            jLabel53.setText("Type of business");
            jPanel15.setEnabled(true);
            jLabel16.setText("Company PIN");
            company_name.setEnabled(true);
            company_branch.setEnabled(true);
            current_city.setEnabled(true);
            website.setEnabled(true);
            county.setEnabled(true);
            location.setEnabled(true);
            jLabel99.setEnabled(false);
            jLabel100.setEnabled(false);
            jLabel104.setFocusable(true);
            jLabel107.setFocusable(true);
            jLabel131.setFocusable(true);
            lname_TF.setText("");
            id_TF.setText("");
            occupation.setText("");
        } else if (contact_type.getSelectedItem().equals("Association")) {
            lname_TF.setEnabled(false);
            jLabel4.setText("Association Name:");
            lname_TF.setBackground(Color.lightGray);
            id_TF.setEnabled(false);
            id_TF.setBackground(Color.lightGray);
            occupation2.setEnabled(false);
            occupation.setEnabled(false);
            occupation.setBackground(Color.lightGray);
            jLabel53.setText("Type of business");
            jPanel15.setEnabled(true);
            jLabel16.setText("Business PIN");
            company_name.setEnabled(true);
            company_branch.setEnabled(true);
            current_city.setEnabled(true);
            website.setEnabled(true);
            county.setEnabled(true);
            location.setEnabled(true);
            jLabel99.setEnabled(false);
            jLabel100.setEnabled(false);
            jLabel104.setFocusable(true);
            jLabel107.setFocusable(true);
            jLabel131.setFocusable(true);
            lname_TF.setText("");
            id_TF.setText("");
            occupation.setText("");
        } else {
            lname_TF.setEnabled(true);
            jLabel4.setText("First Name:");
            lname_TF.setBackground(Color.white);
            id_TF.setEnabled(true);
            id_TF.setBackground(Color.white);

            occupation.setEnabled(true);
            occupation.setBackground(Color.white);
            occupation2.setEnabled(true);
            jLabel53.setText("Source of income");
            jPanel15.setEnabled(false);
            jLabel16.setText("PIN");
            company_name.setEnabled(false);
            company_branch.setEnabled(false);
            current_city.setEnabled(false);
            website.setEnabled(false);
            county.setEnabled(false);
            location.setEnabled(false);
            jLabel99.setEnabled(true);
            jLabel100.setEnabled(true);
            jLabel104.setFocusable(false);
            jLabel107.setFocusable(false);
            jLabel131.setFocusable(false);
            location.setText("");
            current_city.setText("");
            county.setText("");
            website.setText("");
            company_branch.setText("");
            company_name.setText("");
            county.setText("");
        }

    }//GEN-LAST:event_contact_typePopupMenuWillBecomeInvisible

    private void contact_typeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contact_typeActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_contact_typeActionPerformed

    private void country_selActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_country_selActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_country_selActionPerformed

    private void source_of_incomeKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_source_of_incomeKeyReleased
        // TODO add your handling code here:
        if (evt.getSource() == source_of_income) {
            String text = source_of_income.getText();
            if (Character.isLowerCase(text.charAt(text.length() - 1))) {
                source_of_income.setText(text.toUpperCase());
            }
        }
    }//GEN-LAST:event_source_of_incomeKeyReleased

    private void occupation2PopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_occupation2PopupMenuWillBecomeInvisible
        // TODO add your handling code here:

        DBConnection.MY_CODE_REFERENCE = "OCCUPATION";
        DBConnection.MY_SUB_CODE = "###";

        try {
            String sql = "SELECT DESCRIPTION from list_control where reference_code = '" + DBConnection.MY_CODE_REFERENCE + "' AND sub_code='" + DBConnection.MY_SUB_CODE + "'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if (rs.next()) {
                String add = rs.getString("DESCRIPTION");
                String tmp = (String) occupation2.getSelectedItem();
                occupation.setText(tmp);

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_occupation2PopupMenuWillBecomeInvisible

    private void occupation2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_occupation2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_occupation2ActionPerformed

    private void bank_name2PopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_bank_name2PopupMenuWillBecomeInvisible
        // TODO add your handling code here:

        DBConnection.MY_CODE_REFERENCE = "BANKS";
        DBConnection.MY_SUB_CODE = "###";

        try {
            String sql = "SELECT DESCRIPTION from list_control where reference_code = '" + DBConnection.MY_CODE_REFERENCE + "' AND sub_code='" + DBConnection.MY_SUB_CODE + "'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if (rs.next()) {
                String add = rs.getString("DESCRIPTION");
                String tmp = (String) bank_name2.getSelectedItem();
                bank_name.setText(tmp);

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_bank_name2PopupMenuWillBecomeInvisible

    private void bank_name2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bank_name2ActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_bank_name2ActionPerformed

    private void bank_name2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_bank_name2KeyReleased
        // TODO add your handling code here:

    }//GEN-LAST:event_bank_name2KeyReleased

    private void websiteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_websiteKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_websiteKeyReleased

    private void current_cityKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_current_cityKeyReleased
        // TODO add your handling code here:
        if (evt.getSource() == current_city) {
            String text = current_city.getText();
            if (Character.isLowerCase(text.charAt(text.length() - 1))) {
                current_city.setText(text.toUpperCase());
            }
        }
    }//GEN-LAST:event_current_cityKeyReleased

    private void company_nameKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_company_nameKeyReleased
        // TODO add your handling code here:
        if (evt.getSource() == company_name) {
            String text = company_name.getText();
            if (Character.isLowerCase(text.charAt(text.length() - 1))) {
                company_name.setText(text.toUpperCase());
            }
        }
    }//GEN-LAST:event_company_nameKeyReleased

    private void company_branchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_company_branchKeyReleased
        // TODO add your handling code here:
        if (evt.getSource() == company_branch) {
            String text = company_branch.getText();
            if (Character.isLowerCase(text.charAt(text.length() - 1))) {
                company_branch.setText(text.toUpperCase());
            }
        }
    }//GEN-LAST:event_company_branchKeyReleased

    private void countyKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_countyKeyReleased
        // TODO add your handling code here:
        if (evt.getSource() == county) {
            String text = county.getText();
            if (Character.isLowerCase(text.charAt(text.length() - 1))) {
                county.setText(text.toUpperCase());
            }
        }
    }//GEN-LAST:event_countyKeyReleased

    private void locationKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_locationKeyReleased
        // TODO add your handling code here:
        if (evt.getSource() == location) {
            String text = location.getText();
            if (Character.isLowerCase(text.charAt(text.length() - 1))) {
                location.setText(text.toUpperCase());
            }
        }
    }//GEN-LAST:event_locationKeyReleased

    private void jLabel104MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel104MouseClicked
        // TODO add your handling code here:
        if (contact_type.getSelectedItem().toString().equals("Individual")) {
            jd.setVisible(false);

        } else {

            DBConnection.dynamic_sql = "select minor_code as code, description as locations from list_control where reference_code = 'LOCATION' and sub_code = '###'";
            DBConnection.panel(new TableDetails_Panel2(), "Location");
        }

    }//GEN-LAST:event_jLabel104MouseClicked

    private void jLabel107MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel107MouseClicked
        // TODO add your handling code here:
        if (contact_type.getSelectedItem().equals("Individual")) {
            jd.setVisible(false);

        } else if (contact_type.getSelectedItem().equals("Company")) {
            DBConnection.dynamic_sql = "select minor_code as code, description as Location from list_contol where reference_code = 'CITIES' and sub_code = '###'";
            DBConnection.panel(new TableDetails_Panel2(), "City");
        } else if (contact_type.getSelectedItem().equals("Association")) {
            DBConnection.dynamic_sql = "select minor_code as code, description as Location from list_control where reference_code = 'CITIES' and sub_code = '###'";
            DBConnection.panel(new TableDetails_Panel2(), "City");
        }

    }//GEN-LAST:event_jLabel107MouseClicked

    private void jLabel98MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel98MouseClicked
        // TODO add your handling code here:
        String temp = "%" + fname_TF.getText() + "%";
        String sql = "select *from contacts where FIRST_NAMES like'" + temp + "'";

        DBConnection.update_table(sql, contact_details);
    }//GEN-LAST:event_jLabel98MouseClicked

    private void jLabel99MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel99MouseClicked
        // TODO add your handling code here:
        String temp = "%" + lname_TF.getText() + "%";
        String sql = "select *from contacts where LAST_NAME like'" + temp + "'";
        DBConnection.update_table(sql, contact_details);
    }//GEN-LAST:event_jLabel99MouseClicked

    private void jLabel100MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel100MouseClicked
        // TODO add your handling code here:
        String temp = "%" + id_TF.getText() + "%";
        String sql = "select *from contacts where NATIONAL_ID like'" + temp + "'";
        try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            contact_details.setModel(DbUtils.resultSetToTableModel(rs));

        } catch (Exception e) {
            // JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_jLabel100MouseClicked

    private void jLabel102MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel102MouseClicked
        // TODO add your handling code here:
        String temp = "%" + pin_TF.getText() + "%";
        String sql = "select *from contacts where PIN like'" + temp + "'";
        DBConnection.update_table(sql, contact_details);
    }//GEN-LAST:event_jLabel102MouseClicked

    private void occupationKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_occupationKeyReleased
        // TODO add your handling code here:
        if (evt.getSource() == occupation) {
            String text = occupation.getText();
            if (Character.isLowerCase(text.charAt(text.length() - 1))) {
                occupation.setText(text.toUpperCase());
            }
        }
    }//GEN-LAST:event_occupationKeyReleased

    private void sale_valueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sale_valueActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sale_valueActionPerformed

    private void property_valueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_property_valueActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_property_valueActionPerformed

    private void purchase_priceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_purchase_priceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_purchase_priceActionPerformed

    private void dp1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dp1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_dp1MouseClicked

    private void dpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dpMouseClicked

    }//GEN-LAST:event_dpMouseClicked

    private void costsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_costsActionPerformed
        // TODO add your handling code here:
        if (owner.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Property Id field cannot be empty.please select a property from the table below thank you.");
            owner.setBackground(Color.red);
            property_idlbl.setText("Required");
            property_idlbl.setForeground(Color.red);

        } else {

            JDialog jd = new JDialog(new JFrame(), true);
            jd.setContentPane(new costspanel());
            jd.setLocation(200, 200);
            jd.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            jd.pack();
            jd.setVisible(true);

        }

    }//GEN-LAST:event_costsActionPerformed

    private void countryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_countryActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_countryActionPerformed

    private void surburbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_surburbActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_surburbActionPerformed

    private void cityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cityActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cityActionPerformed

    private void zonesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_zonesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_zonesActionPerformed

    private void dp2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dp2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_dp2MouseClicked

    private void property_statusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_property_statusActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_property_statusActionPerformed

    private void property_typeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_property_typeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_property_typeActionPerformed

    private void ownerKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ownerKeyReleased
        // TODO add your handling code here:

    }//GEN-LAST:event_ownerKeyReleased

    private void ownerKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ownerKeyTyped
        // TODO add your handling code here:
        if (owner.getText().equals("")) {
            owner.setBackground(Color.red);
            property_idlbl.setText("Required");
            property_idlbl.setForeground(Color.red);
        } else {
            owner.setBackground(Color.GREEN);
            property_idlbl.setText("OK!");
            property_idlbl.setForeground(Color.GREEN);
        }
    }//GEN-LAST:event_ownerKeyTyped

    private void jLabel109MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel109MouseClicked
        // TODO add your handling code here:
        if (!property_id.getText().isEmpty()) {
            // DBConnection.dynamic_sql = "select property_id, property_description from properties_table";
            DBConnection.dynamic_sql = "SELECT minor_code, description from list_control where reference_code = 'PARENT_CATEGORY' and sub_code = '###'";
            DBConnection.panel(new TableDetails_Panel(), "Parent Category (Property)");

        } else {
            property_idlbl.setText("Property ID?");
        }

    }//GEN-LAST:event_jLabel109MouseClicked

    private void bank_name1PopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_bank_name1PopupMenuWillBecomeInvisible
        // TODO add your handling code here:
        DBConnection.MY_CODE_REFERENCE = "BANKS";
        DBConnection.MY_SUB_CODE = "###";

        try {
            String sql = "SELECT DESCRIPTION from list_control where reference_code = '" + DBConnection.MY_CODE_REFERENCE + "' AND sub_code='" + DBConnection.MY_SUB_CODE + "'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if (rs.next()) {
                String add = rs.getString("DESCRIPTION");
                String tmp = (String) bank_name1.getSelectedItem();
                bank_name.setText(tmp);

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_bank_name1PopupMenuWillBecomeInvisible

    private void bank_name1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bank_name1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bank_name1ActionPerformed

    private void bank_name1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_bank_name1KeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_bank_name1KeyReleased

    private void picMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_picMouseClicked
        // TODO add your handling code here:
        slide_show_1.getobj().setVisible(true);
    }//GEN-LAST:event_picMouseClicked

    private void main_acc_codeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_main_acc_codeMouseClicked

        DBConnection.dynamic_sql = "select minor_code, description from list_control where reference_code = 'MAIN_ACCOUNT' and sub_code = '###'";
        DBConnection.panel(new TableDetails_Panel(), "Main Account Code");
    }//GEN-LAST:event_main_acc_codeMouseClicked

    private void sub_acc_codeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sub_acc_codeMouseClicked
        // TODO add your handling code here:

        DBConnection.dynamic_sql = "select minor_code, description from list_control where reference_code = 'SUB_ACCOUNT_CODE' and sub_code = '###'";
        DBConnection.panel(new TableDetails_Panel(), "Sub Account Code");
    }//GEN-LAST:event_sub_acc_codeMouseClicked

    private void account_statusMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_account_statusMouseClicked
        // TODO add your handling code here:

        DBConnection.dynamic_sql = "select minor_code, description from list_control where reference_code = 'ACCOUNT_STATUS' and sub_code = '###'";
        DBConnection.panel(new TableDetails_Panel(), "Account Status");
    }//GEN-LAST:event_account_statusMouseClicked

    private void sub_categ_typeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sub_categ_typeMouseClicked
        // TODO add your handling code here:

        DBConnection.dynamic_sql = "select minor_code, description from list_control where reference_code = 'SUB_CATEGORY_TYPE' and sub_code = '###'";
        DBConnection.panel(new TableDetails_Panel(), "Sub Categ. Type");
    }//GEN-LAST:event_sub_categ_typeMouseClicked

    private void contra_accMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_contra_accMouseClicked
        // TODO add your handling code here:

        DBConnection.dynamic_sql = "select account_number, description from account_master where account_status = 'ACT' and account_number <> '" + jtxt_Main_Account.getText() + jtxt_Sub_Account.getText() + "'";
        DBConnection.panel(new TableDetails_Panel2(), "Contra Account");
    }//GEN-LAST:event_contra_accMouseClicked

    private void reconcile_groupMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_reconcile_groupMouseClicked
        // TODO add your handling code here:

        DBConnection.dynamic_sql = "select description from list_control where reference_code = 'RECONCILE_GROUP' and sub_code = '###'";
        DBConnection.panel(new TableDetails_Panel2(), "Reconcile Group");
    }//GEN-LAST:event_reconcile_groupMouseClicked

    private void budget_patternMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_budget_patternMouseClicked
        // TODO add your handling code here:

        DBConnection.dynamic_sql = "select description from list_control where reference_code = 'BUDGET_PATTERN' and sub_code = '###'";
        DBConnection.panel(new TableDetails_Panel(), "Budget Pattern");
    }//GEN-LAST:event_budget_patternMouseClicked

    private void acc_fund_typeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_acc_fund_typeMouseClicked
        // TODO add your handling code here:

        DBConnection.dynamic_sql = "select description from list_control where reference_code = 'ACCOUNT_FUND_TYPE' and sub_code = '###'";
        DBConnection.panel(new TableDetails_Panel(), "Account Fund Type");
    }//GEN-LAST:event_acc_fund_typeMouseClicked

    private void contact_detailsMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_contact_detailsMousePressed
        // TODO add your handling code here:
        int click = evt.getClickCount();
        int row = contact_details.getSelectedRow();
        if (click == 2) {
            contact_detailsMouseClicked_action_performed();
            update_successful.setText("");
            contact_ref_no.setForeground(Color.black);
            contact_ref_no.setBackground(Color.white);
            contact_id_no.setForeground(Color.black);
            contact_id_no.setBackground(Color.white);
            if (contact_details.getModel().getValueAt(row, 2).equals("Individual")) {
                jLabel99.setEnabled(true);
                jLabel100.setEnabled(true);
                occupation.setEnabled(true);
                occupation.setBackground(Color.white);
                occupation2.setEnabled(true);
            } else {
                jLabel99.setEnabled(true);
                jLabel100.setEnabled(true);
                occupation.setEnabled(false);
                occupation.setBackground(Color.lightGray);
                occupation2.setEnabled(false);
            }

            display_photo();
            Update_contact_information();
            Update_properties_table();
        }
    }//GEN-LAST:event_contact_detailsMousePressed

    private void lease_tableMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lease_tableMousePressed
        // TODO add your handling code here:
        int click = evt.getClickCount();
        if (click == 2) {

            DefaultTableModel tmodel = (DefaultTableModel) lease_table.getModel();
            int row = lease_table.convertRowIndexToModel(lease_table.getSelectedRow());

            //for (int i = 0; i <= tmodel.getColumnCount(); i++) {
            //System.out.println(i + "\t" + tmodel.getColumnName(i));
            //}
            try {
                lease_id_tf.setText(tmodel.getValueAt(row, 0).toString());
                property_id_combo.setText(tmodel.getValueAt(row, 1).toString());
                contact_id_tf.setText(tmodel.getValueAt(row, 2).toString());
                jCombo_lease_types.setSelectedItem(tmodel.getValueAt(row, 4).toString());
                datePicker4.getJFormattedTextField().setText(tmodel.getValueAt(row, 5).toString());
                datePicker6.getJFormattedTextField().setText(tmodel.getValueAt(row, 6).toString());
                lease_acc_tf.setText(tmodel.getValueAt(row, 7).toString());
                non_refund_dpst_tf.setText(tmodel.getValueAt(row, 8).toString());
                refund_depst_tf.setText(tmodel.getValueAt(row, 9).toString());
                lease_fee_amount.setText(tmodel.getValueAt(row, 10).toString());
                water_depst_tf.setText(tmodel.getValueAt(row, 11).toString());
                elect_depst_tf.setText(tmodel.getValueAt(row, 12).toString());
                salesman_id_tf.setText(tmodel.getValueAt(row, 13).toString());
                salesman_name.setText(tmodel.getValueAt(row, 14).toString());
                salesAmnt_TF.setText(tmodel.getValueAt(row, 15).toString());

                jSpinner_salecommission.setValue(tmodel.getValueAt(row, 16));
                salesman_acc_tf.setText(tmodel.getValueAt(row, 17).toString());
                jSpinner_insp_prd.setValue(tmodel.getValueAt(row, 18));
                jCombo_insp_freq.setSelectedItem(tmodel.getValueAt(row, 19).toString());
                datePicker5.getJFormattedTextField().setText(tmodel.getValueAt(row, 20).toString());
                datePicker8.getJFormattedTextField().setText(tmodel.getValueAt(row, 21).toString());
                datePicker7.getJFormattedTextField().setText(tmodel.getValueAt(row, 22).toString());
                datePicker9.getJFormattedTextField().setText(tmodel.getValueAt(row, 23).toString());
                security_charges_tf.setText(tmodel.getValueAt(row, 24).toString());
                utility_charges_tf.setText(tmodel.getValueAt(row, 25).toString());
                utility_charges_acc.setText(tmodel.getValueAt(row, 26).toString());
                penaltyAmnt_TF.setText(tmodel.getValueAt(row, 27).toString());
                jSpinner_penalty_percent.setValue(tmodel.getValueAt(row, 28));
                datePicker10.getJFormattedTextField().setText(tmodel.getValueAt(row, 29).toString());
                jCheck_pen_status.setText(tmodel.getValueAt(row, 30).toString());
                current_lease_tf.setText(tmodel.getValueAt(row, 31).toString());
                inspector_id.setText(tmodel.getValueAt(row, 32).toString());
                jSpinner_lease_prd.setValue(tmodel.getValueAt(row, 33));
                lease_frequency_combo.setSelectedItem(tmodel.getValueAt(row, 34).toString());
                securitycharges_acc.setText(tmodel.getValueAt(row, 35).toString());
                water_depst_acc_tf.setText(tmodel.getValueAt(row, 36).toString());
                elect_depst_acc_tf.setText(tmodel.getValueAt(row, 37).toString());
                non_refund_dpst_tf.setText(tmodel.getValueAt(row, 38).toString());
                non_refundable_deposit_account.setText(tmodel.getValueAt(row, 39).toString());
                refundable_deposit_account.setText(tmodel.getValueAt(row, 40).toString());
                lease_fee_accnt_tf.setText(tmodel.getValueAt(row, 42).toString());

                aprv_status = tmodel.getValueAt(row, 41).toString();
                if (aprv_status.equals("Y")) {
                    jCheckBx_aprv_lease.setSelected(true);
                    jCheckBx_aprv_lease.setEnabled(false);
                    jCheckBx_aprv_lease.setForeground(new Color(187, 187, 187));
                    jCheckBx_aprv_lease.setText("Lease Approved");
                    save_btn.setEnabled(false);

                } else {
                    jCheckBx_aprv_lease.setSelected(false);
                    jCheckBx_aprv_lease.setEnabled(true);
                    jCheckBx_aprv_lease.setForeground(new Color(0, 0, 255));
                    jCheckBx_aprv_lease.setText("Approve Lease");
                    save_btn.setEnabled(true);
                }

                if (refund_depst_tf.getText() != null) {
                    jCheckBox1.setSelected(true);
                    refund_depst_tf.setEditable(true);
                }
                if (non_refund_dpst_tf.getText() != null) {
                    jCheckBox2.setSelected(true);
                    non_refund_dpst_tf.setEditable(true);
                }

                if (non_refund_dpst_tf.getText().equals("")) {
                    jCheckBox2.setSelected(false);
                    non_refund_dpst_tf.setEditable(false);
                }

                if (refund_depst_tf.getText().equals("")) {
                    jCheckBox1.setSelected(false);
                    refund_depst_tf.setEditable(false);
                }

                lease_id_tf.setBackground(Color.white);
                jLabel21.setForeground(Color.green);
                jLabel21.setText("ok!!");

                contact_id_tf.setBackground(Color.white);
                contact_name_lbl.setText("ok!!");
                contact_name_lbl.setForeground(Color.green);
                jLabel18.setText("");

                //**/
            } catch (Exception e) {
                // System.out.println(e);
                e.printStackTrace();
            }
        }
    }//GEN-LAST:event_lease_tableMousePressed

    private void jtbl_Accounts_MasterMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtbl_Accounts_MasterMousePressed
        // TODO add your handling code here:
        int click = evt.getClickCount();
        if (click == 2) {

            DefaultTableModel tmodel = (DefaultTableModel) jtbl_Accounts_Master.getModel();
            int slctdrow = jtbl_Accounts_Master.getSelectedRow();
            String Must_Budget = tmodel.getValueAt(jtbl_Accounts_Master.convertRowIndexToModel(slctdrow), 8).toString();
            String reconcile_Account = tmodel.getValueAt(jtbl_Accounts_Master.convertRowIndexToModel(slctdrow), 9).toString();
            String Restrict_Posting = tmodel.getValueAt(jtbl_Accounts_Master.convertRowIndexToModel(slctdrow), 10).toString();
            String Restrict_Owner = tmodel.getValueAt(jtbl_Accounts_Master.convertRowIndexToModel(slctdrow), 11).toString();
            String Check_Budget = tmodel.getValueAt(jtbl_Accounts_Master.convertRowIndexToModel(slctdrow), 19).toString();
            String Transaction_Account = tmodel.getValueAt(jtbl_Accounts_Master.convertRowIndexToModel(slctdrow), 14).toString();
            jtxt_Account_Group.setText(tmodel.getValueAt(jtbl_Accounts_Master.convertRowIndexToModel(slctdrow), 0).toString());
            jtxt_Cost_Center.setText(tmodel.getValueAt(jtbl_Accounts_Master.convertRowIndexToModel(slctdrow), 1).toString());
            jtxt_Main_Account.setText(tmodel.getValueAt(jtbl_Accounts_Master.convertRowIndexToModel(slctdrow), 2).toString());
            jtxt_Sub_Account.setText(tmodel.getValueAt(jtbl_Accounts_Master.convertRowIndexToModel(slctdrow), 3).toString());
            jtxt_Account_Status.setText(tmodel.getValueAt(jtbl_Accounts_Master.convertRowIndexToModel(slctdrow), 4).toString());
            jtxt_Account_Description.setText(tmodel.getValueAt(jtbl_Accounts_Master.convertRowIndexToModel(slctdrow), 5).toString());
            jtxt_Main_Category.setText(tmodel.getValueAt(jtbl_Accounts_Master.convertRowIndexToModel(slctdrow), 16).toString());
            jtxt_Sub_Category.setText(tmodel.getValueAt(jtbl_Accounts_Master.convertRowIndexToModel(slctdrow), 6).toString());
            jtxt_subcategory_Type.setText(tmodel.getValueAt(jtbl_Accounts_Master.convertRowIndexToModel(slctdrow), 17).toString());
            jtxt_Contra_Account.setText(tmodel.getValueAt(jtbl_Accounts_Master.convertRowIndexToModel(slctdrow), 7).toString());
            jtxt_AccountFund_Type.setText(tmodel.getValueAt(jtbl_Accounts_Master.convertRowIndexToModel(slctdrow), 18).toString());
            jtxt_Reconcile_Group.setText(tmodel.getValueAt(jtbl_Accounts_Master.convertRowIndexToModel(slctdrow), 12).toString());
            jtxt_Budget_Pattern.setText(tmodel.getValueAt(jtbl_Accounts_Master.convertRowIndexToModel(slctdrow), 13).toString());
            Account_No_tf.setText(tmodel.getValueAt(jtbl_Accounts_Master.convertRowIndexToModel(slctdrow), 15).toString());
            if (Must_Budget.equals("Y")) {
                jchk_Must_Budget.setSelected(true);
            } else {
                jchk_Must_Budget.setSelected(false);
            }
            if (Check_Budget.equals("Y")) {
                jchk_Must_Budget.setSelected(true);
            } else {
                jchk_Check_Budget.setSelected(false);
            }
            if (reconcile_Account.equals("Y")) {
                jchk_Must_Budget.setSelected(true);
            } else {
                jchk_reconcile_Account.setSelected(false);
            }
            if (Restrict_Posting.equals("Y")) {
                jchk_Must_Budget.setSelected(true);
            } else {
                jchk_Restrict_Posting.setSelected(false);
            }
            if (Restrict_Owner.equals("Y")) {
                jchk_Must_Budget.setSelected(true);
            } else {
                jchk_Restrict_Owner.setSelected(false);
            }
            if (Transaction_Account.equals("Y")) {
                jCheckBox4.setSelected(true);
            } else {
                jCheckBox4.setSelected(false);
            }

        }
    }//GEN-LAST:event_jtbl_Accounts_MasterMousePressed

    private void contact_informationMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_contact_informationMousePressed
        // TODO add your handling code here:
        int click = evt.getClickCount();
        if (click == 2) {
            int row = contact_information.getSelectedRow();
            contact_id_no.setText(contact_information.getModel().getValueAt(contact_information.convertRowIndexToModel(row), 0).toString());
            contact_ref2.setText(contact_information.getModel().getValueAt(contact_information.convertRowIndexToModel(row), 1).toString());
            // address1.setText(contact_information.getModel().getValueAt(row, 2).toString());
            // address2.setText(contact_information.getModel().getValueAt(row, 3).toString());
            // address3.setText(contact_information.getModel().getValueAt(row, 4).toString());
            // telephone1.setText(contact_information.getModel().getValueAt(row, 5).toString());
            // telephone2.setText(contact_information.getModel().getValueAt(row, 6).toString());
            // telephone3.setText(contact_information.getModel().getValueAt(row, 7).toString());
            // email1.setText(contact_information.getModel().getValueAt(row, 8).toString());
            // email2.setText(contact_information.getModel().getValueAt(row, 9).toString());
            // email3.setText(contact_information.getModel().getValueAt(row, 10).toString());
            contact_priority.setText(contact_information.getModel().getValueAt(contact_information.convertRowIndexToModel(row), 11).toString());
            first_name.setText(contact_information.getModel().getValueAt(contact_information.convertRowIndexToModel(row), 12).toString());
            last_name.setText(contact_information.getModel().getValueAt(contact_information.convertRowIndexToModel(row), 13).toString());
            relationship.setSelectedItem(contact_information.getModel().getValueAt(contact_information.convertRowIndexToModel(row), 14).toString());
            national_id_no.setText(contact_information.getModel().getValueAt(contact_information.convertRowIndexToModel(row), 15).toString());
            postal_address.setText(contact_information.getModel().getValueAt(contact_information.convertRowIndexToModel(row), 16).toString());
            city_town.setSelectedItem(contact_information.getModel().getValueAt(contact_information.convertRowIndexToModel(row), 17).toString());
            physical_address.setText(contact_information.getModel().getValueAt(contact_information.convertRowIndexToModel(row), 18).toString());
            residential_address.setText(contact_information.getModel().getValueAt(contact_information.convertRowIndexToModel(row), 19).toString());
            telephone4.setText(contact_information.getModel().getValueAt(contact_information.convertRowIndexToModel(row), 20).toString());
            telephone5.setText(contact_information.getModel().getValueAt(contact_information.convertRowIndexToModel(row), 21).toString());
            email4.setText(contact_information.getModel().getValueAt(contact_information.convertRowIndexToModel(row), 22).toString());
            email5.setText(contact_information.getModel().getValueAt(contact_information.convertRowIndexToModel(row), 23).toString());

            //populate from table here;
        }
    }//GEN-LAST:event_contact_informationMousePressed

    private void brws2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_brws2ActionPerformed
        // TODO add your handling code here:
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Choose image");
        fc.setMultiSelectionEnabled(false);
        fc.showOpenDialog(this);
        File f = fc.getSelectedFile();

        try {

            String filename = f.getAbsolutePath();
            pathTf2.setText(filename);

            int width = pic.getWidth();
            int height = pic.getHeight();
            ImageIcon icon = new ImageIcon(filename);
            Image img = icon.getImage();
            pic.setIcon(new ImageIcon(img.getScaledInstance(width, height, Image.SCALE_AREA_AVERAGING)));
        } catch (Exception e) {

            e.printStackTrace();

        }
    }//GEN-LAST:event_brws2ActionPerformed

    private void jCheckBox4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox4ActionPerformed

    private void jlbl_Account_Group13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlbl_Account_Group13MouseClicked
        // TODO add your handling code here:
        CodeListForm_1.getObj().setVisible(true);
    }//GEN-LAST:event_jlbl_Account_Group13MouseClicked

    private void jlbl_Account_Group12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlbl_Account_Group12MouseClicked
        // TODO add your handling code here:
        CodeListForm_1.getObj().setVisible(true);
    }//GEN-LAST:event_jlbl_Account_Group12MouseClicked

    private void supplier_CheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_supplier_CheckBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_supplier_CheckBoxActionPerformed

    private void country_selPopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_country_selPopupMenuWillBecomeInvisible
        // TODO add your handling code here:
        DBConnection.MY_CODE_REFERENCE = "COUNTRIES";
        DBConnection.MY_SUB_CODE = "###";

        try {
            String sql = "SELECT DESCRIPTION from list_control where reference_code = '" + DBConnection.MY_CODE_REFERENCE + "' AND sub_code='" + DBConnection.MY_SUB_CODE + "'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if (rs.next()) {
                if (country_sel.getSelectedItem().equals("KENYA")) {
                    citzn_combo.setSelectedItem("Kenyan");
                } else {
                    String add = rs.getString("description");
                    citzn_combo.setSelectedItem("Non-Kenyan");
                }

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_country_selPopupMenuWillBecomeInvisible

    private void jLabel131MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel131MouseClicked
        // TODO add your handling code here:
        if (contact_type.getSelectedItem().equals("Individual")) {
            jd.setVisible(false);

        } else if (contact_type.getSelectedItem().equals("Company")) {
            DBConnection.dynamic_sql = "select minor_code as code, description as Location from list_contol where reference_code = 'COUNTIES' and sub_code = '###'";
            DBConnection.panel(new TableDetails_Panel2(), "County");
        } else if (contact_type.getSelectedItem().equals("Association")) {
            DBConnection.dynamic_sql = "select minor_code as code, description as Location from list_contol where reference_code = 'COUNTIES' and sub_code = '###'";
            DBConnection.panel(new TableDetails_Panel2(), "County");
        }
    }//GEN-LAST:event_jLabel131MouseClicked

    private void jTabbedPane1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTabbedPane1MousePressed
        // TODO add your handling code here:

    }//GEN-LAST:event_jTabbedPane1MousePressed

    private void contactInfo_panelMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_contactInfo_panelMousePressed
        // TODO add your handling code here:
        update_successful.setText("");
    }//GEN-LAST:event_contactInfo_panelMousePressed

    private void property_typePopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_property_typePopupMenuWillBecomeInvisible
        // TODO add your handling code here:

        DBConnection.MY_CODE_REFERENCE = "PROPERTY TYPES";
        DBConnection.MY_SUB_CODE = "###";

        try {
            String sql = "SELECT DESCRIPTION from list_control where reference_code = '" + DBConnection.MY_CODE_REFERENCE + "' AND sub_code='" + DBConnection.MY_SUB_CODE + "'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if (rs.next()) {
                String add = rs.getString("DESCRIPTION");
                String tmp = (String) property_type.getSelectedItem();

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_property_typePopupMenuWillBecomeInvisible

    private void parent_propertyKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_parent_propertyKeyTyped
        // TODO add your handling code here:
        char keychar = evt.getKeyChar();
        if (Character.isLowerCase(keychar)) {
            evt.setKeyChar(Character.toUpperCase(keychar));
        }
        String temp = "%" + searchrecord_tf.getText() + "%";
        String sql = "select *from properties_table where parent_property like'" + temp + "'";

        DBConnection.update_table(sql, properties_table);
    }//GEN-LAST:event_parent_propertyKeyTyped

    private void bank_branch1PopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_bank_branch1PopupMenuWillBecomeInvisible
        // TODO add your handling code here:

        DBConnection.MY_CODE_REFERENCE = "BANK_BRANCH";
        DBConnection.MY_SUB_CODE = "###";

        try {
            String sql = "SELECT DESCRIPTION from list_control where reference_code = '" + DBConnection.MY_CODE_REFERENCE + "' AND sub_code='" + DBConnection.MY_SUB_CODE + "'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if (rs.next()) {
                String add = rs.getString("DESCRIPTION");
                String tmp = (String) bank_branch1.getSelectedItem();

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_bank_branch1PopupMenuWillBecomeInvisible

    private void countryPopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_countryPopupMenuWillBecomeInvisible
        // TODO add your handling code here:
        DBConnection.MY_CODE_REFERENCE = "COUNTRIES";
        DBConnection.MY_SUB_CODE = "###";

        try {
            String sql = "SELECT DESCRIPTION from list_control where reference_code = '" + DBConnection.MY_CODE_REFERENCE + "' AND sub_code='" + DBConnection.MY_SUB_CODE + "'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if (rs.next()) {
                String add = rs.getString("DESCRIPTION");
                String tmp = (String) country.getSelectedItem();

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_countryPopupMenuWillBecomeInvisible

    private void cityPopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_cityPopupMenuWillBecomeInvisible
        // TODO add your handling code here:
        DBConnection.MY_CODE_REFERENCE = "CITIES";
        DBConnection.MY_SUB_CODE = "###";

        try {
            String sql = "SELECT DESCRIPTION from list_control where reference_code = '" + DBConnection.MY_CODE_REFERENCE + "' AND sub_code='" + DBConnection.MY_SUB_CODE + "'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if (rs.next()) {
                String add = rs.getString("DESCRIPTION");
                String tmp = (String) city.getSelectedItem();

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_cityPopupMenuWillBecomeInvisible

    private void cityPopupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_cityPopupMenuWillBecomeVisible
        // TODO add your handling code here:
    }//GEN-LAST:event_cityPopupMenuWillBecomeVisible

    private void surburbPopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_surburbPopupMenuWillBecomeInvisible
        // TODO add your handling code here:
        DBConnection.MY_CODE_REFERENCE = "SURBURB";
        DBConnection.MY_SUB_CODE = "###";

        try {
            String sql = "SELECT DESCRIPTION from list_control where reference_code = '" + DBConnection.MY_CODE_REFERENCE + "' AND sub_code='" + DBConnection.MY_SUB_CODE + "'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if (rs.next()) {
                String add = rs.getString("DESCRIPTION");
                String tmp = (String) surburb.getSelectedItem();

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_surburbPopupMenuWillBecomeInvisible

    private void zonesPopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_zonesPopupMenuWillBecomeInvisible
        // TODO add your handling code here:
        DBConnection.MY_CODE_REFERENCE = "ZONES";
        DBConnection.MY_SUB_CODE = "###";

        try {
            String sql = "SELECT DESCRIPTION from list_control where reference_code = '" + DBConnection.MY_CODE_REFERENCE + "' AND sub_code='" + DBConnection.MY_SUB_CODE + "'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if (rs.next()) {
                String add = rs.getString("DESCRIPTION");
                String tmp = (String) zones.getSelectedItem();

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_zonesPopupMenuWillBecomeInvisible

    private void jButton1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MousePressed
        // TODO add your handling code here:
        if (property_id.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Property Id field cannot be empty.please select a property from the table below.");
            property_id.setBackground(Color.red);
            property_idlbl.setText("Required");
            property_idlbl.setForeground(Color.red);

        } else {
            JDialog jd = new JDialog(new JFrame(), true);

            jd.setContentPane(new propertyattributes());
            jd.setLocation(200, 200);
            jd.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            jd.pack();
            jd.setVisible(true);
        }
    }//GEN-LAST:event_jButton1MousePressed

    private void pro_id_searchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pro_id_searchMouseClicked
        // TODO add your handling code here:

        DBConnection.dynamic_sql = "SELECT PROPERTY_ID, PROPERTY_DESCRIPTION FROM LEASABLE_PROPERTIES order by property_id";
        auto_pop_panel(property_id_combo, property_id_combo.getText());
        DBConnection.panel(new TableDetails_Panel2(), "Property ID (Lease)");

    }//GEN-LAST:event_pro_id_searchMouseClicked

    private void jCombo_lease_typesPopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_jCombo_lease_typesPopupMenuWillBecomeInvisible
        // TODO add your handling code here:

        DBConnection.MY_CODE_REFERENCE = "LEASE_TYPES";
        DBConnection.MY_SUB_CODE = "###";

        try {
            String sql = "SELECT DESCRIPTION from list_control where reference_code = '" + DBConnection.MY_CODE_REFERENCE + "' AND sub_code='" + DBConnection.MY_SUB_CODE + "'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if (rs.next()) {
                String add = rs.getString("DESCRIPTION");
                String tmp = (String) jCombo_lease_types.getSelectedItem();

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_jCombo_lease_typesPopupMenuWillBecomeInvisible

    private void c_id2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_c_id2MouseClicked
        // TODO add your handling code here:
        if (!property_id_combo.getText().isEmpty()) {
            // DBConnection.dynamic_sql = "select property_id, property_description from properties_table";
            DBConnection.dynamic_sql = "select contact_id, first_names||' '||last_name as NAMES from contacts where contact_id <> (select contact_id from properties_table where property_id = '" + property_id_combo.getText() + "')";
            auto_pop_panel(contact_id_tf, contact_id_tf.getText());
            DBConnection.panel(new TableDetails_Panel2(), "Contact ID (Lease)");

        } else {
            p_id.setText("PROPERTY ID?");
        }


    }//GEN-LAST:event_c_id2MouseClicked

    private void l_idMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_l_idMouseClicked
        // TODO add your handling code here:
        if (!contact_id_tf.getText().isEmpty()) {
            // DBConnection.dynamic_sql = "select property_id, property_description from properties_table";
            DBConnection.dynamic_sql = "SELECT account_number, description FROM account_master order by description";
            auto_pop_panel(lease_acc_tf, lease_acc_tf.getText());
            DBConnection.panel(new TableDetails_Panel2(), "Lease ACC (Lease)");

        } else {
            contact_name_lbl.setText("Contact ID?");
        }


    }//GEN-LAST:event_l_idMouseClicked

    private void company_branch_tfPopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_company_branch_tfPopupMenuWillBecomeInvisible
        // TODO add your handling code here:

        DBConnection.MY_CODE_REFERENCE = "BANK_BRANCH";
        DBConnection.MY_SUB_CODE = "###";

        try {
            String sql = "SELECT DESCRIPTION from list_control where reference_code = '" + DBConnection.MY_CODE_REFERENCE + "' AND sub_code='" + DBConnection.MY_SUB_CODE + "'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if (rs.next()) {
                String add = rs.getString("DESCRIPTION");
                String tmp = (String) company_branch_tf.getSelectedItem();

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_company_branch_tfPopupMenuWillBecomeInvisible

    private void l_idMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_l_idMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_l_idMouseEntered

    private void water_depMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_water_depMouseClicked
        // TODO add your handling code here:
        if (!contact_id_tf.getText().isEmpty()) {
            // DBConnection.dynamic_sql = "select property_id, property_description from properties_table";
            DBConnection.dynamic_sql = "SELECT account_number, description FROM account_master order by description";
            auto_pop_panel(water_depst_acc_tf, water_depst_acc_tf.getText());
            DBConnection.panel(new TableDetails_Panel2(), "Water ACC (Lease)");

        } else {
            contact_name_lbl.setText("Contact ID?");
        }

    }//GEN-LAST:event_water_depMouseClicked

    private void water_depMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_water_depMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_water_depMouseEntered

    private void electricty_depMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_electricty_depMouseClicked
        // TODO add your handling code here:
        if (!contact_id_tf.getText().isEmpty()) {
            // DBConnection.dynamic_sql = "select property_id, property_description from properties_table";
            DBConnection.dynamic_sql = "SELECT account_number, description FROM account_master order by description";
            auto_pop_panel(elect_depst_acc_tf, elect_depst_acc_tf.getText());
            DBConnection.panel(new TableDetails_Panel2(), "Electricity ACC (Lease)");

        } else {
            contact_name_lbl.setText("Contact ID?");
        }
    }//GEN-LAST:event_electricty_depMouseClicked

    private void electricty_depMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_electricty_depMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_electricty_depMouseEntered

    private void security_chargeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_security_chargeMouseClicked
        // TODO add your handling code here:
        if (!contact_id_tf.getText().isEmpty()) {
            // DBConnection.dynamic_sql = "select property_id, property_description from properties_table";
            DBConnection.dynamic_sql = "SELECT account_number, description FROM account_master order by description";
            DBConnection.panel(new TableDetails_Panel2(), "Security ACC (Lease)");

        } else {
            contact_name_lbl.setText("Contact ID?");
        }
    }//GEN-LAST:event_security_chargeMouseClicked

    private void security_chargeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_security_chargeMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_security_chargeMouseEntered

    private void utility_chargeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_utility_chargeMouseClicked
        // TODO add your handling code here:
        if (!contact_id_tf.getText().isEmpty()) {
            // DBConnection.dynamic_sql = "select property_id, property_description from properties_table";
            DBConnection.dynamic_sql = "SELECT account_number, description FROM account_master order by description";
            DBConnection.panel(new TableDetails_Panel2(), "Utility ACC (Lease)");

        } else {
            contact_name_lbl.setText("Contact ID?");
        }
    }//GEN-LAST:event_utility_chargeMouseClicked

    private void utility_chargeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_utility_chargeMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_utility_chargeMouseEntered

    private void salesman_idMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_salesman_idMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_salesman_idMouseEntered

    private void salesman_idMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_salesman_idMouseClicked
        // TODO add your handling code here:
        if (!contact_id_tf.getText().isEmpty()) {
            // DBConnection.dynamic_sql = "select property_id, property_description from properties_table";
            DBConnection.dynamic_sql = "SELECT contact_id, first_names,last_name FROM contacts where (is_agent=1 or is_employee = 1) and contact_id <> '" + contact_id_tf.getText() + "' order by first_names";
            auto_pop_panel(salesman_id_tf, salesman_id_tf.getText());
            DBConnection.panel(new TableDetails_Panel2(), "Salesman (Lease)");

        } else {
            contact_name_lbl.setText("Contact ID?");
        }
    }//GEN-LAST:event_salesman_idMouseClicked

    private void salesman_accMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_salesman_accMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_salesman_accMouseEntered

    private void salesman_accMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_salesman_accMouseClicked
        // TODO add your handling code here:
        if (!contact_id_tf.getText().isEmpty()) {
            // DBConnection.dynamic_sql = "select property_id, property_description from properties_table";
            DBConnection.dynamic_sql = "SELECT account_number, description FROM account_master order by description";
            auto_pop_panel(salesman_acc_tf, salesman_acc_tf.getText());
            DBConnection.panel(new TableDetails_Panel2(), "Salesman ACC (Lease)");

        } else {
            contact_name_lbl.setText("Contact ID?");
        }
    }//GEN-LAST:event_salesman_accMouseClicked

    private void inspectorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_inspectorMouseClicked
        // TODO add your handling code here:
        if (!contact_id_tf.getText().isEmpty()) {
            // DBConnection.dynamic_sql = "select property_id, property_description from properties_table";
            DBConnection.dynamic_sql = "SELECT contact_id, first_names,last_name FROM contacts where  is_employee = 1 order by first_names";
            auto_pop_panel(inspector_tf, inspector_tf.getText());
            DBConnection.panel(new TableDetails_Panel2(), "Inspector (Lease)");

        } else {
            contact_name_lbl.setText("Contact ID?");
        }
    }//GEN-LAST:event_inspectorMouseClicked

    private void inspectorMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_inspectorMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_inspectorMouseEntered

    private void ref_depMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ref_depMouseClicked
        // TODO add your handling code here:
        if (!contact_id_tf.getText().isEmpty()) {
            // DBConnection.dynamic_sql = "select property_id, property_description from properties_table";
            DBConnection.dynamic_sql = "SELECT account_number, description FROM account_master order by description";
            auto_pop_panel(refundable_deposit_account, refundable_deposit_account.getText());
            DBConnection.panel(new TableDetails_Panel2(), "Refundable DEP (Lease)");

        } else {
            contact_name_lbl.setText("Contact ID?");
        }

    }//GEN-LAST:event_ref_depMouseClicked

    private void ref_depMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ref_depMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_ref_depMouseEntered

    private void nonref_depMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nonref_depMouseClicked
        // TODO add your handling code here:
        if (!contact_id_tf.getText().isEmpty()) {
            // DBConnection.dynamic_sql = "select property_id, property_description from properties_table";
            DBConnection.dynamic_sql = "SELECT account_number, description FROM account_master order by description";
            auto_pop_panel(non_refundable_deposit_account, non_refundable_deposit_account.getText());
            DBConnection.panel(new TableDetails_Panel2(), "Non-Refundable DEP (Lease)");

        } else {
            contact_name_lbl.setText("Contact ID?");
        }
    }//GEN-LAST:event_nonref_depMouseClicked

    private void nonref_depMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nonref_depMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_nonref_depMouseEntered

    private void jRadioButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton19ActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_jRadioButton19ActionPerformed

    private void lease_percent2StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_lease_percent2StateChanged
        // TODO add your handling code here:
        DBConnection.percentage_amount(lease_percent2, current_lease_tf, lease_fee_amount);
    }//GEN-LAST:event_lease_percent2StateChanged

    private void jRadioButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton20ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton20ActionPerformed

    private void lease_fee_amountKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_lease_fee_amountKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_lease_fee_amountKeyTyped

    private void contact_ref_noActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contact_ref_noActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_contact_ref_noActionPerformed

    private void jTabbedPane1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTabbedPane1FocusGained
        // TODO add your handling code here:


    }//GEN-LAST:event_jTabbedPane1FocusGained

    private void jTabbedPane1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTabbedPane1MouseClicked
        // TODO add your handling code here:
        if (contactdetails_panel.isShowing()) {
            save_btn.setEnabled(true);
        }
        if (contact_info_pane.isShowing()) {
            save_btn.setEnabled(true);
        }
        if (propertyInfo_panel.isShowing()) {
            save_btn.setEnabled(true);
        }
        if (ChartOfAccount_pane.isShowing()) {
            save_btn.setEnabled(true);
        }
        if (lease_panel.isShowing()) {
            if (aprv_status.equals("Y")) {
                save_btn.setEnabled(false);
            } else {
                save_btn.setEnabled(true);
            }
        }


    }//GEN-LAST:event_jTabbedPane1MouseClicked

    private void jlblownerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblownerMouseClicked
        // TODO add your handling code here:
        if (!property_id.getText().isEmpty()) {
            // DBConnection.dynamic_sql = "select property_id, property_description from properties_table";
            DBConnection.dynamic_sql = "SELECT minor_code, description from list_control where reference_code = 'PROPERTY_OWNER' and sub_code = '###'";
            DBConnection.panel(new TableDetails_Panel(), "Property Owner(Property)");

        } else {
            property_idlbl.setText("Property ID?");
        }
    }//GEN-LAST:event_jlblownerMouseClicked

    private void jlblsearch_parentMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblsearch_parentMouseClicked
        // TODO add your handling code here:
        if (!property_id.getText().isEmpty()) {
            // DBConnection.dynamic_sql = "select property_id, property_description from properties_table";
            DBConnection.dynamic_sql = "SELECT property_id, property_description from properties_table";
            DBConnection.panel(new TableDetails_Panel(), "Property ID (Properties)");

        } else {
            property_idlbl.setText("Property ID?");
        }
    }//GEN-LAST:event_jlblsearch_parentMouseClicked

    private void lease_panelFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_lease_panelFocusLost
        // TODO add your handling code here:
        jLabel18.setText("");
    }//GEN-LAST:event_lease_panelFocusLost

    private void lease_id_tfKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_lease_id_tfKeyTyped
        // TODO add your handling code here:

        lease_id_tf.setBackground(Color.white);
        jLabel21.setForeground(Color.green);
        jLabel21.setText("ok!!");

        jLabel18.setText("");
    }//GEN-LAST:event_lease_id_tfKeyTyped

    private void property_id_comboKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_property_id_comboKeyTyped
        // TODO add your handling code here:


    }//GEN-LAST:event_property_id_comboKeyTyped

    private void contact_id_tfKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_contact_id_tfKeyTyped
        // TODO add your handling code here:


    }//GEN-LAST:event_contact_id_tfKeyTyped

    private void l_id1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_l_id1MouseClicked
        // TODO add your handling code here:
        if (!contact_id_tf.getText().isEmpty()) {
            // DBConnection.dynamic_sql = "select property_id, property_description from properties_table";
            DBConnection.dynamic_sql = "SELECT minor_code, description from list_control where reference_code = 'TAX_CODE' and sub_code = '###'";
            auto_pop_panel(tax_code, tax_code.getText());
            DBConnection.panel(new TableDetails_Panel(), "Tax Code (Lease)");

        } else {
            contact_name_lbl.setText("Contact ID?");
        }
    }//GEN-LAST:event_l_id1MouseClicked

    private void l_id1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_l_id1MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_l_id1MouseEntered

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        autogenerate_lease_id();
        property_id_combo.setText("");
        jRadioButton_active.setSelected(true);
        contact_id_tf.setText("");
        //lease_acc_tf.setText("");
        //tax_code.setText("");
        current_lease_tf.setText("");
        jCheckBox3.setSelected(false);

        datePicker5.getJFormattedTextField().setText("");
        datePicker6.getJFormattedTextField().setText("");
        datePicker7.getJFormattedTextField().setText("");
        datePicker8.getJFormattedTextField().setText("");
        datePicker9.getJFormattedTextField().setText("");
        lease_fee_amount.setText("0");
        refund_depst_tf.setText("0");
        non_refund_dpst_tf.setText("0");
        water_depst_tf.setText("0");
        elect_depst_tf.setText("0");
        security_charges_tf.setText("0");
        utility_charges_tf.setText("0");
        penaltyAmnt_TF.setText("0");
        salesAmnt_TF.setText("0");


    }//GEN-LAST:event_jButton2ActionPerformed

    private void fund_unit_iconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_fund_unit_iconMouseClicked
        // TODO add your handling code here:
        DBConnection.dynamic_sql = "select minor_code, description from list_control where reference_code = 'COST_CENTER' and sub_code = '###'";
        DBConnection.panel(new TableDetails_Panel(), "Fund Unit");

    }//GEN-LAST:event_fund_unit_iconMouseClicked

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tmodel = (DefaultTableModel) property_attributes.getModel();
        property_id.setBackground(Color.yellow);
        property_id.setText("0");
        property_quantity.setText("");
        property_category.setText("");
        owner.setText(contact_id_no.getText());
        tmodel.setRowCount(0);
        property_value.setText("");
        purchase_price.setText("");
        parent_property.setText(selectedValue);
        sale_value.setText("");
        asking_value.setText("");
        bank_acc.setText("");
        property_description.setText("");
        gprs.setText("");
    }//GEN-LAST:event_jButton9ActionPerformed

    private void fund_unit_iconMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_fund_unit_iconMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_fund_unit_iconMouseEntered

    private void jlblowner1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblowner1MouseClicked
        // TODO add your handling code here:
        if (!property_id.getText().isEmpty()) {
            // DBConnection.dynamic_sql = "select property_id, property_description from properties_table";
            DBConnection.dynamic_sql = "SELECT minor_code, description from list_control where reference_code = 'TAX_CODE' and sub_code = '###'";
            DBConnection.panel(new TableDetails_Panel(), "Tax Code (Property)");

        } else {
            property_idlbl.setText("Property ID?");
        }
    }//GEN-LAST:event_jlblowner1MouseClicked

    private void jCheckBx_aprv_leaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBx_aprv_leaseActionPerformed
        // TODO add your handling code here:current_lease_tf

        String aupdate_sql;
        if (!(lease_id_tf.getText().equals("") && contact_id_tf.getText().equals("") && property_id_combo.getText().equals("") && current_lease_tf.getText().equals(""))) {

            String approve = approveAction(jCheckBx_aprv_lease, "Approve lease?");
            if (approve.equals("Y")) {
                //automatic posting into recurrents
                into_recurrents();

                aupdate_sql = "update lease set APPROVED = '" + approve + "' where lease_id = '" + lease_id_tf.getText() + "' and contact_id = '" + contact_id_tf.getText() + "' and property_id = '" + property_id_combo.getText() + "'";

                DBConnection.regular_sql_executor(aupdate_sql, null, "Lease Approved");
                update_lease_table();
            }
        } else {
            jCheckBx_aprv_lease.setSelected(false);
            JOptionPane.showMessageDialog(null, "<html><font color = blue>Error approving!</font><br>make sure <i>lease, contact, property</i> and<br><i>current lease amout</i> fields are filled", "", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jCheckBx_aprv_leaseActionPerformed

    private void properties_tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_properties_tableMouseClicked
        // TODO add your handling code here:
        int click = evt.getClickCount();
        if (click == 1) {
            properties_table_selected();
            owner.setBackground(Color.GREEN);
            property_idlbl.setText("OK!");
            property_idlbl.setForeground(Color.GREEN);
            Update_Property_attributes_table();
            show_image();
        }
    }//GEN-LAST:event_properties_tableMouseClicked

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        into_recurrents();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void agent_CheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agent_CheckBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_agent_CheckBoxActionPerformed

    private void refund_depst_tfFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_refund_depst_tfFocusLost
        // TODO add your handling code here:
        set_to_zero(refund_depst_tf);
    }//GEN-LAST:event_refund_depst_tfFocusLost

    private void non_refund_dpst_tfFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_non_refund_dpst_tfFocusLost
        // TODO add your handling code here:
        set_to_zero(non_refund_dpst_tf);
    }//GEN-LAST:event_non_refund_dpst_tfFocusLost

    private void water_depst_tfFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_water_depst_tfFocusLost
        // TODO add your handling code here:
        set_to_zero(water_depst_tf);
    }//GEN-LAST:event_water_depst_tfFocusLost

    private void elect_depst_tfFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_elect_depst_tfFocusLost
        // TODO add your handling code here:
        set_to_zero(elect_depst_tf);
    }//GEN-LAST:event_elect_depst_tfFocusLost

    private void security_charges_tfFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_security_charges_tfFocusLost
        // TODO add your handling code here:
        set_to_zero(security_charges_tf);
    }//GEN-LAST:event_security_charges_tfFocusLost

    private void utility_charges_tfFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_utility_charges_tfFocusLost
        // TODO add your handling code here:
        set_to_zero(utility_charges_tf);
    }//GEN-LAST:event_utility_charges_tfFocusLost

    private void lease_fee_srchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lease_fee_srchMouseClicked
        // TODO add your handling code here:
        if (!lease_fee_amount.getText().equals("0")) {
            // DBConnection.dynamic_sql = "select property_id, property_description from properties_table";
            DBConnection.dynamic_sql = "SELECT account_number, description FROM account_master order by description";
            auto_pop_panel(lease_fee_accnt_tf, lease_fee_accnt_tf.getText());
            DBConnection.panel(new TableDetails_Panel2(), "Lease Fee ACC (Lease)");

        } else {
            contact_name_lbl.setText("Contact ID?");
        }
    }//GEN-LAST:event_lease_fee_srchMouseClicked

    private void lease_fee_srchMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lease_fee_srchMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_lease_fee_srchMouseEntered

    private void reportsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reportsActionPerformed
        // TODO add your handling code here:
      
        searchReports.main(null);
       
    }//GEN-LAST:event_reportsActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
        }


        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Dynamic1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Account_No_tf;
    public static javax.swing.JPanel ChartOfAccount_pane;
    public static javax.swing.JLabel TAX_LBL;
    private javax.swing.JLabel acc_fund_type;
    private javax.swing.JLabel account_status;
    private javax.swing.JCheckBox agent_CheckBox;
    private javax.swing.JTextField asking_value;
    private javax.swing.JTextField bank_acc;
    private javax.swing.JTextField bank_acc_no;
    public static javax.swing.JComboBox<String> bank_branch;
    public static javax.swing.JComboBox<String> bank_branch1;
    private javax.swing.JTextField bank_name;
    public static javax.swing.JComboBox bank_name1;
    public static javax.swing.JComboBox bank_name2;
    private javax.swing.JButton brws2;
    private javax.swing.JButton brwsBtn;
    private javax.swing.JLabel budget_pattern;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.ButtonGroup buttonGroup4;
    private javax.swing.ButtonGroup buttonGroup_commission;
    private javax.swing.ButtonGroup buttonGroup_lease_fee;
    private javax.swing.ButtonGroup buttonGroup_lease_status;
    private javax.swing.ButtonGroup buttonGroup_penalty;
    private javax.swing.JCheckBox buyer_CheckBox;
    public static javax.swing.JLabel c_id2;
    public static javax.swing.JComboBox city;
    private javax.swing.JComboBox<String> city_town;
    public static javax.swing.JComboBox citzn_combo;
    private javax.swing.JTextField company_branch;
    public static javax.swing.JComboBox<String> company_branch_tf;
    private javax.swing.JTextField company_name;
    private javax.swing.JPanel contactInfo_panel;
    public static javax.swing.JTable contact_details;
    public static javax.swing.JTextField contact_id_no;
    public static javax.swing.JTextField contact_id_tf;
    private javax.swing.JPanel contact_info_pane;
    private javax.swing.JTable contact_information;
    public static javax.swing.JLabel contact_name_lbl;
    private javax.swing.JTextField contact_priority;
    private javax.swing.JTextField contact_ref2;
    private javax.swing.JTextField contact_ref_no;
    private javax.swing.JComboBox contact_type;
    public static javax.swing.JPanel contactdetails_panel;
    private javax.swing.JLabel contra_acc;
    public static javax.swing.JLabel contra_acc_lbl;
    private javax.swing.JButton costs;
    public static javax.swing.JComboBox country;
    public static javax.swing.JComboBox country_sel;
    public static javax.swing.JTextField county;
    public static javax.swing.JTextField current_city;
    private static javax.swing.JTextField current_lease_tf;
    public static javax.swing.JPanel dp;
    public static javax.swing.JPanel dp1;
    public static javax.swing.JPanel dp2;
    public static javax.swing.JPanel dp3;
    public static javax.swing.JPanel dp4;
    public static javax.swing.JPanel dp5;
    public static javax.swing.JPanel dp6;
    public static javax.swing.JPanel dp7;
    public static javax.swing.JPanel dp8;
    public static javax.swing.JPanel dp9;
    public static javax.swing.JTextField elect_depst_acc_tf;
    private static javax.swing.JTextField elect_depst_tf;
    public static javax.swing.JLabel electricty_dep;
    private javax.swing.JTextField email4;
    private javax.swing.JTextField email5;
    private javax.swing.JCheckBox employee_CheckBox;
    private javax.swing.JButton export_to_excel;
    private javax.swing.JTextField first_name;
    private javax.swing.JTextField fname_TF;
    public static javax.swing.JLabel fund_unit_icon;
    private javax.swing.JComboBox gender;
    private javax.swing.JTextField gprs;
    public static javax.swing.JTextField id_TF;
    private javax.swing.JButton import_from_excel;
    public static javax.swing.JLabel inspector;
    public static javax.swing.JTextField inspector_id;
    public static javax.swing.JTextField inspector_tf;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton9;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JCheckBox jCheckBox4;
    private javax.swing.JCheckBox jCheckBx_aprv_lease;
    private javax.swing.JCheckBox jCheck_pen_status;
    private javax.swing.JComboBox jCombo_insp_freq;
    public static javax.swing.JComboBox jCombo_lease_types;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel100;
    private javax.swing.JLabel jLabel101;
    private javax.swing.JLabel jLabel102;
    private javax.swing.JLabel jLabel103;
    public static javax.swing.JLabel jLabel104;
    private javax.swing.JLabel jLabel105;
    private javax.swing.JLabel jLabel106;
    public static javax.swing.JLabel jLabel107;
    private javax.swing.JLabel jLabel108;
    private javax.swing.JLabel jLabel109;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel110;
    private javax.swing.JLabel jLabel111;
    private javax.swing.JLabel jLabel112;
    private javax.swing.JLabel jLabel113;
    private javax.swing.JLabel jLabel114;
    private javax.swing.JLabel jLabel115;
    private javax.swing.JLabel jLabel116;
    private javax.swing.JLabel jLabel117;
    private javax.swing.JLabel jLabel118;
    private javax.swing.JLabel jLabel119;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel120;
    private javax.swing.JLabel jLabel121;
    private javax.swing.JLabel jLabel122;
    private javax.swing.JLabel jLabel123;
    private javax.swing.JLabel jLabel124;
    private javax.swing.JLabel jLabel125;
    private javax.swing.JLabel jLabel126;
    private javax.swing.JLabel jLabel127;
    private javax.swing.JLabel jLabel128;
    private javax.swing.JLabel jLabel129;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel130;
    public static javax.swing.JLabel jLabel131;
    private javax.swing.JLabel jLabel132;
    private javax.swing.JLabel jLabel133;
    private javax.swing.JLabel jLabel134;
    private javax.swing.JLabel jLabel135;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    public static javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    public static javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    public static javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JLabel jLabel96;
    private javax.swing.JLabel jLabel97;
    private javax.swing.JLabel jLabel98;
    private javax.swing.JLabel jLabel99;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JRadioButton jRadioButton15;
    private javax.swing.JRadioButton jRadioButton16;
    private javax.swing.JRadioButton jRadioButton17;
    private javax.swing.JRadioButton jRadioButton18;
    private javax.swing.JRadioButton jRadioButton19;
    private javax.swing.JRadioButton jRadioButton20;
    private javax.swing.JRadioButton jRadioButton_active;
    private javax.swing.JRadioButton jRadioButton_closed;
    private javax.swing.JRadioButton jRadioButton_onhold;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator10;
    private javax.swing.JSeparator jSeparator14;
    private javax.swing.JSeparator jSeparator15;
    private javax.swing.JSeparator jSeparator16;
    private javax.swing.JSeparator jSeparator17;
    private javax.swing.JSeparator jSeparator18;
    private javax.swing.JToolBar.Separator jSeparator19;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JToolBar.Separator jSeparator20;
    private javax.swing.JToolBar.Separator jSeparator21;
    private javax.swing.JSeparator jSeparator22;
    private javax.swing.JSeparator jSeparator23;
    private javax.swing.JSeparator jSeparator24;
    private javax.swing.JSeparator jSeparator26;
    private javax.swing.JSeparator jSeparator27;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JSeparator jSeparator9;
    private javax.swing.JSpinner jSpinner_insp_prd;
    private javax.swing.JSpinner jSpinner_lease_prd;
    private javax.swing.JSpinner jSpinner_penalty_percent;
    private javax.swing.JSpinner jSpinner_salecommission;
    private static javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField jTextField38;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JToolBar jToolBar2;
    private javax.swing.JToolBar jToolBar3;
    public static javax.swing.JLabel jbl_account_code;
    private javax.swing.JCheckBox jchk_Check_Budget;
    private javax.swing.JCheckBox jchk_Must_Budget;
    private javax.swing.JCheckBox jchk_Restrict_Owner;
    private javax.swing.JCheckBox jchk_Restrict_Posting;
    private javax.swing.JCheckBox jchk_reconcile_Account;
    private javax.swing.JLabel jlbl_AccountFund_Type;
    private javax.swing.JLabel jlbl_Account_Group;
    private javax.swing.JLabel jlbl_Account_Group12;
    private javax.swing.JLabel jlbl_Account_Group13;
    private javax.swing.JLabel jlbl_Account_Status;
    private javax.swing.JLabel jlbl_Budget_Pattern;
    private javax.swing.JLabel jlbl_Contra_Account;
    private javax.swing.JLabel jlbl_Main_Account;
    private javax.swing.JLabel jlbl_Reconcile_Group;
    private javax.swing.JLabel jlbl_Sub_Account;
    private javax.swing.JLabel jlbl_Sub_Category;
    private javax.swing.JLabel jlbl_Sub_Category_Edit;
    private javax.swing.JLabel jlbl_Subcategory_Type;
    private javax.swing.JLabel jlblowner;
    private javax.swing.JLabel jlblowner1;
    private javax.swing.JLabel jlblsearch_parent;
    public static javax.swing.JTable jtbl_Accounts_Master;
    public static javax.swing.JTextField jtxt_AccountFund_Type;
    private javax.swing.JTextField jtxt_Account_Description;
    public static javax.swing.JTextField jtxt_Account_Group;
    public static javax.swing.JTextField jtxt_Account_Status;
    public static javax.swing.JTextField jtxt_Budget_Pattern;
    public static javax.swing.JTextField jtxt_Contra_Account;
    public static javax.swing.JTextField jtxt_Cost_Center;
    public static javax.swing.JTextField jtxt_Main_Account;
    public static javax.swing.JTextField jtxt_Main_Category;
    public static javax.swing.JTextField jtxt_Reconcile_Group;
    public static javax.swing.JTextField jtxt_Sub_Account;
    public static javax.swing.JTextField jtxt_Sub_Category;
    public static javax.swing.JTextField jtxt_subcategory_Type;
    public static javax.swing.JLabel l_id;
    public static javax.swing.JLabel l_id1;
    private javax.swing.JCheckBox landlord_CheckBox;
    private javax.swing.JTextField last_name;
    public static javax.swing.JLabel lease_acc_desc;
    public static javax.swing.JTextField lease_acc_tf;
    public static javax.swing.JTextField lease_fee_accnt_tf;
    private javax.swing.JTextField lease_fee_amount;
    public static javax.swing.JLabel lease_fee_srch;
    private javax.swing.JComboBox lease_frequency_combo;
    public static javax.swing.JTextField lease_id_tf;
    public static javax.swing.JPanel lease_panel;
    private javax.swing.JSpinner lease_percent2;
    public static javax.swing.JTable lease_table;
    private javax.swing.JTextField lname_TF;
    public static javax.swing.JTextField location;
    public static javax.swing.JLabel main_acc_code;
    private javax.swing.JLabel main_category;
    private javax.swing.JButton more_charges_btn;
    private javax.swing.JLabel msg_lbl;
    private javax.swing.JTextField national_id_no;
    private static javax.swing.JTextField non_refund_dpst_tf;
    public static javax.swing.JTextField non_refundable_deposit_account;
    public static javax.swing.JLabel nonref_dep;
    private javax.swing.JTextField occupation;
    public static javax.swing.JComboBox occupation2;
    private javax.swing.JButton other_depst_btn;
    public static javax.swing.JTextField owner;
    public static javax.swing.JLabel p_id;
    public static javax.swing.JTextField parent_property;
    public static javax.swing.JTextField pathTF;
    private javax.swing.JTextField pathTf2;
    private static javax.swing.JTextField penaltyAmnt_TF;
    private javax.swing.JTextField physical_address;
    public static javax.swing.JLabel pic;
    public static javax.swing.JTextField pin_TF;
    private javax.swing.JTextField postal_address;
    public static javax.swing.JLabel pro_id_search;
    private javax.swing.JTable properties_table;
    public static javax.swing.JPanel propertyInfo_panel;
    public static javax.swing.JTable property_attributes;
    public static javax.swing.JTextField property_category;
    private javax.swing.JTextArea property_description;
    public static javax.swing.JTextField property_id;
    public static javax.swing.JTextField property_id_combo;
    private javax.swing.JLabel property_idlbl;
    private javax.swing.JTextField property_quantity;
    private javax.swing.JComboBox property_status;
    public static javax.swing.JComboBox property_type;
    private javax.swing.JTextField property_value;
    private javax.swing.JTextField purchase_price;
    private javax.swing.JLabel reconcile_group;
    public static javax.swing.JLabel ref_dep;
    private javax.swing.JButton refresh_btn;
    private static javax.swing.JTextField refund_depst_tf;
    public static javax.swing.JTextField refundable_deposit_account;
    private javax.swing.JComboBox<String> relationship;
    private javax.swing.JButton reports;
    private javax.swing.JTextField residential_address;
    private javax.swing.JTextField sale_value;
    private javax.swing.JTextField salesAmnt_TF;
    public static javax.swing.JLabel salesman_acc;
    public static javax.swing.JTextField salesman_acc_tf;
    public static javax.swing.JLabel salesman_id;
    public static javax.swing.JTextField salesman_id_tf;
    public static javax.swing.JLabel salesman_name;
    private javax.swing.JButton save_btn;
    private javax.swing.JTextField searchrecord_tf;
    public static javax.swing.JLabel security_charge;
    private static javax.swing.JTextField security_charges_tf;
    public static javax.swing.JTextField securitycharges_acc;
    public static javax.swing.JTextField show_path;
    private javax.swing.JTextField source_of_income;
    private javax.swing.JComboBox status;
    private javax.swing.JLabel sub_acc_code;
    private javax.swing.JLabel sub_categ_type;
    private javax.swing.JLabel sub_category;
    private javax.swing.JCheckBox supplier_CheckBox;
    public static javax.swing.JComboBox surburb;
    public static javax.swing.JTextField tax_code;
    public static javax.swing.JTextField tax_code1;
    public static javax.swing.JLabel tax_desc;
    private javax.swing.JTextField telephone4;
    private javax.swing.JTextField telephone5;
    private javax.swing.JCheckBox tenant_CheckBox;
    private javax.swing.JLabel update_successful;
    public static javax.swing.JLabel userImage;
    public static javax.swing.JLabel utility_charge;
    public static javax.swing.JTextField utility_charges_acc;
    private static javax.swing.JTextField utility_charges_tf;
    public static javax.swing.JLabel water_dep;
    public static javax.swing.JTextField water_depst_acc_tf;
    private static javax.swing.JTextField water_depst_tf;
    private javax.swing.JTextField website;
    public static javax.swing.JComboBox zones;
    // End of variables declaration//GEN-END:variables

    public static void update_lease_table() {

        String select_query = "select LEASE_ID,"
                + "PROPERTY_ID,"
                + "CONTACT_ID,"
                + "LEASE_STATUS,"
                + "LEASE_TYPES,"
                + "START_LEASE_DATE,"
                + "END_LEASE_DATE,"
                + "LEASE_ACCOUNT,"
                + "LEASE_PREPAYMENT,"
                + "REFUNDABLE_DEPOSIT,"
                + "LEASE_FEE,"
                + "WATER_DEPOSIT,"
                + "ELECTRICITY_DEPOSIT,"
                + "SALESMAN_ID,"
                + "SALESMAN_NAME,"
                + "SALESMAN_AMOUNT,"
                + "SALESMAN_PERCENT,"
                + "SALESMAN_ACCOUNT,"
                + "INSPECTION_FREQUENCY,"
                + "INSPECTION_PERIOD,"
                + "LEASE_DUE_DATE,"
                + "NEXT_LEASEPERIOD_START_DATE,"
                + "LEASE_CHANGE_DATE,"
                + "LEASE_REVIEW_DATE,"
                + "SECURITY_CHARGES,"
                + "UTILITY_CHARGES,"
                + "UTILITY_CHARGES_ACCOUNT,"
                + "PENALTY_AMOUNT,"
                + "PENALTY_PERCENT,"
                + "PENALTY_DATE,"
                + "PENALTY_STATUS,"
                + "CURRENT_LEASE,"
                + "INSPECTOR_ID,"
                + "LEASE_PAYMENT_FREQUENCY,"
                + "LEASE_PAYMENT_PERIOD,"
                + "SECURITY_CHARGES_ACCOUNT,"
                + "WATER_DEPOSIT_ACCOUNT,"
                + "ELECTRICITY_DEPOSIT_ACCOUNT,"
                + "NON_REFUNDABLE_DEPOSIT,"
                + "NON_REFUNDABLE_ACCOUNT,"
                + "REFUNDABLE_DEPOSIT_ACCOUNT,"
                + "approved,"
                + "lease_fee_account"
                + " from lease table";

        DBConnection.update_table(select_query, lease_table);
    }

    public void add_lease() {
        if (lease_id_tf.getText().equals("")) {
            lease_id_tf.setBackground(Color.red);
            jLabel21.setForeground(Color.red);
            jLabel21.setText("Required!!");
            jLabel18.setText("");

        }

        if (property_id_combo.getText().equals("")) {
            property_id_combo.setBackground(Color.red);
            p_id.setForeground(Color.red);
            p_id.setText("Required!!");
            jLabel18.setText("");

        }

        if (contact_id_tf.getText().equals("")) {
            contact_id_tf.setBackground(Color.red);
            contact_name_lbl.setText("Required!!");
            contact_name_lbl.setForeground(Color.red);
            jLabel18.setText("");
        }

        if (lease_id_tf.getText().equals("") && property_id_combo.getText().equals("") && contact_id_tf.getText().equals("")) {
            lease_id_tf.setBackground(Color.red);
            jLabel21.setForeground(Color.red);
            jLabel21.setText("Required!!");

            property_id_combo.setBackground(Color.red);
            p_id.setForeground(Color.red);
            p_id.setText("Required!!");

            contact_id_tf.setBackground(Color.red);
            contact_name_lbl.setText("Required!!");
            contact_name_lbl.setForeground(Color.red);
            jLabel18.setText("");
        }

        String insert_query = "insert into lease ("
                + "PROPERTY_ID,"
                + "CONTACT_ID,"
                + "LEASE_STATUS,"
                + "LEASE_TYPES,"
                + "START_LEASE_DATE,"
                + "END_LEASE_DATE,"
                + "LEASE_ACCOUNT,"
                + "LEASE_PREPAYMENT,"
                + "REFUNDABLE_DEPOSIT,"
                + "LEASE_FEE,"
                + "WATER_DEPOSIT,"
                + "ELECTRICITY_DEPOSIT,"
                + "SALESMAN_ID,"
                + "SALESMAN_NAME,"
                + "SALESMAN_AMOUNT,"
                + "SALESMAN_PERCENT,"
                + "SALESMAN_ACCOUNT,"
                + "INSPECTION_FREQUENCY,"
                + "INSPECTION_PERIOD,"
                + "LEASE_DUE_DATE,"
                + "NEXT_LEASEPERIOD_START_DATE,"
                + "LEASE_CHANGE_DATE,"
                + "LEASE_REVIEW_DATE,"
                + "SECURITY_CHARGES,"
                + "UTILITY_CHARGES,"
                + "UTILITY_CHARGES_ACCOUNT,"
                + "PENALTY_AMOUNT,"
                + "PENALTY_PERCENT,"
                + "PENALTY_DATE,"
                + "PENALTY_STATUS,"
                + "CURRENT_LEASE,"
                + "INSPECTOR_ID,"
                + "LEASE_PAYMENT_FREQUENCY,"
                + "LEASE_PAYMENT_PERIOD,"
                + "SECURITY_CHARGES_ACCOUNT,"
                + "WATER_DEPOSIT_ACCOUNT,"
                + "ELECTRICITY_DEPOSIT_ACCOUNT,"
                + "NON_REFUNDABLE_DEPOSIT,"
                + "NON_REFUNDABLE_ACCOUNT,"
                + "LEASE_FEE_ACCOUNT,"
                + "REFUNDABLE_DEPOSIT_ACCOUNT)"
                + "values(" + property_id_combo.getText() + ","
                + "" + contact_id_tf.getText() + ","
                + "'" + selectedValue + "',"
                + "'" + jCombo_lease_types.getSelectedItem() + "',"
                + "'" + datePicker4.getJFormattedTextField().getText() + "',"
                + "'" + datePicker6.getJFormattedTextField().getText() + "',"
                + "'" + lease_acc_tf.getText() + "',"
                + "'" + non_refund_dpst_tf.getText() + "',"
                + "" + refund_depst_tf.getText() + ","
                + "" + lease_fee_amount.getText() + ","
                + "" + water_depst_tf.getText() + ","
                + "" + elect_depst_tf.getText() + ","
                + "'" + salesman_id_tf.getText() + "',"
                + "'" + salesman_name.getText() + "',"
                + "'" + salesAmnt_TF.getText() + "',"
                + "" + jSpinner_salecommission.getValue() + ","
                + "'" + salesman_acc_tf.getText() + "',"
                + "" + jSpinner_insp_prd.getValue() + ","
                + "'" + jCombo_insp_freq.getSelectedItem() + "',"
                + "'" + datePicker5.getJFormattedTextField().getText() + "',"
                + "'" + datePicker8.getJFormattedTextField().getText() + "',"
                + "'" + datePicker7.getJFormattedTextField().getText() + "',"
                + "'" + datePicker9.getJFormattedTextField().getText() + "',"
                + "" + security_charges_tf.getText() + ","
                + "" + utility_charges_tf.getText() + ","
                + "'" + utility_charges_acc.getText() + "',"
                + "" + penaltyAmnt_TF.getText() + ","
                + "" + jSpinner_penalty_percent.getValue() + ","
                + "'" + datePicker9.getJFormattedTextField().getText() + "',"
                + "'" + jCheck_pen_status.getText() + "',"
                + "" + current_lease_tf.getText() + ","
                + "'" + inspector_id.getText() + "',"
                + "" + jSpinner_lease_prd.getValue() + ","
                + "'" + lease_frequency_combo.getSelectedItem() + "',"
                + "'" + securitycharges_acc.getText() + "',"
                + "'" + water_depst_acc_tf.getText() + "',"
                + "'" + elect_depst_acc_tf.getText() + "',"
                + "" + non_refund_dpst_tf.getText() + ","
                + "'" + non_refundable_deposit_account.getText() + "',"
                + "'" + lease_fee_accnt_tf.getText() + "',"
                + "'" + refundable_deposit_account.getText() + "')";

        //DBConnection.check_if_exist("select property_id from lease where property_id = ? and lease_status != 'CLS'", property_id, insert_query, jLabel18);
        try {
            System.out.println(insert_query);
            conn = DBConnection.ConnectDB();
            pst = conn.prepareStatement(insert_query);
            pst.execute();
            Insert_Timestamp();
            jLabel18.setForeground(Color.BLUE);
            jLabel18.setText("Contact id:" + contact_id_tf.getText() + "'s lease record id:" + lease_id_tf.getText() + " saved successfully!!");

            update_lease_table();

        } catch (HeadlessException | SQLException e) {
            e.printStackTrace();
            jLabel18.setForeground(Color.red);
            jLabel18.setText("Record already exists!!");
        }

        try {
            FileOutputStream fileOut
                    = new FileOutputStream("lease_id_no.ser");
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(lease_id_tf.getText());
            out.close();
            fileOut.close();
            //JOptionPane.showMessageDialog(null,"serialized data is saved in receiptno.ser");
        } catch (IOException k) {
            k.printStackTrace();
        }

        autogenerate_lease_id();
        update_lease_table();

    }

    public void update_lease() {

        String update_query = "update lease set property_id=" + property_id_combo.getText() + ","
                + "contact_id=" + contact_id_tf.getText() + ","
                + "lease_status='" + selectedValue + "',"
                + "lease_types='" + jCombo_lease_types.getSelectedItem() + "',"
                + "start_lease_date='" + datePicker4.getJFormattedTextField().getText() + "',"
                + "end_lease_date='" + datePicker6.getJFormattedTextField().getText() + "',"
                + "lease_account='" + lease_acc_tf.getText() + "',"
                + "lease_prepayment='" + non_refund_dpst_tf.getText() + "',"
                + "refundable_deposit=" + refund_depst_tf.getText() + ","
                + "lease_fee=" + lease_fee_amount.getText() + ","
                + "water_deposit=" + water_depst_tf.getText() + ","
                + "electricity_deposit='" + elect_depst_tf.getText() + "',"
                + "lease_fee_account = '" + lease_fee_accnt_tf.getText() + "',"
                + "salesman_id='" + salesman_id_tf.getText() + "',"
                + "salesman_name='" + salesman_name.getText() + "',"
                + "salesman_amount='" + salesAmnt_TF.getText() + "',"
                + "salesman_percent='" + jSpinner_salecommission.getValue() + "',"
                + "salesman_account='" + salesman_acc_tf.getText() + "',"
                + "inspection_frequency=" + jSpinner_insp_prd.getValue() + ","
                + "inspection_period='" + jCombo_insp_freq.getSelectedItem() + "',"
                + "lease_due_date='" + datePicker5.getJFormattedTextField().getText() + "',"
                + "next_leaseperiod_start_date='" + datePicker8.getJFormattedTextField().getText() + "',"
                + "lease_change_date='" + datePicker7.getJFormattedTextField().getText() + "',"
                + "lease_review_date='" + datePicker9.getJFormattedTextField().getText() + "',"
                + "security_charges='" + security_charges_tf.getText() + "',"
                + "utility_charges='" + utility_charges_tf.getText() + "',"
                + "utility_charges_account='" + utility_charges_acc.getText() + "',"
                + "penalty_amount='" + penaltyAmnt_TF.getText() + "',"
                + "penalty_percent=" + jSpinner_penalty_percent.getValue() + ","
                + "penalty_date='" + datePicker10.getJFormattedTextField().getText() + "',"
                + "penalty_status='" + jCheck_pen_status.getText() + "',"
                + "current_lease='" + current_lease_tf.getText() + "',"
                + "inspector_id='" + inspector_id.getText() + "',"
                + "lease_payment_frequency='" + jSpinner_lease_prd.getValue() + "',"
                + "lease_payment_period='" + lease_frequency_combo.getSelectedItem() + "',"
                + "security_charges_account='" + securitycharges_acc.getText() + "',"
                + "water_deposit_account='" + water_depst_acc_tf.getText() + "',"
                + "electricity_deposit_account='" + elect_depst_acc_tf.getText() + "',"
                + "non_refundable_deposit=" + non_refund_dpst_tf.getText() + ","
                + "non_refundable_account='" + non_refundable_deposit_account.getText() + "',"
                + "refundable_deposit_account='" + refundable_deposit_account.getText() + "' "
                + "where lease_id=" + lease_id_tf.getText() + "";
        try {
            //JOptionPane.showMessageDialog(null,insert_query);
            conn = DBConnection.ConnectDB();
            pst = conn.prepareStatement(update_query);
            pst.execute();
            update_lease_table();
            Insert_Timestamp2();
            jLabel18.setText("Lease# : " + lease_id_tf.getText() + " updated");

        } catch (HeadlessException | SQLException e) {
            //  JOptionPane.showMessageDialog(null, e);
            e.printStackTrace();
            jLabel18.setForeground(Color.red);
            jLabel18.setText("Lease# : " + lease_id_tf.getText() + " not updated!!");

        }
        update_lease_table();

    }

    public void delete_lease() {

        String delete_query = " delete from lease where lease_id='" + lease_id_tf.getText() + "' ";
        try {
            //JOptionPane.showMessageDialog(null,insert_query);
            conn = DBConnection.ConnectDB();
            pst = conn.prepareStatement(delete_query);
            pst.execute();

        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        update_lease_table();

    }

    public void check_boxes_status() {

        DefaultTableModel tmodel = (DefaultTableModel) jtbl_Accounts_Master.getModel();
        int slctdrow = jtbl_Accounts_Master.getSelectedRow();

        //char d = Character.valueOf(tmodel.getValueAt(slctdrow, 1));
        String Must_Budget = tmodel.getValueAt(slctdrow, 16).toString();
        //String Check_Budget = tmodel.getValueAt(slctdrow, 1).toString();
        String reconcile_Account = tmodel.getValueAt(slctdrow, 14).toString();
        String Restrict_Posting = tmodel.getValueAt(slctdrow, 11).toString();
        String Restrict_Owner = tmodel.getValueAt(slctdrow, 22).toString();

        if (Must_Budget.equals("Y")) {
            jchk_Must_Budget.setSelected(true);
        } else {
            jchk_Must_Budget.setSelected(false);
        }
        //if(Check_Budget.equals("Y")){ jchk_Must_Budget.setSelected(true); }else{ jchk_Check_Budget.setSelected(false); }
        if (reconcile_Account.equals("Y")) {
            jchk_Must_Budget.setSelected(true);
        } else {
            jchk_reconcile_Account.setSelected(false);
        }
        if (Restrict_Posting.equals("Y")) {
            jchk_Must_Budget.setSelected(true);
        } else {
            jchk_Restrict_Posting.setSelected(false);
        }
        if (Restrict_Owner.equals("Y")) {
            jchk_Must_Budget.setSelected(true);
        } else {
            jchk_Restrict_Owner.setSelected(false);
        }
    }

    public String selected_value() {
        if (jRadioButton_active.isSelected()) {
            selectedValue = "ACT";
        }
        if (jRadioButton_closed.isSelected()) {
            selectedValue = "CLS";
        }
        if (jRadioButton_onhold.isSelected()) {
            selectedValue = "HLD";
        }
        //if(jRadioButton_active.isSelected()){selectedValue = jRadioButton_active.getText();}  
        //if(jRadioButton_closed.isSelected()){selectedValue = jRadioButton_active.getText();}
        //if(jRadioButton_onhold.isSelected()){selectedValue = jRadioButton_active.getText();}

        return selectedValue;
    }

    public static void callContactDetails() {
        jTabbedPane1.setSelectedIndex(0);
    }

    public static void callContactInformation() {
        jTabbedPane1.setSelectedIndex(1);
    }

    public static void callProperties() {
        jTabbedPane1.setSelectedIndex(2);
    }

    public static void callAccountMaster() {
        jTabbedPane1.setSelectedIndex(3);
    }

    public static void callLeasing() {
        jTabbedPane1.setSelectedIndex(4);
    }

    public String approveAction(JCheckBox checkbox, String approve_confirmation_message) {
        String checked_status = "N";
        checkbox.setSelected(false);
        int p = JOptionPane.showConfirmDialog(null, approve_confirmation_message, null, JOptionPane.YES_NO_OPTION);
        if (p == 0) {
            checkbox.setSelected(true);
            if (checkbox.isSelected()) {

                checkbox.setForeground(new Color(187, 187, 187));
                checkbox.setEnabled(false);
                checked_status = "Y";
                lease_table.setDefaultRenderer(Object.class, new TableCellRendererColor());
            }
        }
        return checked_status;
    }

    public class TableCellRendererColor extends DefaultTableCellRenderer {

        private Component components;

        @Override

        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            components = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column); //To change body of generated methods, choose Tools | Templates.
            components.setForeground(Color.black);
            String valueS = (String) lease_table.getValueAt(row, 41);

            if (valueS.equals("Y")) {

                components.setBackground(Color.green);
            }
            if (valueS.equals("N")) {
                components.setBackground(Color.white);
            }
            if (isSelected) {
                components.setBackground(new Color(75, 110, 175));
                components.setForeground(new Color(187, 187, 187));
            }

            return components;
        }
    }

//=============================================================================================================================================
    //AUTOMATIC POSTING TO RECURRENTS
    public void into_recurrents() {

        new Thread() {

            @Override
            public void run() {
                Connection con = DBConnection.ConnectDB();
                try {
                    con.setAutoCommit(false);
                    try (Statement st = con.createStatement()) {

                        if (!into_recrrents_sql(current_lease_tf, lease_acc_tf).equals("no sql")) {
                            st.addBatch(into_recrrents_sql(current_lease_tf, lease_acc_tf));
                        }

                        if (!into_recrrents_sql(lease_fee_amount, lease_fee_accnt_tf).equals("no sql")) {
                            st.addBatch(into_recrrents_sql(lease_fee_amount, lease_fee_accnt_tf));
                        }

                        if (!into_recrrents_sql(refund_depst_tf, refundable_deposit_account).equals("no sql")) {
                            st.addBatch(into_recrrents_sql(refund_depst_tf, refundable_deposit_account));
                        }

                        if (!into_recrrents_sql(non_refund_dpst_tf, non_refundable_deposit_account).equals("no sql")) {
                            st.addBatch(into_recrrents_sql(non_refund_dpst_tf, non_refund_dpst_tf));
                        }

                        if (!into_recrrents_sql(water_depst_tf, water_depst_acc_tf).equals("no sql")) {
                            st.addBatch(into_recrrents_sql(water_depst_tf, water_depst_acc_tf));
                        }

                        if (!into_recrrents_sql(elect_depst_tf, elect_depst_acc_tf).equals("no sql")) {
                            st.addBatch(into_recrrents_sql(elect_depst_tf, elect_depst_acc_tf));
                        }

                        if (!into_recrrents_sql(security_charges_tf, securitycharges_acc).equals("no sql")) {
                            st.addBatch(into_recrrents_sql(security_charges_tf, securitycharges_acc));
                        }
                        if (!into_recrrents_sql(utility_charges_tf, utility_charges_acc).equals("no sql")) {
                            st.addBatch(into_recrrents_sql(utility_charges_tf, utility_charges_acc));
                        }
                        if (!into_recrrents_sql(salesman_id_tf, salesman_acc_tf).equals("no sql")) {
                            st.addBatch(into_recrrents_sql(salesman_id_tf, salesman_acc_tf));
                        }

                        st.executeBatch();
                        con.commit();
                        JOptionPane.showMessageDialog(null, "Lease Transactions Posted");
                        st.closeOnCompletion();
                    }
                } catch (SQLException e) {
                    e.getNextException().printStackTrace();
                }
            }
        }.start();
    }

    public void set_to_zero(JTextField textfield) {

        if (textfield.getText().equals("")) {
            textfield.setText("0");
        }
    }

    public void auto_pop_panel(JTextField texfield, String text) {
        if (!texfield.getText().equals("")) {
            TableDetails_Panel2.filter_text = text;
        } else {
            TableDetails_Panel2.filter_text = null;
        }
    }

    public String into_recrrents_sql(JTextField textfield1, JTextField textfield2) {

        String sql = "no sql";
        String amount = textfield1.getText();
        String account_number = textfield2.getText();
        System.out.println(amount + "\t" + account_number);
        if (!amount.equals("0") && !account_number.equals("")) {

            sql = "insert into ledger_recurrents("
                    + "ACCOUNT_NUMBER,"
                    + "LEDGER_NUMBER,"
                    + "LEDGER_TYPE,"
                    + "TRANSACTION_DATE,"
                     + "DOCUMENT_NUMBER,"
                    + "DOCUMENT_TYPE,"
                    + "DESCRIPTION,"
                    + "REFERENCE_NUMBER,"
                    + "REFERENCE_TYPE,"
                    + "CONTRA_ACCOUNT,"
                    + "TRANSACTION_TYPE,"
                    + "TRANSACTION_STATUS,"
                    + "AMOUNT,"
                    + " AMOUNT_VALUE,"
                    + "RECEIVE_IN,"
                    // + "PAY_OUT,"
                    + "IS_RECURRENT,"
                     + "APPROVED,"
                    + "property_id,"
                    + "due_date"
                    + ")"
                    + "values("
                    + "'" + account_number + "',"
                    + "'" + contact_id_tf.getText() + "',"
                    + "'LEA',"
                    + "'" + datePicker4.getJFormattedTextField().getText() + "',"
                     + "'0',"
                    + "'INT',"
                    + "'" + DBConnection.global_resultSet("select description from account_master where account_number = '" + account_number + "'") + "',"
                    + "'" + lease_id_tf.getText() + "',"
                    + "'LEA',"
                    + "'" + DBConnection.global_resultSet("select contra_account from account_master where account_number = '" + account_number + "'") + "',"
                    + "'IOF',"
                    + "'N',"
                    + "'" + amount + "',"
                    + "'" + amount + "',"
                    + "'Y',"
                    //+ "'" + selected_status(jRB_out) + "',"
                    + "'Y',"
                    + "'Y',"
                    + "'" + property_id_combo.getText() + "',"
                    + "" + datePicker5.getModel().getValue() + ""
                    + ")";

        }
        System.out.println(sql);
        return sql;
    }

//=============================================================================================================================================
}
