/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus;

/**
 *
 * @author PSL-STUFF
 */
import java.awt.*;
 import javax.swing.*;
 import java.awt.event.*;



 class myImage extends JFrame  implements ActionListener
{

ImageIcon m[];
JLabel l;
JButton b,b1;
int i,l1;
JPanel p;
private static myImage my = null;
public myImage()
{
    setLayout(new BorderLayout( ));
    setSize(1000, 1000);
    setVisible(true);
    JPanel p=new JPanel(new FlowLayout());
    b=new JButton("Previous");
    b1=new JButton("Next");
    p.add(b);
    p.add(b1);
    add(p,BorderLayout.SOUTH);
    b.addActionListener(this);
    b1.addActionListener(this);
    m = new ImageIcon[3];
    m[0] = new ImageIcon("C:/Users/PSL-STUFF/Desktop/sample1.jpg");
    m[1] = new ImageIcon("C:/Users/PSL-STUFF/Desktop/sample5.jpg");
    m[2] = new ImageIcon("C:/Users/PSL-STUFF/Desktop/sample6.jpg");
    l = new JLabel();
    l.setBounds(0, 200, getWidth(), getHeight());
    add(l,BorderLayout.CENTER);
    l.setIcon(m[0]);

}

 public static myImage getobj(){
    
        if(my == null){
        
            my = new myImage();
        }
        return my;
    }
public  void actionPerformed(ActionEvent e)
{

    if(e.getSource()==b)
    {
        if(i==0)
        {
            JOptionPane.showMessageDialog(null,"This is the first image");
        }
        else
            {
            i=i-1;
            l.setIcon(m[i]);
        }
    }
    if(e.getSource()==b1)
    {
        if(i==m.length-1)
        {
            JOptionPane.showMessageDialog(null,"This is the last image");
        }
        else
            {
            i=i+1;
            l.setIcon(m[i]);
            }
        }

     }


public static void main(String args[])
{
    myImage i1 = new myImage();
}


 }
