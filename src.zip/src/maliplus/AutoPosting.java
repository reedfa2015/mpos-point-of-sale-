/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus;

import java.sql.*;

/**
 *
 * @author Extus
 */
public class AutoPosting {
        
    public static void main(String[]args){
    
    int n = 2;
        Connection con = DBConnection.ConnectDB();
        try{
            con.setAutoCommit(false);
            try (Statement st = con.createStatement()) {
                
                st.addBatch("insert into ledger_recurrents (account_number,amount,amount_value) values('6789','7000','50')");
                System.out.println("1st added batch");
                
                st.addBatch("update ledger_recurrents set approved = 'Y' where account_number = '6789'");
                System.out.println("2nd added batch");
                if(n==3){
                st.addBatch("insert into lledger_transactions(account_number)values('6789')");
                System.out.println("3rd added batch");
            }
                
                st.executeBatch();
                con.commit();
                System.out.println("batch executed");
                st.close();
            }
        }catch(Exception e){ e.printStackTrace();}
    }

}
