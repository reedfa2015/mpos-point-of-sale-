/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus;

import java.awt.AWTException;
import java.awt.CheckboxMenuItem;
import java.awt.Image;
import java.awt.Menu;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
//import java.awt.event.ItemListener;
import java.net.URL;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.ImageIcon;
//import javax.swing.JOptionPane;

/**
 *
 * @author Extus
 */
public class ServicesTray {

    static TrayIcon trayIcon;

    static String username, address = "localhost";
    static ArrayList<String> users = new ArrayList();
    static int port = 2222;
    static Boolean isConnected = false;

    static Socket sock;
    static BufferedReader reader;
    static PrintWriter writer;

    public ServicesTray() {

        ShowTrayIcon();
    }

    public static void ShowTrayIcon() {

        if (!SystemTray.isSupported()) {
            System.out.println("System does not support Tray icon");
            System.exit(0);
            return;
        }
        final PopupMenu popup = new PopupMenu();
        trayIcon = new TrayIcon(CreateIcon("/images_/mali2.png", "tray icon"));
        final SystemTray tray = SystemTray.getSystemTray();

        MenuItem LaunchTXItem = new MenuItem("Connect");
        MenuItem LaunchTXI2tem = new MenuItem("Disconnect");
        CheckboxMenuItem cb1 = new CheckboxMenuItem("Connect on start up");
        CheckboxMenuItem cb2 = new CheckboxMenuItem("Set tooltip");
        Menu displayMenu = new Menu("Information");
        MenuItem infoItem = new MenuItem("Check updates");
        MenuItem AboutItem = new MenuItem("About");
        MenuItem settingsItem = new MenuItem("Settings");
        MenuItem launchDB = new MenuItem("Lauch DB");
        MenuItem exitItem = new MenuItem("Exit");

        //Add components to popup menu
        popup.add(LaunchTXItem);
        popup.add(LaunchTXI2tem);
        popup.addSeparator();
        popup.add(cb1);
        popup.add(cb2);
        popup.addSeparator();
        popup.add(displayMenu);
        displayMenu.add(infoItem);
        displayMenu.add(AboutItem);
        popup.add(settingsItem);
        popup.add(launchDB);
        popup.add(exitItem);

        trayIcon.setPopupMenu(popup);

        try {
            tray.add(trayIcon);
        } catch (AWTException e) {
            System.out.println("TrayIcon could not be added.");

        }

        trayIcon.addActionListener((ActionEvent e) -> {
            //JOptionPane.showMessageDialog(null,
                    //"Replace with Transaction monitoring Window");
        });

        LaunchTXItem.addActionListener((ActionEvent e) -> {
            connect();
           // JOptionPane.showMessageDialog(null,
             //       "Transaction Window");
        });
        LaunchTXI2tem.addActionListener((ActionEvent e) -> {
           //JOptionPane.showMessageDialog(null,
             //       "Transaction Window");
        });

        cb1.addItemListener((ItemEvent e) -> {
            int cb1Id = e.getStateChange();
            if (cb1Id == ItemEvent.SELECTED) {
                trayIcon.setImageAutoSize(true);
            } else {
                trayIcon.setImageAutoSize(false);
            }
        });

        cb2.addItemListener((ItemEvent e) -> {
            int cb2Id = e.getStateChange();
            if (cb2Id == ItemEvent.SELECTED) {
                trayIcon.setToolTip("Maliplus");
            } else {
                trayIcon.setToolTip(null);
            }
        });

        ActionListener listener = (ActionEvent e) -> {
            MenuItem item = (MenuItem) e.getSource();
            //TrayIcon.MessageType type = null;
            System.out.println(item.getLabel());
            if ("Error".equals(item.getLabel())) {
                //type = TrayIcon.MessageType.ERROR;
                trayIcon.displayMessage("Maliplus",
                        "This is an error message", TrayIcon.MessageType.ERROR);

            } else if ("Warning".equals(item.getLabel())) {
                //type = TrayIcon.MessageType.WARNING;
                trayIcon.displayMessage("Maliplus",
                        "This is a warning message", TrayIcon.MessageType.WARNING);

            } else if ("Check updates".equals(item.getLabel())) {
                //type = TrayIcon.MessageType.INFO;
                trayIcon.displayMessage("MaliPlus",
                        "Checking Updates", TrayIcon.MessageType.INFO);

            } else if ("About".equals(item.getLabel())) {
                //type = TrayIcon.MessageType.NONE;
                trayIcon.displayMessage("MaliPlus",
                        "Maliplus from PrimeSoft Solutions (K) Ltd", TrayIcon.MessageType.NONE);
            }
        };

        infoItem.addActionListener(listener);

        exitItem.addActionListener((ActionEvent e) -> {
            tray.remove(trayIcon);
            System.exit(0);
        });
    }

    protected static Image CreateIcon(String path, String desc) {
        URL imageURL = ServicesTray.class.getResource(path);
        return (new ImageIcon(imageURL, desc).getImage());
    }

    public static void connect() {

        if (isConnected == false) {
            //username = "Maliplus";
            //tf_username.setEditable(false);
            
            String anon="anon";
            Random generator = new Random(); 
            int i = generator.nextInt(999) + 1;
            String is=String.valueOf(i);
            anon=anon.concat(is);
            username=anon;

            try {
                sock = new Socket(address, port);
                InputStreamReader streamreader = new InputStreamReader(sock.getInputStream());
                reader = new BufferedReader(streamreader);
                writer = new PrintWriter(sock.getOutputStream());
                writer.println(username + ":has connected.:Connect");
                writer.flush();
                isConnected = true;
            } catch (Exception ex) {
                trayIcon.displayMessage("Maliplus",
                        "Cannot Connect! Try Again", TrayIcon.MessageType.INFO);

                //tf_username.setEditable(true);
            }

            ListenThread();

        } else if (isConnected == true) {
            trayIcon.displayMessage("Maliplus",
                    "You are already connected", TrayIcon.MessageType.INFO);

        }
    }

    public static class IncomingReader implements Runnable {

        @Override
        public void run() {
            String[] data;
            String stream, done = "Done", connect = "Connect", disconnect = "Disconnect";

            try {
                while ((stream = reader.readLine()) != null) {
                    data = stream.split(":");

                    if (data[2].equals(connect)) {
                        userAdd(data[0]);
                    } else if (data[2].equals(disconnect)) {
                        userRemove(data[0]);
                    } else if (data[2].equals(done)) {
                        //users.setText("");
                        writeUsers();
                        users.clear();
                    }
                }
            } catch (Exception ex) {
            }
        }
    }

    public static void userAdd(String data) {
        users.add(data);
    }

    public static void userRemove(String data) {
        trayIcon.displayMessage("Maliplus",
                data + " is now offline", TrayIcon.MessageType.INFO);
    }

    public static void writeUsers() {
        String[] tempList = new String[(users.size())];
        users.toArray(tempList);
        for (String token : tempList) {
            //users.append(token + "\n");
        }
    }

    public static void ListenThread() {
        Thread IncomingReader = new Thread(new IncomingReader());
        IncomingReader.start();
    }

    public void sendDisconnect() {
        String bye = (username + ": :Disconnect");
        try {
            writer.println(bye);
            writer.flush();
        } catch (Exception e) {
            trayIcon.displayMessage("Maliplus",
                    "Could not send Disconnect message.", TrayIcon.MessageType.ERROR);
        }
    }

    public void Disconnect() {
        try {
            trayIcon.displayMessage("Maliplus",
                    "Disconnected", TrayIcon.MessageType.INFO);

            sock.close();
        } catch (Exception ex) {
            trayIcon.displayMessage("Maliplus",
                    "Failed to disconnect", TrayIcon.MessageType.ERROR);

        }
        isConnected = false;
        //tf_username.setEditable(true);

    }
}
