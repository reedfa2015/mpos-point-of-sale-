/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus;

/**
 *
 * @author PSL-STUFF
 */

import com.jfoenix.controls.JFXTextField;
import java.awt.BorderLayout;
import java.io.IOException;

import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;


public class users3 {
    
         @FXML
    private JFXTextField username2;
              @FXML
    private JFXTextField username;
    
         

    private void initSwingComponents() {
        
        JFrame frame = new JFrame("Users");
        frame.setLayout(new BorderLayout());
        final JFXPanel jfxPanel = new JFXPanel();
        frame.add(jfxPanel, BorderLayout.CENTER);
        final JPanel swingButtons = new JPanel();
        frame.add(swingButtons, BorderLayout.SOUTH);

        frame.setSize(1102, 792);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        
        Platform.runLater(() -> initFX(jfxPanel));
        
      
    }
    
     
       

    private void initFX(JFXPanel jfxPanel) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("user_group.fxml"));
            Scene scene = new Scene(root, 1102, 792);
            scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
            jfxPanel.setScene(scene);
             
         
           
              
        } catch (IOException exc) {
            exc.printStackTrace();
            System.exit(1);
        }
    }

    public static void main(String[] args) {
        users3 test = new users3();
        SwingUtilities.invokeLater(() -> test.initSwingComponents() );
        

        
    }
}