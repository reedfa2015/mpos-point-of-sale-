/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author Extus
 */
class RfesultSet {

    static ArrayList<String> some_array = new ArrayList();

    public static String format_excel_headers(ArrayList list) {

        String a = list.toString();

        String replace = a.replace("[", "");
        String replace1 = replace.replace("]", "");

        return replace1;
    }

    public static int Array_size(ArrayList list) {
        int elements = list.size();

        return elements;
    }

    public static FileInputStream file() {
        FileInputStream selected_file = null;
        String path = "C:\\Users\\user pc\\Desktop\\Excel Eports\\expt1.xlsx";
        try {
            selected_file = new FileInputStream(path);
        } catch (Exception e) {
        }

        return selected_file;
    }

    public static ArrayList read_excel_header() throws FileNotFoundException, IOException {

        FileInputStream input = file();
        XSSFWorkbook workbook = new XSSFWorkbook(input);

        XSSFSheet sheet = workbook.getSheetAt(0);

        ArrayList<String> columndata = null;

        Iterator<Row> rowIterator = sheet.iterator();
        columndata = new ArrayList<>();

        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            while (cellIterator.hasNext()) {
                Cell cell = cellIterator.next();

                if (row.getRowNum() == 0) {
                    if (cell.getRowIndex() == 0) {

                        switch (cell.getCellType()) {
                            case Cell.CELL_TYPE_NUMERIC:
                                columndata.add(cell.getNumericCellValue() + "");
                                break;
                            case Cell.CELL_TYPE_STRING:
                                columndata.add(cell.getStringCellValue());

                                break;
                        }
                    }
                }
            }
        }
        return columndata;
    }

    public static void excel_to_db2() throws InvalidFormatException {

        try {
            Connection con = DBConnection.ConnectDB();
            Statement st = con.createStatement();
            //con.setAutoCommit(false);
            FileInputStream input = file();
            Workbook wb = WorkbookFactory.create(input);
            Sheet sheet = wb.getSheetAt(0);
            
            ArrayList data = new ArrayList();
            
            Row row;
            String quote = "'";

            DataFormatter formatter = new DataFormatter();

            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                row = sheet.getRow(i);

                for (int j = 0; j < Array_size(read_excel_header()); j++) {
                    data.add(quote + formatter.formatCellValue(sheet.getRow(i).getCell(j)) + quote);

                }
               
                String sql = "INSERT INTO list_control2 (" + format_excel_headers(read_excel_header()) + ") VALUES(" + format_excel_headers(data) + ")";                
                
                st.addBatch(sql);
                

                System.out.println(sql);                
                data.removeAll(data);
                System.out.println("Import rows " + i);
            }
            int[] executeBatch = st.executeBatch();
            con.close();
            input.close();

            JOptionPane.showMessageDialog(null, "Successfully imported to Database");
            //ProgressBar1.setValue(100);
        } catch (SQLException ex) {
            System.out.println(ex);
            ex.printStackTrace();
        } catch (IOException ioe) {
            System.out.println(ioe);
        }
    }

    public static void main(String[] args) {
        try {
            excel_to_db2();
        } catch (InvalidFormatException ex) {
            Logger.getLogger(RfesultSet.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
