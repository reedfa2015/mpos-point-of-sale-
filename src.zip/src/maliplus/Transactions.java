/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JTextField;

/**
 *
 * @author Extus
 */
public class Transactions{
    private int[]theArray = new int[50];
    private int arraySize = 10;
    
    public static JTextField jtf = new JTextField();
    
    
    
    Connection con = DBConnection.ConnectDB();;
    
    public void gerateRandomArray(){
    
        for(int i=0; i<arraySize;i++){
            theArray[i] = (int) ((Math.random()*10)+10);
            //handles transaction amount values from lease
        }
    }
    public void printArray(){
    
        System.out.println("-----------");
        for(int i=0;i<arraySize;i++){
            System.out.print("| "+ i +" | ");
            System.out.println(theArray[i] + " |");
            System.out.println("-----------");    
        }    
    }
    
    public int getValueAtIndex(int index){
    
        if(index<arraySize)return theArray[index];
        //replace with rs
        return 0;
    }
    public boolean doesArrayContainThisValue(int searchValue){
    //check transaction id from transactions array
        boolean valueInArray = false;
        for(int i = 0; i < arraySize; i++){
            if(theArray[i] == searchValue){
            
                valueInArray = true;
            }
    }
        return valueInArray;
    }
    
    public void deleteIndex(int index){
    
        
        if(index<arraySize){
        
            for(int i = index; i < (arraySize - 1); i++){
            
                theArray[i] = theArray[i+1];
            }
        }
    }
    public void insertValue(int value){
    //adjust transaction amount
        if(arraySize < 50){
        
            theArray[arraySize] = value;
           arraySize++;
        }
    }
    
    public String linearSearchForValue(int value){
    //check transaction IDs in bulk before posting
        boolean valueInArray = false;
        
        String indexWithValue = "";
        
        System.out.print("The value was found in the following: ");
        
        for(int i = 0; i < arraySize; i++){
        
            if(theArray[i] == value){
            
                valueInArray = true;
                
                System.out.print(i + " ");
                indexWithValue+=" ";
            }
        }
        if(!valueInArray){
        
            indexWithValue+= "None";
            
            System.out.print(indexWithValue);
        }
        return indexWithValue;
    }
    

    public static void specifiedAmount(){
        //from the amounttextfield in transaction form
        String amount = jtf.getText();
        int amt = Integer.parseInt(amount);
                
    }
    public boolean check_if_in_or_out(int status){
        boolean check_state = false;
        //check transction type--debited or credited
        if(status == 1){
            check_state = true;
            Transactions.specifiedAmount();
        }
      return check_state;
    }
    public void current_account_Amount(int amount){
    
        
        String sql_getCount = "";
        
        String sql = "";
        try{
            PreparedStatement pst_count = con.prepareStatement(sql_getCount);
            PreparedStatement pst = con.prepareStatement(sql);
            
            ResultSet rs_count = pst_count.executeQuery();
            ResultSet rs = pst.executeQuery();
            
            for(int i = 0; i <= rs_count.getInt(1);i++){
            
                
            }
            
        }
        catch(Exception e){ e.printStackTrace(); }
    }
    public void countExistingData(int index){
       //total transaction account as per ID 
        
        try{
        String querry = "";
        
        Statement st = con.createStatement();
       
        ResultSet rs = st.executeQuery(querry);

        int value;
        int total = 100;
        while(rs.next())
        {
            value = rs.getInt(index);
            System.out.println(value);
            total += value; 
        }
        System.out.println("Total value --- "+total);
        }
        catch(Exception e){e.printStackTrace();}
        
    }
    
}