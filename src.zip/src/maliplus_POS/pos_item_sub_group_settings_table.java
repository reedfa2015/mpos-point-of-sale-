/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;
import javafx.beans.property.StringProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author PSL-STUFF
 */
public class pos_item_sub_group_settings_table {
private final SimpleStringProperty description2;
private final SimpleStringProperty code2;
private final SimpleStringProperty reference_code2;
private final SimpleStringProperty text2;
private final SimpleIntegerProperty sort_order2;
private final SimpleStringProperty date_modified2;
private final SimpleStringProperty modified_by2;
private final SimpleStringProperty reference12;
private final SimpleStringProperty reference22;
private final SimpleStringProperty date_created2;
private final SimpleStringProperty created_by2;
public pos_item_sub_group_settings_table (String DESC,String L_I,String R_C,String K_W,Integer O_B,String D_M,String M_B,String REF1,String REF2,String D_C,String C_B ){
    this.description2 = new SimpleStringProperty(DESC);
    this.code2 = new SimpleStringProperty(L_I);
     this.reference_code2 = new SimpleStringProperty(R_C);
     this.text2 = new SimpleStringProperty(K_W);
     this.sort_order2 = new SimpleIntegerProperty(O_B);
     this.date_modified2 = new SimpleStringProperty(D_M);
     this.modified_by2 = new SimpleStringProperty(M_B);
     this.reference12 = new SimpleStringProperty(REF1);
     this.reference22 = new SimpleStringProperty(REF2);   
     this.date_created2 = new SimpleStringProperty(D_C);
     this.created_by2 = new SimpleStringProperty(C_B);
}

    



  public String getDESCRIPTION(){
      return description2.get();
  }
  public String getLIST(){
      return code2.get();
  }
  public String getREFERENCE_CODE(){
      return reference_code2.get();
  }

  public String getTEXT(){
      return text2.get();
  }
  public Integer getSORT_ORDER(){
      return sort_order2.get();
  }
  
  public String getDATE_MODIFIED(){
      return date_modified2.get();
  }
  public String getMODIFIED_BY(){
      return modified_by2.get();
  }

   public String getREFERENCE1(){
      return reference12.get();
  }
   public String getREFERENCE2(){
      return reference22.get();
  }
    public String getDATE_CREATED2(){
      return date_created2.get();
  }
     public String getCREATED_BY2(){
      return created_by2.get();
  }

  
  public void SetDESCRIPTION(String DESC ){
      description2.set(DESC);
  }
  public void SetLIST(String L_I ){
      code2.set(L_I);
  }
   public void SetREFERENCE_CODE(String R_C){
      reference_code2.set(R_C);
  }
  
   public void SetTEXT(String K_W){
      text2.set(K_W);
  }
   public void SetSORT_ORDER(Integer O_B){
      sort_order2.set(O_B);
  }
   
   public void SetDATE_MODIFIED(String D_M){
      date_modified2.set(D_M);
  }
   public void SetMODIFIED_BY(String D_M){
      modified_by2.set(D_M);
  }
   public void SetREFERENCE1(String REF1 ){
      reference12.set(REF1);
  }
    public void SetREFERENCE2(String REF2 ){
      reference22.set(REF2);
  }
    public void SetDATE_CREATED2(String D_C ){
      date_created2.set(D_C);
  }
      public void SetCREATED_BY2(String C_B ){
      created_by2.set(C_B);
  }
   
     
      public StringProperty descriptionProperty() {
        return description2 ;
    }
      public StringProperty listProperty() {
        return code2 ;
    }
       public StringProperty reference_codeProperty() {
        return reference_code2 ;
    }
    
      public StringProperty textProperty() {
        return text2 ;
    }
        public IntegerProperty sort_orderProperty() {
        return sort_order2 ;
    }

      
            public StringProperty date_modifiedProperty() {
        return date_modified2 ;
    }
                 public StringProperty modified_byProperty() {
        return modified_by2 ;
    }

                  public StringProperty reference1Property() {
        return reference12 ;
    }
                 public StringProperty reference2Property() {
        return reference22 ;
    }
                public StringProperty date_created2Property() {
        return date_created2 ;
    }
                public StringProperty created_by2Property() {
        return created_by2 ;
    }


}
