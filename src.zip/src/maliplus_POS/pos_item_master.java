/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;

/**
 *
 * @author PSL-STUFF
 */
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXDialog;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import java.awt.Toolkit;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.ResourceBundle;
import java.util.function.UnaryOperator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.embed.swing.JFXPanel;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextFormatter;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.util.converter.DoubleStringConverter;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import maliplus.DBConnection;
import static maliplus_POS.Pos_Controller.stage2;
import static maliplus_POS.pos_stock_adjustment_initial.INITIAL_VALUE;
import org.controlsfx.control.MaskerPane;
import org.controlsfx.control.Notifications;

public class pos_item_master implements Initializable{
    
     static Connection conn = null;
    static ResultSet rs = null;
    static PreparedStatement pst = null;
    
    @FXML
    private AnchorPane item_master_root;
    
    @FXML
    private JFXButton insert_btn;

    @FXML
    private JFXButton save_btn;

    @FXML
    private JFXButton delete_btn;

    @FXML
    private JFXButton print_preview_btn;

    @FXML
    private JFXButton export_btn;

    @FXML
    private JFXButton approve_post_btn;

    @FXML
    private JFXButton customized_stock_result_btn;

    @FXML
    private JFXButton find_items_btn;

    @FXML
    private JFXButton refresh_btn;

    @FXML
    private JFXButton clear_btn;

    @FXML
    private JFXButton item_notes_btn;

    @FXML
    private JFXButton back_btn;

    @FXML
    private JFXDialog display_message_dgBox;

    @FXML
    private Label item_type_lbl;

    @FXML
    private Label item_main_group_lbl;

    @FXML
    private Label purchase_uom_lbl;

    @FXML
    private Label wholesale_uom_lbl;

    @FXML
    private Label sales_uom_lbl;

    @FXML
    private Label unit_of_measure_lbl;

    @FXML
    private Label pack_type_lbl;

    @FXML
    private Label barcode_type_lbl;

    @FXML
    private Label barcode_lbl;

    @FXML
    private Label item_sub_group_lbl;

    @FXML
    private JFXTextField item_type_txtf;

        @FXML
    private Label in_lbl;
    
    @FXML
    private JFXTextField item_main_group_txtf;

    @FXML
    private JFXTextField item_sub_group_txtf;

    @FXML
    private JFXTextField barcode_txtf;

    @FXML
    private JFXTextField barcode_type_txtf;

    @FXML
    private JFXTextField pack_type_txtf;

    @FXML
    private JFXTextField unit_of_measure_txtf;

    @FXML
    private JFXTextField sales_uom_txtf;

    @FXML
    private JFXTextField wholesale_uom_txtf;

    @FXML
    private JFXTextField purchase_uom_txtf;

    @FXML
    private JFXTextField ref_account_txtf;

    @FXML
    private Label search_lbl;

    @FXML
    private Label pack_type_edit_lbl;

    @FXML
    private Label inventory_unit_of_measure_edit_lbl;

    @FXML
    private JFXCheckBox message_alert_chkbx;

    @FXML
    private JFXCheckBox ref_no_chkbx;

    @FXML
    private JFXTextArea short_description_txtArea;

    @FXML
    private Label parent_item_lbl;

    @FXML
    private Label supplier_code_lbl;

    @FXML
    private Label manufacturers_lbl;

    @FXML
    private Label package_description_lbl;

    @FXML
    private JFXTextField parent_item_txtf;

    @FXML
    private JFXTextField supplier_code_txtf;

    @FXML
    private JFXTextField manufacturers_txtf;

    @FXML
    private Spinner<Double> purchase_unit_price_spinner;

    @FXML
    private Spinner<Double> retail_sale_price_spinner;

    @FXML
    private Spinner<Double> wholesale_price_spinner;

    @FXML
    private Spinner<Double> wholesale_auto_trigger_spinner;

    @FXML
    private JFXCheckBox taxable_chkbx;

    @FXML
    private Spinner<Double> maximum_discount_spinner;

    @FXML
    private Spinner<Double> sales_profit_margin_spinner;

    @FXML
    private Spinner<Double> re_order_level_spinner;

    @FXML
    private Spinner<Double> unit_standard_measure_spinner;

    @FXML
    private Spinner<Double> shelf_life_spinner;

    @FXML
    private JFXTextArea description_txtArea;

    @FXML
    private JFXCheckBox reduce_in_sale_chkbx;

    @FXML
    private JFXCheckBox allow_zero_price_chkbx;

    @FXML
    private JFXCheckBox by_profit_margin_chkbx;

    @FXML
    private Label tax_group_lbl;

    @FXML
    private JFXTextField tax_group_txtf;

    @FXML
    private JFXTextField in_txtf;

    @FXML
    private JFXTextField item_code_txtf;

    @FXML
    private JFXTextField item_name_txtf;

    @FXML
    private JFXTextField last_added_item_txtf;
    
      @FXML
    private JFXTextField Supplier_name_txtf;

      @FXML
    private JFXTextField  parent_item_name_txtf;
      
      @FXML
    private MaskerPane masker;
      
          @FXML
    private AnchorPane bg;
          
          @FXML
    private Label item_type_edit_lbl;

    @FXML
    private Label item_main_group_edit_lbl;

    @FXML
    private Label item_sub_group_edit_lbl;

      
   final KeyCombination keyComb1 = new KeyCodeCombination(KeyCode.F,KeyCombination.CONTROL_ANY);
        @FXML
    void keyReleasedhandle(KeyEvent event) {
       if(event.getSource()==item_master_root){
          if (keyComb1.match(event)) {
        try {
        loadItemDetailsStage(200,100);
        } catch (IOException ex) {
        Logger.getLogger(pos_stock_adjustment_initial.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
       }
    }
         protected static final String INITIAL_VALUE = "0";
  
    
    NumberFormat format = NumberFormat.getIntegerInstance();
       UnaryOperator<TextFormatter.Change> filter = c -> {
    if (c.isContentChange()) {
        ParsePosition parsePosition = new ParsePosition(0);
        // NumberFormat evaluates the beginning of the text
        format.parse(c.getControlNewText(), parsePosition);
        if (parsePosition.getIndex() == 0 ||
                parsePosition.getIndex() < c.getControlNewText().length()) {
            // reject parsing the complete text failed
            return null;
        }
    }
    return c;
};
    
            void loadItemDetailsStage(int x, int y) throws IOException{
      
               stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_items Controller = new pos_items();
             // primarystage = (Stage) Controller.getScene().getWindow(); 
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_item_details_panel.fxml"));
              /*  loader.<pos_items>getController();
              Controller.setsearch_item2(item_code_txtf.getText());*/
              
            
              loader.setController(Controller);
               Parent  root4 = loader.load();
                Scene  scene3 = new Scene(root4);
                // scene3.setRoot(root4);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("ITEM DETAILS");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(x);
                 stage2.setY(y);
               // loader.<pos_item_filter>getController().setController(this);
                // stage2.show();
               stage2.showAndWait();
               //find.setText("");
              String result = loader.<pos_items>getController().getResult();
              String result2= loader.<pos_items>getController().getResult2();
              String load_item_details= loader.<pos_items>getController().getResult5();     
                if (result != null) {
                    
                    loadMaskerPanel4(result,result2,load_item_details);

                  }
               
                   
                
    }
            
                     void loadItemDetailsStage2(int x, int y) throws IOException{
      
               stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_items Controller = new pos_items();
             // primarystage = (Stage) Controller.getScene().getWindow(); 
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_item_details_panel.fxml"));
              /*  loader.<pos_items>getController();
              Controller.setsearch_item2(item_code_txtf.getText());*/
              
            
              loader.setController(Controller);
               Parent  root4 = loader.load();
                Scene  scene3 = new Scene(root4);
                // scene3.setRoot(root4);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("ITEM DETAILS");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(x);
                 stage2.setY(y);
               // loader.<pos_item_filter>getController().setController(this);
                // stage2.show();
               stage2.showAndWait();
               //find.setText("");
              String result = loader.<pos_items>getController().getResult();
              String result2= loader.<pos_items>getController().getResult2();
            //  String load_item_details= loader.<pos_items>getController().getResult5();     
                if (result != null) {
                  parent_item_txtf.setText(result);
                  parent_item_name_txtf.setText(result2);
                  }
               
                   
                
    }
            
               void loadItemDetails(String result, String result2,String load_item_details){
            // if a result was selected, add it to the list
                  item_code_txtf.setText(result);
                  item_name_txtf.setText(result2);
                 
               conn=DBConnection.ConnectDB();
               try{
                   pst=conn.prepareStatement(load_item_details);
                   rs=pst.executeQuery();
                   while(rs.next()){
                      item_type_txtf.setText(rs.getString("ITEM_TYPE"));
                      item_main_group_txtf.setText(rs.getString("ITEM_GROUP"));
                      item_sub_group_txtf.setText(rs.getString("SUB_GROUP"));
                      barcode_txtf.setText(rs.getString("BARCODE"));
                      barcode_type_txtf.setText(rs.getString("BARCODE_TYPE"));
                      pack_type_txtf.setText(rs.getString("PACK_TYPE"));
                      sales_uom_txtf.setText(rs.getString("IUOM"));
                      wholesale_uom_txtf.setText(rs.getString("WUOM"));
                      purchase_uom_txtf.setText(rs.getString("PUOM"));
                      ref_account_txtf.setText(rs.getString("ITEM_ACCOUNT"));
                      parent_item_txtf.setText(rs.getString("PARENT_ITEM"));
                      supplier_code_txtf.setText(rs.getString("SUPPLIER"));
                      manufacturers_txtf.setText(rs.getString("MANUFACTURER"));
                      short_description_txtArea.setText(rs.getString("DESCRIPTION"));
                      in_txtf.setText(rs.getString("MEASURE_TYPE"));
                      unit_of_measure_txtf.setText(rs.getString("SUOM"));
                      description_txtArea.setText(rs.getString("PACKAGE"));
                      
                     //  sales_price4.setText(String.valueOf(rs.getInt("SALE_PRICE")));
                     //  discount_percent.setText("0");
                     //  sale_quantity.setText("1");
                     //  calculateSalesAmount();
                      // sale-quantity.
                       TextFormatter<Double> priceFormatter = new TextFormatter<Double>(
        new DoubleStringConverter(), rs.getDouble("BUY_PRICE"), filter);
                       TextFormatter<Double> priceFormatter2 = new TextFormatter<Double>(
        new DoubleStringConverter(), rs.getDouble("SALE_PRICE"), filter);
                       TextFormatter<Double> priceFormatter3 = new TextFormatter<Double>(
        new DoubleStringConverter(), rs.getDouble("WHOLE_PRICE"), filter); 
                         TextFormatter<Double> priceFormatter4 = new TextFormatter<Double>(
                       new DoubleStringConverter(), rs.getDouble("DISCOUNT_RATE"), filter); 
                             TextFormatter<Double> priceFormatter5 = new TextFormatter<Double>(
                       new DoubleStringConverter(), rs.getDouble("SHELF_LIFE"), filter);
                             TextFormatter<Double> priceFormatter6 = new TextFormatter<Double>(
                       new DoubleStringConverter(), rs.getDouble("REORDER_LEVEL"), filter);
                               TextFormatter<Double> priceFormatter7 = new TextFormatter<Double>(
                       new DoubleStringConverter(), rs.getDouble("UNIT_MEASURE"), filter);
                                      TextFormatter<Double> priceFormatter8 = new TextFormatter<Double>(
                       new DoubleStringConverter(), rs.getDouble("PROFIT_MARGIN"), filter);
            //buying_price_spinner.getEditor().setText(String.valueOf(rs.getDouble("BUY_PRICE")));
            //System.out.println(rs.getDouble("BUY_PRICE"));
             purchase_unit_price_spinner.getEditor().setTextFormatter(priceFormatter);
             retail_sale_price_spinner.getEditor().setTextFormatter(priceFormatter2);
             wholesale_price_spinner.getEditor().setTextFormatter(priceFormatter3);
             maximum_discount_spinner.getEditor().setTextFormatter(priceFormatter4);
             shelf_life_spinner.getEditor().setTextFormatter(priceFormatter5);
             re_order_level_spinner.getEditor().setTextFormatter(priceFormatter6);
             unit_standard_measure_spinner.getEditor().setTextFormatter(priceFormatter7);
             sales_profit_margin_spinner.getEditor().setTextFormatter(priceFormatter8);
           //  System.out.println(buying_price_spinner.getEditor().getText());
           /* if(buying_price_spinner.getEditor().getText().equals("0.0")){
           buying_price_spinner.setStyle("-fx-control-inner-background: yellow;"
           + "-fx-text-fill: black;");
           }
           else{
           buying_price_spinner.setStyle("-fx-control-inner-background: green;"
           + "-fx-text-fill: white;");
           }*/
             
             
       // item_code.setStyle("-fx-text-fill: red;");
       
       if(rs.getString("TAXABLE").equals("Y")){
           taxable_chkbx.setSelected(true);
           taxable_chkbx.setText("Y");
       }
       else
       {
           taxable_chkbx.setSelected(false);
           taxable_chkbx.setText("N");
       }
        if(rs.getString("OPTION1").equals("Y")){
           message_alert_chkbx.setSelected(true);
        //   message_alert_chkbx.setText("Y");
       }
       else
       {
          message_alert_chkbx.setSelected(false);
         // message_alert_chkbx.setText("N");
       }
           if(rs.getString("OPTION2").equals("Y")){
           ref_no_chkbx.setSelected(true);
      //     ref_no_chkbx.setText("Y");
       }
       else
       {
          ref_no_chkbx.setSelected(false);
         // ref_no_chkbx.setText("N");
       }   
           
           if(rs.getString("DATA_OPTION").equals("Y")){
           allow_zero_price_chkbx.setSelected(true);
           allow_zero_price_chkbx.setText("Y");
       }
       else
       {
          allow_zero_price_chkbx.setSelected(false);
          allow_zero_price_chkbx.setText("N");
       }
           
          if(rs.getString("TAX_GROUP").equals("DFT")){
           tax_group_txtf.setText("Default 16%");
          }
          
          else
          if(rs.getString("TAX_GROUP").equals("No Tax")){
          tax_group_txtf.setText("NON");
          }
          else
              if(rs.getString("TAX_GROUP").equals("TX1")){
                  tax_group_txtf.setText("Tax Group 1");
              }
          else
                  if(rs.getString("TAX_GROUP").equals("TX2")){
                   tax_group_txtf.setText("Tax Group 2");   
                  }
          else
                  if(rs.getString("TAX_GROUP").equals("TX3")){
                   tax_group_txtf.setText("Tax Group 3");   
                  }
                   }
               }
               catch(Exception e){
                 e.printStackTrace();  
               }
        }
             
           void loadItemdetails2(){
               String load_item_details="SELECT * FROM ITEM_MASTER WHERE ITEM_CODE='"+item_code_txtf.getText()+"'";
                       conn=DBConnection.ConnectDB();
               try{
                   pst=conn.prepareStatement(load_item_details);
                   rs=pst.executeQuery();
                   while(rs.next()){
                      item_name_txtf.setText(rs.getString("ITEM_NAME")); 
                      item_type_txtf.setText(rs.getString("ITEM_TYPE"));
                      item_main_group_txtf.setText(rs.getString("ITEM_GROUP"));
                      item_sub_group_txtf.setText(rs.getString("SUB_GROUP"));
                      barcode_txtf.setText(rs.getString("BARCODE"));
                      barcode_type_txtf.setText(rs.getString("BARCODE_TYPE"));
                      pack_type_txtf.setText(rs.getString("PACK_TYPE"));
                      sales_uom_txtf.setText(rs.getString("IUOM"));
                      wholesale_uom_txtf.setText(rs.getString("WUOM"));
                      purchase_uom_txtf.setText(rs.getString("PUOM"));
                      ref_account_txtf.setText(rs.getString("ITEM_ACCOUNT"));
                      parent_item_txtf.setText(rs.getString("PARENT_ITEM"));
                      supplier_code_txtf.setText(rs.getString("SUPPLIER"));
                      manufacturers_txtf.setText(rs.getString("MANUFACTURER"));
                      short_description_txtArea.setText(rs.getString("DESCRIPTION"));
                      in_txtf.setText(rs.getString("MEASURE_TYPE"));
                      unit_of_measure_txtf.setText(rs.getString("SUOM"));
                      description_txtArea.setText(rs.getString("PACKAGE"));
                      
                     //  sales_price4.setText(String.valueOf(rs.getInt("SALE_PRICE")));
                     //  discount_percent.setText("0");
                     //  sale_quantity.setText("1");
                     //  calculateSalesAmount();
                      // sale-quantity.
                       TextFormatter<Double> priceFormatter = new TextFormatter<Double>(
        new DoubleStringConverter(), rs.getDouble("BUY_PRICE"), filter);
                       TextFormatter<Double> priceFormatter2 = new TextFormatter<Double>(
        new DoubleStringConverter(), rs.getDouble("SALE_PRICE"), filter);
                       TextFormatter<Double> priceFormatter3 = new TextFormatter<Double>(
        new DoubleStringConverter(), rs.getDouble("WHOLE_PRICE"), filter); 
                         TextFormatter<Double> priceFormatter4 = new TextFormatter<Double>(
                       new DoubleStringConverter(), rs.getDouble("DISCOUNT_RATE"), filter); 
                             TextFormatter<Double> priceFormatter5 = new TextFormatter<Double>(
                       new DoubleStringConverter(), rs.getDouble("SHELF_LIFE"), filter);
                             TextFormatter<Double> priceFormatter6 = new TextFormatter<Double>(
                       new DoubleStringConverter(), rs.getDouble("REORDER_LEVEL"), filter);
                               TextFormatter<Double> priceFormatter7 = new TextFormatter<Double>(
                       new DoubleStringConverter(), rs.getDouble("UNIT_MEASURE"), filter);
                                      TextFormatter<Double> priceFormatter8 = new TextFormatter<Double>(
                       new DoubleStringConverter(), rs.getDouble("PROFIT_MARGIN"), filter);
            //buying_price_spinner.getEditor().setText(String.valueOf(rs.getDouble("BUY_PRICE")));
            //System.out.println(rs.getDouble("BUY_PRICE"));
             purchase_unit_price_spinner.getEditor().setTextFormatter(priceFormatter);
             retail_sale_price_spinner.getEditor().setTextFormatter(priceFormatter2);
             wholesale_price_spinner.getEditor().setTextFormatter(priceFormatter3);
             maximum_discount_spinner.getEditor().setTextFormatter(priceFormatter4);
             shelf_life_spinner.getEditor().setTextFormatter(priceFormatter5);
             re_order_level_spinner.getEditor().setTextFormatter(priceFormatter6);
             unit_standard_measure_spinner.getEditor().setTextFormatter(priceFormatter7);
             sales_profit_margin_spinner.getEditor().setTextFormatter(priceFormatter8);
           //  System.out.println(buying_price_spinner.getEditor().getText());
           /* if(buying_price_spinner.getEditor().getText().equals("0.0")){
           buying_price_spinner.setStyle("-fx-control-inner-background: yellow;"
           + "-fx-text-fill: black;");
           }
           else{
           buying_price_spinner.setStyle("-fx-control-inner-background: green;"
           + "-fx-text-fill: white;");
           }*/
             
             
       // item_code.setStyle("-fx-text-fill: red;");
       
       if(rs.getString("TAXABLE").equals("Y")){
           taxable_chkbx.setSelected(true);
           taxable_chkbx.setText("Y");
       }
       else
       {
           taxable_chkbx.setSelected(false);
           taxable_chkbx.setText("N");
       }
        if(rs.getString("OPTION1").equals("Y")){
           message_alert_chkbx.setSelected(true);
        //   message_alert_chkbx.setText("Y");
       }
       else
       {
          message_alert_chkbx.setSelected(false);
         // message_alert_chkbx.setText("N");
       }
           if(rs.getString("OPTION2").equals("Y")){
           ref_no_chkbx.setSelected(true);
      //     ref_no_chkbx.setText("Y");
       }
       else
       {
          ref_no_chkbx.setSelected(false);
         // ref_no_chkbx.setText("N");
       }   
           
           if(rs.getString("DATA_OPTION").equals("Y")){
           allow_zero_price_chkbx.setSelected(true);
           allow_zero_price_chkbx.setText("Y");
       }
       else
       {
          allow_zero_price_chkbx.setSelected(false);
          allow_zero_price_chkbx.setText("N");
       }
           
          if(rs.getString("TAX_GROUP").equals("DFT")){
           tax_group_txtf.setText("Default 16%");
          }
          
          else
          if(rs.getString("TAX_GROUP").equals("No Tax")){
          tax_group_txtf.setText("NON");
          }
          else
              if(rs.getString("TAX_GROUP").equals("TX1")){
                  tax_group_txtf.setText("Tax Group 1");
              }
          else
                  if(rs.getString("TAX_GROUP").equals("TX2")){
                   tax_group_txtf.setText("Tax Group 2");   
                  }
          else
                  if(rs.getString("TAX_GROUP").equals("TX3")){
                   tax_group_txtf.setText("Tax Group 3");   
                  }
                   }
               }
               catch(Exception e){
                 e.printStackTrace(); 
                 /*               Image img = new Image("/images_/tick3.jpg");
                 Notifications recordNOTFOUND = Notifications.create()
                 .title("ITEM NOT FOUND!")
                 .text("Item not found.please try writing the full code for the item.Thank you!!")
                 .graphic(new ImageView(img))
                 .hideAfter(Duration.seconds(5))
                 .position(Pos.CENTER)
                 .onAction((ActionEvent event1) -> {
                 //System.out.println("Clicked on notification!");
                 });
                 
                 recordNOTFOUND.show();*/
     
               }
               }
      
               void loadMaskerPanel4(String result, String result2,String load_item_details){
                 Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                  loadItemDetails(result,result2,load_item_details);
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
                 
             }
               
                 void loadMaskerPanel(){
                 Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                 loadItemdetails2();
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
                 
             }
                 
                     void loadMaskerPanel2(){
                 Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                windowOpened();
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
                 
             }
                     
                     void loadMaskerPanel3(){
                 Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                  insertintoTable();
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
                 
             }
                     
                     
    void setSpinnerValue(Spinner<Double> spinner,double k){
        TextFormatter<Double> priceFormatter = new TextFormatter<Double>(
        new DoubleStringConverter(), k, filter);
        spinner.setValueFactory(new SpinnerValueFactory.DoubleSpinnerValueFactory(
        0.00, 10000.00, Double.parseDouble(INITIAL_VALUE)));
        spinner.setEditable(true);
        spinner.getEditor().setTextFormatter(priceFormatter); 
    }
    
    void insertintoTable(){
        
                    String sql2="insert into ITEM_MASTER("
             + "ITEM_CODE,"
             + "ITEM_NAME,"
             + "ITEM_TYPE,"
             + "SUB_GROUP,"
             + "BARCODE,"
             + "PACK_TYPE,"
             + "IUOM,"
             + "SUOM,"
             + "WUOM,"
             + "PUOM,"
             + "ITEM_ACCOUNT,"
             + "PARENT_ITEM,"
             + "SUPPLIER,"
             + "MANUFACTURER,"
             + "BUY_PRICE,"
             + "SALE_PRICE,"
             + "WHOLE_PRICE,"
             + "DISCOUNT_RATE,"
             + "REORDER_LEVEL,"
             + "UNIT_MEASURE,"
             + "SHELF_LIFE,"
             + "MEASURE_TYPE,"
             + "PACKAGE,"
             + "DESCRIPTION)"
             + "values('"+item_code_txtf.getText()+"',"
             + "'"+item_name_txtf.getText()+"',"
             + "'"+item_type_txtf.getText()+"',"
             + "'"+item_sub_group_txtf.getText()+"',"
             + "'"+barcode_txtf.getText()+"',"
             + "'"+pack_type_txtf.getText()+"',"
             + "'"+unit_of_measure_txtf.getText()+"',"
             + "'"+sales_uom_txtf.getText()+"',"
             + "'"+wholesale_uom_txtf.getText()+"',"
             + "'"+purchase_uom_txtf.getText()+"',"
             + "'"+ref_account_txtf.getText()+"',"
             + "'"+parent_item_txtf.getText()+"',"
             + "'"+supplier_code_txtf.getText()+"',"
             + "'"+manufacturers_txtf.getText()+"',"
             + "'"+Double.parseDouble(purchase_unit_price_spinner.getEditor().getText())+"',"
             + "'"+Double.parseDouble(retail_sale_price_spinner.getEditor().getText())+"',"
             + "'"+Double.parseDouble(wholesale_price_spinner.getEditor().getText())+"',"
             + "'"+Double.parseDouble(maximum_discount_spinner.getEditor().getText())+"',"
             + "'"+Double.parseDouble(re_order_level_spinner.getEditor().getText())+"',"
             + "'"+Double.parseDouble(unit_standard_measure_spinner.getEditor().getText())+"',"
             + "'"+Double.parseDouble(shelf_life_spinner.getEditor().getText())+"',"
             + "'"+in_txtf.getText()+"',"
             + "'"+description_txtArea.getText()+"',"
             + "'"+short_description_txtArea.getText()+"')";
             try{
             conn=DBConnection.ConnectDB();
             pst=conn.prepareStatement(sql2);
             pst.execute();
             Image img = new Image("/images_/tick3.jpg");
             Notifications recordSavedSuccessfully = Notifications.create()
             .title("Saved Successfully!!")
             .text("Record saved successfully.Thank you!!")
             .graphic(new ImageView(img))
             .hideAfter(Duration.seconds(5))
             .position(Pos.CENTER)
             .onAction((ActionEvent event1) -> {
             //System.out.println("Clicked on notification!");
             });
             recordSavedSuccessfully.show();
             }
             catch(Exception e){
             e.printStackTrace();
             }
         String pos_types="ITEM_GROUPS";
            String sub_code="###";
             String sql = "select minor_code from list_control where reference_code='"+pos_types+"' AND sub_code='"+sub_code+"' and description='"+item_main_group_txtf.getText()+"'";
             try{
                 conn=DBConnection.ConnectDB();
                 pst=conn.prepareStatement(sql);
                 rs=pst.executeQuery();
                 while(rs.next()){
                   System.out.println(rs.getString("MINOR_CODE"));
                   String sql3="update list_control set MINOR_CODE='"+rs.getString("MINOR_CODE")+"' where ITEM_CODE='"+item_code_txtf.getText()+"'";
                   try{
                      conn=DBConnection.ConnectDB();
                      pst=conn.prepareStatement(sql3);
                      pst.execute();
                      System.out.println("record updated successfully!!");
                   }
                   catch(Exception e){
                       e.printStackTrace();
                   }
       
                 }
                 
             }
             catch(Exception e){
                 e.printStackTrace();
             }
         
    }
                    void windowOpened(){
         //setSpinnerValue(transaction_quantity_spinner,0.00);
  //setSpinnerValue(buying_price_spinner,0.00);
 // showCurrentDateonload();
  // checkToseeifactiveCustomers_are_selected();
 //   loadStockAdjustmentDetailstable();
 //acc.setExpandedPane(stock_adjustment_transactions_tp);
 /*String sql= "SELECT * from JOURNAL_CONTROL WHERE JOURNAL_TYPE='ADJ'";
 loadStockAdjustmentDetailstable(sql);*/
    ///showCurrentDateonload();
    setSpinnerValue(purchase_unit_price_spinner,0.00);
    setSpinnerValue(retail_sale_price_spinner,0.00);
    setSpinnerValue(wholesale_price_spinner,0.00);
    setSpinnerValue(wholesale_auto_trigger_spinner,0.00);
    setSpinnerValue(maximum_discount_spinner,0.00);
    setSpinnerValue(sales_profit_margin_spinner,0.00);
    setSpinnerValue(re_order_level_spinner,0.00);
    setSpinnerValue(unit_standard_measure_spinner,0.00);
    setSpinnerValue(shelf_life_spinner,0.00);
    
      item_code_txtf.setStyle("-fx-control-inner-background: white;"
                     + "-fx-text-fill: blue;");
        item_name_txtf.setStyle("-fx-control-inner-background: white;"
                     + "-fx-text-fill: green;");
         last_added_item_txtf.setStyle("-fx-control-inner-background: white;"
                     + "-fx-text-fill: black;");

    Calendar now = Calendar.getInstance();   // Gets the current date and time
    int year = now.get(Calendar.YEAR);       // The current year
    int month = now.get(Calendar.MONTH)+1;
   //showCurrentDateonload();
//  journal_number_txtf.setText(this.Journal_Number);
 // item_location_txtf.setText(this.Item_Location);    
//  journal_quantity_txtf.setText(this.Journal_Quantity);  
 // journal_control_count_txtf.setText(this.Journal_Control_Count);
  //loadStockAdjustmentDetailstable();
    }
                    
     void isCheckBoxSelected(){
         if(by_profit_margin_chkbx.isSelected()==true){
             by_profit_margin_chkbx.setText("Y");
              allow_zero_price_chkbx.setText("N");
              allow_zero_price_chkbx.setDisable(true);
              allow_zero_price_chkbx.setSelected(false);
         }
         else{
             by_profit_margin_chkbx.setText("N");
             allow_zero_price_chkbx.setDisable(false);
         }
         
     }               

     void isCheckBoxSelected2(){
         if(allow_zero_price_chkbx.isSelected()==true){
             allow_zero_price_chkbx.setText("Y");
              by_profit_margin_chkbx.setText("N");
              by_profit_margin_chkbx.setSelected(false);
              //allow_zero_price_chkbx.setDisable(true);
             
         }
         else{
             allow_zero_price_chkbx.setText("N");
            // allow_zero_price_chkbx.setDisable(false);
         }
         
     }
     
     void isCheckBoxSelected3(){
         if(taxable_chkbx.isSelected()==true){
             taxable_chkbx.setText("Y");
             // by_profit_margin_chkbx.setText("N");
             // by_profit_margin_chkbx.setSelected(false);
              //allow_zero_price_chkbx.setDisable(true);
             
         }
         else{
             taxable_chkbx.setText("N");
            // allow_zero_price_chkbx.setDisable(false);
         }
         
     }
     
    @FXML
    void actionPerformed(ActionEvent event) {
        if(event.getSource().equals(insert_btn)){
           loadMaskerPanel3();
        }
        
        else
        if(event.getSource().equals(item_code_txtf)){
            loadMaskerPanel();
        }
        else
            if(event.getSource().equals(allow_zero_price_chkbx)){
                isCheckBoxSelected2();
            }
        else
                if(event.getSource().equals(by_profit_margin_chkbx)){
                    isCheckBoxSelected();
                }
        else
                    if(event.getSource().equals(taxable_chkbx)){
                    isCheckBoxSelected3();    
                    }
    }
         void loadtypeDetailsStage(String sql,String title,String x,String y,JFXTextField textfield,int a,int b) throws IOException{
         Scene scene3; 
             Stage  stage2 = new Stage();
              //String sql = "select minor_code,description from list_control where reference_code='"+pos_types+"' AND sub_code='"+sub_code+"'";
                
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_type Controller = new pos_type();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_type_details.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 Parent root3 = loader.load();
                // String x="DESCRIPTION";
                // String y="MINOR_CODE";
               //  String pos_types= "ITEM_TYPES";
                // String sub_code = "###";
                 loader.<pos_type>getController().loadtypesDetailstable(sql, x, y);
                 scene3 = new Scene(root3);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle(title);
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(a);
                 stage2.setY(b);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();ca
               stage2.showAndWait();

              String result = loader.<pos_type>getController().getResult2();
          
                if (result != null) {
        // if a result was selected, add it to the list
                  textfield.setText(result);
                 // ledger_name3.setText(result2);
         }
    }
         
              void loadtypeDetailsStage2(String sql,String title,String x,String y,JFXTextField textfield,int a,int b) throws IOException{
         Scene scene3; 
             Stage  stage2 = new Stage();
              //String sql = "select minor_code,description from list_control where reference_code='"+pos_types+"' AND sub_code='"+sub_code+"'";
                
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_type Controller = new pos_type();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_type_details.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 Parent root3 = loader.load();
                // String x="DESCRIPTION";
                // String y="MINOR_CODE";
               //  String pos_types= "ITEM_TYPES";
                // String sub_code = "###";
                 loader.<pos_type>getController().loadtypesDetailstable(sql, x, y);
                 scene3 = new Scene(root3);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle(title);
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(a);
                 stage2.setY(b);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();ca
               stage2.showAndWait();

              String result = loader.<pos_type>getController().getResult();
          
                if (result != null) {
        // if a result was selected, add it to the list
                  textfield.setText(result);
                 // ledger_name3.setText(result2);
         }
    }
         void getBarcode(){
             String barcode="select barcode from item_master where item_code='"+item_code_txtf.getText()+"'";
             try{
                 conn=DBConnection.ConnectDB();
                 pst=conn.prepareStatement(barcode);
                 rs=pst.executeQuery();
                 while(rs.next()){
                     barcode_txtf.setText(rs.getString("BARCODE"));
                 }
             }
             catch(Exception e){
                 e.printStackTrace();
             }
         }
         
           void loadCustomerDetailsStage(int x,int y) throws IOException{
        Scene scene3; 
               stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
             pos_suppliers Controller = new pos_suppliers();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_customers.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 Parent root3 = loader.load();
                 scene3 = new Scene(root3);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("Inventory Items");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(x);
                 stage2.setY(y);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();
               stage2.showAndWait();

              String result = loader.<pos_suppliers>getController().getResult();
              String result2= loader.<pos_suppliers>getController().getResult2();
              String result3= loader.<pos_suppliers>getController().getResult3();
              String result4=loader.<pos_suppliers>getController().getResult4();
             
                if (result != null) {
        // if a result was selected, add it to the list
                  supplier_code_txtf.setText(result);
                  Supplier_name_txtf.setText(result2);
                  if(result4 !=null){
                      /*try{
                      conn=DBConnection.ConnectDB();
                      pst=conn.prepareStatement(result4);
                      rs=pst.executeQuery();
                      while(rs.next()){
                      rs.getString("ORDER_NUMBER");
                      order_no.setText(rs.getString("ORDER_NUMBER"));
                      }
                      }
                      catch(Exception e){
                      e.printStackTrace();
                      }*/
                  }
                  if(result3 !=null){
                      /*                try{
                      conn=DBConnection.ConnectDB();
                      pst=conn.prepareStatement(result3);
                      rs= pst.executeQuery();
                      while(rs.next()){
                      
                      
                      
                      item_code.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, String> cellData) -> {
                      return cellData.getValue().item_codeProperty();
                      
                      });
                      
                      item_description.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, String> cellData) -> {
                      return cellData.getValue().item_descriptionProperty();
                      });
                      quantity.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                      return cellData.getValue().quantityProperty();
                      });
                      sales_price.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                      return cellData.getValue().sales_priceProperty();
                      });
                      sales_amount.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                      return cellData.getValue().sales_amountProperty();
                      });
                      discount.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                      return cellData.getValue().discountProperty();
                      });
                      taxable.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                      return cellData.getValue().taxableProperty();
                      });
                      tax_amount.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                      return cellData.getValue().tax_amountProperty();
                      });
                      item_location.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, String> cellData) -> {
                      return cellData.getValue().item_locationProperty();
                      });
                      
                      // pos_table.setItems(data);
                      
                      
                      
                      
                      
                      
                      item_description.setCellFactory(column -> {
                      return new TableCell<pos_details, String>() {
                      @Override
                      protected void updateItem(String item, boolean empty) {
                      super.updateItem(item, empty); //This is mandatory
                      
                      if (item == null || empty) { //If the cell is empty
                      setText(null);
                      setStyle("");
                      } else { //If the cell is not empty
                      
                      setText(item); //Put the String data in the cell
                      
                      //We get here all the info of the Person of this row
                      pos_details item_description2 = getTableView().getItems().get(getIndex());
                      
                      
                      
                      try{
                      if (item_description2.getITEM_DESCRIPTION().isEmpty()==false) {
                      setTextFill(Color.BLACK); //The text in red
                      setStyle("-fx-background-color:PALEGREEN"); //The background of the cell in yellow
                      
                      // pos_table.setItems(data);
                      // data.removeAll(data);
                      // pos_table.setItems(data);
                      
                      }   else {
                      //Here I see if the row of this cell is selected or not
                      if(getTableView().getSelectionModel().getSelectedItems().contains(item_description2))
                      setTextFill(Color.WHITE);
                      else
                      setTextFill(Color.BLACK);
                      }
                      
                      }
                      catch(Exception e){
                      e.printStackTrace();
                      }
                      
                      
                      }
                      }
                      };
                      });
                      quantity.setCellFactory(TableColumn ->{
                      return new TableCell<pos_details, Number>() {
                      @Override
                      protected void updateItem(Number item, boolean empty) {
                      super.updateItem(item, empty); //This is mandatory
                      
                      if (item == null || empty) { //If the cell is empty
                      setText(null);
                      setStyle("");
                      } else { //If the cell is not empty
                      
                      setText(String.valueOf(item)); //Put the String data in the cell
                      
                      //We get here all the info of the Person of this row
                      pos_details quantity2 = getTableView().getItems().get(getIndex());
                      
                      
                      try{
                      if (quantity2.getITEM_CODE().isEmpty()==false) {
                      setTextFill(Color.WHITE); //The text in red
                      setStyle("-fx-background-color: BLUE"); //The background of the cell in yellow
                      
                      }   else {
                      //Here I see if the row of this cell is selected or not
                      if(getTableView().getSelectionModel().getSelectedItems().contains(quantity2))
                      setTextFill(Color.WHITE);
                      else
                      setTextFill(Color.BLACK);
                      }
                      
                      
                      }
                      catch(Exception e){
                      e.printStackTrace();
                      }
                      
                      
                      }
                      }
                      };
                      });
                      
                      sales_amount.setCellFactory(TableColumn2 ->{
                      return new TableCell<pos_details, Number>() {
                      @Override
                      protected void updateItem(Number item2, boolean empty) {
                      super.updateItem(item2, empty); //This is mandatory
                      
                      if (item2 == null || empty) { //If the cell is empty
                      setText(null);
                      setStyle("");
                      } else { //If the cell is not empty
                      
                      setText(String.valueOf(item2)); //Put the String data in the cell
                      
                      //We get here all the info of the Person of this row
                      pos_details sales_amount2 = getTableView().getItems().get(getIndex());
                      
                      
                      try{
                      if (sales_amount2.getITEM_CODE().isEmpty()==false) {
                      setTextFill(Color.WHITE); //The text in red
                      setStyle("-fx-background-color: PURPLE"); //The background of the cell in yellow
                      
                      }   else {
                      //Here I see if the row of this cell is selected or not
                      if(getTableView().getSelectionModel().getSelectedItems().contains(sales_amount2))
                      setTextFill(Color.WHITE);
                      else
                      setTextFill(Color.BLACK);
                      }
                      
                      
                      }
                      catch(Exception e){
                      e.printStackTrace();
                      }
                      
                      
                      }
                      }
                      };
                      });
                      
                      //   if(pos_table.getSelectionModel().isEmpty()==true){
                      //      pos_table.setItems(data);
                      //  }
                      
                      
                      
                      
                      //else{
                      // pos_table.setEditable(true);le
                      
                      
                      //pos_table.setItems(data);
                      //  pos_table.setItems(data);
                      //}
                      // pos_table.setEditable(true);
                      
                      }
                      
                      
                      //  data.removeAll(data);
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      }
                      catch(Exception e){
                      // e.printStackTrace();
                      }*/    
                  }
                  
             
            
        
         }
                
    }     
         
    @FXML
    void onmouseClicked(MouseEvent event) {
        if(event.getSource().equals(item_type_lbl)){
        try {
            item_type_txtf.setStyle("-fx-control-inner-background: white;");
            String pos_types="ITEM_TYPES";
            String sub_code="###";
             String sql = "select minor_code,description from list_control where reference_code='"+pos_types+"' AND sub_code='"+sub_code+"'";
                
                loadtypeDetailsStage(sql,"TYPES","DESCRIPTION","MINOR_CODE",item_type_txtf,200,100);
            } catch (IOException ex) {
                Logger.getLogger(pos_item_master.class.getName()).log(Level.SEVERE, null, ex);
            }     
        }
        else
            if(event.getSource().equals(item_main_group_lbl)){
                if(!item_type_txtf.getText().equalsIgnoreCase("")){
                 try {
                     item_main_group_txtf.setStyle("-fx-control-inner-background: white;");
                String pos_types="ITEM_GROUPS";
            String sub_code="###";
             String sql = "select minor_code,description from list_control where reference_code='"+pos_types+"' AND sub_code='"+sub_code+"'";
             
                loadtypeDetailsStage(sql,"ITEM MAIN GROUPS","DESCRIPTION","MINOR_CODE",item_main_group_txtf,200,150);
            } catch (IOException ex) {
                Logger.getLogger(pos_item_master.class.getName()).log(Level.SEVERE, null, ex);
            }   
                }
                 else{
                               Image img = new Image("/images_/caution2.jpg");
                 Notifications recordNOTFOUND = Notifications.create()
                 .title("Caution!")
                 .text("Item Type field should not be empty.Thank you!!")
                 .graphic(new ImageView(img))
                 .hideAfter(Duration.seconds(5))
                 .position(Pos.CENTER)
                 .onAction((ActionEvent event1) -> {
                 //System.out.println("Clicked on notification!");
                 });
                 
                 recordNOTFOUND.show();
                 item_type_txtf.setStyle("-fx-control-inner-background: yellow;");
                }
                
            }
            else
        
            if(event.getSource().equals(item_sub_group_lbl)){
                if(!item_type_txtf.getText().equalsIgnoreCase("")|!item_main_group_txtf.getText().equalsIgnoreCase("")){
                try {
             String x="DESCRIPTION";
            String title="ITEM SUB GROUPS";
            String y="MINOR_CODE";
            String sub_code="###";
            // String sql = "select SUB_GROUP,SUB_GROUP_NAME,ITEM_GROUP from ITEM_SUBGROUPS WHERE GROUP_NAME = '"+item_main_group_txtf.getText()+"'";
             //System.out.println(sql);
             
            String pos_types="ITEM_GROUPS";
            String sub_code2="$$$";
            String extend_control="A";
       //String major_code="BVG";
       String getMINORCODE="select MINOR_CODE from list_control where description='"+item_main_group_txtf.getText()+"' and sub_code='"+sub_code+"'";
       try{
           conn=DBConnection.ConnectDB();
           pst=conn.prepareStatement(getMINORCODE);
           rs=pst.executeQuery();
           while(rs.next()){
              String sql="select * from list_control where LIST_CONTROL.REFERENCE_CODE='"+pos_types+"'  AND LIST_CONTROL.sub_code='"+sub_code2+"' AND EXTEND_CONTROL='"+extend_control+"' AND MAJOR_CODE='"+rs.getString("MINOR_CODE")+"'";
                loadtypeDetailsStage(sql,title,x,y,item_sub_group_txtf,200,200);   
           }
       }
       catch(Exception e){
           e.printStackTrace();
       }

          
                }
                catch(Exception e){
                    e.printStackTrace();
                }
                }
                else{
                               Image img = new Image("/images_/block_icon - Copy - Copy.jpg");
                 Notifications recordNOTFOUND = Notifications.create()
                 .title("Not Allowed!")
                 .text("Main Item field should not be empty.Thank you!!")
                 .graphic(new ImageView(img))
                 .hideAfter(Duration.seconds(5))
                 .position(Pos.CENTER)
                 .onAction((ActionEvent event1) -> {
                 //System.out.println("Clicked on notification!");
                 });
                 
                 recordNOTFOUND.show();
                 item_main_group_txtf.setStyle("-fx-control-inner-background: yellow;");
                }
               
            }
        else
                if(event.getSource().equals(barcode_lbl)){
                    if(!item_code_txtf.getText().equalsIgnoreCase("")){
                       getBarcode(); 
                    }
                    else{
                               Image img = new Image("/images_/caution2.jpg");
                 Notifications recordNOTFOUND = Notifications.create()
                 .title("Not Allowed!")
                 .text("Item Code Field should not be empty.Thank you!!")
                 .graphic(new ImageView(img))
                 .hideAfter(Duration.seconds(5))
                 .position(Pos.CENTER)
                 .onAction((ActionEvent event1) -> {
                 //System.out.println("Clicked on notification!");
                 });
                 
                 recordNOTFOUND.show();
                 item_code_txtf.setStyle("-fx-control-inner-background: yellow;");
                }
                    
                    
                }
        else
                    if(event.getSource().equals(barcode_type_lbl)){
                          try {
                     barcode_type_txtf.setStyle("-fx-control-inner-background: white;");
                String pos_types="BARCODE_TYPES";
            String sub_code="###";
             String sql = "select minor_code,description from list_control where reference_code='"+pos_types+"' AND sub_code='"+sub_code+"'";
             
                loadtypeDetailsStage(sql,"BARCODE TYPES","DESCRIPTION","MINOR_CODE",barcode_type_txtf,200,250);
            } catch (IOException ex) {
                Logger.getLogger(pos_item_master.class.getName()).log(Level.SEVERE, null, ex);
            }
                    }
        if(event.getSource().equals(pack_type_lbl)){
                          try {
                     pack_type_txtf.setStyle("-fx-control-inner-background: white;");
                String pos_types="PACK_TYPES";
            String sub_code="###";
             String sql = "select minor_code,description from list_control where reference_code='"+pos_types+"' AND sub_code='"+sub_code+"'";
             
                loadtypeDetailsStage(sql,"PACK TYPES","DESCRIPTION","MINOR_CODE",pack_type_txtf,200,300);
                 unit_of_measure_txtf.setText(pack_type_txtf.getText());
                 sales_uom_txtf.setText(pack_type_txtf.getText());
                 wholesale_uom_txtf.setText(pack_type_txtf.getText());
                 purchase_uom_txtf.setText(pack_type_txtf.getText());
            } catch (IOException ex) {
                Logger.getLogger(pos_item_master.class.getName()).log(Level.SEVERE, null, ex);
            }
                    }
         else
            if(event.getSource().equals(unit_of_measure_lbl)){
                if(!pack_type_txtf.getText().equalsIgnoreCase("")){
                   try {
             String pos_types="PACK_TYPE_NAME";
            String title="Unit of Measure";
            String sub_code="PACK_TYPE";
             String sql = "select PACK_TYPE,PACK_TYPE_NAME from ITEM_PACK_TYPES WHERE PACK_TYPE_NAME = '"+pack_type_txtf.getText()+"'";
             //System.out.println(sql);
                loadtypeDetailsStage(sql,title,pos_types,sub_code,unit_of_measure_txtf,200,350);
            } catch (IOException ex) {
                Logger.getLogger(pos_item_master.class.getName()).log(Level.SEVERE, null, ex);
            }   
                }
                   else{
                               Image img = new Image("/images_/block_icon - Copy - Copy.jpg");
                 Notifications recordNOTFOUND = Notifications.create()
                 .title("Not Allowed!")
                 .text("Pack Type Field should not be empty.Thank you!!")
                 .graphic(new ImageView(img))
                 .hideAfter(Duration.seconds(5))
                 .position(Pos.CENTER)
                 .onAction((ActionEvent event1) -> {
                 //System.out.println("Clicked on notification!");
                 });
                 
                 recordNOTFOUND.show();
                 pack_type_txtf.setStyle("-fx-control-inner-background: yellow;");
                }
              
            }
          else
            if(event.getSource().equals(sales_uom_lbl)){
                if(!pack_type_txtf.getText().equalsIgnoreCase("")){
                   try {
             String pos_types="PACK_TYPE_NAME";
            String title="Unit of Measure";
            String sub_code="PACK_TYPE";
             String sql = "select PACK_TYPE,PACK_TYPE_NAME from ITEM_PACK_TYPES WHERE PACK_TYPE_NAME = '"+pack_type_txtf.getText()+"'";
             //System.out.println(sql);
                loadtypeDetailsStage(sql,title,pos_types,sub_code,sales_uom_txtf,200,350);
            } catch (IOException ex) {
                Logger.getLogger(pos_item_master.class.getName()).log(Level.SEVERE, null, ex);
            }   
                }
                   else{
                               Image img = new Image("/images_/block_icon - Copy - Copy.jpg");
                 Notifications recordNOTFOUND = Notifications.create()
                 .title("Not Allowed!")
                 .text("Pack Type Field should not be empty.Thank you!!")
                 .graphic(new ImageView(img))
                 .hideAfter(Duration.seconds(5))
                 .position(Pos.CENTER)
                 .onAction((ActionEvent event1) -> {
                 //System.out.println("Clicked on notification!");
                 });
                 
                 recordNOTFOUND.show();
                 pack_type_txtf.setStyle("-fx-control-inner-background: yellow;");
                }
              
            }
        
         else
            if(event.getSource().equals(wholesale_uom_lbl)){
                if(!pack_type_txtf.getText().equalsIgnoreCase("")){
                   try {
             String pos_types="PACK_TYPE_NAME";
            String title="Unit of Measure";
            String sub_code="PACK_TYPE";
             String sql = "select PACK_TYPE,PACK_TYPE_NAME from ITEM_PACK_TYPES WHERE PACK_TYPE_NAME = '"+pack_type_txtf.getText()+"'";
             //System.out.println(sql);
                loadtypeDetailsStage(sql,title,pos_types,sub_code,wholesale_uom_txtf,200,400);
            } catch (IOException ex) {
                Logger.getLogger(pos_item_master.class.getName()).log(Level.SEVERE, null, ex);
            }   
                }
                   else{
                               Image img = new Image("/images_/block_icon - Copy - Copy.jpg");
                 Notifications recordNOTFOUND = Notifications.create()
                 .title("Not Allowed!")
                 .text("Pack Type Field should not be empty.Thank you!!")
                 .graphic(new ImageView(img))
                 .hideAfter(Duration.seconds(5))
                 .position(Pos.CENTER)
                 .onAction((ActionEvent event1) -> {
                 //System.out.println("Clicked on notification!");
                 });
                 
                 recordNOTFOUND.show();
                 pack_type_txtf.setStyle("-fx-control-inner-background: yellow;");
                }
              
            }
        
           else
            if(event.getSource().equals(purchase_uom_lbl)){
                if(!pack_type_txtf.getText().equalsIgnoreCase("")){
                   try {
             String pos_types="PACK_TYPE_NAME";
            String title="Unit of Measure";
            String sub_code="PACK_TYPE";
             String sql = "select PACK_TYPE,PACK_TYPE_NAME from ITEM_PACK_TYPES WHERE PACK_TYPE_NAME = '"+pack_type_txtf.getText()+"'";
             //System.out.println(sql);
                loadtypeDetailsStage(sql,title,pos_types,sub_code,purchase_uom_txtf,200,450);
            } catch (IOException ex) {
                Logger.getLogger(pos_item_master.class.getName()).log(Level.SEVERE, null, ex);
            }   
                }
                   else{
                               Image img = new Image("/images_/block_icon - Copy - Copy.jpg");
                 Notifications recordNOTFOUND = Notifications.create()
                 .title("Not Allowed!")
                 .text("Pack Type Field should not be empty.Thank you!!")
                 .graphic(new ImageView(img))
                 .hideAfter(Duration.seconds(5))
                 .position(Pos.CENTER)
                 .onAction((ActionEvent event1) -> {
                 //System.out.println("Clicked on notification!");
                 });
                 
                 recordNOTFOUND.show();
                 pack_type_txtf.setStyle("-fx-control-inner-background: yellow;");
                }
              
            }
        else
                if(event.getSource().equals(parent_item_lbl)){
            try {
                loadItemDetailsStage2(750,100);
            } catch (IOException ex) {
                Logger.getLogger(pos_item_master.class.getName()).log(Level.SEVERE, null, ex);
            }
                }
        else
                    if(event.getSource().equals(supplier_code_lbl)){
            try {
                loadCustomerDetailsStage(750,150);
            } catch (IOException ex) {
                Logger.getLogger(pos_item_master.class.getName()).log(Level.SEVERE, null, ex);
            }
                    }
        else
                
                    if(event.getSource().equals(tax_group_lbl)){
                          try {
                     tax_group_txtf.setStyle("-fx-control-inner-background: white;");
                String pos_types="TAX_GROUPS";
            String sub_code="###";
             String sql = "select minor_code,description from list_control where reference_code='"+pos_types+"' AND sub_code='"+sub_code+"'";
             
                loadtypeDetailsStage(sql,"TAX GROUPS","DESCRIPTION","MINOR_CODE",tax_group_txtf,1000,500);
            } catch (IOException ex) {
                Logger.getLogger(pos_item_master.class.getName()).log(Level.SEVERE, null, ex);
            }
                    }
        
            else
                
                    if(event.getSource().equals(manufacturers_lbl)){
                          try {
                     manufacturers_txtf.setStyle("-fx-control-inner-background: white;");
                String pos_types="MFG";
                //String sub_code="###";
                String sql = "select ledger_name,ledger_group from suppliers where ledger_group='"+pos_types+"'";
             
                loadtypeDetailsStage(sql,"TAX GROUPS","lEDGER_NAME","LEDGER_GROUP",manufacturers_txtf,750,150);
            } catch (IOException ex) {
                Logger.getLogger(pos_item_master.class.getName()).log(Level.SEVERE, null, ex);
            }
                    }
        
        else
                  
                
                    if(event.getSource().equals(in_lbl)){
                          try {
                     in_txtf.setStyle("-fx-control-inner-background: white;");
                String pos_types="MEASURE_TYPES";
            String sub_code="###";
             String sql = "select minor_code,description from list_control where reference_code='"+pos_types+"' AND sub_code='"+sub_code+"'";
             
                loadtypeDetailsStage2(sql,"Units of Measure","DESCRIPTION","MINOR_CODE",in_txtf,1000,500);
            } catch (IOException ex) {
                Logger.getLogger(pos_item_master.class.getName()).log(Level.SEVERE, null, ex);
            }
                    }
        else
                        if(event.getSource().equals(item_type_edit_lbl)){
                            pos_item_types_controller.main(null);
                        }
          else
                        if(event.getSource().equals(item_main_group_edit_lbl)){
                            pos_item_groups_controller.main(null);
                        }
                        else
                        if(event.getSource().equals(item_sub_group_edit_lbl)){
                            pos_item_sub_group_settings_controller.main(null);
                        }
          else
                        if(event.getSource().equals(pack_type_edit_lbl)){
                            pos_item_pack_types_controller.main(null);
                        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
       loadMaskerPanel2();
        
    }
    
    public static JFrame frame;
      public static JFXPanel fxPanel = new JFXPanel();
       public  void initAndShowGUI() {
        // This method is invoked on the EDT thread
       
        try{
          frame = new JFrame("ITEM MASTER FORM");
        frame.add(fxPanel);
        frame.setSize(2000, 1000);
        
        frame.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("../images_/mali_bg.png")));
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setResizable(true);
        frame.setLocationRelativeTo(null); 
       
        }
        catch(Exception e){
            e.printStackTrace();
        }
        
        
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                initFX(fxPanel);
               // loadComboBoxes();
            }
       });
    }
    
    
       private  void initFX(JFXPanel fxPanel) {
        // This method is invoked on the JavaFX thread
      
         //  Scene scene = createScene();
          // fxPanel.setScene(scene);
     try {
        Parent  root5 = FXMLLoader.load(getClass().getResource("pos_item_details.fxml"));
          Scene scene2 = new Scene(root5, 2000, 1000,Color.ALICEBLUE);
                scene2.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
            fxPanel.setScene(scene2);
            
            
           
        } catch (IOException exc) {
            exc.printStackTrace();
            System.exit(1);
        }
        
      
      
    }
    
     public static void main(String[] args) {
         SwingUtilities.invokeLater(new Runnable() {
             @Override
            public void run() {
              
                pos_item_master test = new pos_item_master();
                test.initAndShowGUI();
                
                
                
               
                
            }
        });
        
         
    }
}
