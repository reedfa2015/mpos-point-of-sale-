/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXDialog;
import com.jfoenix.controls.JFXRadioButton;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.function.UnaryOperator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.embed.swing.JFXPanel;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Accordion;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextFormatter;
import javafx.scene.control.TitledPane;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.util.converter.DoubleStringConverter;
import javafx.util.converter.IntegerStringConverter;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import maliplus.DBConnection;
import static maliplus_POS.Pos_Controller.stage2;
import org.controlsfx.control.MaskerPane;
/**
 *
 * @author PSL-STUFF
 */
public class pos_stock_transfer_journal implements Initializable{
    static Connection conn = null;
    static ResultSet rs = null;
    static PreparedStatement pst = null;
    
    

     @FXML
    private ScrollPane stock_adjustment_Root;

    @FXML
    private JFXButton insert_btn;

    @FXML
    private JFXButton save_btn;

    @FXML
    private JFXButton delete_btn;

    @FXML
    private JFXButton print_preview_btn;

    @FXML
    private JFXButton export_btn;

    @FXML
    private JFXButton approve_post_btn;

    @FXML
    private JFXButton customized_stock_result_btn;

    @FXML
    private JFXButton find_items_btn;

    @FXML
    private JFXButton refresh_btn;

    @FXML
    private JFXButton clear_btn;

    @FXML
    private JFXButton item_notes_btn;

    @FXML
    private JFXButton back_btn;

    @FXML
    private JFXDialog display_message_dgBox;

    @FXML
    private Accordion acc;

    @FXML
    private TitledPane stock_adjustment_transactions_tp;

    @FXML
    private JFXDialog quantity_display_message_dgbox;

    @FXML
    private JFXTextField type_txtf;

    @FXML
    private TableView<pos_transfer_journal_table> stock_adjustment_tbl;

    @FXML
    private TableColumn<pos_transfer_journal_table, String> item_code_tbnode;

    @FXML
    private TableColumn<pos_transfer_journal_table, String> item_name_tbnode;

    @FXML
    private TableColumn<pos_transfer_journal_table, String> item_price_tbnode;

    @FXML
    private TableColumn<pos_transfer_journal_table, Number> ordered_quantity_tbnode;

    @FXML
    private TableColumn<pos_transfer_journal_table, String> sent_quantity_tbnode;

    @FXML
    private TableColumn<pos_transfer_journal_table, String> received_quantity_tbnode;

    @FXML
    private TableColumn<pos_transfer_journal_table, String> comment_tbnode;
    
    
    @FXML
    private TableView<pos_stock_adjustments_initial_table> stock_adjustment_tb;

    @FXML
    private TableColumn<pos_stock_adjustments_initial_table, String> description2_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_initial_table, String> created_by_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_initial_table, String> date_created_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_initial_table, String> journal_number_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_initial_table, String> control_quantity_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_initial_table, String> count_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_initial_table, String> trn_location_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_initial_table, String> journal_status_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_initial_table, String> journal_date_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_initial_table, String> fiscal_year_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_initial_table, String> fiscal_month_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_initial_table, String> date_modified_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_initial_table, String> modified_by_tbnode;

    @FXML
    private JFXTextField control_account_txtf;

    @FXML
    private Label ledger_type_lbl;

    @FXML
    private Label trn_type_lbl;

    @FXML
    private Spinner<?> fiscal_year_spinner;

    @FXML
    private Spinner<?> month_spinner;

    @FXML
    private Label journal_number_lbl;

    @FXML
    private JFXTextField journal_number2_txtf;

    @FXML
    private JFXTextField journal_quantity_txtf;

    @FXML
    private JFXTextField journal_control_count_txtf;

    @FXML
    private Label item_location_lbl;

    @FXML
    private JFXTextField item_location_txtf;

    @FXML
    private JFXTextField description2_txtf1;

    @FXML
    private Label description_lbl2;

    @FXML
    private JFXRadioButton adjustments_rdbtn;

    @FXML
    private JFXRadioButton stock_taking_rdbtn;

    @FXML
    private DatePicker stcoking_date_dtpicker;

    @FXML
    private Text transaction_quantity_text;

    @FXML
    private Label item_code_lbl;

    @FXML
    private JFXTextField item_code_txtf;

    @FXML
    private JFXTextField item_name_txtf;

    @FXML
    private Spinner<Double> transaction_quantity_spinner;
    
    @FXML
    private Spinner<Double> sent_quantity_spinner;
    
    @FXML
    private Spinner<Double> received_quantity_spinner;

    @FXML
    private Spinner<?> buying_price_spinner;

    @FXML
    private JFXTextField description2_txtf;

    @FXML
    private Label journal_display_message_lbl;

    @FXML
    private Label uom_lbl;

    @FXML
    private Label barcode_lbl;

    @FXML
    private Label supplier_lbl;

    @FXML
    private JFXTextField supplier_txtf;

    @FXML
    private Label replicate_supplier_code_lbl;

    @FXML
    private Label type_lbl;

    @FXML
    private JFXTextField barcode_txtf;
    
    @FXML
    private Label from_location_lbl;
    
    @FXML
    private Label via_location_lbl;
            
    @FXML
    private Label to_location_lbl;

    
    @FXML
    private MaskerPane masker;
    
    @FXML
    private JFXRadioButton stock_transfer_rdbtn;

    @FXML
    private JFXRadioButton internal_stock_transfer_rdbtn;

    @FXML
    private JFXTextField uom_txtf;

    @FXML
    private Label description_lbl;
    
    @FXML
    private DatePicker date_created_dtPicker;

    @FXML
    private DatePicker date_sent_dtPicker;

    @FXML
    private DatePicker date_received_dtPicker;
    
    @FXML
    private JFXTextField from_location_txtf;
     @FXML
    private JFXTextField via_location_txtf;
      @FXML
    private JFXTextField to_location_txtf;
      
       @FXML
    private JFXCheckBox confirm_order_chkbx;
       
       @FXML
    private JFXCheckBox sent_chkbx;
       @FXML
    private JFXCheckBox received_chkbx;
    
    final ObservableList<pos_transfer_journal_table> data2= FXCollections.observableArrayList();
           public  void loadStockAdjustmentDetailstable(String sql){
               conn=DBConnection.ConnectDB();
          
                        try{
                       pst=conn.prepareStatement(sql);
                       rs= pst.executeQuery();
                       while(rs.next()){ 
                           data2.add(new pos_transfer_journal_table(
                           rs.getString("ITEM_CODE"),
                           rs.getString("DESCRIPTION"),
                           rs.getDouble("QUANTITY"),
                           rs.getString("SENT_QUANTITY"),
                           rs.getString("RECEIVED_QUANTITY"),
                           rs.getString("COMMENT")
                           ));
        item_code_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_transfer_journal_table, String> cellData) -> {
            return cellData.getValue().item_codeProperty();
     
        });
        item_name_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_transfer_journal_table, String> cellData) -> {
            return cellData.getValue().item_nameProperty();
     
            
        });
        ordered_quantity_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_transfer_journal_table, Number> cellData) -> {
            return cellData.getValue().ordered_quantityProperty();
     
        });
       sent_quantity_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_transfer_journal_table, String> cellData) -> {
            return cellData.getValue().sent_quantityProperty();
     
        });
        received_quantity_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_transfer_journal_table, String> cellData) -> {
            return cellData.getValue().received_quantityProperty();
     
        });
        comment_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_transfer_journal_table, String> cellData) -> {
            return cellData.getValue().commentProperty();
     
        });
       
       
            
       
       
      
      
        
        

     
       // item_code.setStyle("-fx-control-inner-background: yellow;");
       // item_code.setStyle("-fx-text-fill: red;");
       // item_description.setStyle("-fx-text-fill: green;");
       // quantity.setStyle("-fx-text-fill: blue;");
       // sales_price.setStyle("-fx-text-fill: orange;");
       // sales_amount.setStyle("-fx-text-fill: purple;");
       // discount.setStyle("-fx-text-fill: red;");
       // taxable.setStyle("-fx-text-fill: violet;");
       // tax_amount.setStyle("-fx-text-fill: blue;");
       // item_location.setStyle("-fx-text-fill: grey;");
       // display.setStyle(" -fx-font-size: 14px;");
       
  
                           stock_adjustment_tbl.setItems(data2);
                           
                         item_name_tbnode.setCellFactory(column -> {
    return new TableCell<pos_transfer_journal_table, String>() {
        @Override
        protected void updateItem(String item_name, boolean empty) {
            super.updateItem(item_name, empty); //This is mandatory

            if (item_name == null || empty) { //If the cell is empty
                setText(null);
                setStyle("");
            } else { //If the cell is not empty

                setText(item_name); //Put the String data in the cell

                //We get here all the info of the Person of this row
                pos_transfer_journal_table item_name2 = getTableView().getItems().get(getIndex());
               

     
                try{
                if (item_name2.getITEM_NAME().isEmpty()==false) {
                    setTextFill(Color.BLACK); //The text in red
                    setStyle("-fx-background-color:PALEGREEN"); //The background of the cell in yellow
                    
                }   else {
                    //Here I see if the row of this cell is selected or not
                    if(getTableView().getSelectionModel().getSelectedItems().contains(item_name2))
                        setTextFill(Color.WHITE);
                    else
                        setTextFill(Color.BLACK);
                }
    
                }
                catch(Exception e){
                    e.printStackTrace();
                }
                
              
            }
        }
    };
});             
           
    
                       }
                    //   pst.close();
                    //   rs.close();
                   }
                   catch(Exception e2){
                      e2.printStackTrace();
                   } 
}
           
           final ObservableList<pos_stock_adjustments_initial_table> data3= FXCollections.observableArrayList();
           public  void loadStocktransferInitialDetailstable(String sql){
               conn=DBConnection.ConnectDB();
          
                        try{
                       pst=conn.prepareStatement(sql);
                       rs= pst.executeQuery();
                       while(rs.next()){ 
                           data3.add(new pos_stock_adjustments_initial_table(
                           rs.getString("DESCRIPTION"),
                           rs.getString("CREATED_BY"),
                           rs.getString("DATE_CREATED"),
                           rs.getString("JOURNAL_NUMBER"),
                           rs.getString("CONTROL_QUANTITY"),
                           rs.getString("CONTROL_COUNT"),
                           rs.getString("TRN_LOCATION"),
                           rs.getString("JOURNAL_STATUS"),
                           rs.getString("JOURNAL_DATE"),
                           rs.getString("FISCAL_YEAR"),
                           rs.getString("FISCAL_MONTH"),
                           rs.getString("DATE_MODIFIED"),
                           rs.getString("MODIFIED_BY")
                           ));
        description2_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_initial_table, String> cellData) -> {
            return cellData.getValue().descriptionProperty();
     
        });
        created_by_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_initial_table, String> cellData) -> {
            return cellData.getValue().created_byProperty();
     
        });
        date_created_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_initial_table, String> cellData) -> {
            return cellData.getValue().date_createdProperty();
     
        });
        journal_number_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_initial_table, String> cellData) -> {
            return cellData.getValue().journal_numberProperty();
     
        });
        control_quantity_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_initial_table, String> cellData) -> {
            return cellData.getValue().control_quantityProperty();
     
        });
        count_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_initial_table, String> cellData) -> {
            return cellData.getValue().countProperty();
     
        });
        trn_location_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_initial_table, String> cellData) -> {
            return cellData.getValue().trn_locationProperty();
     
        });
        journal_status_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_initial_table, String> cellData) -> {
            return cellData.getValue().journal_statusProperty();
     
        });
        journal_date_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_initial_table, String> cellData) -> {
            return cellData.getValue().journal_dateProperty();
     
        });
        fiscal_year_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_initial_table, String> cellData) -> {
            return cellData.getValue().fiscal_yearProperty();
     
        });
        fiscal_month_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_initial_table, String> cellData) -> {
            return cellData.getValue().fiscal_monthProperty();
     
        });
        date_modified_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_initial_table, String> cellData) -> {
            return cellData.getValue().date_modifiedProperty();
     
        });
        modified_by_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_initial_table, String> cellData) -> {
            return cellData.getValue().modified_byProperty();
     
        });
            
       
       
      
      
        
        

     
       // item_code.setStyle("-fx-control-inner-background: yellow;");
       // item_code.setStyle("-fx-text-fill: red;");
       // item_description.setStyle("-fx-text-fill: green;");
       // quantity.setStyle("-fx-text-fill: blue;");
       // sales_price.setStyle("-fx-text-fill: orange;");
       // sales_amount.setStyle("-fx-text-fill: purple;");
       // discount.setStyle("-fx-text-fill: red;");
       // taxable.setStyle("-fx-text-fill: violet;");
       // tax_amount.setStyle("-fx-text-fill: blue;");
       // item_location.setStyle("-fx-text-fill: grey;");
       // display.setStyle(" -fx-font-size: 14px;");
       
  
                           stock_adjustment_tb.setItems(data3);
                           
                         description2_tbnode.setCellFactory(column -> {
    return new TableCell<pos_stock_adjustments_initial_table, String>() {
        @Override
        protected void updateItem(String item, boolean empty) {
            super.updateItem(item, empty); //This is mandatory

            if (item == null || empty) { //If the cell is empty
                setText(null);
                setStyle("");
            } else { //If the cell is not empty

                setText(item); //Put the String data in the cell

                //We get here all the info of the Person of this row
                pos_stock_adjustments_initial_table description2 = getTableView().getItems().get(getIndex());
               

     
                try{
                if (description2.getDESCRIPTION().isEmpty()==false) {
                    setTextFill(Color.BLACK); //The text in red
                    setStyle("-fx-background-color:PALEGREEN"); //The background of the cell in yellow
                    
                }   else {
                    //Here I see if the row of this cell is selected or not
                    if(getTableView().getSelectionModel().getSelectedItems().contains(description2))
                        setTextFill(Color.WHITE);
                    else
                        setTextFill(Color.BLACK);
                }
    
                }
                catch(Exception e){
                    e.printStackTrace();
                }
                
              
            }
        }
    };
});             
           
     journal_number_tbnode.setCellFactory(column -> {
    return new TableCell<pos_stock_adjustments_initial_table, String>() {
        @Override
        protected void updateItem(String item, boolean empty) {
            super.updateItem(item, empty); //This is mandatory

            if (item == null || empty) { //If the cell is empty
                setText(null);
                setStyle("");
            } else { //If the cell is not empty

                setText(item); //Put the String data in the cell

                //We get here all the info of the Person of this row
                pos_stock_adjustments_initial_table journal_number2 = getTableView().getItems().get(getIndex());
               

     
                try{
                if (journal_number2.getJOURNAL_NUMBER().isEmpty()==false) {
                    setTextFill(Color.WHITE); //The text in red
                    setStyle("-fx-background-color:PURPLE"); //The background of the cell in yellow
                    
                }   else {
                    //Here I see if the row of this cell is selected or not
                    if(getTableView().getSelectionModel().getSelectedItems().contains(journal_number2))
                        setTextFill(Color.WHITE);
                    else
                        setTextFill(Color.BLACK);
                }
    
                }
                catch(Exception e){
                    e.printStackTrace();
                }
                
              
            }
        }
    };
}); 
                       }
                    //   pst.close();
                    //   rs.close();
                   }
                   catch(Exception e2){
                      e2.printStackTrace();
                   } 
}
           void selectRadioButton1(
                   JFXRadioButton button1,
                   JFXRadioButton button2,
                   JFXTextField textfield1,
                   JFXCheckBox checkbox1,
                   JFXTextField textfield2,
                   JFXCheckBox checkbox2,
                   DatePicker dtPicker1,
                   DatePicker dtPicker2,
                   JFXTextField textfield3,
                   JFXCheckBox checkbox3,
                   DatePicker dtPicker3
                   ){
               if(button1.isSelected()){
                  //button2.setSelected(false);
                 //  button1.setSelectedColor(Color.GREEN);
                 //  button2.setSelected(true);
                  // button1.setDisable(true);
                  // button2.setDisable(false);
                 //  button2.setSelectedColor(Color.RED);
                   button2.setSelected(false);
                   textfield1.setEditable(true);
                   checkbox1.setSelected(true);
                   textfield2.setEditable(true);
                   checkbox2.setSelected(true);
                   dtPicker1.getEditor().setDisable(false);
                   dtPicker1.getEditor().setText("");
                   dtPicker2.getEditor().setDisable(false);
                   dtPicker2.getEditor().setText("");
                   textfield3.setEditable(false);
                   textfield3.setText("");
                   checkbox3.setSelected(false);
                   dtPicker3.getEditor().setDisable(true);
                   dtPicker3.getEditor().setText("");
                   dtPicker3.setDisable(true);
                   
               }
              else{
                  button2.setSelected(true);
                  checkbox1.setSelected(true);
                  checkbox3.setSelected(false);
                  checkbox2.setSelected(true);
                  textfield1.setEditable(true);
                  textfield3.setEditable(true);
                  textfield2.setEditable(true);
                  dtPicker1.getEditor().setDisable(false);
                  dtPicker3.getEditor().setDisable(false);
                  dtPicker3.setDisable(false);
                  dtPicker2.getEditor().setDisable(false);
               }
                   //button2.setSelected(true);
                   // button2.setSelectedColor(Color.GREEN);
                   // button1.setSelected(false);
                  // button1.setSelectedColor(Color.RED);
                  /* checkbox1.setSelected(true);
                  checkbox3.setSelected(false);
                  checkbox2.setSelected(true);
                  textfield1.setEditable(true);
                  textfield3.setEditable(true);
                  textfield2.setEditable(true);
                  dtPicker1.getEditor().setDisable(true);
                  dtPicker3.getEditor().setDisable(false);
                  dtPicker2.getEditor().setDisable(true);*/
              // }
               
           }
           void selectRadioButton2(
            JFXRadioButton button1,
                   JFXRadioButton button2,
                   JFXTextField textfield1,
                   JFXCheckBox checkbox1,
                   JFXTextField textfield2,
                   JFXCheckBox checkbox2,
                   DatePicker dtPicker1,
                   DatePicker dtPicker2,
                   JFXTextField textfield3,
                   JFXCheckBox checkbox3,
                   DatePicker dtPicker3
           
           ){
                  if(button2.isSelected()){
                    button1.setSelected(false);
                  // button2.setSelected(true);
                  // button2.setSelectedColor(Color.GREEN);
                   //button2.setDisable(true);
                   //button1.setDisable(false);
                  // button1.setSelected(true);
                   //button1.setSelectedColor(Color.RED);
                   checkbox1.setSelected(true);
                   checkbox3.setSelected(true);
                   checkbox2.setSelected(true);
                   textfield1.setEditable(true);
                   textfield3.setEditable(true);
                   textfield2.setEditable(true);
                   dtPicker1.getEditor().setDisable(false);
                   dtPicker3.getEditor().setDisable(false);
                   dtPicker3.setDisable(false);
                   dtPicker2.getEditor().setDisable(false);
                   }
                  else{
                      button1.setSelected(true);
                      textfield1.setEditable(true);
                  checkbox1.setSelected(true);
                  textfield2.setEditable(true);
                  checkbox2.setSelected(true);
                  dtPicker1.getEditor().setDisable(false);
                  dtPicker2.getEditor().setDisable(false);
                  textfield3.setEditable(false);
                  textfield3.setText("");
                  checkbox3.setSelected(false);
                  dtPicker3.getEditor().setDisable(true);
                  dtPicker3.setDisable(true);
                  dtPicker3.getEditor().setText("");
                  }
                  // button1.setSelected(true);
                  // button2.setSelected(false);
                //   button1.setSelectedColor(Color.GREEN);
                  // button2.setSelected(false);
                  // button2.setSelectedColor(Color.RED); 
                  /* textfield1.setEditable(true);
                  checkbox1.setSelected(true);
                  textfield2.setEditable(true);
                  checkbox2.setSelected(true);
                  dtPicker1.getEditor().setDisable(true);
                  dtPicker2.getEditor().setDisable(true);
                  textfield3.setEditable(false);
                  checkbox3.setSelected(false);
                  dtPicker3.getEditor().setDisable(false);*/
                   //} 
           }
           
           void sent_chkbx_isSelected(
                   
               DatePicker dtPicker1,
               JFXTextField textfield,
               JFXRadioButton Button,
               JFXRadioButton Button2){
               if(sent_chkbx.isSelected()==true){
                dtPicker1.setDisable(false);
               dtPicker1.getEditor().setDisable(false);
               textfield.setEditable(true);
               Button.setSelected(true);
                 selectRadioButton2(
                internal_stock_transfer_rdbtn,
                stock_transfer_rdbtn,
                from_location_txtf,
                confirm_order_chkbx,
                to_location_txtf,
                received_chkbx,
                date_created_dtPicker,
                date_received_dtPicker,
                via_location_txtf,
                sent_chkbx,
                date_sent_dtPicker 
        );   
               }
               else
               {
                   dtPicker1.setDisable(true);
                   dtPicker1.getEditor().setDisable(true);
                   textfield.setEditable(false);
                   Button.setSelected(false);
                   Button2.setSelected(true);
                   selectRadioButton1(
                internal_stock_transfer_rdbtn,
                stock_transfer_rdbtn,
                from_location_txtf,
                confirm_order_chkbx,
                to_location_txtf,
                received_chkbx,
                date_created_dtPicker,
                date_received_dtPicker,
                via_location_txtf,
                sent_chkbx,
                date_sent_dtPicker 
        ); 
                   
               }
               
               
           }
              void loadBarcodeDetailsonEnter(){
          conn=DBConnection.ConnectDB();
          String sql="SELECT ITEM_CODE,ITEM_NAME,BARCODE,DATE_CREATED,IUOM FROM ITEM_MASTER WHERE barcode='"+barcode_txtf.getText()+"'";
               try{
                   pst=conn.prepareStatement(sql);
                   rs=pst.executeQuery();
                   while(rs.next()){
                       item_code_txtf.setText(rs.getString("ITEM_CODE"));
                       item_name_txtf.setText(rs.getString("ITEM_NAME"));
                       barcode_txtf.setText(String.valueOf(rs.getInt("BARCODE")));
                       date_created_dtPicker.getEditor().setText(String.valueOf(rs.getDate("DATE_CREATED")));
                       uom_txtf.setText(rs.getString("IUOM"));
                       //calculateSalesAmount();
                      // sale-quantity.
                       
                   }
               }
               catch(Exception e){
                 e.printStackTrace();  
               }
    }

    @FXML
    void actionPerformed(ActionEvent event) throws IOException {
        if(event.getSource()==internal_stock_transfer_rdbtn){
         selectRadioButton1(
                internal_stock_transfer_rdbtn,
                stock_transfer_rdbtn,
                from_location_txtf,
                confirm_order_chkbx,
                to_location_txtf,
                received_chkbx,
                date_created_dtPicker,
                date_received_dtPicker,
                via_location_txtf,
                sent_chkbx,
                date_sent_dtPicker 
        );   
        }
        else
            if(event.getSource()==stock_transfer_rdbtn){
              selectRadioButton2(
                internal_stock_transfer_rdbtn,
                stock_transfer_rdbtn,
                from_location_txtf,
                confirm_order_chkbx,
                to_location_txtf,
                received_chkbx,
                date_created_dtPicker,
                date_received_dtPicker,
                via_location_txtf,
                sent_chkbx,
                date_sent_dtPicker 
        );   
            }
        else
                if(event.getSource()==sent_chkbx){
                    sent_chkbx_isSelected(
                    date_sent_dtPicker,
                    via_location_txtf,
                    stock_transfer_rdbtn,
                    internal_stock_transfer_rdbtn
                    
                    
                    
                    );
                }
        else
                    if(event.getSource()==item_code_txtf){
                        getItemcodeandItemname();
                    }
        else
                             if(event.getSource()==from_location_txtf){
            Stage stage2=null;
            Scene scene = null;
            Parent root=null;
            String From_Location_Title="From Location";
            String fxml_Path="pos_details_panel.fxml";
           loadlocationStage(
           stage2,
           scene,
           root,
           from_location_txtf,
           100,
           300,
           From_Location_Title,
           fxml_Path
           );
        }
        else
            if(event.getSource()==via_location_txtf){
                Stage stage3=null;
                Scene scene3=null;
                Parent root3=null;
                String via_location_title="Via Location";
                String fxm_Path="pos_details_panel.fxml";
                loadlocationStage(
                stage3,
                scene3,
                root3,
                via_location_txtf,
                400,
                300,
                via_location_title,
                fxm_Path
                );
            }
        else
                if(event.getSource()==to_location_txtf){
                Stage stage4=null;
                Scene scene4=null;
                Parent root4=null;
                String to_location_title="To Location";
                String fxm_Path="pos_details_panel.fxml";
                loadlocationStage(
                stage4,
                scene4,
                root4,
                to_location_txtf,
                800,
                300,
                to_location_title,
                fxm_Path
                );
            }
        else
                    if(event.getSource()==type_txtf){
                        loadtypeDetailsStage();
                    }
        else
                        if(event.getSource()==barcode_txtf){
                        loadBarcodeDetailsonEnter();    
                        }
       else
                  if(event.getSource()==insert_btn){
                    
                      
                  }          
       
        
         
    }
         void loadtypeDetailsStage() throws IOException{
         Scene scene3; 
             Stage  stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_type Controller = new pos_type();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_type_details.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 Parent root3 = loader.load();
                 String x="DESCRIPTION";
                 String y="MINOR_CODE";
                 String pos_types= "DOCUMENT_TYPES";
                 String sub_code = "###";
                 String sql = "select minor_code,description from list_control where reference_code='"+pos_types+"' AND sub_code='"+sub_code+"'";
                 loader.<pos_type>getController().loadtypesDetailstable(sql, x, y);
                 scene3 = new Scene(root3);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("TYPE");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(750);
                 stage2.setY(50);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();ca
               stage2.showAndWait();

              String result = loader.<pos_type>getController().getResult();
          
                if (result != null) {
        // if a result was selected, add it to the list
                  type_txtf.setText(result);
                  type_txtf.requestFocus();
                 // ledger_name3.setText(result2);
         }
    }
    final KeyCombination keyComb1 = new KeyCodeCombination(KeyCode.F,KeyCombination.CONTROL_ANY);
         KeyCombination keyComb2 = new KeyCodeCombination(KeyCode.E,KeyCombination.CONTROL_ANY);
         
         
         void loadItemDetails(String result,String result2,String load_item_details){
               // if a result was selected, add it to the list
                  item_code_txtf.setText(result);
                  item_name_txtf.setText(result2);
                 
               conn=DBConnection.ConnectDB();
               try{
                   pst=conn.prepareStatement(load_item_details);
                   rs=pst.executeQuery();
                   while(rs.next()){
                      barcode_txtf.setText(rs.getString("BARCODE"));
                      uom_txtf.setText(rs.getString("IUOM"));
                     //  sales_price4.setText(String.valueOf(rs.getInt("SALE_PRICE")));
                     //  discount_percent.setText("0");
                     //  sale_quantity.setText("1");
                     //  calculateSalesAmount();
                      // sale-quantity.
                      /*   TextFormatter<Double> priceFormatter2 = new TextFormatter<>(
                      new DoubleStringConverter(), rs.getDouble("BUY_PRICE"), filter);*/
            //buying_price_spinner.getEditor().setText(String.valueOf(rs.getDouble("BUY_PRICE")));
            //System.out.println(rs.getDouble("BUY_PRICE"));
            // buying_price_spinner.getEditor().setTextFormatter(priceFormatter2);
           //  System.out.println(buying_price_spinner.getEditor().getText());
           /*if(buying_price_spinner.getEditor().getText().equals("0.0")){
           buying_price_spinner.setStyle("-fx-control-inner-background: yellow;"
           + "-fx-text-fill: black;");
           }
           else{
           buying_price_spinner.setStyle("-fx-control-inner-background: green;"
           + "-fx-text-fill: white;");
           }*/
             
             
       // item_code.setStyle("-fx-text-fill: red;");
                       
                   }
               }
               catch(Exception e){
                 e.printStackTrace();  
               }
         }
              void loadItemDetailsStage() throws IOException{
      
               stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_items Controller = new pos_items();
             // primarystage = (Stage) Controller.getScene().getWindow(); 
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_item_details_panel.fxml"));
              /*  loader.<pos_items>getController();
              Controller.setsearch_item2(item_code_txtf.getText());*/
              
            
              loader.setController(Controller);
               Parent  root4 = loader.load();
                Scene  scene3 = new Scene(root4);
                // scene3.setRoot(root4);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("ITEM DETAILS");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(125);
                 stage2.setY(200);
               // loader.<pos_item_filter>getController().setController(this);
                // stage2.show();
               stage2.showAndWait();
               //find.setText("");
              String result = loader.<pos_items>getController().getResult();
              String result2= loader.<pos_items>getController().getResult2();
              String load_item_details= loader.<pos_items>getController().getResult5();     
                if (result != null) {
                    loadMaskerPane4(result,result2,load_item_details);
                  }
               
                   
                
    }
    @FXML
    void keyReleased(KeyEvent event) {

    }

    @FXML
    void keyReleasedhandle(KeyEvent event) {
         if(event.getSource()==stock_adjustment_Root){
          if (keyComb1.match(event)) {
        try {
        loadItemDetailsStage();
        } catch (IOException ex) {
        Logger.getLogger(pos_stock_adjustment_initial.class.getName()).log(Level.SEVERE, null, ex);
        }
        }  
          /* else
          if (keyComb2.match(event)) {
          stock_adjustment_Root.getScene().getWindow().hide();
          }*/
       }
    }

               void loadlocationStage(
                       Stage stage,
                       Scene scene,
                       Parent root,
                       JFXTextField textfield,
                       int x,
                       int y,
                       String title,
                       String fxm_Path
               ) throws IOException {
       
          
                stage = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_locations Controller = new pos_locations();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource(""+fxm_Path+""));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 root = loader.load();
                scene = new Scene(root);
                 scene.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage.setScene(scene);
                 stage.setTitle(""+title+"");
                 stage.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage.setResizable(false);
                 
                 stage.setX(x);
                 stage.setY(y);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();
               stage.showAndWait();

              String result = loader.<pos_locations>getController().getResult();

                if (result != null) {
        // if a result was selected, add it to the list
                 textfield.setText(result);
                 textfield.requestFocus();
         }
                 
               
                 
    }
    @FXML
    void mouseClicked(MouseEvent event) throws IOException {
        if(event.getSource()==from_location_lbl){
            Stage stage2=null;
            Scene scene = null;
            Parent root=null;
            String From_Location_Title="From Location";
            String fxml_Path="pos_details_panel.fxml";
           loadlocationStage(
           stage2,
           scene,
           root,
           from_location_txtf,
           100,
           300,
           From_Location_Title,
           fxml_Path
           );
        }
        else
            if(event.getSource()==via_location_lbl){
                Stage stage3=null;
                Scene scene3=null;
                Parent root3=null;
                String via_location_title="Via Location";
                String fxm_Path="pos_details_panel.fxml";
                loadlocationStage(
                stage3,
                scene3,
                root3,
                via_location_txtf,
                400,
                300,
                via_location_title,
                fxm_Path
                );
            }
        else
                if(event.getSource()==to_location_lbl){
                Stage stage4=null;
                Scene scene4=null;
                Parent root4=null;
                String to_location_title="To Location";
                String fxm_Path="pos_details_panel.fxml";
                loadlocationStage(
                stage4,
                scene4,
                root4,
                to_location_txtf,
                800,
                300,
                to_location_title,
                fxm_Path
                );
            }
        else
                    if(event.getSource()==type_lbl){
                    loadtypeDetailsStage();
                    }
        else
                        if(event.getSource()==item_location_lbl){
         
                Stage stage4=null;
                Scene scene4=null;
                Parent root4=null;
                String to_location_title="Item Location";
                String fxm_Path="pos_details_panel.fxml";
                loadlocationStage(
                stage4,
                scene4,
                root4,
                item_location_txtf,
                850,
                100,
                to_location_title,
                fxm_Path
                );
                  
                        }
        else
                            if(event.getSource()==description_lbl2){
                                loadDescriptionDetailsStage();
                            }
    }
     NumberFormat format = NumberFormat.getIntegerInstance();
       UnaryOperator<TextFormatter.Change> filter = c -> {
    if (c.isContentChange()) {
        ParsePosition parsePosition = new ParsePosition(0);
        // NumberFormat evaluates the beginning of the text
        format.parse(c.getControlNewText(), parsePosition);
        if (parsePosition.getIndex() == 0 ||
                parsePosition.getIndex() < c.getControlNewText().length()) {
            // reject parsing the complete text failed
            return null;
        }
    }
    return c;
};
  
      void loadDescriptionDetailsStage() throws IOException{
         Scene scene3; 
             Stage  stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_type Controller = new pos_type();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_type_details.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 Parent root3 = loader.load();
                 String x="DESCRIPTION";
                 String y="MINOR_CODE";
                 String transfer_description_types= "TRANSFER_DESCRIPTION";
                 String sub_code = "###";
                 String sql = "select minor_code,description from list_control where reference_code='"+transfer_description_types+"' AND sub_code='"+sub_code+"'";
                 loader.<pos_type>getController().loadtypesDetailstable(sql, x, y);
                 scene3 = new Scene(root3);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("TYPE");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(1000);
                 stage2.setY(100);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();ca
               stage2.showAndWait();

              String result = loader.<pos_type>getController().getResult2();
          
                if (result != null) {
        // if a result was selected, add it to the list
                  description2_txtf1.setText(result);
                 // ledger_name3.setText(result2);
         }
    } 
      
      void mouseClickedstockdetailTable(){
           pos_transfer_journal_table item_details = stock_adjustment_tbl.getSelectionModel().getSelectedItem();
             
             item_code_txtf.setText(item_details.getITEM_CODE());
             item_name_txtf.setText(item_details.getITEM_NAME());
             transaction_quantity_spinner.getEditor().setText(String.valueOf(item_details.getORDERED_QUANTITY()));
             TextFormatter<Double> priceFormatter5 = new TextFormatter<Double>(
             new DoubleStringConverter(),item_details.getORDERED_QUANTITY(), filter);
          transaction_quantity_spinner.getEditor().setTextFormatter(priceFormatter5);;
             sent_quantity_spinner.getEditor().setText(item_details.getSENT_QUANTITY());
             received_quantity_spinner.getEditor().setText(item_details.getRECEIVED_QUANTITY());
             description2_txtf.setText(item_details.getCOMMENT());
      }
       
    @FXML
    void onSelectItem(MouseEvent event) {
       if(event.getSource()==stock_adjustment_tb){
       
        loadMaskerPane();
       }
      else
           if(event.getSource()==stock_adjustment_tbl){
            
             loadMaskerPane3();
             
             
           }
    }

    
    @FXML
    void onkeyTyped(KeyEvent event) {

    }  
    void Journal_table_mouseClicked(){
        
    }
      protected static final String INITIAL_VALUE = "0";
     void setSpinnerValue(Spinner<Double> spinner,double k){
        TextFormatter<Double> priceFormatter = new TextFormatter<Double>(
        new DoubleStringConverter(), k, filter);
        spinner.setValueFactory(new SpinnerValueFactory.DoubleSpinnerValueFactory(
        0.00, 10000.00, Double.parseDouble(INITIAL_VALUE)));
        spinner.setEditable(true);
        spinner.getEditor().setTextFormatter(priceFormatter); 
    }
     void getItemcodeandItemname(){
        String temp="%" + item_code_txtf.getText() + "%";
        String sql="Select item_code,item_name,buy_price,iuom from item_master WHERE item_code like '"+temp+"'";
         
        try{
         conn=DBConnection.ConnectDB();
         pst=conn.prepareStatement(sql);
         
         rs=pst.executeQuery();
         while(rs.next()){
             item_code_txtf.setText(rs.getString("ITEM_CODE"));
             item_name_txtf.setText(rs.getString("ITEM_NAME"));
             TextFormatter<Double> priceFormatter2 = new TextFormatter<Double>(
        new DoubleStringConverter(), rs.getDouble("BUY_PRICE"), filter);
            //buying_price_spinner.getEditor().setText(String.valueOf(rs.getDouble("BUY_PRICE")));
           // System.out.println(rs.getDouble("BUY_PRICE"));
             buying_price_spinner.getEditor().setTextFormatter(priceFormatter2);
             if(buying_price_spinner.getEditor().getText().equals("0.0")){
                 buying_price_spinner.setStyle("-fx-control-inner-background: yellow;"
                     + "-fx-text-fill: black;");
             }
             else{
                 buying_price_spinner.setStyle("-fx-control-inner-background: green;"
                     + "-fx-text-fill: white;"); 
             }
             uom_txtf.setText(rs.getString("IUOM"));
         }
         //rs.close();
                
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
     void onMouseClickedJournalTable(){
         Connection conn = DBConnection.ConnectDB();
        
          pos_stock_adjustments_initial_table selectedItem = stock_adjustment_tb.getSelectionModel().getSelectedItem();
            String sql="select  DATE_CREATED from JOURNAL_CONTROL where JOURNAL_NUMBER = '"+String.valueOf(selectedItem.getJOURNAL_NUMBER())+"'";
           try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
         java.sql.Date check_status6 = rs.getDate("DATE_CREATED");
         //System.out.println(""+check_status6+""); 
         SimpleDateFormat formatter2 = new SimpleDateFormat("MM-dd-yyyy");
        //formatter2.parse(check_status6);
        String ref = formatter2.format(check_status6);
        
        
        
        
      // System.out.println(String.valueOf(ref));
        
         String dateValue = ""+ref+"";
      //  sale_date.setValue(LocalDate.parse(ref,formatter));
       
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
      //  stcoking_date_dtpicker.setValue(LocalDate.parse(dateValue,formatter));
            }
           
       }
       catch(Exception e){
           e.printStackTrace();
       }
         
       // pos_stock_adjustments_initial_table selectedItem = stock_adjustment_tb.getSelectionModel().getSelectedItem();
        journal_number2_txtf.setText(selectedItem.getJOURNAL_NUMBER()); 
        description2_txtf1.setText(selectedItem.getDESCRIPTION());
        data2.removeAll(data2);
        String sql2="Select * from STOCK_TRNS where JOURNAL_NUMBER='"+journal_number2_txtf.getText()+"'";
        loadStockAdjustmentDetailstable(sql2);
    
        String control_account="select CONTROL_ACCOUNT from JOURNAL_CONTROL";
           try{
               pst=conn.prepareStatement(control_account);
               rs=pst.executeQuery();
               while(rs.next()){
                 control_account_txtf.setText(rs.getString("CONTROL_ACCOUNT"));
               }
           }
           catch(Exception e){
               e.printStackTrace();
           }
        
            transaction_quantity_spinner.getEditor().setText(String.valueOf(selectedItem.getCONTROL_QUANTITY()));;
        // sales_price4.getValueFactory()
           journal_control_count_txtf.setText(selectedItem.getCOUNT());
           TextFormatter<Integer> priceFormatter5 = new TextFormatter<Integer>(
        new IntegerStringConverter(),Integer.parseInt(selectedItem.getFISCAL_YEAR()), filter);
           TextFormatter<Integer> priceFormatter6 = new TextFormatter<Integer>(
        new IntegerStringConverter(),Integer.parseInt(selectedItem.getFISCAL_MONTH()), filter);
          fiscal_year_spinner.getEditor().setTextFormatter(priceFormatter5);
          month_spinner.getEditor().setTextFormatter(priceFormatter6);
          item_location_txtf.setText(String.valueOf(selectedItem.getTRN_LOCATION()));
          String ledger_type="select ledger_type from JOURNAL_CONTROL";
          try{
              pst=conn.prepareStatement(ledger_type);
              rs=pst.executeQuery();
              while(rs.next()){
                  ledger_type_lbl.setText(rs.getString("LEDGER_TYPE"));
              }
                      
          }
          catch(Exception e){
              e.printStackTrace();
          }
          
          String trn_type="select journal_type from JOURNAL_CONTROL";
          try{
              pst=conn.prepareStatement(trn_type);
              rs=pst.executeQuery();
              while(rs.next()){
                  trn_type_lbl.setText(rs.getString("JOURNAL_TYPE"));
                  
              }
                      
          }
          catch(Exception e){
              e.printStackTrace();
          }
     }
     void loadMaskerPane(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                    onMouseClickedJournalTable();
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
     }
     
      void loadMaskerPane3(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                    mouseClickedstockdetailTable();
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
     }
      
      
       void loadMaskerPane4(String result,String result2,String load_item_details){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                      loadItemDetails(result,result2,load_item_details);
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
     }
    
     
     void loadWindowOpenedContent(){
             acc.setExpandedPane(stock_adjustment_transactions_tp);
        // masker.setVisible(true);
        /* selectRadioButton(
        internal_stock_transfer_rdbtn,
        stock_transfer_rdbtn,
        from_location_txtf,
        confirm_order_chkbx,
        to_location_txtf,
        received_chkbx,
        date_created_dtPicker,
        date_received_dtPicker,
        via_location_txtf,
        sent_chkbx,
        date_sent_dtPicker
        );*/
        setSpinnerValue(transaction_quantity_spinner,0.00);
        setSpinnerValue(sent_quantity_spinner,0.00);
        setSpinnerValue(received_quantity_spinner,0.00);
          String refresh_stock_journal_table= "SELECT * from JOURNAL_CONTROL WHERE JOURNAL_STATUS='ACT' AND JOURNAL_TYPE='TSF'";
        loadStocktransferInitialDetailstable(refresh_stock_journal_table);
          selectRadioButton2(
                internal_stock_transfer_rdbtn,
                stock_transfer_rdbtn,
                from_location_txtf,
                confirm_order_chkbx,
                to_location_txtf,
                received_chkbx,
                date_created_dtPicker,
                date_received_dtPicker,
                via_location_txtf,
                sent_chkbx,
                date_sent_dtPicker 
        ); 
     }
     void loadMaskerPane2(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                    loadWindowOpenedContent();
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
     }
     
     
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    
          loadMaskerPane2();
          
    
          
    
    }
    
    
     public static JFrame frame;
      public static JFXPanel fxPanel = new JFXPanel();
       public  void initAndShowGUI() {
        // This method is invoked on the EDT thread
       
        try{
          frame = new JFrame("Stock Transfer");
        frame.add(fxPanel);
        frame.setSize(2000, 1000);
        
        //frame.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("../images_/mali_bg.png")));
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setResizable(true);
        frame.setLocationRelativeTo(null); 
       
        }
        catch(Exception e){
            e.printStackTrace();
        }
        
        
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                initFX(fxPanel);
               // loadComboBoxes();
            }
       });
    }
       
        private  void initFX(JFXPanel fxPanel) {
        // This method is invoked on the JavaFX thread
      
         //  Scene scene = createScene();
          // fxPanel.setScene(scene);
     try {
        Parent  root5 = FXMLLoader.load(getClass().getResource("pos_stock_transfer_journal.fxml"));
          Scene scene2 = new Scene(root5, 2000, 1000);
                scene2.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
            fxPanel.setScene(scene2);
            
            
           
        } catch (IOException exc) {
            exc.printStackTrace();
            System.exit(1);
        }
        
      
      
    }
    public static void main(String[] args) {
         SwingUtilities.invokeLater(new Runnable() {
             @Override
            public void run() {
              
                pos_stock_transfer_journal test = new pos_stock_transfer_journal();
                test.initAndShowGUI();
                
                
                
               
                
            }
        });
        
         
    }
}
