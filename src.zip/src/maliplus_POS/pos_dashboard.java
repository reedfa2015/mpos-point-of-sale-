/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;

/**
 *
 * @author PSL-STUFF
 */

import com.jfoenix.controls.JFXTextField;
import java.awt.BorderLayout;
import java.io.IOException;

import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import static maliplus.Controller.user;


public class pos_dashboard {
    
    
         @FXML
    private JFXTextField username2;
              @FXML
    private JFXTextField username;
    private void initSwingComponents() {
        JFrame frame = new JFrame("Maliplus dashboard");
        frame.setLayout(new BorderLayout());
        final JFXPanel jfxPanel = new JFXPanel();
        frame.add(jfxPanel, BorderLayout.CENTER);
        final JPanel swingButtons = new JPanel();
        frame.add(swingButtons, BorderLayout.SOUTH);

        frame.setSize(1524, 1000);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        

        Platform.runLater(() -> initFX(jfxPanel));
    }

    private void initFX(JFXPanel jfxPanel) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("pos_dashboard.fxml"));
            Scene scene = new Scene(root, 1524, 1000);
            scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
            jfxPanel.setScene(scene);
           
        } catch (IOException exc) {
            exc.printStackTrace();
            System.exit(1);
        }
    }

    public static void main(String[] args) {
        pos_dashboard test = new pos_dashboard();
        SwingUtilities.invokeLater(() -> test.initSwingComponents() );
    }
}