/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author PSL-STUFF
 */
public class pos_debtor_payment_table {
private final SimpleStringProperty document_number2;
private final SimpleStringProperty document_type2;
private final SimpleStringProperty document_date2;
private final SimpleStringProperty due_date2;
private final SimpleDoubleProperty amount2;
private final SimpleStringProperty paid_amount2;
private final SimpleDoubleProperty balance2;
private final SimpleStringProperty description2;
private final SimpleStringProperty reference2;
private final SimpleStringProperty reference_type2;
private final SimpleStringProperty category2;
private final SimpleStringProperty approved2;
private final SimpleStringProperty matched_number2;
private final SimpleStringProperty matched_type2;
private final SimpleStringProperty check_option2;
public pos_debtor_payment_table (String D_N,String D_T,String D_D,String DU_D,Double AMNT,String P_AMNT,Double BAL,String DESC,String REF,
        String REF_T,String CAT,String APV,String MTC,String MTCT,String CHK){
    this.document_number2 = new SimpleStringProperty(D_N);
     this.document_type2 = new SimpleStringProperty(D_T);
     this.document_date2 = new SimpleStringProperty(D_D);
     this.due_date2 = new SimpleStringProperty(DU_D);
     this.amount2 = new SimpleDoubleProperty(AMNT);
     this.paid_amount2 = new SimpleStringProperty(P_AMNT);
     this.balance2 = new SimpleDoubleProperty(BAL);
     this.description2 = new SimpleStringProperty(DESC);
     this.reference2 = new SimpleStringProperty(REF);  
     this.reference_type2 = new SimpleStringProperty(REF_T);
     this.category2 = new SimpleStringProperty(CAT);
     this.approved2 = new SimpleStringProperty(APV);
     this.matched_number2 = new SimpleStringProperty(MTC);
     this.matched_type2 = new SimpleStringProperty(MTCT);
     this.check_option2 = new SimpleStringProperty(CHK);
}

    



  public String getdocument_number(){
      return document_number2.get();
  }
  public String getdocument_type(){
      return document_type2.get();
  }

  public String getdocument_date(){
      return document_date2.get();
  }
  public String getdue_date(){
      return due_date2.get();
  }
  public Double getamount(){
      return amount2.get();
  }
  
  public String getpaid_amount(){
      return paid_amount2.get();
  }
  public Double getbalance(){
      return balance2.get();
  }
   public String getdescription(){
      return description2.get();
  }
   public String getreference(){
      return reference2.get();
  }
   public String getreference_type(){
      return reference_type2.get();
  }
    public String getcategory(){
      return category2.get();
  }
     public String getapproved(){
      return approved2.get();
  }
      public String getmatched_number(){
      return matched_number2.get();
  }
       public String getmatched_type(){
      return matched_type2.get();
  }
        public String getcheck_option(){
      return check_option2.get();
  }

  
  public void SetDOCUMENT_NUMBER(String D_N ){
      document_number2.set(D_N);
  }
   public void SetDOCUMENT_TYPE(String D_T){
      document_type2.set(D_T);
  }
  
   public void SetDOCUMENT_DATE(String D_D){
      document_date2.set(D_D);
  }
   public void SetDUE_DATE(String DU_D){
      due_date2.set(DU_D);
  }
   public void SetAMOUNT(Double AMNT ){
      amount2.set(AMNT);
  }
   
   public void SetPAID_AMOUNT(String P_AMNT ){
      paid_amount2.set(P_AMNT);
  }
  public void SetBALANCE(Double BAL ){
      balance2.set(BAL);
  }
   public void SetDESCRIPTION(String DESC ){
      description2.set(DESC);
  }
    public void SetREFERENCE(String REF ){
      reference2.set(REF);
  }
   
     
      public StringProperty document_numberProperty() {
        return document_number2 ;
    }
       public StringProperty document_typeProperty() {
        return document_type2 ;
    }
    
      public StringProperty document_dateProperty() {
        return document_date2 ;
    }
        public StringProperty due_dateProperty() {
        return due_date2 ;
    }
          public DoubleProperty amountProperty() {
        return amount2 ;
    }
      
            public StringProperty paid_amountProperty() {
        return paid_amount2 ;
    }

                   public DoubleProperty balanceProperty() {
        return balance2 ;
    }
                  public StringProperty descriptionProperty() {
        return description2 ;
    }
                 public StringProperty referenceProperty() {
        return reference2 ;
    }
                         public StringProperty reference_typeProperty() {
        return reference_type2 ;
    }
                     public StringProperty categoryProperty() {
        return category2 ;
    }
                     public StringProperty approvedProperty() {
        return approved2 ;
    }
                     public StringProperty matched_numberProperty() {
        return matched_number2 ;
    }
                     public StringProperty matched_typeProperty() {
        return matched_type2 ;
    }
                      public StringProperty check_optionProperty() {
        return check_option2 ;
    }


}
