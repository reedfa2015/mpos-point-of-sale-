/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import static maliplus_POS.Pos_Controller.stage2;

/**
 *
 * @author PSL-STUFF
 */
public class pos_Stock_Initializable extends Application{
   //  public static Boolean load_approve_Post_stage= false;
 @Override
    public void start(Stage primarystage) throws Exception{
       pos_stock_adjustment_initial Controller = new pos_stock_adjustment_initial();
        FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_stock_adjustment_final.fxml"));
         //FXMLLoader loader2 = new FXMLLoader(this.getClass().getResource("pos_details_panel.fxml"));
         // Parent root = (Parent) loader.load();
           //Pos_Controller Controller = new Pos_Controller();
          //Pos_Controller Controller = loader.getController(); 
        loader.setController(Controller);
        ScrollPane mainPane = (ScrollPane) loader.load();
        primarystage.setScene(new Scene(mainPane));
        primarystage.setMaximized(true);
        primarystage.setResizable(true);
        mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm());
        primarystage.setTitle("MaliPlus Retail ©2017 PrimeSoft Solutions (K) Ltd");
        primarystage.getIcons().add(new Image("/images_/Mali_bg.png"));
      
        primarystage.show();
        
        
        
        

    }
    
     public static void main(String[]args){
         
        launch(args);
    }    
    
    
}
