/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXRadioButton;
import com.jfoenix.controls.JFXSpinner;
import com.jfoenix.controls.JFXTextField;
import java.io.File;
import java.net.URL;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.util.ResourceBundle;
import java.util.function.UnaryOperator;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextFormatter;
import javafx.scene.input.MouseEvent;
import javafx.util.converter.IntegerStringConverter;
import javax.swing.JFileChooser;
/**
 *
 * @author PSL-STUFF
 */
public class pos_user_options implements Initializable{
    /* static Connection conn = null;
    static ResultSet rs = null;
    static PreparedStatement pst = null;*/
    
    @FXML
    private JFXCheckBox active_customers_chkbx;

    @FXML
    private JFXCheckBox favorite_maximized_chkbx;

    @FXML
    private JFXCheckBox favorite_has_no_borders_chkbx;

    @FXML
    private JFXCheckBox save_barcode_image_chkbx;

    @FXML
    private JFXCheckBox auto_fill_cash_orders_chkbx;

    @FXML
    private JFXTextField general_image_txtf;

    @FXML
    private JFXTextField export_document_path_txtf;

    @FXML
    private JFXTextField export_statement_path_txtf;

    @FXML
    private JFXTextField help_file_location_txtf;

    @FXML
    private JFXTextField barcode_location_txtf;

    @FXML
    private Label general_image_lbl;

    @FXML
    private Label export_document_path_lbl;

    @FXML
    private Label export_statement_path_lbl;

    @FXML
    private Label help_file_location_lbl;

    @FXML
    private Label query_file_location_lbl;
    @FXML
    private JFXTextField query_file_location_txtf;
    

    @FXML
    private Label barcode_location_lbl;

    @FXML
    private JFXComboBox<String> communication_por_cmbbx;
    
    void displayCommunicationPortPortNumber(JFXComboBox Combobox){
         Combobox.setValue("COM 1");
    }
   

    @FXML
    private JFXTextField printer_serial_number_txtf;

    @FXML
    private JFXTextField registration_key_txtf;

    @FXML
    private JFXTextField print_output_file_path_txtf;

    @FXML
    private JFXTextField driver_executes_path_txtf;

    @FXML
    private JFXTextField additional_text_txtf;

    @FXML
    private JFXTextField zero_tax_group_txtf;

    @FXML
    private Label device_tyoe_lbl;

    @FXML
    private JFXTextField configured_tax_group_txtf;

    @FXML
    private JFXTextField device_type_txtf;

    @FXML
    private JFXCheckBox manual_header_chkbx;

    @FXML
    private Spinner<Integer> baud_rate_spinner;

    @FXML
    private Spinner<Integer> logical_number_spinner;

    @FXML
    private Spinner<Integer> item_name_length_spinner;

    @FXML
    private JFXCheckBox enable_pole_display_chkbx;

    @FXML
    private JFXComboBox<String> communication_port_cmbbx;

    @FXML
    private Spinner<Integer> character_per_line_spinner;

    @FXML
    private JFXTextField idle_message_line1_txtf;

    @FXML
    private JFXTextField idle_message_line_2_txtf;

    @FXML
    private JFXTextField amount_due_text_txtf;

    @FXML
    private JFXTextField change_message_txtf;

    @FXML
    private JFXRadioButton scrolling_rbtn;

    @FXML
    private JFXRadioButton no_scroll_rbtn;

    @FXML
    private Spinner<Integer> initervals_in_millisecs_spinner;
    
     @FXML
    private Spinner<Integer> no_of_lines_spinner;

    @FXML
    private JFXTextField change_text_txtf;

    @FXML
    private JFXTextField total_text_txtf;

    @FXML
    private JFXButton ok_btn;

    @FXML
    private JFXButton cancel_btn;
       
    
    protected static final String INITIAL_VALUE = "0";
  
    
    NumberFormat format = NumberFormat.getIntegerInstance();
       UnaryOperator<TextFormatter.Change> filter = c -> {
    if (c.isContentChange()) {
        ParsePosition parsePosition = new ParsePosition(0);
        // NumberFormat evaluates the beginning of the text
        format.parse(c.getControlNewText(), parsePosition);
        if (parsePosition.getIndex() == 0 ||
                parsePosition.getIndex() < c.getControlNewText().length()) {
            // reject parsing the complete text failed
            return null;
        }
    }
    return c;
};
    TextFormatter<Integer> priceFormatter = new TextFormatter<Integer>(
        new IntegerStringConverter(), 0, filter);

    

    @FXML
    void actionPerformed(ActionEvent event) {
        if(event.getSource().equals(ok_btn)){
            
        }
            
        else
        if(event.getSource().equals(cancel_btn)){
                cancel_btn.getScene().getWindow().hide();
                }
        setFocusonRadioButtons(event,scrolling_rbtn,no_scroll_rbtn);

    }

    @FXML
    void mouseClicked(MouseEvent event) {
        /*   if(event.getSource().equals(general_image_lbl)){
        JFileChooser fileChooser=new JFileChooser();
        int returnValue=fileChooser.showOpenDialog(null);
        if(returnValue==JFileChooser.APPROVE_OPTION){
        File selectedFile=fileChooser.getSelectedFile();
        general_image_txtf.setText(selectedFile.getAbsolutePath());
        }
        }
        else
        if(event.getSource().equals(export_document_path_lbl)){
        JFileChooser fileChooser=new JFileChooser();
        int returnValue=fileChooser.showOpenDialog(null);
        if(returnValue==JFileChooser.APPROVE_OPTION){
        File selectedFile=fileChooser.getSelectedFile();
        export_document_path_txtf.setText(selectedFile.getAbsolutePath());
        }
        }
        else
        if(event.getSource().equals(export_statement_path_lbl)){
        JFileChooser fileChooser=new JFileChooser();
        int returnValue=fileChooser.showOpenDialog(null);
        if(returnValue==JFileChooser.APPROVE_OPTION){
        File selectedFile=fileChooser.getSelectedFile();
        export_statement_path_txtf.setText(selectedFile.getAbsolutePath());
        }
        }
        else
        if(event.getSource().equals(help_file_location_lbl)){
        JFileChooser fileChooser=new JFileChooser();
        int returnValue=fileChooser.showOpenDialog(null);
        if(returnValue==JFileChooser.APPROVE_OPTION){
        File selectedFile=fileChooser.getSelectedFile();
        help_file_location_txtf.setText(selectedFile.getAbsolutePath());
        }
        }
        else
        if(event.getSource().equals(query_file_location_lbl)){
        JFileChooser fileChooser=new JFileChooser();
        int returnValue=fileChooser.showOpenDialog(null);
        if(returnValue==JFileChooser.APPROVE_OPTION){
        File selectedFile=fileChooser.getSelectedFile();
        query_file_location_txtf.setText(selectedFile.getAbsolutePath());
        }
        }
        else
        if(event.getSource().equals(barcode_location_lbl)){
        JFileChooser fileChooser=new JFileChooser();
        int returnValue=fileChooser.showOpenDialog(null);
        if(returnValue==JFileChooser.APPROVE_OPTION){
        File selectedFile=fileChooser.getSelectedFile();
        barcode_location_txtf.setText(selectedFile.getAbsolutePath());
        }
        }*/
                
    }
   
  
   
    
    
    void setSpinnerValue(Spinner<Integer> spinner,int k){
        TextFormatter<Integer> priceFormatter = new TextFormatter<Integer>(
        new IntegerStringConverter(), k, filter);
        spinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(
        0, 10000, Integer.parseInt(INITIAL_VALUE)));
        spinner.setEditable(true);
        spinner.getEditor().setTextFormatter(priceFormatter); 
    }
   
  void setFocusonRadioButtons(ActionEvent event,JFXRadioButton radioButton,JFXRadioButton radioButton2){
      if(event.getSource().equals(radioButton)){ 
          radioButton2.setSelected(false);
      }
      else
          if(event.getSource().equals(radioButton2)){
             radioButton.setSelected(false); 
          }
          
      
  }
      
void checkToseeifactiveCustomers_are_selected(){
    if(active_customers_chkbx.isSelected()==true){
        active_customers_chkbx.setText("Y");
    }
    else{
        active_customers_chkbx.setText("N");
    }
}
      
        @Override
    public void initialize(URL url, ResourceBundle rb) {
   setSpinnerValue(baud_rate_spinner,9600);
   setSpinnerValue(logical_number_spinner,1);
   setSpinnerValue(item_name_length_spinner,20);
   setSpinnerValue(character_per_line_spinner,20);
   setSpinnerValue(initervals_in_millisecs_spinner,200);
   setSpinnerValue(no_of_lines_spinner,2);
   displayCommunicationPortPortNumber(communication_port_cmbbx);
   displayCommunicationPortPortNumber(communication_por_cmbbx);
   checkToseeifactiveCustomers_are_selected();
    }



 
}
