/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.util.Duration;
import javax.swing.JFrame;
import maliplus.DBConnection;
import static maliplus_POS.Pos_Controller.pst;
import static maliplus_POS.Pos_Controller.rs;
import static maliplus_POS.Pos_Controller.stage2;
import org.controlsfx.control.Notifications;
/**
 *
 * @author PSL-STUFF
 */
public class pos_customers implements Initializable{
      static Connection conn = null;
    static ResultSet rs = null;
    static PreparedStatement pst = null;
    public static JFrame frame;
public static Scene scene2;
static Parent  root5;
    final ObservableList<pos_customer_details_panel> data2= FXCollections.observableArrayList();
 @FXML
    private TableView<pos_customer_details_panel> customers;

    @FXML
    private TableColumn<pos_customer_details_panel, String> ledger_number;

    @FXML
    private TableColumn<pos_customer_details_panel,String> ledger_name;

    @FXML
    private JFXTextField search_item_txtf;

    @FXML
    void onKeyTyped(KeyEvent event) {
           if(event.getSource()==search_item_txtf){
       ledger_number.setCellValueFactory(cellData -> cellData.getValue().ledger_numberProperty());
        ledger_name.setCellValueFactory(cellData -> cellData.getValue().ledger_nameProperty());
     
        
         FilteredList<pos_customer_details_panel> filteredData = new FilteredList<>(data2, p -> true);
            search_item_txtf.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(item -> {
                // If filter text is empty, display all persons.
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }

                // Compare first name and last name of every person with filter text.
                String lowerCaseFilter = newValue.toLowerCase();
                 String upperCaseFilter = newValue.toUpperCase();
                if (item.getLEDGER_NUMBER().toUpperCase().contains(upperCaseFilter)) {
                    return true; // Filter matches item_code.
                } else 
                    if (item.getLEDGER_NAME().toLowerCase().contains(lowerCaseFilter)) {
                    return true; // Filter matches item_name.
                }
                
                return false; // Does not match.
            });
        });
            
             SortedList<pos_customer_details_panel> sortedData = new SortedList<>(filteredData);
              sortedData.comparatorProperty().bind(customers.comparatorProperty());
              customers.setItems(sortedData);
        }
        
    }
   
    @FXML
    void onSelectItem(MouseEvent event) {
         int click = event.getClickCount();
        
        if(click ==2){
        try {  
           
                 actioncustomerDetails_panelTable_mouse_clicked1();
             } catch (IOException ex) {
                 Logger.getLogger(pos_customers.class.getName()).log(Level.SEVERE, null, ex);
             }
    }
             
            
    }
        public  void loadCustomerDetailstable()throws IOException{
             conn = DBConnection.ConnectDB();
             DBConnection.dynamic_sql = "select ledger_number,ledger_name from customers"; 
                        try{
                       pst=conn.prepareStatement(DBConnection.dynamic_sql);
                       rs= pst.executeQuery();
                       while(rs.next()){ 
                           data2.add(new pos_customer_details_panel(
                           rs.getString("LEDGER_NUMBER"),
                           rs.getString("LEDGER_NAME")
                           ));
        ledger_number.setCellValueFactory((TableColumn.CellDataFeatures<pos_customer_details_panel, String> cellData) -> {
            return cellData.getValue().ledger_numberProperty();
        });
        ledger_name.setCellValueFactory((TableColumn.CellDataFeatures<pos_customer_details_panel, String> cellData) -> {
            return cellData.getValue().ledger_nameProperty();
        });
       
        

     
       // item_code.setStyle("-fx-control-inner-background: yellow;");
       // item_code.setStyle("-fx-text-fill: red;");
       // item_description.setStyle("-fx-text-fill: green;");
       // quantity.setStyle("-fx-text-fill: blue;");
       // sales_price.setStyle("-fx-text-fill: orange;");
       // sales_amount.setStyle("-fx-text-fill: purple;");
       // discount.setStyle("-fx-text-fill: red;");
       // taxable.setStyle("-fx-text-fill: violet;");
       // tax_amount.setStyle("-fx-text-fill: blue;");
       // item_location.setStyle("-fx-text-fill: grey;");
       // display.setStyle(" -fx-font-size: 14px;");
       
  
                           customers.setItems(data2);
                           
                                   
                       }
                    //   pst.close();
                    //   rs.close();
                   }
                   catch(Exception e2){
                      e2.printStackTrace();
                   } 
}
    
         private Pos_Controller Controller;

    public void setController(Pos_Controller controller ) {
        this.Controller = controller;
    }
    private String result = null;
    private String result2 = null;
    private String result3 = null;
    private String result4 = null;
   
    public String getResult() {
        
        return result;
    }

    public String getResult2() {
        
        return result2;
    }
    
     public String getResult3() {
        
        return result3;
    }
     public String getResult4() {
        
        return result4;
    }
     
          void  actioncustomerDetails_panelTable_mouse_clicked1()throws IOException{ 
         // Pos_Controller Controller =  new Pos_Controller();
       

         //FXMLLoader loader2 = new FXMLLoader(this.getClass().getResource("pos_details_panel.fxml"));
         // Parent root = (Parent) loader.load();
           //Pos_Controller Controller = new Pos_Controller();
         
         // loader.setController(Controller);
         // loader.load();
         
        
         pos_customer_details_panel selectedItem = customers.getSelectionModel().getSelectedItem();
        
       // System.out.println(selectedItem.getMAIN_LOCATION());
        try{
           // test_me.setText(selectedItem.getMAIN_LOCATION());
            result =selectedItem.getLEDGER_NUMBER();
            result2 = selectedItem.getLEDGER_NAME();
            //System.out.println("'"+selectedItem.getLEDGER_NUMBER()+"'");
            
              conn = DBConnection.ConnectDB();
            result3 = "SELECT * from STOCK_TRNS where LEDGER_NUMBER='"+selectedItem.getLEDGER_NUMBER()+"'"; 
            result4 = "SELECT ORDER_NUMBER from CASH_ORDERS where LEDGER_NUMBER= '"+selectedItem.getLEDGER_NUMBER()+"'";
         
            customers.getScene().getWindow().hide();
            
           
        }
        catch(Exception e){
            
        }
        
          
    }

     
    
     void try_me() throws IOException{
         
         Controller.actionlocationsDetails_panelTable_mouse_clicked(); 
     }
     
   
    
    
    
   
    
    
   
      

      
        @Override
    public void initialize(URL url, ResourceBundle rb) {
       
        try {
            // TODO
            loadCustomerDetailstable();
            
            //locatpion2.setText("ok");
        } catch (IOException ex) {
            Logger.getLogger(pos_customers.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }

 
}
