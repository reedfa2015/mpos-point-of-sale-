/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author PSL-STUFF
 */
public class pos_order_details_panel {
private final SimpleStringProperty order_number2;
private final SimpleStringProperty description2;
private final SimpleStringProperty ledger_number2;

public pos_order_details_panel (String O_N,String DESC,String LEDNU ){
    this.order_number2 = new SimpleStringProperty(O_N);
     this.description2 = new SimpleStringProperty(DESC);
     this.ledger_number2 = new SimpleStringProperty(LEDNU);

         
}

    



  public String getORDER_NUMBER(){
      return order_number2.get();
  }
  public String getDESCRIPTION(){
      return description2.get();
  }
    public String getLEDGER_NUMBER(){
      return ledger_number2.get();
  }

  
  public void SetORDER_NUMBER(String O_N ){
      order_number2.set(O_N);
  }
   public void SetDECSRIPTION(String DESC){
      description2.set(DESC);
  }
  public void SetLEDGER_NUMBER(String LEDNU){
      ledger_number2.set(LEDNU);
  }
   
     
      public StringProperty order_numberProperty() {
        return order_number2 ;
    }
       public StringProperty descriptionProperty() {
        return description2 ;
    }
        public StringProperty ledger_numberProperty() {
        return ledger_number2 ;
    }
    



}
