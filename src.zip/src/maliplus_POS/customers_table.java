/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author PSL-STUFF
 */
public class customers_table {
private final SimpleStringProperty ledger_number2;
private final SimpleStringProperty customer_name2;
private final SimpleStringProperty status2;
private final SimpleStringProperty telephone2;
private final SimpleStringProperty base_location2;
private final SimpleStringProperty town_city2;
private final SimpleStringProperty email_address2;
private final SimpleStringProperty contact_person2;
private final SimpleStringProperty contact_phone2;
private final SimpleStringProperty cred2;

public customers_table (String L_N,String C_N,String STS,String TEL,String B_L,String T_C,String E_A,String C_P,String C_PH,
        String CRED){
    this.ledger_number2 = new SimpleStringProperty(L_N);
     this.customer_name2 = new SimpleStringProperty(C_N);
     this.status2 = new SimpleStringProperty(STS);
     this.telephone2 = new SimpleStringProperty(TEL);
     this.base_location2 = new SimpleStringProperty(B_L);
     this.town_city2 = new SimpleStringProperty(T_C);
     this.email_address2 = new SimpleStringProperty(E_A);
     this.contact_person2 = new SimpleStringProperty(C_P);
      this.contact_phone2 = new SimpleStringProperty(C_PH);
     this.cred2 = new SimpleStringProperty(CRED);  

}

    



  public String getledger_number(){
      return ledger_number2.get();
  }
  public String getcustomer_name(){
      return customer_name2.get();
  }

  public String getstatus(){
      return status2.get();
  }
  public String gettelephone(){
      return telephone2.get();
  }
  public String getbase_location(){
      return base_location2.get();
  }
  
  public String gettown_city(){
      return town_city2.get();
  }
  public String getemail_address(){
      return email_address2.get();
  }
   public String getcontact_person(){
      return contact_person2.get();
  }
    public String getcontact_phone(){
      return contact_phone2.get();
  }
   public String getcred(){
      return cred2.get();
  }
  

  
  public void SetLEDGER_NUMBER(String L_N ){
      ledger_number2.set(L_N);
  }
   public void SetCUSTOMER_NAME(String C_N){
      customer_name2.set(C_N);
  }
  
   public void SetSTATUS(String STS){
      status2.set(STS);
  }
   public void SetTELEPHONE(String TEL){
      telephone2.set(TEL);
  }
   public void SetBASE_LOCATION(String B_L ){
      base_location2.set(B_L);
  }
   
   public void SetTOWN_CITY(String T_C ){
      town_city2.set(T_C);
  }
  public void SetEMAIL_ADDRESS(String E_A ){
      email_address2.set(E_A);
  }
   public void SetCONTACT_PERSON(String C_P ){
      contact_person2.set(C_P);
  }
   public void SetCONTACT_PHONE(String C_PH ){
      contact_phone2.set(C_PH);
  }
    public void SetCRED(String CRED){
      cred2.set(CRED);
  }
   
     
      public StringProperty ledger_numberProperty() {
        return ledger_number2 ;
    }
       public StringProperty customer_nameProperty() {
        return customer_name2 ;
    }
    
      public StringProperty statusProperty() {
        return status2 ;
    }
        public StringProperty telephoneProperty() {
        return telephone2 ;
    }
          public StringProperty base_locationProperty() {
        return base_location2 ;
    }
      
            public StringProperty town_cityProperty() {
        return town_city2 ;
    }

                   public StringProperty email_addressProperty() {
        return email_address2 ;
    }
                  public StringProperty contact_personProperty() {
        return contact_person2 ;
    }
                  public StringProperty contact_phoneProperty() {
        return contact_phone2 ;
    }
                 public StringProperty credProperty() {
        return cred2 ;
    }
     


}
