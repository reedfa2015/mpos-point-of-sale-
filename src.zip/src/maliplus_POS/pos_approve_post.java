/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.image.Image;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import static maliplus_POS.Pos_Controller.stage2;
/**
 *
 * @author PSL-STUFF
 */
public class pos_approve_post implements Initializable{
      static Connection conn = null;
    static ResultSet rs = null;
    static PreparedStatement pst = null;
 
   
    @FXML
    private JFXButton ok_btn;

    @FXML
    private JFXButton cancel_btn;

    @FXML
    private JFXTextField invoice_amount_txtf;

    @FXML
    private JFXTextField tendered_amount_txtf;

    @FXML
    private JFXTextField amount_balance_txtf;

    @FXML
    private JFXTextField loyalty_card_number_txtf;

    @FXML
    private JFXTextField reference_document_txtf;

    @FXML
    private Spinner<?> redeem_points_spinner;

    @FXML
    private JFXCheckBox redeem_points_chkbx;

    @FXML
    private Label loyalty_card_lbl;

    @FXML
    private Label ref_type_lbl;

    @FXML
    private Label cash_collection_lbl;

    @FXML
    private JFXTextField cash_collection_txtf;

    @FXML
    private JFXTextField ref_type_txtf;

    void balance(){
          try {
              double balance;
              int x =9;
              Number first_number=NumberFormat.getNumberInstance(java.util.Locale.US).parse(invoice_amount_txtf.getText());
              Number second_number=NumberFormat.getNumberInstance(java.util.Locale.US).parse(tendered_amount_txtf.getText());
              System.out.println(""+second_number+"");
              balance=Double.parseDouble(String.valueOf(first_number))-Double.parseDouble(String.valueOf(second_number));  
             // balance=first_number-second_number;
             String s = NumberFormat.getNumberInstance().format(balance);
              amount_balance_txtf.setText(s);
          } catch (ParseException ex) {
              Logger.getLogger(pos_approve_post.class.getName()).log(Level.SEVERE, null, ex);
          }
    }
       void loadCash_CollectionDetailsStage() throws IOException{
         Scene scene3; 
               stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_type Controller = new pos_type();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_type_details.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
              
                 Parent root3 = loader.load();
                 String x="DESCRIPTION";
                 String y="KEY_WORD";
                 String cash_collection_account= "CASH_COLLECTION_ACCOUNT";
                 String sub_code = "###";
                 String sql = "select key_word,description from list_control where reference_code='"+cash_collection_account+"' AND sub_code='"+sub_code+"'";
                 loader.<pos_type>getController().loadtypesDetailstable(sql, x, y);
                 
                 
                 scene3 = new Scene(root3);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("CASH COLLECTION ACCOUNT");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(1000);
                 stage2.setY(50);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();
               stage2.showAndWait();

              String result = loader.<pos_type>getController().getResult();
          
                if (result != null) {
        // if a result was selected, add it to the list
               
                  cash_collection_txtf.setText(result);
                   cash_collection_txtf.setStyle("-fx-text-fill: green;"
                                       + "-fx-font-size: 14px;");
                 // ledger_name3.setText(result2);
         }
    }
       
          void loadRef_typeDetailsStage() throws IOException{
         Scene scene3; 
               stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_type Controller = new pos_type();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_type_details.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
              
                 Parent root3 = loader.load();
                 String x="DESCRIPTION";
                 String y="KEY_WORD";
                 String ref_type= "POS_REF_TYPES";
                 String sub_code = "###";
                 String sql = "select key_word,description from list_control where reference_code='"+ref_type+"' AND sub_code='"+sub_code+"'";
                 loader.<pos_type>getController().loadtypesDetailstable(sql, x, y);
                 
                 
                 scene3 = new Scene(root3);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("REF TYPES");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(1000);
                 stage2.setY(50);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();
               stage2.showAndWait();

              String result = loader.<pos_type>getController().getResult();
          
                if (result != null) {
        // if a result was selected, add it to the list
               
                  ref_type_txtf.setText(result);
                  ref_type_txtf.setStyle("-fx-text-fill: red;"
                                       + "-fx-font-size: 14px;");
                 // ledger_name3.setText(result2);
         }
    }
       
    @FXML
    void onkeyReleased(KeyEvent event) {
        if(event.getSource().equals(tendered_amount_txtf)){
           try{
              balance(); 
           } 
           catch(Exception e){
            //  e.printStackTrace(); 
           }
            
        }
       
    }
    
   
     
    @FXML
    void actionPerformed(ActionEvent event) {
     if(event.getSource().equals(cancel_btn)){
         cancel_btn.getScene().getWindow().hide();
     }
    }

    @FXML
    void mouseClicked(MouseEvent event) {
      if(event.getSource().equals(cash_collection_lbl)){
          try {
              loadCash_CollectionDetailsStage();
          } catch (IOException ex) {
              Logger.getLogger(pos_approve_post.class.getName()).log(Level.SEVERE, null, ex);
          }
      }  
        else
          if(event.getSource().equals(ref_type_lbl)){
          try {
              loadRef_typeDetailsStage();
          } catch (IOException ex) {
              Logger.getLogger(pos_approve_post.class.getName()).log(Level.SEVERE, null, ex);
          }
          }
    }
    String Invoice_amount;
    public void setinvoiceAmount(String invoice_amount) {
        this.Invoice_amount= invoice_amount;
    }
     
   String Cash_Collection_Account;
   public void setcash_collection_acc(String Cash_collection_account) {
        this.Cash_Collection_Account= Cash_collection_account;
    }
    
    
    
   
    
    
   
      

      
        @Override
    public void initialize(URL url, ResourceBundle rb) {
       invoice_amount_txtf.setText(this.Invoice_amount);
       //cash_collection_lbl.setText(this.Cash_Collection_Account);
       
    }

 
}
