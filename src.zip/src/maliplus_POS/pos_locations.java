/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;
import maliplus.*;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javax.swing.JFrame;
import maliplus.DBConnection;
import static maliplus_POS.Pos_Controller.stage2;
/**
 *
 * @author PSL-STUFF
 */
public class pos_locations implements Initializable{
      static Connection conn = null;
    static ResultSet rs = null;
    static PreparedStatement pst = null;
    public static JFrame frame;
public static Scene scene2;
static Parent  root5;
    final ObservableList<pos_details_panel> data2= FXCollections.observableArrayList();
 @FXML
    private TableView<pos_details_panel> locations;

    @FXML
    private TableColumn<pos_details_panel, String> main_location;

    @FXML
    private TableColumn<pos_details_panel, String> location_name;

    
     @FXML
    private JFXTextField test_me;
    @FXML
    void onSelectItem(MouseEvent event) {
          int click = event.getClickCount();
        
        if(click ==2){
             try {  
                 actionlocationsDetails_panelTable_mouse_clicked1();
             } catch (IOException ex) {
                 Logger.getLogger(pos_locations.class.getName()).log(Level.SEVERE, null, ex);
             }
        }
            
            
    }
        public  void loadLocationsDetailstable()throws IOException{
             conn = DBConnection.ConnectDB();
             DBConnection.dynamic_sql = "select main_location,location_name from locations"; 
                        try{
                       pst=conn.prepareStatement(DBConnection.dynamic_sql);
                       rs= pst.executeQuery();
                       while(rs.next()){ 
                           data2.add(new pos_details_panel(
                           rs.getString("MAIN_LOCATION"),
                           rs.getString("LOCATION_NAME")
                           ));
        main_location.setCellValueFactory((TableColumn.CellDataFeatures<pos_details_panel, String> cellData) -> {
            return cellData.getValue().main_locationProperty();
        });
        location_name.setCellValueFactory((TableColumn.CellDataFeatures<pos_details_panel, String> cellData) -> {
            return cellData.getValue().location_nameProperty();
        });
       
        

     
       // item_code.setStyle("-fx-control-inner-background: yellow;");
       // item_code.setStyle("-fx-text-fill: red;");
       // item_description.setStyle("-fx-text-fill: green;");
       // quantity.setStyle("-fx-text-fill: blue;");
       // sales_price.setStyle("-fx-text-fill: orange;");
       // sales_amount.setStyle("-fx-text-fill: purple;");
       // discount.setStyle("-fx-text-fill: red;");
       // taxable.setStyle("-fx-text-fill: violet;");
       // tax_amount.setStyle("-fx-text-fill: blue;");
       // item_location.setStyle("-fx-text-fill: grey;");
       // display.setStyle(" -fx-font-size: 14px;");
       
  
                           locations.setItems(data2);
                           
                                   
                       }
                    //   pst.close();
                    //   rs.close();
                   }
                   catch(Exception e2){
                      e2.printStackTrace();
                   } 
}
    
         private Pos_Controller Controller;

    public void setController(Pos_Controller controller ) {
        this.Controller = controller;
    }
 

    private String result = null;
    public String getResult() {
        
        return result;
    }

     void  actionlocationsDetails_panelTable_mouse_clicked1()throws IOException{ 
         // Pos_Controller Controller =  new Pos_Controller();
       

         //FXMLLoader loader2 = new FXMLLoader(this.getClass().getResource("pos_details_panel.fxml"));
         // Parent root = (Parent) loader.load();
           //Pos_Controller Controller = new Pos_Controller();
         
         // loader.setController(Controller);
         // loader.load();
         
        
         pos_details_panel selectedItem = locations.getSelectionModel().getSelectedItem();
        
        System.out.println(selectedItem.getMAIN_LOCATION());
        try{
           // test_me.setText(selectedItem.getMAIN_LOCATION());
            result =selectedItem.getMAIN_LOCATION();
            locations.getScene().getWindow().hide();
            
           
        }
        catch(Exception e){
            
        }
        
          
    }
     
    
     void try_me() throws IOException{
         
         Controller.actionlocationsDetails_panelTable_mouse_clicked(); 
     }
     
   
    
    
    
   
    
    
   
      

      
        @Override
    public void initialize(URL url, ResourceBundle rb) {
       
        try {
            // TODO
            loadLocationsDetailstable();
            
            //locatpion2.setText("ok");
        } catch (IOException ex) {
            Logger.getLogger(pos_locations.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }

 
}
