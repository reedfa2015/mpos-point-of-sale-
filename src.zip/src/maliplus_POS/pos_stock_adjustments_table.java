/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author PSL-STUFF
 */
public class pos_stock_adjustments_table {
private final SimpleStringProperty item_code2;
private final SimpleStringProperty item_name2;
private final SimpleDoubleProperty quantity2;
private final SimpleStringProperty item_price2;
private final SimpleStringProperty description2;
private final SimpleStringProperty item_location2;
private final SimpleDoubleProperty stock_in_hand2;
private final SimpleDoubleProperty variance2;
private final SimpleDoubleProperty close2;
public pos_stock_adjustments_table (String I_C,String I_N,Integer Qty,String I_P,String DESC,String I_L,Integer SIH,Double VAR,Double CLS ){
    this.item_code2 = new SimpleStringProperty(I_C);
     this.item_name2 = new SimpleStringProperty(I_N);
     this.quantity2 = new SimpleDoubleProperty(Qty);
     this.item_price2 = new SimpleStringProperty(I_P);
     this.description2 = new SimpleStringProperty(DESC);
     this.item_location2 = new SimpleStringProperty(I_L);
     this.stock_in_hand2 = new SimpleDoubleProperty(SIH);
     this.variance2 = new SimpleDoubleProperty(VAR);
     this.close2 = new SimpleDoubleProperty(CLS);    
}

    



  public String getITEM_CODE(){
      return item_code2.get();
  }
  public String getITEM_NAME(){
      return item_name2.get();
  }

  public Double getQUANTITY(){
      return quantity2.get();
  }
  public String getITEM_PRICE(){
      return item_price2.get();
  }
  public String getDESCRIPTION(){
      return description2.get();
  }
  
  public String getITEM_LOCATION(){
      return item_location2.get();
  }
  public Double getQUANTITY_STOCK_IN_HAND(){
      return stock_in_hand2.get();
  }
   public Double getVARIANCE(){
      return variance2.get();
  }
   public Double getCLOSE(){
      return close2.get();
  }

  
  public void SetITEM_CODE(String I_C ){
      item_code2.set(I_C);
  }
   public void SetITEM_NAME(String I_NAME){
      item_name2.set(I_NAME);
  }
  
   public void SetQUANTITY(Integer Qty){
      quantity2.set(Qty);
  }
   public void SetITEM_PRICE(String I_P){
      item_price2.set(I_P);
  }
   public void SetDESCRIPTION(String DESC ){
      description2.set(DESC);
  }
   
   public void SetITEM_LOCATION(String I_L ){
      item_location2.set(I_L);
  }
  public void SetQUANTITY_STOCK_IN_HAND(Integer SIH ){
      stock_in_hand2.set(SIH);
  }
   public void SetVARIANCE(Double VAR ){
      variance2.set(VAR);
  }
    public void SetCLOSE(Double CLS ){
      close2.set(CLS);
  }
   
     
      public StringProperty item_codeProperty() {
        return item_code2 ;
    }
       public StringProperty item_nameProperty() {
        return item_name2 ;
    }
    
      public DoubleProperty quantityProperty() {
        return quantity2 ;
    }
        public StringProperty item_priceProperty() {
        return item_price2 ;
    }
          public StringProperty descriptionProperty() {
        return description2 ;
    }
      
            public StringProperty item_locationProperty() {
        return item_location2 ;
    }

                   public DoubleProperty stock_in_handProperty() {
        return stock_in_hand2 ;
    }
                  public DoubleProperty varianceProperty() {
        return variance2 ;
    }
                 public DoubleProperty closeProperty() {
        return close2 ;
    }


}
