/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;

import maliplus.*;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.awt.BorderLayout;
import java.awt.Toolkit;
import java.beans.PropertyVetoException;
import java.io.IOException;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.StackPane;
import javax.swing.JOptionPane;
import static maliplus_POS.pos_panel1.jfxPanel;
import static maliplus_POS.pos_panel1.jfxPanel2;
import static maliplus_POS.pos_panel1.scene2;
import static maliplus_POS.pos_panel1.scene3;
import java.net.URL;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.ResourceBundle;
import javafx.concurrent.Task;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.input.KeyCode;
//import javafx.scene.input.KeyEvent;
import java.awt.event.KeyEvent;
import javafx.scene.layout.Pane;
import javax.swing.JInternalFrame;
import javax.swing.event.InternalFrameEvent;
import javax.swing.event.InternalFrameListener;
import org.controlsfx.control.Notifications;
import javafx.util.Duration;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import org.controlsfx.control.MaskerPane;
import java.awt.*;
import javafx.scene.control.Tooltip;
import java.awt.Toolkit;
import javafx.scene.image.Image;
public class Controller implements Initializable {
 public static Boolean isSplashLoaded= false;   
 public static JFXPanel jfxPanel3;
public static  JFXPanel jfxPanel4;  
public static Scene scene4;
public static Scene scene5;
     Connection con2 = null;
     PreparedStatement pst = null;
     ResultSet rs = null;

public static HashMap<String, String> user = new HashMap<>();

@FXML
    private AnchorPane login_anchor;

    @FXML
    private JFXTextField username;

    @FXML
    private JFXPasswordField password;
        
    @FXML
    private TextField textField ;

    @FXML
    private void printMessage() {
        System.out.println(textField.getText());
    }
    
    
    @FXML
    private JFXButton login;

    @FXML
    private JFXButton exit;

    @FXML
    private Label error_message;
        @FXML
    private ImageView logo;
       
    @FXML
    private AnchorPane anc1; 
    
    @FXML
    private AnchorPane anpane1; 
        @FXML
    private JFXButton save;

    @FXML
    private JFXButton reset;

    @FXML
    private JFXButton new_entries;

    @FXML
    private JFXButton transaction;

    @FXML
    private JFXButton users;

    @FXML
    private JFXButton sales;

    @FXML
    private JFXButton reports;

       @FXML
    private JFXButton exit2;

 @FXML
    private ImageView indicator;

    @FXML
    private MaskerPane maskerpane;
    @FXML
    private JFXButton contact_information;

    @FXML
    private JFXButton leasing;

    @FXML
    private JFXButton transactions;

    @FXML
    private JFXButton user_details;

   
    
    @FXML
    private JFXButton property_details;

    @FXML
    private JFXButton cash_sales;

    @FXML
    private JFXButton security;

    @FXML
    private JFXButton configurations;

    @FXML
    private JFXButton chart_of_accounts;

    @FXML
    private JFXButton code_list;

    @FXML
    private JFXButton sell_in_credit;

    @FXML
    private JFXButton sale_returns;

    @FXML
    private JFXButton debtors_payment;

    @FXML
    private JFXButton customer_reports;

    @FXML
    private JFXButton suppliers;

    @FXML
    private JFXButton buy_in_cash;

    @FXML
    private JFXButton buy_in_credit;

    @FXML
    private JFXButton return_purchases;

    @FXML
    private JFXButton pay_suppliers;

    @FXML
    private JFXButton supplier_reports;

    @FXML
    private JFXButton item_details;

    @FXML
    private JFXButton adjust_stock_balances;

    @FXML
    private JFXButton location_transfers;

    @FXML
    private JFXButton re_package;

    @FXML
    private JFXButton track_sheets;

    @FXML
    private JFXButton blending_products;

    @FXML
    private JFXButton ledger_transactions;

    @FXML
    private JFXButton ledger_journals;

    @FXML
    private JFXButton account_enquiry;

    @FXML
    private JFXButton standard_reports;

    @FXML
    private JFXButton close_month;

    @FXML
    private JFXButton close_year;

 
   
    
    @FXML
    private Label id;
    
    @FXML
    private MenuItem users2;

    @FXML
    private MenuItem groups;

    @FXML
    private MenuItem activate;

    @FXML
    private MenuItem de_activate;

    @FXML
    private MenuItem block_data;
    
        @FXML
    private Tooltip show_state;
    


    @FXML
    private FlowPane content_pane;
    
    @FXML
    private StackPane stackpane;

    @FXML
    private Pane pane;
    
    
    @FXML
    private AnchorPane root;
    
    @FXML
    private AnchorPane pos_panel_root;
    
   
    
    
    @FXML
    private JFXButton customers_btn;

    @FXML
    private JFXButton cash_sales_btn;

    @FXML
    private JFXButton sale_returns_btn;

    @FXML
    private JFXButton customer_reports_btn;

    @FXML
    private JFXButton supplier_reports_btn;

    @FXML
    private JFXButton sell_in_credit_btn;

    @FXML
    private JFXButton pay_suppliers_btn;

    @FXML
    private JFXButton item_details_btn;

    @FXML
    private JFXButton debtor_payments_btn;

    @FXML
    private JFXButton stock_adjustment_btn;

    @FXML
    private JFXButton return_purchases_btn;

    @FXML
    private JFXButton location_transfers_btn;

    @FXML
    private JFXButton serialized_tracksheets_btn;

    @FXML
    private JFXButton standard_reports_btn;

    @FXML
    private JFXButton ledger_transactions_btn;

    @FXML
    private JFXButton account_inquiry_btn;

    @FXML
    private JFXButton suppliers_btn;

    @FXML
    private JFXButton buy_in_cash_btn;

    @FXML
    private JFXButton buy_in_credit_btn;

    @FXML
    private JFXButton configurations_btn;

    @FXML
    private JFXButton security_btn;

    @FXML
    private JFXButton close_month_btn;

    @FXML
    private JFXButton close_year_btn;

    @FXML
    private JFXButton exit_btn;
    
        private  void LoadSplashScreen(){
        
           try {
              // dashboard.hide();
              
               Controller.isSplashLoaded=true;
                
                pane = FXMLLoader.load(getClass().getResource("splash_screen.fxml"));
                pos_panel_root.getChildren().setAll(pane);
              // scene3.getRoot().setVisible(true);
               scene2 = new Scene(pos_panel_root, 1400, 992);
              jfxPanel.setScene(scene2);
           
               
               FadeTransition fadeIn = new FadeTransition(Duration.seconds(1),pos_panel_root);
               fadeIn.setFromValue(0);
               fadeIn.setToValue(60);
               fadeIn.setCycleCount(1);
               
               FadeTransition fadeOut = new FadeTransition(Duration.seconds(3),pos_panel_root);
               fadeOut.setFromValue(1);
               fadeOut.setToValue(0);
               fadeOut.setCycleCount(1);
               
             
               
               
               fadeIn.play();
               
             fadeIn.setOnFinished((e)->{
                 fadeOut.play();
              });
               
              fadeOut.setOnFinished((e)->{
                 try {
        Parent root2 = FXMLLoader.load(getClass().getResource("splash_login.fxml"));
           scene3 = new Scene(root2, 1400, 992);
            scene3.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
            jfxPanel.setScene(scene3);
            
         
           
              
        } catch (IOException exc) {
            exc.printStackTrace();
            System.exit(1);
        }
                            
             });
               
          } catch (IOException ex) {
              Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
          }
}
       
        
        
        
         @FXML
    void handleButton(MouseEvent event) throws IOException {
       if(event.getSource()==exit){
            System.exit(0);
       
        }
        
            if(event.getSource()==exit2){
            System.exit(0);
            }
        
        else
            if(event.getSource()==save){
            
                
                
            }
          
        
 
            
    }
    
     @FXML
    void mouseClicked(ActionEvent event) {
            if(event.getSource()==users2){
             users3.main(null);
             
             
            
            }
            
            
            
               
    }
    
    
    
   
    
     public  void initFX2(JFXPanel jfxPanel3) {
        try {
         //  Controller Controller = new Controller();
             // primarystage = (Stage) Controller.getScene().getWindow(); 
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_dashboard.fxml"));
              /*  loader.<pos_items>getController();
              Controller.setsearch_item2(item_code_txtf.getText());*/
              
            
              loader.getController();
           anpane1 = loader.load();
            scene4 = new Scene(anpane1, 1256, 858);
            scene4.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
            jfxPanel3.setScene(scene4);
           
        } catch (IOException exc) {
            exc.printStackTrace();
            System.exit(1);
        }
    }
     
      private void initFX() {
        try {
             
          Parent root22 = FXMLLoader.load(getClass().getResource("pos_panel.fxml"));
           scene3 = new Scene(root22, 1400, 992);
            scene3.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
            jfxPanel.setScene(scene3);
            
         
           
              
        } catch (IOException exc) {
            exc.printStackTrace();
            System.exit(1);
        }
    }
      public  class MyInternalFrame extends JInternalFrame implements InternalFrameListener {
       public MyInternalFrame(){
            super("Frame", true, true, true, true);    
            setDefaultCloseOperation(maliplus_POS.pos_panel1.dashboard.DO_NOTHING_ON_CLOSE);    
            maliplus_POS.pos_panel1.dashboard.addInternalFrameListener(this);    
            maliplus_POS.pos_panel1.dashboard.setLayout(new BorderLayout()); 
            jfxPanel3=new JFXPanel();
            maliplus_POS.pos_panel1.dashboard.add(jfxPanel3, BorderLayout.CENTER);
            maliplus_POS.pos_panel1.dashboard.setVisible(true);
            maliplus_POS.pos_panel1.dashboard.setSize(1450, 858);
            maliplus_POS.pos_panel1.dashboard.setVisible(true);
                try {
            maliplus_POS.pos_panel1.dashboard.setMaximum(true);
           }
                catch (PropertyVetoException e) {
  // Vetoed by internalFrame
  // ... possibly add some handling for this case
}
             Platform.runLater(() -> initFX2(jfxPanel3));
            
  
        }
      
        @Override
        public void internalFrameOpened(InternalFrameEvent event) {
            //To change body of implemented methods use File | Settings | File Templates.
           
        }
  
        
        @Override
        public void internalFrameClosing(InternalFrameEvent event) {
            Notifications closeDashboard = Notifications.create()
                        .title("Exiting MaliPlus Dashboard!!")
                        .text("Are you sure you want to close this window.Warning!!closing this window will terminate all other opened windows!!")
                        .graphic(null)
                        .hideAfter(Duration.seconds(10))
                        .position(Pos.CENTER)
                        .onAction((ActionEvent event1) -> {
                            System.out.println("Clicked on notification!");
            });        
          closeDashboard.show();
        
      }
  
       
       @Override
        public void internalFrameClosed(InternalFrameEvent event) {
            //To change body of implemented methods use File | Settings | File Templates.
        }
  
        
       @Override
        public void internalFrameIconified(InternalFrameEvent event) {
        
            
        }
  
        
       @Override
        public void internalFrameDeiconified(InternalFrameEvent event) {
            //To change body of implemented methods use File | Settings | File Templates.
        }
  
       
       @Override
        public void internalFrameActivated(InternalFrameEvent event) {
            //To change body of implemented methods use File | Settings | File Templates.
        }
  
        
       @Override
        public void internalFrameDeactivated(InternalFrameEvent event) {
            //To change body of implemented methods use File | Settings | File Templates.
        }
   } 
    

     private void loadHomeDetails() throws IOException{
                 try {
        Parent root10 = FXMLLoader.load(getClass().getResource("dashboard.fxml"));
           scene2 = new Scene(root10, 1400, 992);
           // scene2.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
            jfxPanel2.setScene(scene2);
            
         
           
              
        } catch (IOException exc) {
            exc.printStackTrace();
            System.exit(1);
        }
         
         
         
         try {
                   
        Parent root6 = FXMLLoader.load(getClass().getResource("pos_panel.fxml"));
           scene3 = new Scene(root6, 1400, 992);
            scene3.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
            jfxPanel.setScene(scene3);
            
         
           
              
        } catch (IOException exc) {
            exc.printStackTrace();
            System.exit(1);
        }
          
               
            
    }
     private static String generateStorngPasswordHash(String password) throws NoSuchAlgorithmException, InvalidKeySpecException
    {
        int iterations = 1000;
        char[] chars = password.toCharArray();
        byte[] salt = getSalt();
         
        PBEKeySpec spec = new PBEKeySpec(chars, salt, iterations, 64 * 8);
        SecretKeyFactory skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
        byte[] hash = skf.generateSecret(spec).getEncoded();
        return iterations + ":" + toHex(salt) + ":" + toHex(hash);
    }

private static byte[] getSalt() throws NoSuchAlgorithmException
    {
        SecureRandom sr = SecureRandom.getInstance("SHA1PRNG");
        byte[] salt = new byte[16];
        sr.nextBytes(salt);
        return salt;
    }

  private static String toHex(byte[] array) throws NoSuchAlgorithmException
    {
        BigInteger bi = new BigInteger(1, array);
        String hex = bi.toString(16);
        int paddingLength = (array.length * 2) - hex.length();
        if(paddingLength > 0)
        {
            return String.format("%0"  +paddingLength + "d", 0) + hex;
        }else{
            return hex;
        }
    }

   
    private static boolean validatePassword(String originalPassword, String storedPassword) throws NoSuchAlgorithmException, InvalidKeySpecException
    {
        
        String[] parts = storedPassword.split(":");
        int iterations = Integer.parseInt(parts[0]);
        byte[] salt = fromHex(parts[1]);
        byte[] hash = fromHex(parts[2]);
         
        PBEKeySpec spec = new PBEKeySpec(originalPassword.toCharArray(), salt, iterations, hash.length * 8);
        SecretKeyFactory skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
        byte[] testHash = skf.generateSecret(spec).getEncoded();
         
        int diff = hash.length ^ testHash.length;
        for(int i = 0; i < hash.length && i < testHash.length; i++)
        {
            diff |= hash[i] ^ testHash[i];
        }
        return diff == 0;
    }
    private static byte[] fromHex(String hex) throws NoSuchAlgorithmException
    {
        byte[] bytes = new byte[hex.length() / 2];
        for(int i = 0; i<bytes.length ;i++)
        {
            bytes[i] = (byte)Integer.parseInt(hex.substring(2 * i, 2 * i + 2), 16);
        }
        return bytes;
    }
    
            void loadMaskerPane(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    maskerpane.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                    try {
                        loadCredentials();
                    } catch (NoSuchAlgorithmException ex) {
                        Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (InvalidKeySpecException ex) {
                        Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    maskerpane.setVisible(false);
                }
            };
            new Thread(task).start();
     }
            
            void loadCredentials() throws NoSuchAlgorithmException, InvalidKeySpecException{
                     String generatedSecuredPasswordHash;
                     String sql= "select PASS_WORD from USERS where USER_NAMES='"+username.getText()+"' and PASS_WORD='"+password.getText()+"' ";
              try{
            con2 = DBConnection.ConnectDB(); 
            pst = con2.prepareStatement(sql);
            rs = pst.executeQuery();
            
            
                      String  originalPassword = ""+password.getText()+"";
       
                    
                             generatedSecuredPasswordHash = generateStorngPasswordHash(originalPassword);
                             // System.out.println(generatedSecuredPasswordHash);
                         
    

         
       
            if(rs.next()){
            
                    String x= rs.getString("PASS_WORD");
                    System.out.println(""+x+"");   
                
                
                
         boolean matched;
                
                    matched = validatePassword(""+password.getText()+"",generatedSecuredPasswordHash);
                
         System.out.println(matched);
        
           //  if(matched==true){
                  MyInternalFrame inf = new MyInternalFrame();
           inf.setVisible(true);
           
                 maliplus_POS.pos_panel1.jToolBar1.setVisible(true);
                  maliplus_POS.pos_panel1.jToolBar2.setVisible(true);
                   maliplus_POS.pos_panel1.jToolBar3.setVisible(true);
                   maliplus_POS.pos_panel1.jMenuBar1.setVisible(true);
                   
                   
                   Platform.runLater(() -> initFX());
                   
            // }
         
          //  matched = validatePassword(""+password.getText()+"", ""+rs+"");
          //  System.out.println(matched);     
               
           
    
            //loadHomeDetails();
  
         
           
                   
                
              
                
             //   primarystage.hide();
           
           // primarystage1=(Stage)mainPane2.getScene().getWindow();
           // primarystage1.close();
              
              
            //  Maliplus_Panel.main(null);
        
             // primarystage1.close();
            
         
             
               //current_password.setText(""+user.get("password")+"");
                
            //loginAction();
            }
            else{
         // JOptionPane.showMessageDialog(null,"Invalid UserName or Password or click to Create new account");
           error_message.setText("Invalid username or password!!");
           password.setText("");
          }
              }
            catch(SQLException e){
       // JOptionPane.showMessageDialog(null,e);
        e.printStackTrace();
            }
            
                
          //else{
         // JOptionPane.showMessageDialog(null,"Invalid UserName or Password or click to Create new account");
          // error_message.setText("Invalid username or password!!");
          // password.setText("");
         //  }
        
               
}
   @FXML
    void actionPerformed(ActionEvent event) throws IOException,NoSuchAlgorithmException, InvalidKeySpecException {
                           if(event.getSource()==password){ 
                               //giveAlertifCapslockkeyisOn();
                               Toolkit.getDefaultToolkit().setLockingKeyState(KeyEvent.VK_CAPS_LOCK, false);
                               loadMaskerPane();
                }
            else
                           if(event.getSource()==login){
                              Toolkit.getDefaultToolkit().setLockingKeyState(KeyEvent.VK_CAPS_LOCK, false);
                              loadMaskerPane();
                               /*              con2 = DBConnection.ConnectDB();
                               try{
                               
                               
                               
                               String originalPassword= "select * from USERS where USER_NAMES=? and PASS_WORD=?";
                               pst = con2.prepareStatement(originalPassword);
                               pst.setString(1, username.getText());
                               pst.setString(2, password.getText());
                               rs =  pst.executeQuery();
                               if(rs.next()){
                               
                               
                               //loadHomeDetails();
                               
                               
                               MyInternalFrame inf = new MyInternalFrame();
                               inf.setVisible(true);
                               
                               maliplus_POS.pos_panel1.jToolBar1.setVisible(true);
                               maliplus_POS.pos_panel1.jToolBar2.setVisible(true);
                               maliplus_POS.pos_panel1.jToolBar3.setVisible(true);
                               maliplus_POS.pos_panel1.jMenuBar1.setVisible(true);
                               
                               
                               
                               
                               //   primarystage.hide();
                               
                               // primarystage1=(Stage)mainPane2.getScene().getWindow();
                               // primarystage1.close();
                               
                               Platform.runLater(() -> initFX());
                               //  Maliplus_Panel.main(null);
                               
                               // primarystage1.close();
                               
                               
                               
                               //current_password.setText(""+user.get("password")+"");
                               
                               //loginAction();
                               
                               
                               
                               }
                               else{
                               //  JOptionPane.showMessageDialog(null,"Invalid UserName or Password or click to Create new account");
                               error_message.setText("Invalid username or password!!");
                               password.setText("");
                               }
                               }catch(SQLException e){
                               JOptionPane.showMessageDialog(null,e);
                               
                               }*/
               
                }
            else
            
          if(event.getSource()==customers_btn){
              pos_customers_form.main(null);
          } 
            else
              if(event.getSource()==item_details_btn){
             pos_item_master.main(null);
              }
            else
                  if(event.getSource()==leasing){
                         Dynamic1.getObj().setVisible(true);
           Dynamic1.callLeasing();
                  }
            else
            if(event.getSource()==transactions){
             Transactions_Form.getobj().setVisible(true);
            }
            else
                if(event.getSource()==chart_of_accounts){
                 Dynamic1.getObj().setVisible(true);
                 Dynamic1.callAccountMaster();
                }
            else
                    if(event.getSource()==security){
               // users_2.getObj().setVisible(true);
                    }
            else
                   if(event.getSource()==configurations){
                        Configurations1.getObj().setVisible(true);  
                   }
            else
                       if(event.getSource()==code_list){
                            CodeListForm_1.getObj().setVisible(true);     
                       }
            else
                    if(event.getSource()==user_details){
                              users_2.getObj().setVisible(true); 
                           }
           else
                if(event.getSource()==standard_reports){
                        Standard_Report.getObj().setVisible(true);
                } 
                           else
                    if(event.getSource()==cash_sales_btn){
                         Pos_Controller.main(null);
                    }
            
            
           
    }
    
    
 
    
      @FXML
    void clicked(MouseEvent event) {
     if(event.getSource()==indicator){
                       con2 = DBConnection.ConnectDB();
        try{
            String sql = "select * from USERS where USER_NAMES=? and PASS_WORD=?";
            pst = con2.prepareStatement(sql);
            pst.setString(1, username.getText());
            pst.setString(2, password.getText());
            rs =  pst.executeQuery();
            if(rs.next()){
               user.put("user_names",""+username.getText()+"");
           //    user.put("password", ""+password.getText()+"");
          
                Maliplus_Panel.main(null);
               
               
             
               //current_password.setText(""+user.get("password")+"");
                
            //loginAction();
          
            
            
                }
            else{
          //  JOptionPane.showMessageDialog(null,"Invalid UserName or Password or click to Create new account");
            error_message.setText("Invalid username or password!!");
            password.setText("");
            }
        }catch(SQLException e){
        JOptionPane.showMessageDialog(null,e);
        
            }   
     }
    }
    
    void giveAlertifCapslockkeyisOn(){
     if (!Toolkit.getDefaultToolkit().getLockingKeyState(KeyEvent.VK_CAPS_LOCK)) {
 
         
         Toolkit.getDefaultToolkit().setLockingKeyState(KeyEvent.VK_CAPS_LOCK, true);
       // password.setTooltip(new Tooltip("Capslock key is ON!!"));
            final Tooltip tooltip = new Tooltip();
            tooltip.setText("CAPSLOCK KEY IS ON...Passwords are case sensitive");
             Image image = new Image(
    getClass().getResourceAsStream("/images_/caution3.png")
                   );
           tooltip.setGraphic(new ImageView(image));
           tooltip.setStyle("-fx-text-fill: white;");
       password.setTooltip(tooltip);
       
   }
 
    }
    
     void giveAlertifCapslockkeyisOn2(){
     if (!Toolkit.getDefaultToolkit().getLockingKeyState(KeyEvent.VK_CAPS_LOCK)) {
      
         
         Toolkit.getDefaultToolkit().setLockingKeyState(KeyEvent.VK_CAPS_LOCK, true);
         
         final Tooltip tooltip = new Tooltip();
            tooltip.setText("CAPSLOCK KEY IS ON...Usernames are case sensitive");
            Image image = new Image(
    getClass().getResourceAsStream("/images_/caution3.png")
                   );
           tooltip.setGraphic(new ImageView(image));
           tooltip.setStyle("-fx-text-fill: white;");
            
       username.setTooltip(tooltip);
       // password.setTooltip(new Tooltip("Capslock key is ON!!"));    
       
   }
 
    }
    
        @FXML
    void mouseReleased(MouseEvent event) {
        if(event.getSource().equals(password)){
            giveAlertifCapslockkeyisOn();
        }
        else
            if(event.getSource().equals(username)){
                giveAlertifCapslockkeyisOn2();
            }
    }
    

   @Override
    public void initialize(URL url, ResourceBundle rb) {
         
        if(!Controller.isSplashLoaded){
           LoadSplashScreen();  
        }
        
      //  giveAlertifCapslockkeyisOn();
    }
    
    
    
    
    
}
