/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;

import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.AnchorPane;
/**
 *
 * @author PSL-STUFF
 */
public class drawer_controller implements Initializable {
     @FXML
    private JFXButton home_btn;

    @FXML
    private JFXButton cash_sales_btn;

    @FXML
    private JFXButton sell_in_credit_btn;

    @FXML
    private JFXButton stock_adjustments_btn;

    @FXML
    private JFXButton stock_transfers_btn;

    @FXML
    private JFXButton pay_suppliers_btn;

    @FXML
    private JFXButton buy_in_cash_btn;

    @FXML
    private JFXButton buy_in_credit_btn;

    @FXML
    private JFXButton return_purchases_btn;

    @FXML
    private JFXButton location_transfers_btn;

    @FXML
    private JFXButton debtors_payment_btn;

    @FXML
    private JFXButton configurations_btn;

    @FXML
    private JFXButton security_btn;

    @FXML
    private JFXButton serialized_tracksheets_btn;

    @FXML
    private JFXButton account_inquiry_btn;

    @FXML
    void actionPerformed(ActionEvent event) {
        if(event.getSource()==home_btn){
            loadDashboardDetails();
        }
    }   

   void loadDashboardDetails(){
       
      
       pos_customers_form Controller = new pos_customers_form();
       Controller.loadDashboard();
      
       
   }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    //    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    
    
    
    }
}
