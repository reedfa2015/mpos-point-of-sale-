/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;
import java.util.ListIterator;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author PSL-STUFF
 */
public class pos_type_details_panel {
private final SimpleStringProperty description2;
private final SimpleStringProperty key_word2;

public pos_type_details_panel (String DESC,String KEYWORD){
    this.description2 = new SimpleStringProperty(DESC);
    this.key_word2= new SimpleStringProperty(KEYWORD);

         
}



  public String getDESCRIPTION(){
      return description2.get();
  }
  
   public String getKEYWORD(){
      return key_word2.get();
  }
 


  
  public void SetDESCRIPTION(String DESC ){
      description2.set(DESC);
  }
  
  public void SetKEYWORD(String KEYWORD ){
      key_word2.set(KEYWORD);
  }
   
     
      public StringProperty descriptionProperty() {
        return description2 ;
    }
    
       
      public StringProperty key_wordProperty() {
        return key_word2 ;
    }



}
