/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;
import java.awt.Toolkit;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.embed.swing.JFXPanel;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXDialog;
import com.jfoenix.controls.JFXDrawer;
import com.jfoenix.controls.JFXHamburger;
import com.jfoenix.controls.JFXRadioButton;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.transitions.hamburger.HamburgerBackArrowBasicTransition;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.util.function.UnaryOperator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextFormatter;
import javafx.scene.image.Image;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.media.MediaView;
import javafx.stage.Stage;
import javafx.util.converter.DoubleStringConverter;
import javafx.util.converter.IntegerStringConverter;
import javax.swing.JDialog;
import maliplus.DBConnection;
import static maliplus_POS.Pos_Controller.rs;
import static maliplus_POS.Pos_Controller.stage2;
import static maliplus_POS.pos_stock_adjustment_initial.pst;
import org.controlsfx.control.MaskerPane;
import org.controlsfx.control.textfield.CustomTextField;
/**
 *
 * @author PSL-STUFF
 */
public class pos_customers_form implements Initializable{
    static Connection conn = null;
    static ResultSet rs = null;
    static PreparedStatement pst = null;
    
    private Boolean result = null;
    public Boolean getResult() {
        
        return result;
    }
    
    @FXML
    private AnchorPane customer_ancp;

    @FXML
    private MaskerPane maskerpane;
    
       @FXML
    private MediaView media_view;
       
       


    @FXML
    private JFXButton insert_btn;

    @FXML
    private JFXButton save_btn;

    @FXML
    private JFXButton search_btn;

    @FXML
    private JFXButton excel_btn;

    @FXML
    private JFXButton refresh_btn;

    @FXML
    private JFXButton report_btn;

    @FXML
    private JFXButton clear_btn;

    @FXML
    private JFXButton back_btn;

    @FXML
    private JFXRadioButton new_rdbtn;

    @FXML
    private JFXRadioButton existing_rdbtn;

    @FXML
    private JFXTextField src_txtf;

    @FXML
    private Label src_lbl;

    @FXML
    private Label ledger_number_lbl;

    @FXML
    private CustomTextField ledger_number_txtf;

    @FXML
    private Label ledger_number_lbl2;

    @FXML
    private CustomTextField customer_name_txtf;

    @FXML
    private JFXRadioButton customer_rdbtn;

    @FXML
    private JFXRadioButton supplier_rdbtn;

    @FXML
    private Label current_status_lbl;

    @FXML
    private JFXTextField current_status_txtf;

    @FXML
    private Label customer_group_lbl;

    @FXML
    private Label account_number_lbl;

    @FXML
    private JFXTextField account_number_txtf;

    @FXML
    private Label account_number_lbl2;

    @FXML
    private JFXTextField vat_number_txtf;

    @FXML
    private JFXTextField pin_number_txtf;

    @FXML
    private Label customer_group_edit_lbl;

    @FXML
    private Label sales_area_lbl;

    @FXML
    private JFXTextField sales_area_txtf;

    @FXML
    private JFXTextField card_number_txtf;

    @FXML
    private Label card_number_lbl;

    @FXML
    private Spinner<Double> credit_limit_spinner;

    @FXML
    private Spinner<Double> current_period_spinner;

    @FXML
    private JFXCheckBox credit_account_chkbx;

    @FXML
    private JFXCheckBox whole_sale_customer_chkbx;

    @FXML
    private Label inventory_location_lbl;

    @FXML
    private Spinner<Double> discount_rate_spinner;

    @FXML
    private Spinner<Double> pref_priority_spinner;

    @FXML
    private Spinner<Double> credit_rating_spinner;

    @FXML
    private JFXTextField inventory_location_txtf;

    @FXML
    private JFXTextField customer_group_txtf;

    @FXML
    private JFXCheckBox customer_chkbx;

    @FXML
    private JFXCheckBox supplier_chkbx;

    @FXML
    private JFXTextField contact_title_txtf;

    @FXML
    private JFXTextField telephone_number_txtf;

    @FXML
    private JFXTextField email_txtf;

    @FXML
    private JFXTextArea address_txtarea;

    @FXML
    private JFXTextField contact_person_txf;

    @FXML
    private JFXTextField phone_txtf;

    @FXML
    private JFXTextField city_town_txtf;

    @FXML
    private Spinner<Double> distance_spinner;
    
    
    @FXML
    private TableView<customers_table> customer_table;

    @FXML
    private TableColumn<customers_table, String> ledger_number_tbnode;

    @FXML
    private TableColumn<customers_table, String> customer_name_tbnode;

    @FXML
    private TableColumn<customers_table, String> status_tbnode;

    @FXML
    private TableColumn<customers_table, String> telephone_tbnode;

    @FXML
    private TableColumn<customers_table, String> base_location_tbnode;

    @FXML
    private TableColumn<customers_table, String> town_city_tbnode;

    @FXML
    private TableColumn<customers_table, String> email_address_tbnode;

    @FXML
    private TableColumn<customers_table, String> contact_person_tbnode;

    @FXML
    private TableColumn<customers_table, String> contact_phone_tbnode;

    @FXML
    private TableColumn<customers_table, String> cred_tbnode;
    
     @FXML
    private JFXHamburger hamburger;

    @FXML
    private JFXDrawer drawer;
    
    
    @FXML
    private AnchorPane multi_pane_changer;
    
        @FXML
    private JFXButton home_btn;

    @FXML
    private JFXButton cash_sales_btn;

    @FXML
    private JFXButton sell_in_credit_btn;

    @FXML
    private JFXButton stock_adjustments_btn;

    @FXML
    private JFXButton stock_transfers_btn;

    @FXML
    private JFXButton pay_suppliers_btn;

    @FXML
    private JFXButton buy_in_cash_btn;

    @FXML
    private JFXButton buy_in_credit_btn;

    @FXML
    private JFXButton return_purchases_btn;

    @FXML
    private JFXButton location_transfers_btn;

    @FXML
    private JFXButton debtors_payment_btn;

    @FXML
    private JFXButton configurations_btn;

    @FXML
    private JFXButton security_btn;

    @FXML
    private JFXButton serialized_tracksheets_btn;

    @FXML
    private JFXButton account_inquiry_btn;

ObservableList<customers_table> data = FXCollections.observableArrayList();
  void loadCustomerDetailTable(){
         
         
          String customers="select *  from CUSTOMERS" ;
          conn=DBConnection.ConnectDB();
          try{
                  
                pst=conn.prepareStatement(customers);
               rs=pst.executeQuery();
                     while(rs.next()){
                     data.add(new customers_table(
                           rs.getString("LEDGER_NUMBER"),
                           rs.getString("LEDGER_NAME"),
                           rs.getString("LEDGER_STATUS"),
                           rs.getString("TELEPHONES"),
                           rs.getString("BASE_LOCATION"),
                           rs.getString("TOWNCITY"),
                           rs.getString("EMAIL_ADDRESS"),
                           rs.getString("CONTACT_PERSON"),
                           rs.getString("CONTACT_PHONE"),
                           rs.getString("ON_CREDIT")
             
             
             ));  
                     
                         ledger_number_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<customers_table, String> cellData) -> {
            return cellData.getValue().ledger_numberProperty();
     
        });
        customer_name_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<customers_table, String> cellData) -> {
            return cellData.getValue().customer_nameProperty();
     
        });
        status_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<customers_table, String> cellData) -> {
            return cellData.getValue().statusProperty();
     
        });
        telephone_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<customers_table, String> cellData) -> {
            return cellData.getValue().telephoneProperty();
     
        });
        base_location_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<customers_table, String> cellData) -> {
            return cellData.getValue().base_locationProperty();
     
        });
        town_city_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<customers_table, String> cellData) -> {
            return cellData.getValue().town_cityProperty();
     
        });
        email_address_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<customers_table, String> cellData) -> {
            return cellData.getValue().email_addressProperty();
     
        });
        contact_person_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<customers_table, String> cellData) -> {
            return cellData.getValue().contact_personProperty();
     
        });
        contact_phone_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<customers_table, String> cellData) -> {
            return cellData.getValue().contact_phoneProperty();
     
        });
        cred_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<customers_table, String> cellData) -> {
            return cellData.getValue().credProperty();
     
        });
      
                      customer_table.setItems(data);
                      //calculateTotalSalesAmount();
          }
                          
                       
             }
             catch(Exception e){
                e.printStackTrace();
             }
  }     
       void playMedia(){
           String workingDirectory=System.getProperty("user.dir");
           File f= new File(workingDirectory,"//videos/bgslide2.mp4");
           
          Media m= new Media(f.toURI().toString());
          MediaPlayer mp= new MediaPlayer(m);
           mp.setAutoPlay(true);
           //mp.setStartTime(Duration.seconds(0));
          // mp.setStopTime(Duration.seconds(48));
          mp.setCycleCount(mp.INDEFINITE);
           media_view.setMediaPlayer(mp);
       //   mp.play();
          
          
          
           
       }
       
       void windowOpened(){
            setSpinnerValue(credit_limit_spinner,0.00);
            setSpinnerValue(current_period_spinner,0.00);
            setSpinnerValue(discount_rate_spinner,0.00);
            setSpinnerValue(pref_priority_spinner,0.00);
            setSpinnerValue(credit_rating_spinner,0.00);
            setSpinnerValue(distance_spinner,0.00);
       }
            void loadMaskerPane(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    maskerpane.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                    playMedia();
                    loadCustomerDetailTable();
                    windowOpened();
                    opendrawerContent();
                    setAnchorPane(multi_pane_changer);
                    loadDashboard();
                   
                    maskerpane.setVisible(false);
                }
            };
            new Thread(task).start();
     }
           void loadMaskerPane2(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    maskerpane.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                    onSelectCustomer();
                   
                    maskerpane.setVisible(false);
                }
            };
            new Thread(task).start();
     } 
          
              void loadMaskerPane3(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    maskerpane.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                     loadcustomerdetails2();
                   
                    maskerpane.setVisible(false);
                }
            };
            new Thread(task).start();
     }
          
           
           void SearchCustomerDetails(){
           FilteredList<customers_table> filteredData = new FilteredList<>(data, p -> true);
            customer_name_txtf.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(customer -> {
                // If filter text is empty, display all persons.
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }

                // Compare first name and last name of every person with filter text.
                String lowerCaseFilter = newValue.toLowerCase();
                 String upperCaseFilter = newValue.toUpperCase();
                if (customer.getcustomer_name().toUpperCase().contains(upperCaseFilter)) {
                    return true; // Filter matches item_code.
                } /*else
                if (journal.getTRN_LOCATION().toLowerCase().contains(lowerCaseFilter)) {
                return true; // Filter matches item_name.
                }
                else
                if (journal.getDATE_CREATED().toLowerCase().contains(lowerCaseFilter)) {
                return true; // Filter matches item_name.
                }
                else
                if (journal.getDESCRIPTION().toLowerCase().contains(lowerCaseFilter)) {
                return true; // Filter matches item_name.
                }*/
                /*           else
                if (item.getBARCODE().toLowerCase().contains(lowerCaseFilter)) {
                return true; // Filter matches item_name.
                }*/
                return false; // Does not match.
            });
        });
            
             SortedList<customers_table> sortedData = new SortedList<>(filteredData);
              sortedData.comparatorProperty().bind(customer_table.comparatorProperty());
              customer_table.setItems(sortedData);
}
           
                 void SearchCustomerDetails2(){
           FilteredList<customers_table> filteredData = new FilteredList<>(data, p -> true);
            src_txtf.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(customer -> {
                // If filter text is empty, display all persons.
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }

                // Compare first name and last name of every person with filter text.
                String lowerCaseFilter = newValue.toLowerCase();
                 String upperCaseFilter = newValue.toUpperCase();
                if (customer.getcustomer_name().toUpperCase().contains(upperCaseFilter)) {
                    return true; // Filter matches item_code.
                } /*else
                if (journal.getTRN_LOCATION().toLowerCase().contains(lowerCaseFilter)) {
                return true; // Filter matches item_name.
                }
                else
                if (journal.getDATE_CREATED().toLowerCase().contains(lowerCaseFilter)) {
                return true; // Filter matches item_name.
                }
                else
                if (journal.getDESCRIPTION().toLowerCase().contains(lowerCaseFilter)) {
                return true; // Filter matches item_name.
                }*/
                /*           else
                if (item.getBARCODE().toLowerCase().contains(lowerCaseFilter)) {
                return true; // Filter matches item_name.
                }*/
                return false; // Does not match.
            });
        });
            
             SortedList<customers_table> sortedData = new SortedList<>(filteredData);
              sortedData.comparatorProperty().bind(customer_table.comparatorProperty());
              customer_table.setItems(sortedData);
}
                       void SearchCustomerDetails3(){
           FilteredList<customers_table> filteredData = new FilteredList<>(data, p -> true);
            ledger_number_txtf.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(customer -> {
                // If filter text is empty, display all persons.
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }

                // Compare first name and last name of every person with filter text.
                String lowerCaseFilter = newValue.toLowerCase();
                 String upperCaseFilter = newValue.toUpperCase();
                if (customer.getledger_number().toUpperCase().contains(upperCaseFilter)) {
                    return true; // Filter matches item_code.
                } /*else
                if (journal.getTRN_LOCATION().toLowerCase().contains(lowerCaseFilter)) {
                return true; // Filter matches item_name.
                }
                else
                if (journal.getDATE_CREATED().toLowerCase().contains(lowerCaseFilter)) {
                return true; // Filter matches item_name.
                }
                else
                if (journal.getDESCRIPTION().toLowerCase().contains(lowerCaseFilter)) {
                return true; // Filter matches item_name.
                }*/
                /*           else
                if (item.getBARCODE().toLowerCase().contains(lowerCaseFilter)) {
                return true; // Filter matches item_name.
                }*/
                return false; // Does not match.
            });
        });
            
             SortedList<customers_table> sortedData = new SortedList<>(filteredData);
              sortedData.comparatorProperty().bind(customer_table.comparatorProperty());
              customer_table.setItems(sortedData);
}
           
           @FXML
    void onKeyTyped(KeyEvent event) {
        if(event.getSource()==customer_name_txtf){
         SearchCustomerDetails(); 
        }
        else
            if(event.getSource()==src_txtf){
             SearchCustomerDetails2();    
            }
        else
                if(event.getSource()==ledger_number_txtf){
                SearchCustomerDetails3();       
                }
    }
    
      @FXML
    void actionPerformed(ActionEvent event) {
        if(event.getSource()==src_txtf){
            loadMaskerPane3();
        }
        else
            if(event.getSource()==home_btn){
                try{
                 // pos_customers_form Controller = new pos_customers_form();
                FXMLLoader loader = new FXMLLoader(this.getClass().getResource("customers.fxml"));
                loader.getController();
                loader.load();
                loadDashboard();   
                }
                catch(Exception e){
                    e.printStackTrace();
                }
               
            }
    
    }
            
            
              NumberFormat format = NumberFormat.getIntegerInstance();
       UnaryOperator<TextFormatter.Change> filter = c -> {
    if (c.isContentChange()) {
        ParsePosition parsePosition = new ParsePosition(0);
        // NumberFormat evaluates the beginning of the text
        format.parse(c.getControlNewText(), parsePosition);
        if (parsePosition.getIndex() == 0 ||
                parsePosition.getIndex() < c.getControlNewText().length()) {
            // reject parsing the complete text failed
            return null;
        }
    }
    return c;
};
        TextFormatter<Double> priceFormatter = new TextFormatter<Double>(
        new DoubleStringConverter(), 0.00, filter);
     void loadspInnervalues(){   
         String credit_limit_value="Select * from customers where ledger_number='"+ledger_number_txtf.getText()+"'";
        
         try{
             pst=conn.prepareStatement(credit_limit_value);
             rs=pst.executeQuery();
             while(rs.next()){
                  if(rs.getString("CHECK_OPTION1").equals("Y")){
       whole_sale_customer_chkbx.setSelected(true);
        whole_sale_customer_chkbx.setText("Y");
       }
       else{
        whole_sale_customer_chkbx.setSelected(false);
        whole_sale_customer_chkbx.setText("N");
       }
                  
       contact_title_txtf.setText(rs.getString("CONTACT_TITLE"));
       address_txtarea.setText(rs.getString("ADDRESS"));
       account_number_txtf.setText(rs.getString("ACCOUNT_NUMBER"));
       pin_number_txtf.setText(rs.getString("PIN_CODE"));
       customer_group_txtf.setText(rs.getString("LEDGER_GROUP"));
       sales_area_txtf.setText(rs.getString("SALES_AREA"));
       card_number_txtf.setText(rs.getString("CARD_NUMBER"));
       vat_number_txtf.setText(rs.getString("VAT_NUMBER"));
       
                 
                  TextFormatter<Double> priceFormatter1 = new TextFormatter<Double>(
        new DoubleStringConverter(),rs.getDouble("CREDIT_LIMIT"), filter);
          credit_limit_spinner.getEditor().setTextFormatter(priceFormatter1);
          
          TextFormatter<Double> priceFormatter2 = new TextFormatter<Double>(
        new DoubleStringConverter(),rs.getDouble("CREDIT_PERIOD"), filter);
          current_period_spinner.getEditor().setTextFormatter(priceFormatter2);
          
          TextFormatter<Double> priceFormatter3 = new TextFormatter<Double>(
        new DoubleStringConverter(),rs.getDouble("DISCOUNT_RATE"), filter);
          discount_rate_spinner.getEditor().setTextFormatter(priceFormatter3);
          
           TextFormatter<Double> priceFormatter4 = new TextFormatter<Double>(
        new DoubleStringConverter(),rs.getDouble("PREF_PRIORITY"), filter);
          pref_priority_spinner.getEditor().setTextFormatter(priceFormatter4);
          
           TextFormatter<Double> priceFormatter6 = new TextFormatter<Double>(
        new DoubleStringConverter(),rs.getDouble("CREDIT_RATING"), filter);
          credit_rating_spinner.getEditor().setTextFormatter(priceFormatter6);
          
           TextFormatter<Double> priceFormatter7 = new TextFormatter<Double>(
        new DoubleStringConverter(),rs.getDouble("DISTANCE"), filter);
          distance_spinner.getEditor().setTextFormatter(priceFormatter7);
             }
         }
         catch(Exception e){
             e.printStackTrace();
         }
         
         
         
        
          
     } 
     
      void loadcustomerdetails2(){ 
          
          String temp = "%" + src_txtf.getText() + "%";
         String credit_limit_value="Select * from customers where ledger_name like '"+temp+"'";
        
         try{
             pst=conn.prepareStatement(credit_limit_value);
             rs=pst.executeQuery();
             while(rs.next()){
                  if(rs.getString("CHECK_OPTION1").equals("Y")){
       whole_sale_customer_chkbx.setSelected(true);
        whole_sale_customer_chkbx.setText("Y");
       }
       else{
        whole_sale_customer_chkbx.setSelected(false);
        whole_sale_customer_chkbx.setText("N");
       }
       
          ledger_number_txtf.setText(rs.getString("LEDGER_NUMBER"));
        customer_name_txtf.setText(rs.getString("LEDGER_NAME"));
       current_status_txtf.setText(rs.getString("LEDGER_STATUS"));
       telephone_number_txtf.setText(rs.getString("TELEPHONES"));
       inventory_location_txtf.setText(rs.getString("BASE_LOCATION"));
       city_town_txtf.setText(rs.getString("TOWNCITY"));
       email_txtf.setText(rs.getString("EMAIL_ADDRESS"));
       contact_person_txf.setText(rs.getString("CONTACT_PERSON"));
       phone_txtf.setText(rs.getString("CONTACT_PHONE"));
       
 
      
        
        if(rs.getString("ON_CREDIT").equals("Y")){
             credit_account_chkbx.setSelected(true);
               credit_account_chkbx.setText("Y");
        }
        else{
              credit_account_chkbx.setSelected(false);
               credit_account_chkbx.setText("N"); 
        }           
                  
                  
       contact_title_txtf.setText(rs.getString("CONTACT_TITLE"));
       address_txtarea.setText(rs.getString("ADDRESS"));
       account_number_txtf.setText(rs.getString("ACCOUNT_NUMBER"));
       pin_number_txtf.setText(rs.getString("PIN_CODE"));
       customer_group_txtf.setText(rs.getString("LEDGER_GROUP"));
       sales_area_txtf.setText(rs.getString("SALES_AREA"));
       card_number_txtf.setText(rs.getString("CARD_NUMBER"));
       vat_number_txtf.setText(rs.getString("VAT_NUMBER"));
       
       
       
                 
                  TextFormatter<Double> priceFormatter1 = new TextFormatter<Double>(
        new DoubleStringConverter(),rs.getDouble("CREDIT_LIMIT"), filter);
          credit_limit_spinner.getEditor().setTextFormatter(priceFormatter1);
          
          TextFormatter<Double> priceFormatter2 = new TextFormatter<Double>(
        new DoubleStringConverter(),rs.getDouble("CREDIT_PERIOD"), filter);
          current_period_spinner.getEditor().setTextFormatter(priceFormatter2);
          
          TextFormatter<Double> priceFormatter3 = new TextFormatter<Double>(
        new DoubleStringConverter(),rs.getDouble("DISCOUNT_RATE"), filter);
          discount_rate_spinner.getEditor().setTextFormatter(priceFormatter3);
          
           TextFormatter<Double> priceFormatter4 = new TextFormatter<Double>(
        new DoubleStringConverter(),rs.getDouble("PREF_PRIORITY"), filter);
          pref_priority_spinner.getEditor().setTextFormatter(priceFormatter4);
          
           TextFormatter<Double> priceFormatter6 = new TextFormatter<Double>(
        new DoubleStringConverter(),rs.getDouble("CREDIT_RATING"), filter);
          credit_rating_spinner.getEditor().setTextFormatter(priceFormatter6);
          
           TextFormatter<Double> priceFormatter7 = new TextFormatter<Double>(
        new DoubleStringConverter(),rs.getDouble("DISTANCE"), filter);
          distance_spinner.getEditor().setTextFormatter(priceFormatter7);
             }
         }
         catch(Exception e){
             e.printStackTrace();
         }
         
         
         
        
          
     } 
            protected static final String INITIAL_VALUE = "0.00"; 
       void setSpinnerValue(Spinner<Double> spinner,double k){
        TextFormatter<Double> priceFormatter = new TextFormatter<Double>(
        new DoubleStringConverter(), k, filter);
        spinner.setValueFactory(new SpinnerValueFactory.DoubleSpinnerValueFactory(
        0.00, 10000.00, Double.parseDouble(INITIAL_VALUE)));
        spinner.setEditable(true);
        spinner.getEditor().setTextFormatter(priceFormatter); 
    }
    void onSelectCustomer(){
        customers_table selectedItem = customer_table.getSelectionModel().getSelectedItem();
        ledger_number_txtf.setText(selectedItem.getledger_number());
        customer_name_txtf.setText(selectedItem.getcustomer_name());
       current_status_txtf.setText(selectedItem.getstatus());
       telephone_number_txtf.setText(selectedItem.gettelephone());
       inventory_location_txtf.setText(selectedItem.getbase_location());
       city_town_txtf.setText(selectedItem.gettown_city());
       email_txtf.setText(selectedItem.getemail_address());
       contact_person_txf.setText(selectedItem.getcontact_person());
       phone_txtf.setText(selectedItem.getcontact_phone());
       
 
      
        
        if(selectedItem.getcred().equals("Y")){
             credit_account_chkbx.setSelected(true);
               credit_account_chkbx.setText("Y");
        }
        else{
              credit_account_chkbx.setSelected(false);
               credit_account_chkbx.setText("N"); 
        }
        
        loadspInnervalues();
        
       
    }    


@FXML
  void onSelectItem(MouseEvent event){
   if(event.getSource()==customer_table)  {
      loadMaskerPane2();
   }
 }
 
 void loadDashboard(){
            try {
            //  Controller Controller = new Controller();
             // primarystage = (Stage) Controller.getScene().getWindow(); 
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_stock_adjustment_final.fxml"));
              /*  loader.<pos_items>getController();
              Controller.setsearch_item2(item_code_txtf.getText());*/
      
             

            ScrollPane mainPane= (ScrollPane) loader.load();
           multi_pane_changer.getChildren().setAll(mainPane);
            
                    } catch (IOException ex) {
            Logger.getLogger(pos_customers_form.class.getName()).log(Level.SEVERE, null, ex);
        } 
            
          
       
  }
  

public void setAnchorPane(AnchorPane anchorPane) {
   this.multi_pane_changer = anchorPane;
}
 void opendrawerContent(){
         try {
            //
            // TODO
         
     
           // VBox box = new VBox();
                VBox box = FXMLLoader.load(getClass().getResource("drawer_content.fxml"));
                  
          
            drawer.setSidePane(box);
            
            HamburgerBackArrowBasicTransition burgerTask2  =  new HamburgerBackArrowBasicTransition(hamburger);
            burgerTask2.setRate(-1);
            hamburger.addEventHandler(MouseEvent.MOUSE_PRESSED, (e) ->{
                
                burgerTask2.setRate(burgerTask2.getRate()* 1);
                burgerTask2.play();
                if(drawer.isShown()){
                    drawer.close();
                }
                else
                    drawer.open();
             
               
               
                
                
            });
        } catch (IOException ex) {
            Logger.getLogger(pos_customers_form.class.getName()).log(Level.SEVERE, null, ex);
        }
 }
       
  
    @Override
    public void initialize(URL url, ResourceBundle rb) {
      //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
      loadMaskerPane();
     // loadDashboard();
    
    }
     private  void initFX(JFXPanel fxPanel) {
        // This method is invoked on the JavaFX thread
      
         //  Scene scene = createScene();
          // fxPanel.setScene(scene);
     try {
               
             String workingDirectory=System.getProperty("Users.dir");
  
         StackPane pane= new StackPane();
           pane = FXMLLoader.load(getClass().getResource("customers.fxml"));
           // pane.getChildren().add(mv);
          Scene scene2 = new Scene(pane, 2000, 1000);
                scene2.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
          // mp.play();
        
         
               
           fxPanel.setScene(scene2);
         
            
           
        } catch (IOException exc) {
            exc.printStackTrace();
            System.exit(1);
        }
        
      
      
    }
     
       public static JFrame frame;
      public static JFXPanel fxPanel = new JFXPanel();
       public  void initAndShowGUI() {
        // This method is invoked on the EDT thread
       
        try{
          frame = new JFrame("Customers/Suppliers Form");
          frame.add(fxPanel);
          frame.setSize(2000, 1000);
        
        frame.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("../images_/Mali (2).png")));
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setResizable(true);
        frame.setLocationRelativeTo(null); 
       // playMedia();
       
        }
        catch(Exception e){
            e.printStackTrace();
        }
        
        
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                initFX(fxPanel);
               // loadComboBoxes();
            }
       });
    }
     
       public static void main(String[] args) {
         SwingUtilities.invokeLater(new Runnable() {
             @Override
            public void run() {
              
                pos_customers_form test = new pos_customers_form();
                test.initAndShowGUI();
                
                
                
               
                
            }
        });
        
         
    }
     
     
}
