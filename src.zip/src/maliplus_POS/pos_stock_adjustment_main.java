/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDialog;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.function.UnaryOperator;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextFormatter;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.converter.DoubleStringConverter;
import maliplus.DBConnection;
import static maliplus_POS.Pos_Controller.stage2;
/**
 *
 * @author PSL-STUFF
 */
public class pos_stock_adjustment_main implements Initializable{
   static Connection conn = null;
    static ResultSet rs = null;
    static PreparedStatement pst = null;
    @FXML
    private JFXButton insert_btn;

    @FXML
    private JFXButton save_btn;

    @FXML
    private JFXButton delete_btn;

    @FXML
    private JFXButton print_preview_btn;

    @FXML
    private JFXButton export_btn;

    @FXML
    private JFXButton approve_post_btn;

    @FXML
    private JFXButton customized_stock_result_btn;

    @FXML
    private JFXButton find_items_btn;

    @FXML
    private JFXButton refresh_btn;

    @FXML
    private JFXButton clear_btn;

    @FXML
    private JFXButton item_notes_btn;

    @FXML
    private JFXButton back_btn;

    @FXML
    private JFXDialog display_message_dgBox;

    @FXML
    private Label item_code_lbl;

    @FXML
    private JFXTextField item_code_txtf;

    @FXML
    private JFXTextField item_name_txtf;

    @FXML
    private DatePicker stcoking_date_dtpicker;

    @FXML
    private Spinner<Double> transaction_quantity_spinner;

    @FXML
    private Spinner<Double> buying_price_spinner;

    @FXML
    private JFXTextField description_txtf;

    @FXML
    private Label item_location_lbl;

    @FXML
    private Label journal_number_lbl;

    @FXML
    private Label journal_display_message_lbl;

    @FXML
    private Label uom_lbl;

    @FXML
    private Label barcode_lbl;

    @FXML
    private Label supplier_lbl;

    @FXML
    private JFXTextField supplier_txtf;

    @FXML
    private Label replicate_supplier_code_lbl;

    @FXML
    private Label type_lbl;

    @FXML
    private JFXDialog quantity_display_message_dgbox;

    @FXML
    private JFXTextField uom_txtf;

    @FXML
    private JFXTextField barcode_txtf;

    @FXML
    private JFXTextField type_txtf;

    @FXML
    private JFXTextField journal_number_txtf;

    @FXML
    private JFXTextField item_location_txtf;

    @FXML
    private JFXTextField document_number_txtf;

    @FXML
    private JFXTextField journal_quantity_txtf;

    @FXML
    private JFXTextField journal_control_count_txtf;

    @FXML
    private TableView<pos_stock_adjustments_table> stock_adjustment_tbl;

    @FXML
    private TableColumn<pos_stock_adjustments_table,String > item_code_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_table, String> item_name_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_table, String> transaction_date_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_table, Number> quantity_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_table, String> item_price_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_table, String> description_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_table, String> document_number_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_table, String> item_location_tbnode;  
  final ObservableList<pos_stock_adjustments_table> data= FXCollections.observableArrayList();
         public  void loadStockAdjustmentDetailstable(){
               conn=DBConnection.ConnectDB();
           String sql= "SELECT * from STOCK_TRNS WHERE JOURNAL_NUMBER='"+journal_number_txtf.getText()+"'";
                        try{
                       pst=conn.prepareStatement(sql);
                       rs= pst.executeQuery();
                       double difference=0.0;
                       while(rs.next()){ 
                           difference=rs.getDouble("QUANTITY")-rs.getDouble("CLOSING");
                           data.add(new pos_stock_adjustments_table(
                           rs.getString("ITEM_CODE"),
                           rs.getString("DESCRIPTION"),
                           rs.getInt("QUANTITY"),
                           rs.getString("ITEM_PRICE"),
                           rs.getString("DESCRIPTION"),
                           rs.getString("ITEM_LOCATION"),
                           rs.getInt("CLOSING"),
                           difference,
                           rs.getDouble("QUANTITY")        
                           ));
        item_code_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_table, String> cellData) -> {
            return cellData.getValue().item_codeProperty();
     
        });
            
       
        item_name_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_table, String> cellData) -> {
            return cellData.getValue().item_nameProperty();
        });
       
        quantity_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_table, Number> cellData) -> {
            return cellData.getValue().quantityProperty();
        });
        item_price_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_table, String> cellData) -> {
            return cellData.getValue().item_priceProperty();
        });
        description_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_table, String> cellData) -> {
            return cellData.getValue().descriptionProperty();
        });
        
        item_location_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_table, String> cellData) -> {
            return cellData.getValue().item_locationProperty();
        });
       
      
        
        

     
       // item_code.setStyle("-fx-control-inner-background: yellow;");
       // item_code.setStyle("-fx-text-fill: red;");
       // item_description.setStyle("-fx-text-fill: green;");
       // quantity.setStyle("-fx-text-fill: blue;");
       // sales_price.setStyle("-fx-text-fill: orange;");
       // sales_amount.setStyle("-fx-text-fill: purple;");
       // discount.setStyle("-fx-text-fill: red;");
       // taxable.setStyle("-fx-text-fill: violet;");
       // tax_amount.setStyle("-fx-text-fill: blue;");
       // item_location.setStyle("-fx-text-fill: grey;");
       // display.setStyle(" -fx-font-size: 14px;");
       
  
                           stock_adjustment_tbl.setItems(data);
                           
                             item_name_tbnode.setCellFactory(column -> {
    return new TableCell<pos_stock_adjustments_table, String>() {
        @Override
        protected void updateItem(String item, boolean empty) {
            super.updateItem(item, empty); //This is mandatory

            if (item == null || empty) { //If the cell is empty
                setText(null);
                setStyle("");
            } else { //If the cell is not empty

                setText(item); //Put the String data in the cell

                //We get here all the info of the Person of this row
                pos_stock_adjustments_table item_name2 = getTableView().getItems().get(getIndex());
               

     
                try{
                if (item_name2.getITEM_NAME().isEmpty()==false) {
                    setTextFill(Color.BLACK); //The text in red
                    setStyle("-fx-background-color:PALEGREEN"); //The background of the cell in yellow
                    
                }   else {
                    //Here I see if the row of this cell is selected or not
                    if(getTableView().getSelectionModel().getSelectedItems().contains(item_name2))
                        setTextFill(Color.WHITE);
                    else
                        setTextFill(Color.BLACK);
                }
    
                }
                catch(Exception e){
                    e.printStackTrace();
                }
                
              
            }
        }
    };
});             
           
     item_price_tbnode.setCellFactory(column -> {
    return new TableCell<pos_stock_adjustments_table, String>() {
        @Override
        protected void updateItem(String item, boolean empty) {
            super.updateItem(item, empty); //This is mandatory

            if (item == null || empty) { //If the cell is empty
                setText(null);
                setStyle("");
            } else { //If the cell is not empty

                setText(item); //Put the String data in the cell

                //We get here all the info of the Person of this row
                pos_stock_adjustments_table item_price2 = getTableView().getItems().get(getIndex());
               

     
                try{
                if (item_price2.getITEM_PRICE().isEmpty()==false) {
                    setTextFill(Color.WHITE); //The text in red
                    setStyle("-fx-background-color:PURPLE"); //The background of the cell in yellow
                    
                }   else {
                    //Here I see if the row of this cell is selected or not
                    if(getTableView().getSelectionModel().getSelectedItems().contains(item_price2))
                        setTextFill(Color.WHITE);
                    else
                        setTextFill(Color.BLACK);
                }
    
                }
                catch(Exception e){
                    e.printStackTrace();
                }
                
              
            }
        }
    };
}); 
                       }
                    //   pst.close();
                    //   rs.close();
                   }
                   catch(Exception e2){
                      e2.printStackTrace();
                   } 
}
    
   
   

    void loadStockDetailTable()throws IOException {
         Scene scene3; 
               stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_stock_adjustment_main Controller = new pos_stock_adjustment_main();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_stock_adjustment_window2.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 Parent root3 = loader.load();
                 scene3 = new Scene(root3);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("MALIPLUS:STOCK ADJUSTMENTS FORM");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(true);
                 stage2.setMaximized(true);
                 //stage2.setX(450);
                // stage2.setY(50);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();
                 stage2.show();
    }
   String Journal_Number;
    public void setjournal_number(String journal_number) {
        this.Journal_Number= journal_number;
    }
    String Item_Location;
    public void setitem_location(String item_location) {
        this.Item_Location= item_location;
    }
    String Journal_Quantity;
    public void setjournal_quantity(String journal_quantity) {
        this.Journal_Quantity= journal_quantity;
    }
    String Journal_Control_Count;
    public void setjournal_control_count(String journal_control_count) {
        this.Journal_Control_Count= journal_control_count;
    }
    void loadStockAdjustmentInitialWindow()throws IOException {
         Scene scene3; 
               stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_stock_adjustment_initial Controller = new pos_stock_adjustment_initial();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_stock_adjustment.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 Parent root3 = loader.load();
                 scene3 = new Scene(root3);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("MALIPLUS:STOCK ADJUSTMENTS FORM");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 //stage2.setX(450);
                // stage2.setY(50);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();
                 stage2.showAndWait();
               
                  
                 
    }     
    
  
   

    

   

   
   
  
   
       protected static final String INITIAL_VALUE = "0";
  
    
    NumberFormat format = NumberFormat.getIntegerInstance();
       UnaryOperator<TextFormatter.Change> filter = c -> {
    if (c.isContentChange()) {
        ParsePosition parsePosition = new ParsePosition(0);
        // NumberFormat evaluates the beginning of the text
        format.parse(c.getControlNewText(), parsePosition);
        if (parsePosition.getIndex() == 0 ||
                parsePosition.getIndex() < c.getControlNewText().length()) {
            // reject parsing the complete text failed
            return null;
        }
    }
    return c;
};
    TextFormatter<Double> priceFormatter = new TextFormatter<Double>(
        new DoubleStringConverter(), 0.00, filter);
    
   void setSpinnerValue(Spinner<Double> spinner,double k){
        TextFormatter<Double> priceFormatter = new TextFormatter<Double>(
        new DoubleStringConverter(), k, filter);
        spinner.setValueFactory(new SpinnerValueFactory.DoubleSpinnerValueFactory(
        0.00, 10000.00, Double.parseDouble(INITIAL_VALUE)));
        spinner.setEditable(true);
        spinner.getEditor().setTextFormatter(priceFormatter); 
    }
   
      void showCurrentDateonload(){
        //DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyyy");
        /*TextField date = sale_date.getEditor();
        formatter.format(date);*/
       Date ref_date = new Date();
        SimpleDateFormat formatter2 = new SimpleDateFormat("MM-dd-yyyy");
          String ref = formatter2.format(ref_date);
     //   System.out.println(String.valueOf(ref));
        
      String dateValue = ""+ref+"";
      //  sale_date.setValue(LocalDate.parse(ref,formatter));
       
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
      
          stcoking_date_dtpicker.setValue(LocalDate.parse(dateValue,formatter));
      // SimpleDateFormat format = new SimpleDateFormat("MMM dd, yyyy");
     //  setText(format.format(date));
    
    
      
/* try{
sale_date.getEditor().setText(dateFormat.format(date));
}
catch(Exception e){
e.printStackTrace();
}*/
    }
      void StockAdjustmentTable_mouse_clicked(){
          
           pos_stock_adjustments_table selectedItem = stock_adjustment_tbl.getSelectionModel().getSelectedItem();
            String sql="select  DATE_CREATED from STOCK_TRNS where ITEM_CODE = '"+String.valueOf(selectedItem.getITEM_CODE())+"'";
       Connection conn = DBConnection.ConnectDB();
           try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
         java.sql.Date check_status6 = rs.getDate("DATE_CREATED");
         //System.out.println(""+check_status6+""); 
         SimpleDateFormat formatter2 = new SimpleDateFormat("MM-dd-yyyy");
        //formatter2.parse(check_status6);
        String ref = formatter2.format(check_status6);
        
        
        
        
      // System.out.println(String.valueOf(ref));
        
         String dateValue = ""+ref+"";
      //  sale_date.setValue(LocalDate.parse(ref,formatter));
       
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
         stcoking_date_dtpicker.setValue(LocalDate.parse(dateValue,formatter));
            }
           
       }
       catch(Exception e){
           e.printStackTrace();
       }
           item_code_txtf.setText(selectedItem.getITEM_CODE());  
          item_name_txtf.setText(selectedItem.getITEM_NAME());
        //  stcoking_date_dtpicker.getEditor().setText(String.valueOf(selectedItem.getTRN_DATE()));
         // valueFactory.setValue("February")
          transaction_quantity_spinner.getEditor().setText(String.valueOf(selectedItem.getQUANTITY()));;
        // sales_price4.getValueFactory()
           buying_price_spinner.getEditor().setText(selectedItem.getITEM_PRICE());
          description_txtf.setText(String.valueOf(selectedItem.getDESCRIPTION()));
          item_location_txtf.setText(String.valueOf(selectedItem.getITEM_LOCATION()));
          
          ///taxable.setText(String.valueOf(selectedItem.getTAXABLE()));
         // tax_amount.setText(String.valueOf(selectedItem.getTAX_AMOUNT()));
          //location2.setText(String.valueOf(selectedItem.getITEM_LOCATION()));
      }
 @FXML
    void onSelectItem(MouseEvent event) throws IOException {
        if(event.getSource()==stock_adjustment_tbl){
            int click = event.getClickCount();
        
        if(click ==2){
          StockAdjustmentTable_mouse_clicked();   
        }
            
       }
     

           
           
          
        
    }
     @FXML
    void actionPerformed(ActionEvent event) {
        
    }

    @FXML
    void mouseClicked(MouseEvent event) throws IOException {
        if(event.getSource().equals(journal_number_lbl)){
            loadStockAdjustmentInitialWindow();
        }
    }
      
        @Override
    public void initialize(URL url, ResourceBundle rb) {
    setSpinnerValue(transaction_quantity_spinner,0.00);
    setSpinnerValue(buying_price_spinner,0.00);
   showCurrentDateonload();
  journal_number_txtf.setText(this.Journal_Number);
  item_location_txtf.setText(this.Item_Location);    
  journal_quantity_txtf.setText(this.Journal_Quantity);  
  journal_control_count_txtf.setText(this.Journal_Control_Count);
  loadStockAdjustmentDetailstable();
    }



 
}
