/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;
import maliplus.*;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javax.swing.JFrame;
import static maliplus_POS.Pos_Controller.stage2;
/**
 *
 * @author PSL-STUFF
 */
public class pos_type implements Initializable{
      static Connection conn = null;
    static ResultSet rs = null;
    static PreparedStatement pst = null;
    public static JFrame frame;
public static Scene scene2;
static Parent  root5;
    final ObservableList<pos_type_details_panel> data4= FXCollections.observableArrayList();
@FXML
    private TableView<pos_type_details_panel> type4;

    @FXML
    private TableColumn<pos_type_details_panel, String> description;
    
    @FXML
    private TableColumn<pos_type_details_panel, String> keyword;
    

    @FXML
    void onSelectItem(MouseEvent event) {
          int click = event.getClickCount();
        
        if(click ==2){
           try {  
                 actiontypesDetails_panelTable_mouse_clicked1();
             } catch (IOException ex) {
                 Logger.getLogger(pos_type.class.getName()).log(Level.SEVERE, null, ex);
             } 
        }
             
            
    }
        public  void loadtypesDetailstable(String sql,String x,String y )throws IOException{
             conn = DBConnection.ConnectDB();

                     try{
                       pst=conn.prepareStatement(sql);
                       rs= pst.executeQuery();
                       while(rs.next()){ 
                           data4.add(new pos_type_details_panel(
                           rs.getString(""+x+""),
                           rs.getString(""+y+"")
                           ));
        description.setCellValueFactory((TableColumn.CellDataFeatures<pos_type_details_panel, String> cellData) -> {
            return cellData.getValue().descriptionProperty();
        });
      
        keyword.setCellValueFactory((TableColumn.CellDataFeatures<pos_type_details_panel, String> cellData) -> {
            return cellData.getValue().key_wordProperty();
        });
       
        

     
       // item_code.setStyle("-fx-control-inner-background: yellow;");
       // item_code.setStyle("-fx-text-fill: red;");
       // item_description.setStyle("-fx-text-fill: green;");
       // quantity.setStyle("-fx-text-fill: blue;");
       // sales_price.setStyle("-fx-text-fill: orange;");
       // sales_amount.setStyle("-fx-text-fill: purple;");
       // discount.setStyle("-fx-text-fill: red;");
       // taxable.setStyle("-fx-text-fill: violet;");
       // tax_amount.setStyle("-fx-text-fill: blue;");
       // item_location.setStyle("-fx-text-fill: grey;");
       // display.setStyle(" -fx-font-size: 14px;");
       
  
                           type4.setItems(data4);
                           
                                   
                       }
                    //   pst.close();
                    //   rs.close();
                   }
                   catch(Exception e2){
                      e2.printStackTrace();
                   } 
}
    
         private Pos_Controller Controller;

    public void setController(Pos_Controller controller ) {
        this.Controller = controller;
    }
    private String result = null;
    public String getResult() {
        
        return result;
    }
    
    private String result2 = null;
     public String getResult2() {
        
        return result2;
    }

     void  actiontypesDetails_panelTable_mouse_clicked1()throws IOException{ 
         // Pos_Controller Controller =  new Pos_Controller();
       

         //FXMLLoader loader2 = new FXMLLoader(this.getClass().getResource("pos_details_panel.fxml"));
         // Parent root = (Parent) loader.load();
           //Pos_Controller Controller = new Pos_Controller();
         
         // loader.setController(Controller);
         // loader.load();
         
        
         pos_type_details_panel selectedItem = type4.getSelectionModel().getSelectedItem();
        
        //System.out.println(selectedItem.getDESCRIPTION());
        try{
           // test_me.setText(selectedItem.getMAIN_LOCATION());
            result =selectedItem.getKEYWORD();
            result2=selectedItem.getDESCRIPTION();
            type4.getScene().getWindow().hide();
            
           
        }
        catch(Exception e){
            
        }
        
          
    }
     

     
   void execute(){
       
        try {
            // TODO
               String x="DESCRIPTION";
               String y="KEY_WORD";
             String pos_types= "POS TYPES";
             String sub_code = "###";
             String sql = "select key_word,description from list_control where reference_code='"+ pos_types +"' AND sub_code='"+sub_code+"'";
            
          loadtypesDetailstable(sql,x,y);
            
            //locatpion2.setText("ok");
        } catch (IOException ex) {
            Logger.getLogger(pos_type.class.getName()).log(Level.SEVERE, null, ex);
        }
   }
    
    
    
   
    
    
   
      

      
        @Override
    public void initialize(URL url, ResourceBundle rb) {
      // execute();
       
    }

 
}
