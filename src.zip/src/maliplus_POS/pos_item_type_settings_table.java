/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;
import javafx.beans.property.StringProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author PSL-STUFF
 */
public class pos_item_type_settings_table {
private final SimpleStringProperty description2;
private final SimpleStringProperty list2;
private final SimpleStringProperty reference_code2;
private final SimpleStringProperty key_word2;
private final SimpleIntegerProperty order_by2;
private final SimpleStringProperty extend_control2;
private final SimpleStringProperty date_modified2;
private final SimpleStringProperty modified_by2;
private final SimpleStringProperty reference_value2;
private final SimpleStringProperty reference12;
private final SimpleStringProperty reference22;
private final SimpleStringProperty date_created2;
private final SimpleStringProperty created_by2;
public pos_item_type_settings_table (String DESC,String L_I,String R_C,String K_W,Integer O_B,String E_C,String D_M,String M_B,String R_V,String REF1,String REF2,String D_C,String C_B ){
    this.description2 = new SimpleStringProperty(DESC);
    this.list2 = new SimpleStringProperty(L_I);
     this.reference_code2 = new SimpleStringProperty(R_C);
     this.key_word2 = new SimpleStringProperty(K_W);
     this.order_by2 = new SimpleIntegerProperty(O_B);
     this.extend_control2 = new SimpleStringProperty(E_C);
     this.date_modified2 = new SimpleStringProperty(D_M);
     this.modified_by2 = new SimpleStringProperty(M_B);
     this.reference_value2 = new SimpleStringProperty(R_V);
     this.reference12 = new SimpleStringProperty(REF1);
     this.reference22 = new SimpleStringProperty(REF2);   
     this.date_created2 = new SimpleStringProperty(D_C);
     this.created_by2 = new SimpleStringProperty(C_B);
}

    



  public String getDESCRIPTION(){
      return description2.get();
  }
  public String getLIST(){
      return list2.get();
  }
  public String getREFERENCE_CODE(){
      return reference_code2.get();
  }

  public String getKEY_WORD(){
      return key_word2.get();
  }
  public Integer getORDER_BY(){
      return order_by2.get();
  }
  public String getEXTEND_CONTROL(){
      return extend_control2.get();
  }
  
  public String getDATE_MODIFIED(){
      return date_modified2.get();
  }
  public String getMODIFIED_BY(){
      return modified_by2.get();
  }
  public String getREFERENCE_VALUE(){
      return reference_value2.get();
  }
   public String getREFERENCE1(){
      return reference12.get();
  }
   public String getREFERENCE2(){
      return reference22.get();
  }
    public String getDATE_CREATED2(){
      return date_created2.get();
  }
     public String getCREATED_BY2(){
      return created_by2.get();
  }

  
  public void SetDESCRIPTION(String DESC ){
      description2.set(DESC);
  }
  public void SetLIST(String L_I ){
      list2.set(L_I);
  }
   public void SetREFERENCE_CODE(String R_C){
      reference_code2.set(R_C);
  }
  
   public void SetKEY_WORD(String K_W){
      key_word2.set(K_W);
  }
   public void SetORDER_BY(Integer O_B){
      order_by2.set(O_B);
  }
   public void SetEXTEND_CONTROL(String E_C ){
      extend_control2.set(E_C);
  }
   
   public void SetDATE_MODIFIED(String D_M){
      date_modified2.set(D_M);
  }
   public void SetMODIFIED_BY(String D_M){
      modified_by2.set(D_M);
  }
  public void SetREFERENCE_VALUE(String R_V ){
      reference_value2.set(R_V);
  }
   public void SetREFERENCE1(String REF1 ){
      reference12.set(REF1);
  }
    public void SetREFERENCE2(String REF2 ){
      reference22.set(REF2);
  }
    public void SetDATE_CREATED2(String D_C ){
      date_created2.set(D_C);
  }
      public void SetCREATED_BY2(String C_B ){
      created_by2.set(C_B);
  }
   
     
      public StringProperty descriptionProperty() {
        return description2 ;
    }
      public StringProperty listProperty() {
        return list2 ;
    }
       public StringProperty reference_codeProperty() {
        return reference_code2 ;
    }
    
      public StringProperty key_wordProperty() {
        return key_word2 ;
    }
        public IntegerProperty order_byProperty() {
        return order_by2 ;
    }
          public StringProperty extend_controlProperty() {
        return extend_control2 ;
    }
      
            public StringProperty date_modifiedProperty() {
        return date_modified2 ;
    }
                 public StringProperty modified_byProperty() {
        return modified_by2 ;
    }

                   public StringProperty reference_valueProperty() {
        return reference_value2 ;
    }
                  public StringProperty reference1Property() {
        return reference12 ;
    }
                 public StringProperty reference2Property() {
        return reference22 ;
    }
                public StringProperty date_created2Property() {
        return date_created2 ;
    }
                public StringProperty created_by2Property() {
        return created_by2 ;
    }


}
