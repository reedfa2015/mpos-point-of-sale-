/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;

import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javax.swing.JFrame;
import maliplus.DBConnection;
/**
 *
 * @author PSL-STUFF
 */
public class pos_orders implements Initializable{
      static Connection conn = null;
    static ResultSet rs = null;
    static PreparedStatement pst = null;
    public static JFrame frame;
public static Scene scene2;
static Parent  root5;
    final ObservableList<pos_order_details_panel> data2= FXCollections.observableArrayList();
@FXML
    private TableView<pos_order_details_panel> orders;

    @FXML
    private TableColumn<pos_order_details_panel, String> order_number;

    @FXML
    private TableColumn<pos_order_details_panel, String> description;

    
    @FXML
    private TableColumn<pos_order_details_panel, String> ledger_number4;
   
    @FXML
    private JFXTextField search_item_txtf;
    
     @FXML
    void onKeyTyped(KeyEvent event) {
           if(event.getSource()==search_item_txtf){
       order_number.setCellValueFactory(cellData -> cellData.getValue().order_numberProperty());
        description.setCellValueFactory(cellData -> cellData.getValue().descriptionProperty());
        ledger_number4.setCellValueFactory(cellData -> cellData.getValue().ledger_numberProperty());
        
         FilteredList<pos_order_details_panel> filteredData = new FilteredList<>(data2, p -> true);
            search_item_txtf.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(order -> {
                // If filter text is empty, display all persons.
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }

                // Compare first name and last name of every person with filter text.
                String lowerCaseFilter = newValue.toLowerCase();
                 String upperCaseFilter = newValue.toUpperCase();
                if (order.getORDER_NUMBER().contains(upperCaseFilter)) {
                    return true; // Filter matches item_code.
                } else 
                    if (order.getDESCRIPTION().toLowerCase().contains(lowerCaseFilter)) {
                    return true; // Filter matches item_name.
                }
                else 
                    if (order.getLEDGER_NUMBER().toLowerCase().contains(lowerCaseFilter)) {
                    return true; // Filter matches item_name.
                }
                
                return false; // Does not match.
            });
        });
            
             SortedList<pos_order_details_panel> sortedData = new SortedList<>(filteredData);
              sortedData.comparatorProperty().bind(orders.comparatorProperty());
              orders.setItems(sortedData);
        }
    }
    @FXML
    void onSelectItem(MouseEvent event) {
        int click = event.getClickCount();
        
        if(click ==2){
            try {  
                 actionorderDetails_panelTable_mouse_clicked1();
             } catch (IOException ex) {
                 Logger.getLogger(pos_orders.class.getName()).log(Level.SEVERE, null, ex);
             }
        }
             
            
    }
    
   
    
        public  void loadOrderDetailstable()throws IOException{
             conn = DBConnection.ConnectDB();
     
             result4 = "select order_number,description,ledger_number from cash_orders"; 
                        try{
                       pst=conn.prepareStatement(result4);
                       rs= pst.executeQuery();
                       while(rs.next()){ 
                           data2.add(new pos_order_details_panel(
                           rs.getString("ORDER_NUMBER"),
                           rs.getString("DESCRIPTION"),
                           rs.getString("LEDGER_NUMBER")
                           ));
        order_number.setCellValueFactory((TableColumn.CellDataFeatures<pos_order_details_panel, String> cellData) -> {
            return cellData.getValue().order_numberProperty();
        });
        description.setCellValueFactory((TableColumn.CellDataFeatures<pos_order_details_panel, String> cellData) -> {
            return cellData.getValue().descriptionProperty();
        });
        ledger_number4.setCellValueFactory((TableColumn.CellDataFeatures<pos_order_details_panel, String> cellData) -> {
            return cellData.getValue().ledger_numberProperty();
        });
       
        

     
       // item_code.setStyle("-fx-control-inner-background: yellow;");
       // item_code.setStyle("-fx-text-fill: red;");
       // item_description.setStyle("-fx-text-fill: green;");
       // quantity.setStyle("-fx-text-fill: blue;");
       // sales_price.setStyle("-fx-text-fill: orange;");
       // sales_amount.setStyle("-fx-text-fill: purple;");
       // discount.setStyle("-fx-text-fill: red;");
       // taxable.setStyle("-fx-text-fill: violet;");
       // tax_amount.setStyle("-fx-text-fill: blue;");
       // item_location.setStyle("-fx-text-fill: grey;");
       // display.setStyle(" -fx-font-size: 14px;");
       
  
                           orders.setItems(data2);
                           
                                   
                       }
                    //   pst.close();
                    //   rs.close();
                   }
                   catch(Exception e2){
                      e2.printStackTrace();
                   } 
}
    
         private Pos_Controller Controller;

    public void setController(Pos_Controller controller ) {
        this.Controller = controller;
    }
    private String result = null;
    private String result2 = null;
    private String result4 = null;
    private String result5 = null;
    private String result6 = null;
     public String getResult() {
        
        return result;
    }

    public String getResult2() {
        
        return result2;
    }
     public String getResult4() {
        
        return result4;
    }
      public String getResult5() {
        
        return result5;
    }
       public String getResult6() {
        
        return result6;
    }
     void  actionorderDetails_panelTable_mouse_clicked1()throws IOException{ 
         // Pos_Controller Controller =  new Pos_Controller();
       

         //FXMLLoader loader2 = new FXMLLoader(this.getClass().getResource("pos_details_panel.fxml"));
         // Parent root = (Parent) loader.load();
           //Pos_Controller Controller = new Pos_Controller();
         
         // loader.setController(Controller);
         // loader.load();
         
        
         pos_order_details_panel selectedItem = orders.getSelectionModel().getSelectedItem();
        
       // System.out.println(selectedItem.getMAIN_LOCATION());
        try{
           // test_me.setText(selectedItem.getMAIN_LOCATION());
            result =selectedItem.getORDER_NUMBER();
             result5 = "SELECT LEDGER_NAME,CUSTOMERS.LEDGER_NUMBER from CUSTOMERS,CASH_ORDERS where CUSTOMERS.LEDGER_NUMBER='"+selectedItem.getLEDGER_NUMBER()+"'"; 
            // result6 = "SELECT LEDGER_NAME  from CUSTOMERS where CUSTOMERS.LEDGER_NUMBER= CASH_ORDERS.LEDGER_NUMBER"; 
         
             //  result2 = selectedItem.getDESCRIPTION();
          
            orders.getScene().getWindow().hide();
            
           
        }
        catch(Exception e){
            
        }
        
          
    }
     
  
   
    
    
    
   
    
    
   
      

      
        @Override
    public void initialize(URL url, ResourceBundle rb) {
       
        try {
            // TODO
            loadOrderDetailstable();
            
            //locatpion2.setText("ok");
        } catch (IOException ex) {
            Logger.getLogger(pos_orders.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }

 
}
