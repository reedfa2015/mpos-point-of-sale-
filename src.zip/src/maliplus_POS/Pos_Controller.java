/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;
import maliplus.*;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXRadioButton;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import com.jfoenix.controls.JFXTextField;
import java.awt.Toolkit;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.TemporalAccessor;
import java.util.Date;
import java.util.Formatter;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.embed.swing.JFXPanel;
import javafx.fxml.FXML;
import javafx.scene.control.MenuButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.image.ImageView;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableCell;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.controlsfx.control.Notifications;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import org.controlsfx.control.MaskerPane;

/**
 * FXML Controller class
 *
 * @author PSL-STUFF
 */
public class Pos_Controller implements Initializable {
    static ResultSet rs=null;
    static PreparedStatement pst=null;
    
    Connection conn = DBConnection.ConnectDB();
    POS pos = new POS(conn,null);
    
    
     final ObservableList<pos_details> data= FXCollections.observableArrayList();
     final ObservableList<pos_details_panel> data2= FXCollections.observableArrayList();
     final ObservableList<pos_item_details_panel> data3= FXCollections.observableArrayList();
     final ObservableList<pos_type_details_panel> data4= FXCollections.observableArrayList();
       @FXML
    private TableView<pos_type_details_panel> type4;

    @FXML
    private TableColumn<pos_type_details_panel, String> description; 
     
    @FXML
    private TableColumn<pos_details, String> item_code;
      @FXML
    private ImageView item_code4;

    @FXML
    private JFXTextField item_code2;

    @FXML
    private ImageView find2;
    
       @FXML
    private ImageView customer_code;
   
 
    @FXML
    private JFXTextField find;

    @FXML
    private JFXButton insert;

      @FXML
    private AnchorPane POSFX_id;  
    @FXML
    private JFXTextField test_me;
    
    @FXML
    private JFXButton save;

    @FXML
    private JFXButton delete;

    @FXML
    private JFXButton search;

    @FXML
    private JFXButton cash_order;

    @FXML
    private JFXButton approve_post;

    @FXML
    private JFXButton new_order;

    @FXML
    private JFXButton reprice_an_order;

    @FXML
    private JFXButton refresh;

    @FXML
    private JFXButton clear_texts;

    @FXML
    private JFXButton reports;

    @FXML
    private JFXButton item_notes;



    @FXML
    private JFXButton export;
    
    @FXML
    private JFXButton post_approve_completed_orders;


    @FXML
    private MenuButton drop_list;

    @FXML
    private MenuItem mark_complete;

    @FXML
    private MenuItem activate_order;

    @FXML
    private MenuItem replicate_discount;

    @FXML
    private MenuItem remove_all_items;

    @FXML
    private SeparatorMenuItem list_serialized;

    @FXML
    private MenuItem function_keys;

    @FXML
    private MenuItem user_options;

    @FXML
    private MenuItem item_price;

    @FXML
    private MenuItem toggle_price_mode;

    @FXML
    private MenuItem user_logon;

    @FXML
    private JFXButton close_exit;

    @FXML
    private JFXTextField discount_percent;

    @FXML
    private JFXTextField sale_quantity;

    @FXML
    private ImageView sale_price2;

    @FXML
    private ImageView discount_percent2;

    @FXML
    private JFXTextField serial_no;

    @FXML
    private JFXTextField barcode2;

    @FXML
    private ImageView barcode;

    @FXML
    private JFXTextField reference_account;

    @FXML
    private ImageView order_no2;

    @FXML
    private JFXTextField order_no;

     @FXML
    private JFXTextField fname_txtf;
    
    @FXML
    private ImageView location;

    @FXML
    private ImageView type;

    @FXML
    private JFXTextField location2;

    @FXML
    private JFXTextField type2;

    @FXML
    private ImageView function_keys_list;

    @FXML
    private DatePicker sale_date;

    @FXML
    private JFXTextField sales_price4;

    @FXML
    private JFXTextField total_amount;

    @FXML
    private ImageView item_notes_and_information;


    @FXML
    private ImageView export_to_excel;

    @FXML
    private MenuButton additional_buttons;

    
    @FXML
    private JFXTextField customers;

    @FXML
    private ImageView find21;

    @FXML
    private JFXTextField ledger_name3;


    @FXML
    private TableColumn<pos_details, Number> sales_price;

     ObservableList<String> months = FXCollections.observableArrayList(//
               "January", "February", "March", "April", //
               "May", "June", "July", "August", //
               "September", "October", "November", "December");
    // Value factory.
     
     
       // Default value
       

    @FXML
    private TableView<pos_details> pos_table;
    
    @FXML
    private TableView<pos_details_panel> locations;

    @FXML
    private TableColumn<pos_details_panel, String> main_location;

    @FXML
    private TableColumn<pos_details_panel, String> location_name;

    @FXML
    private TableColumn<pos_details, String> item_description;

    @FXML
    private TableColumn<pos_details, Number> quantity;

    @FXML
    private TableColumn<pos_details, Number> sales_amount;

    @FXML
    private TableColumn<pos_details, Number> discount;

    @FXML
    private TableColumn<pos_details, Number> taxable;

    @FXML
    private TableColumn<pos_details, Number> tax_amount;

    @FXML
    private TableColumn<pos_details, String> item_location;

        @FXML
    private JFXRadioButton cash_sale_rbtn;

    @FXML
    private JFXRadioButton invoice_rbtn;

    @FXML
    private JFXRadioButton sale_order_rbtn;

    @FXML
    private JFXRadioButton quotation_rbtn;
    
     @FXML
    private JFXRadioButton returns_rbtn; 
    
    @FXML
    private TextField total_sales_amount;
    
      @FXML
    private MaskerPane maskerpane;
    
      @FXML
    void actionPerfomed(ActionEvent event) throws IOException {
        
        
    }
  
     void loadMaskerPane(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    maskerpane.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                    onWindowOpened();
                    maskerpane.setVisible(false);
                }
            };
            new Thread(task).start();
     }
     
     void loadMaskerPane2(JFXTextField textfield1,JFXTextField textfield2,String result,String result2,String result4,JFXTextField textfield3){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    maskerpane.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                    Image img = new Image("/images_/tick3.jpg");
                                 customer_code.setImage(img);
                                 total_sales_amount.setText("");
                                 try{
                                    textfield1.setText(result);
                                    textfield2.setText(result2);
                                    if(result4 !=null){
                     try{
                       conn=DBConnection.ConnectDB();
                       pst=conn.prepareStatement(result4);
                       rs=pst.executeQuery();
                       while(rs.next()){
                          // rs.getString("ORDER_NUMBER");
                           textfield3.setText(rs.getString("ORDER_NUMBER"));
                                  try{
                 /* if(){
                 
                 }*/
               
                 String sql="Select * from STOCK_TRNS WHERE ORDER_NUMBER='"+order_no.getText()+"' AND ORDER_TYPE= 'CSO' ";
                     conn=DBConnection.ConnectDB();
                     pst=conn.prepareStatement(sql);
                      pst.execute();
                      data.removeAll(data);
                      loadPosDetailstable(sql);
                      calculateTotalSalesAmount();
                    
             }
             catch(Exception e){
                 e.printStackTrace();
             }
                           
                           
                       }
                     } 
                     catch(Exception e){
                         e.printStackTrace();
                     }
                  }
                                    
                                 }
                                 catch(Exception e){
                                     e.printStackTrace();
                                 }
                                 
                    maskerpane.setVisible(false);
                }
            };
            new Thread(task).start();
     }
     
     void loadMaskerPane3(String result,String result2,String load_item_details,JFXTextField textfield1,JFXTextField textfield2,JFXTextField textfield3,JFXTextField textfield4,JFXTextField textfield5,JFXTextField textfield6){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    maskerpane.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                    textfield1.setText(result);
                    textfield2.setText(result2);
                    conn=DBConnection.ConnectDB();
                    try{
                        pst=conn.prepareStatement(load_item_details);
                        rs=pst.executeQuery();
                        while(rs.next()){
                            textfield3.setText(rs.getString("BARCODE"));
                            textfield4.setText(String.valueOf(rs.getDouble("SALE_PRICE")));
                            textfield5.setText("0.0");
                            textfield6.setText("1.0");
                            calculateSalesAmount();
                            // sale-quantity.
                            
                        }
                    }
                    catch(Exception e){
                        e.printStackTrace();
                    }
                    maskerpane.setVisible(false);
                }
            };
            new Thread(task).start();
     }
      
      void loadMaskerPane4(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    maskerpane.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                    actionPosDetailsTable_mouse_clicked();
                    maskerpane.setVisible(false);
                }
            };
            new Thread(task).start();
     }
    
     void loadMaskerPane5(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    maskerpane.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    try {
                        super.succeeded();
                        actionlocationsDetails_panelTable_mouse_clicked();
                        maskerpane.setVisible(false);
                    } catch (IOException ex) {
                        Logger.getLogger(Pos_Controller.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            };
            new Thread(task).start();
     }
     
       void loadMaskerPane6(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    maskerpane.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                  
                        super.succeeded();
                        getOrderno();   
                        maskerpane.setVisible(false);
                   
                }
            };
            new Thread(task).start();
     }
       
         void loadMaskerPane7(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    maskerpane.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    try {
                        super.succeeded();
                           reference_account.setText("");
                         insert_pos_table();   
                        maskerpane.setVisible(false);
                    } catch (IOException ex) {
                        Logger.getLogger(Pos_Controller.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            };
            new Thread(task).start();
     }
       
          void loadMaskerPane8(
                  String result5,
                  JFXTextField textfield1,
                  JFXTextField textfield2){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    maskerpane.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                    if(result5 !=null){
                        conn=DBConnection.ConnectDB();
                        try{
                            pst=conn.prepareStatement(result5);
                            rs= pst.executeQuery();
                            while(rs.next()){
                                textfield1.setText(rs.getString("LEDGER_NUMBER"));
                                textfield2.setText(rs.getString("LEDGER_NAME"));
                                //  ledger_name3.setText(rs.getString("LEDGER_NAME"));
                            }
                        }
                        catch(Exception e){
                            // e.printStackTrace();
                        }
                        
                        
                        
                        try{
                            
                            
                            ObservableList<pos_details> data2 = FXCollections.observableArrayList();
                            
                            String sql2="select order_number,REFERENCE_NUMBER from CASH_ORDERS";
                            try{
                                conn=DBConnection.ConnectDB();
                                pst=conn.prepareStatement(sql2);
                                rs=pst.executeQuery();
                                
                                while(rs.next()){
                                    if(rs.getString("ORDER_NUMBER")!=null){
                                        reference_number = rs.getString("REFERENCE_NUMBER");
                                        try{
                                            /* if(){
                                            
                                            }*/
                                            
                                            String sql="Select * from STOCK_TRNS WHERE ORDER_NUMBER='"+order_no.getText()+"' AND ORDER_TYPE= 'CSO' ";
                                            conn=DBConnection.ConnectDB();
                                            pst=conn.prepareStatement(sql);
                                            pst.execute();
                                            data.removeAll(data);
                                            loadPosDetailstable(sql);
                                            calculateTotalSalesAmount();
                                            
                                        }
                                        catch(Exception e){
                                            e.printStackTrace();
                                        }
                                        
                                        
                                        item_code.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, String> cellData) -> {
                                            return cellData.getValue().item_codeProperty();
                                            
                                        });
                                        
                                        item_description.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, String> cellData) -> {
                                            return cellData.getValue().item_descriptionProperty();
                                        });
                                        quantity.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                                            return cellData.getValue().quantityProperty();
                                        });
                                        sales_price.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                                            return cellData.getValue().sales_priceProperty();
                                        });
                                        sales_amount.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                                            return cellData.getValue().sales_amountProperty();
                                        });
                                        discount.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                                            return cellData.getValue().discountProperty();
                                        });
                                        taxable.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                                            return cellData.getValue().taxableProperty();
                                        });
                                        tax_amount.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                                            return cellData.getValue().tax_amountProperty();
                                        });
                                        item_location.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, String> cellData) -> {
                                            return cellData.getValue().item_locationProperty();
                                        });
                                        
                                        // pos_table.setItems(data);
                                        
                                        
                                        
                                        
                                        
                                        
                                        item_description.setCellFactory(column -> {
                                            return new TableCell<pos_details, String>() {
                                                @Override
                                                protected void updateItem(String item, boolean empty) {
                                                    super.updateItem(item, empty); //This is mandatory
                                                    
                                                    if (item == null || empty) { //If the cell is empty
                                                        setText(null);
                                                        setStyle("");
                                                    } else { //If the cell is not empty
                                                        
                                                        setText(item); //Put the String data in the cell
                                                        
                                                        //We get here all the info of the Person of this row
                                                        pos_details item_description2 = getTableView().getItems().get(getIndex());
                                                        
                                                        
                                                        
                                                        try{
                                                            if (item_description2.getITEM_DESCRIPTION().isEmpty()==false) {
                                                                setTextFill(Color.BLACK); //The text in red
                                                                setStyle("-fx-background-color:PALEGREEN"); //The background of the cell in yellow
                                                                
                                                                // pos_table.setItems(data);
                                                                // data.removeAll(data);
                                                                // pos_table.setItems(data);
                                                                
                                                            }   else {
                                                                //Here I see if the row of this cell is selected or not
                                                                if(getTableView().getSelectionModel().getSelectedItems().contains(item_description2))
                                                                    setTextFill(Color.WHITE);
                                                                else
                                                                    setTextFill(Color.BLACK);
                                                            }
                                                            
                                                        }
                                                        catch(Exception e){
                                                            e.printStackTrace();
                                                        }
                                                        
                                                        
                                                    }
                                                }
                                            };
                                        });
                                        quantity.setCellFactory(TableColumn ->{
                                            return new TableCell<pos_details, Number>() {
                                                @Override
                                                protected void updateItem(Number item, boolean empty) {
                                                    super.updateItem(item, empty); //This is mandatory
                                                    
                                                    if (item == null || empty) { //If the cell is empty
                                                        setText(null);
                                                        setStyle("");
                                                    } else { //If the cell is not empty
                                                        
                                                        setText(String.valueOf(item)); //Put the String data in the cell
                                                        
                                                        //We get here all the info of the Person of this row
                                                        pos_details quantity2 = getTableView().getItems().get(getIndex());
                                                        
                                                        
                                                        try{
                                                            if (quantity2.getITEM_CODE().isEmpty()==false) {
                                                                setTextFill(Color.WHITE); //The text in red
                                                                setStyle("-fx-background-color: BLUE"); //The background of the cell in yellow
                                                                
                                                            }   else {
                                                                //Here I see if the row of this cell is selected or not
                                                                if(getTableView().getSelectionModel().getSelectedItems().contains(quantity2))
                                                                    setTextFill(Color.WHITE);
                                                                else
                                                                    setTextFill(Color.BLACK);
                                                            }
                                                            
                                                            
                                                        }
                                                        catch(Exception e){
                                                            e.printStackTrace();
                                                        }
                                                        
                                                        
                                                    }
                                                }
                                            };
                                        });
                                        
                                        sales_amount.setCellFactory(TableColumn2 ->{
                                            return new TableCell<pos_details, Number>() {
                                                @Override
                                                protected void updateItem(Number item2, boolean empty) {
                                                    super.updateItem(item2, empty); //This is mandatory
                                                    
                                                    if (item2 == null || empty) { //If the cell is empty
                                                        setText(null);
                                                        setStyle("");
                                                    } else { //If the cell is not empty
                                                        
                                                        setText(String.valueOf(item2)); //Put the String data in the cell
                                                        
                                                        //We get here all the info of the Person of this row
                                                        pos_details sales_amount2 = getTableView().getItems().get(getIndex());
                                                        
                                                        
                                                        try{
                                                            if (sales_amount2.getITEM_CODE().isEmpty()==false) {
                                                                setTextFill(Color.WHITE); //The text in red
                                                                setStyle("-fx-background-color: PURPLE"); //The background of the cell in yellow
                                                                
                                                            }   else {
                                                                //Here I see if the row of this cell is selected or not
                                                                if(getTableView().getSelectionModel().getSelectedItems().contains(sales_amount2))
                                                                    setTextFill(Color.WHITE);
                                                                else
                                                                    setTextFill(Color.BLACK);
                                                            }
                                                            
                                                            
                                                        }
                                                        catch(Exception e){
                                                            e.printStackTrace();
                                                        }
                                                        
                                                        
                                                    }
                                                }
                                            };
                                        });
                                    }
                                    else{
                                        ObservableList<pos_details> data20 = FXCollections.observableArrayList();
                                        data20.removeAll(data20);
                                        pos_table.setItems(data20);
                                        
                                    }
                                }
                                
                            }
                            catch(Exception e){
                                // e.printStackTrace();
                            }
                            
                            
                            
                            
                            //   if(pos_table.getSelectionModel().isEmpty()==true){
                            //      pos_table.setItems(data);
                            //  }
                            
                            
                            
                            
                            //else{
                            // pos_table.setEditable(true);le
                            
                            
                            //pos_table.setItems(data);
                            //  pos_table.setItems(data);
                            //}
                            // pos_table.setEditable(true);
                            
                            
                        }
                        catch(Exception e){
                            //  e.printStackTrace();
                        }
                    }
                    maskerpane.setVisible(false);
                }
            };
            new Thread(task).start();
     }
     
           void loadMaskerPane9(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    maskerpane.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                  
                        super.succeeded();
                        updatePOSdetails_Table(); 
                        maskerpane.setVisible(false);
                   
                }
            };
            new Thread(task).start();
     }
           
           void loadMaskerPane10(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    maskerpane.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                  
                        super.succeeded();
                        deletePOSdetails();
                        maskerpane.setVisible(false);
                   
                }
            };
            new Thread(task).start();
     }
          
            
     
     
     
     
    void load_approve_Post_stage(){
        pos_Initializable.load_approve_Post_stage=true;
         try {
               Scene scene4; 
               stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("approve_post.fxml"));
              
              pos_approve_post Controller = new pos_approve_post();
                      loader.<pos_approve_post>getController();
               Controller.setinvoiceAmount(total_sales_amount.getText());
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 Parent root3 = loader.load();
                 scene4 = new Scene(root3);
                 scene4.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene4);
                 stage2.setTitle(""+ledger_name3.getText()+"");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(450);
                 stage2.setY(50);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();
               stage2.showAndWait();
         } catch (IOException ex) {
             Logger.getLogger(Pos_Controller.class.getName()).log(Level.SEVERE, null, ex);
         }
    }
    
  void refreshPos_table(){
       ObservableList<pos_details> data8 = FXCollections.observableArrayList();
             
             try{
                     
                          data8.add(new pos_details(
                           rs.getString("ITEM_CODE"),
                           rs.getString("DESCRIPTION"),
                           rs.getInt("QUANTITY"),
                           rs.getInt("ITEM_PRICE"),
                           rs.getInt("AMOUNT_VALUE"),
                           rs.getInt("DISCOUNT"),
                           rs.getInt("TAX_AMOUNT"),
                           rs.getInt("TAX_AMOUNT"),
                           rs.getString("ITEM_LOCATION")
             
             
             ));  
                      pos_table.setItems(data8);
                      //calculateTotalSalesAmount();
                       
             }
             catch(Exception e){
               //  e.printStackTrace();
             }
  }
  public static String reference_number;
  public static String generateref(String trns_type){
      Date mydate = new Date();
      SimpleDateFormat sdf =  new SimpleDateFormat("YYYYMMDD-HHmmssSSS");
      String currenttime = sdf.format(mydate);
      reference_number = trns_type + currenttime;
      return reference_number;
  }
          
  void getOrderno(){
      conn=DBConnection.ConnectDB();
     // POS.con_pos = POS.connectdb(IP, PORT, DB, username, password)
     // POS.con_pos =conn;
     
       DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
        LocalDate date = sale_date.getValue();
       System.out.println(date);
                Date ref_date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("YYYYMMDDHHmmss");
        String ref = sdf.format(ref_date);
        generateref("CSO");
        long x=1234567;
            pos.cash_orders_insert(
                    "CSO",
                    x,
                    //Long.valueOf(order_no.getText()),
                    customers.getText(),
                    ledger_name3.getText(),
                    formatter.format(date),
                    location2.getText(),
                    "*", 
                    "*", 
                    "*",
                    generateref("CSO"));
            
                     
            
                        String getgeneratedOrderno="Select ORDER_NUMBER from cash_orders where LEDGER_NUMBER='"+customers.getText()+"' ";
                    try{
                        conn=DBConnection.ConnectDB();
                        pst=conn.prepareStatement(getgeneratedOrderno);
                        rs=pst.executeQuery();
                        
                        while(rs.next()){
                            order_no.setText(rs.getString("ORDER_NUMBER"));
                            
                        }
                         
                    }
                    catch(Exception e){
                        e.printStackTrace();
                    }
                   
       // formatter.format(date), location2.getText(),"NON", "NON", reference_account.getText(),reference_number);
      //POS.cash_orders_insert("CSO",0 , "CASH-BUY", "FAREED DEMO CASH SALE",
       // "03/29/2017", "INVENTORY", "P001", "IN0018", "MALIPLUS");
       /*  String sql="Select order_number from cash_orders where ledger_number='"+ customers.getText() +"' and reference_number ='"+reference_number+"' ";
       order_no.setText(String.valueOf(POS.Check_Value_Exist(sql,"ORDER_NUMBER")));*/
      
             Image img = new Image("/images_/tick3.jpg");
      Notifications OrderCreatedSuccessfully = Notifications.create()
                        .title("Order Created Successfully!")
                        .text("Order "+order_no.getText()+" for "+ledger_name3.getText()+" Created Successfully!!")
                        .graphic(new ImageView(img))
                        .hideAfter(Duration.seconds(5))
                        .position(Pos.CENTER)
                        .onAction((ActionEvent event1) -> {
                        //System.out.println("Clicked on notification!");
            });  
   
            OrderCreatedSuccessfully.show();
            
      
  }
  void clearTextFields(){
               item_code2.setText("");
             //  customers.setText("");
              // ledger_name3.setText("");
               find.setText("");
               barcode2.setText("");
               sales_price4.setText("");
               total_amount.setText("");
               discount_percent.setText("");
               serial_no.setText("");
              // reference_account.setText("");
            //   location2.setText("");
            //   type2.setText("");
               sale_quantity.setText("");
              // order_no.setText("");
               //sale_date.getEditor().setText("");
              // total_sales_amount.setText("");
               showCurrentDateonload();
               ObservableList<pos_details> data8 = FXCollections.observableArrayList();
               data8.removeAll(data8);
               
  }
  
    void clearAllTextFields(){
               item_code2.setText("");
               find.setText("");
               barcode2.setText("");
               sales_price4.setText("");
               total_amount.setText("");
               discount_percent.setText("");
               serial_no.setText("");
               reference_account.setText("");
               location2.setText("");
               type2.setText("");
               sale_quantity.setText("");
               order_no.setText("");
               order_no.setStyle("-fx-control-inner-background: default;");
               customers.setText("CASH_SALE");
               ledger_name3.setText("CASH SALE CUSTOMER");
               total_sales_amount.setText("");
               showCurrentDateonload();
               ObservableList<pos_details> data8 = FXCollections.observableArrayList();
               data8.removeAll(data8);
               
  }
    @FXML
    void actionPerformed(ActionEvent event) throws IOException {
        if(event.getSource().equals(mark_complete)){
            if(order_no.getText()!=null){
             conn=DBConnection.ConnectDB();
            String finish="FIN";
          String sql="Update cash_orders set order_status ='"+finish+"' where order_number='"+order_no.getText()+"'";
          try{
             pst=conn.prepareStatement(sql);
             pst.execute();
              ObservableList<pos_details> data8 = FXCollections.observableArrayList();
              data8.removeAll(data8);
              pos_table.setItems(data8);
              total_sales_amount.setText("");
              Image img = new Image("/images_/tick3.jpg");
      Notifications displayMarkedOrder = Notifications.create()
                        .title("Order marked as Completed!")
                        .text("Order "+order_no.getText()+" Marked as FIN!!")
                        .graphic(new ImageView(img))
                        .hideAfter(Duration.seconds(5))
                        .position(Pos.CENTER)
                        .onAction((ActionEvent event1) -> {
                        //System.out.println("Clicked on notification!");
            });  
   
            displayMarkedOrder.show();
            
            
          }
          catch(Exception e){
              e.printStackTrace();
          }   
            }
            
        }
        else
              if(event.getSource().equals(activate_order)){
            if(activate_order.getText()!=null){
                
              
            
            String activated="ACT";
            String check_if_order_is_active="select order_status from cash_orders where order_number='"+order_no.getText()+"'";
                try {
                    conn=DBConnection.ConnectDB();
                    pst=conn.prepareStatement(check_if_order_is_active);
                     rs=pst.executeQuery();
                     while(rs.next()){
                        if(rs.getString("ORDER_STATUS").equals("FIN")){
                           String sql="Update cash_orders set order_status ='"+activated+"' where order_number='"+order_no.getText()+"'";
          try{
             pst=conn.prepareStatement(sql);
             pst.execute();
           //   ObservableList<pos_details> data8 = FXCollections.observableArrayList();
              data.removeAll(data);
              String sql2= "SELECT * from STOCK_TRNS WHERE ORDER_NUMBER='"+order_no.getText()+"' ";
              
              loadPosDetailstable(sql2);
              calculateTotalSalesAmount();
              Image img = new Image("/images_/tick3.jpg");
      Notifications displayMarkedOrder = Notifications.create()
                        .title("Order marked as Active!")
                        .text("Order "+order_no.getText()+" Marked as Active!!")
                        .graphic(new ImageView(img))
                        .hideAfter(Duration.seconds(5))
                        .position(Pos.CENTER)
                        .onAction((ActionEvent event1) -> {
                        //System.out.println("Clicked on notification!");
            });  
   
            displayMarkedOrder.show();
            
            
          }
          catch(Exception e){
             // e.printStackTrace();
          } 
                        }
                        else{
                         Image img = new Image("/images_/block_icon - Copy - Copy.jpg");
      Notifications displayMarkedOrder = Notifications.create()
                        .title("Order Already marked as Active!")
                        .text("Order "+order_no.getText()+" Already Marked as Active!!")
                        .graphic(new ImageView(img))
                        .hideAfter(Duration.seconds(5))
                        .position(Pos.CENTER)
                        .onAction((ActionEvent event1) -> {
                        //System.out.println("Clicked on notification!");
            });  
   
            displayMarkedOrder.show();   
                        }
                     }
                } catch (SQLException ex) {
                   // Logger.getLogger(Pos_Controller.class.getName()).log(Level.SEVERE, null, ex);
                }
            
             
          
            }
            
        }
        else
     if(event.getSource().equals(insert)){
         
        loadMaskerPane7();
       // System.out.println(""+Double.parseDouble(sales_price4.getText())+""); 
        
      
    }
     else
         if(event.getSource().equals(save)){
             loadMaskerPane9();
         }
     else
             if(event.getSource().equals(delete)){
                 loadMaskerPane10();
             }
    else
               if(event.getSource().equals(search)){
              
             } 

      else
               if(event.getSource().equals(cash_order)){
               
             }
      else
               if(event.getSource().equals(approve_post)){
                if(!total_sales_amount.getText().equals("")){
                     if(!pos_Initializable.load_approve_Post_stage){
                     load_approve_Post_stage(); 
                    }
                    
                }
                else{
                       Image img = new Image("/images_/block_icon - Copy - Copy.jpg");
      Notifications OrderCreatedSuccessfully = Notifications.create()
                        .title("Not Allowed!!")
                        .text("Please select or create an order!!")
                        .graphic(new ImageView(img))
                        .hideAfter(Duration.seconds(5))
                        .position(Pos.CENTER)
                        .onAction((ActionEvent event1) -> {
                        //System.out.println("Clicked on notification!");
            });  
   
            OrderCreatedSuccessfully.show();
            order_no.setStyle("-fx-control-inner-background: yellow;");
                }
                
                
                       
             }
      else
               if(event.getSource().equals(new_order)){
               loadMaskerPane6();
               order_no.setStyle("-fx-control-inner-background: green;");
             }
      else
               if(event.getSource().equals(reprice_an_order)){
               
             }
      else
               if(event.getSource().equals(refresh)){
               
             }
      else
               if(event.getSource().equals(clear_texts)){
               clearTextFields();
               
             }
      else
               if(event.getSource().equals(reports)){
               
             }
               else
               if(event.getSource().equals(barcode2)){
                 loadBarcodeDetailsonEnter();  
                insert_pos_table();
                clearTextFields();
                
                   
                   
             }
      else
               if(event.getSource().equals(item_notes)){
               
             }
      else
               if(event.getSource().equals(export)){
               
             }
      else
               if(event.getSource().equals(post_approve_completed_orders)){
               
             }
      else
               if(event.getSource().equals(close_exit)){
               frame.dispose();
             }
     
      else
               if(event.getSource().equals(cash_sale_rbtn)){
               invoice_rbtn.setSelected(false);
               sale_order_rbtn.setSelected(false);
               quotation_rbtn.setSelected(false);
               returns_rbtn.setSelected(false);
             }
    else
               if(event.getSource().equals(invoice_rbtn)){
               cash_sale_rbtn.setSelected(false);
               sale_order_rbtn.setSelected(false);
               quotation_rbtn.setSelected(false);
               returns_rbtn.setSelected(false);
             }
    else
               if(event.getSource().equals(returns_rbtn)){
               cash_sale_rbtn.setSelected(false);
               sale_order_rbtn.setSelected(false);
               quotation_rbtn.setSelected(false);
               invoice_rbtn.setSelected(false);
             }               
               
               
     else
               if(event.getSource().equals(sale_order_rbtn)){
              cash_sale_rbtn.setSelected(false);
               invoice_rbtn.setSelected(false);
               quotation_rbtn.setSelected(false);
               returns_rbtn.setSelected(false);
             }
     else
               if(event.getSource().equals(quotation_rbtn)){
               cash_sale_rbtn.setSelected(false);
               invoice_rbtn.setSelected(false);
               sale_order_rbtn.setSelected(false);
               returns_rbtn.setSelected(false);
             }
        if(event.getSource().equals(find)){
               loadItemDetailsStage();
        }
         else
               if(event.getSource().equals(function_keys)){
             getFunctionKeysList();
             }
          else
               if(event.getSource().equals(user_options)){
             loadUserOptionsStage();
             }
     
 

}
        void  loadUserOptionsStage() throws IOException{
         Scene scene3; 
               stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_user_options Controller = new pos_user_options();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_user_options.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 Parent root3 = loader.load();
                 scene3 = new Scene(root3);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("User Options");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                // stage2.setResizable(false);
                 //stage2.setX(1000);
                // stage2.setY(100);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();
                  stage2.show();

              
    }
    void getFunctionKeysList() throws IOException{
         Scene scene3; 
               stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_function_keys Controller = new pos_function_keys();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_function_keys.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 Parent root3 = loader.load();
                 scene3 = new Scene(root3);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("Locations");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                // stage2.setResizable(false);
                 //stage2.setX(1000);
                // stage2.setY(100);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();
                  stage2.show();

              
    }

    
    
    static Stage stage2;
     //Pos_Controller Controller = new Pos_Controller();
      
    void loadlocationStage() throws IOException {
       
         Scene scene3; 
               stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_locations Controller = new pos_locations();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_details_panel.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 Parent root3 = loader.load();
                 scene3 = new Scene(root3);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("Locations");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(1000);
                 stage2.setY(100);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();
               stage2.showAndWait();

              String result = loader.<pos_locations>getController().getResult();

                if (result != null) {
        // if a result was selected, add it to the list
                  location2.setText(result);
         }
                 
               
                 
    }
    
    void  try_me2(){
        
          pos_details_panel selectedItem = locations.getSelectionModel().getSelectedItem();
        System.out.println(selectedItem.getMAIN_LOCATION());
        try{
             location2.setText(selectedItem.getMAIN_LOCATION()); 
           // FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos.fxml"));
             
            // Parent root = (Parent) loader.load();
            // Parent root3 = loader.load();    
             //Pos_Controller Controller2 = loader.getController();
            // loader.load();
            //try_me();
           //   loader.<Pos_Controller>getController().setController(this);
              
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    private Parent root4;
      private pos_item_filter Controller3;

    public void setController(pos_item_filter controller ) {
        this.Controller3 = controller;
    }
    
      private pos_items Controller2;

    public void setController(pos_items controller ) {
        this.Controller2 = controller;
    }
      void loadItemDetailsStage() throws IOException{
      
               stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_items Controller = new pos_items();
             // primarystage = (Stage) Controller.getScene().getWindow(); 
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_item_details_panel.fxml"));
                 loader.<pos_items>getController();
                 Controller.setsearch_item(find.getText());
              
            
              loader.setController(Controller);
                  root4 = loader.load();
                 scene3 = new Scene(root4);
                // scene3.setRoot(root4);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("ITEM DETAILS");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(300);
                 stage2.setY(50);
                // loader.<pos_item_filter>getController().setController(this);
                // stage2.show();
               stage2.showAndWait();
               find.setText("");
              String result = loader.<pos_items>getController().getResult();
              String result2= loader.<pos_items>getController().getResult2();
              String load_item_details= loader.<pos_items>getController().getResult5();     
                if (result != null) {
        // if a result was selected, add it to the list
                 loadMaskerPane3(result,result2,load_item_details,item_code2,find,barcode2,sales_price4,discount_percent,sale_quantity);
                  }
               
                   
                
    }
      private Scene scene3; 
       void loadFilterItemDetailsStage() throws IOException{
       
               stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_item_filter Controller = new pos_item_filter();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_item_filter.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 root4 = loader.load();
                 scene3 = new Scene(root4);    
                // scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("Find Names");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 loader.<pos_item_filter>getController().setController(this);
                // stage2.show();
                 stage2.showAndWait();
               
             
        // if a result was selected, add it to the list
                 // item_code2.setText(result);
                //  find.setText(result2);
                
               //  String result4 = loader.<pos_item_filter>getController().getResult();
                //  if(result4 !=null){
                ///     Controller2.loadItemDetailstable();
                //    }
        // }
    }
      
        void loadCustomerDetailsStage() throws IOException{
        Scene scene3; 
               stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_customers Controller = new pos_customers();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_customers.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 Parent root3 = loader.load();
                 scene3 = new Scene(root3);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("MALIPLUS:CASH SALES");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(450);
                 stage2.setY(50);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();
               stage2.showAndWait();

              String result = loader.<pos_customers>getController().getResult();
              String result2= loader.<pos_customers>getController().getResult2();
              String result3= loader.<pos_customers>getController().getResult3();
              String result4=loader.<pos_customers>getController().getResult4();
             
                if (result != null) {
        // if a result was selected, add it to the list
        /*customers.setText(result);
        ledger_name3.setText(result2);*/
                  loadMaskerPane2(customers,ledger_name3,result,result2,result4,order_no);
                  
                  if(result3 !=null){
                      /*                try{
                      conn=DBConnection.ConnectDB();
                      pst=conn.prepareStatement(result3);
                      rs= pst.executeQuery();
                      while(rs.next()){
                      
                      
                      
                      item_code.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, String> cellData) -> {
                      return cellData.getValue().item_codeProperty();
                      
                      });
                      
                      item_description.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, String> cellData) -> {
                      return cellData.getValue().item_descriptionProperty();
                      });
                      quantity.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                      return cellData.getValue().quantityProperty();
                      });
                      sales_price.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                      return cellData.getValue().sales_priceProperty();
                      });
                      sales_amount.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                      return cellData.getValue().sales_amountProperty();
                      });
                      discount.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                      return cellData.getValue().discountProperty();
                      });
                      taxable.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                      return cellData.getValue().taxableProperty();
                      });
                      tax_amount.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                      return cellData.getValue().tax_amountProperty();
                      });
                      item_location.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, String> cellData) -> {
                      return cellData.getValue().item_locationProperty();
                      });
                      
                      // pos_table.setItems(data);
                      
                      
                      
                      
                      
                      
                      item_description.setCellFactory(column -> {
                      return new TableCell<pos_details, String>() {
                      @Override
                      protected void updateItem(String item, boolean empty) {
                      super.updateItem(item, empty); //This is mandatory
                      
                      if (item == null || empty) { //If the cell is empty
                      setText(null);
                      setStyle("");
                      } else { //If the cell is not empty
                      
                      setText(item); //Put the String data in the cell
                      
                      //We get here all the info of the Person of this row
                      pos_details item_description2 = getTableView().getItems().get(getIndex());
                      
                      
                      
                      try{
                      if (item_description2.getITEM_DESCRIPTION().isEmpty()==false) {
                      setTextFill(Color.BLACK); //The text in red
                      setStyle("-fx-background-color:PALEGREEN"); //The background of the cell in yellow
                      
                      // pos_table.setItems(data);
                      // data.removeAll(data);
                      // pos_table.setItems(data);
                      
                      }   else {
                      //Here I see if the row of this cell is selected or not
                      if(getTableView().getSelectionModel().getSelectedItems().contains(item_description2))
                      setTextFill(Color.WHITE);
                      else
                      setTextFill(Color.BLACK);
                      }
                      
                      }
                      catch(Exception e){
                      e.printStackTrace();
                      }
                      
                      
                      }
                      }
                      };
                      });
                      quantity.setCellFactory(TableColumn ->{
                      return new TableCell<pos_details, Number>() {
                      @Override
                      protected void updateItem(Number item, boolean empty) {
                      super.updateItem(item, empty); //This is mandatory
                      
                      if (item == null || empty) { //If the cell is empty
                      setText(null);
                      setStyle("");
                      } else { //If the cell is not empty
                      
                      setText(String.valueOf(item)); //Put the String data in the cell
                      
                      //We get here all the info of the Person of this row
                      pos_details quantity2 = getTableView().getItems().get(getIndex());
                      
                      
                      try{
                      if (quantity2.getITEM_CODE().isEmpty()==false) {
                      setTextFill(Color.WHITE); //The text in red
                      setStyle("-fx-background-color: BLUE"); //The background of the cell in yellow
                      
                      }   else {
                      //Here I see if the row of this cell is selected or not
                      if(getTableView().getSelectionModel().getSelectedItems().contains(quantity2))
                      setTextFill(Color.WHITE);
                      else
                      setTextFill(Color.BLACK);
                      }
                      
                      
                      }
                      catch(Exception e){
                      e.printStackTrace();
                      }
                      
                      
                      }
                      }
                      };
                      });
                      
                      sales_amount.setCellFactory(TableColumn2 ->{
                      return new TableCell<pos_details, Number>() {
                      @Override
                      protected void updateItem(Number item2, boolean empty) {
                      super.updateItem(item2, empty); //This is mandatory
                      
                      if (item2 == null || empty) { //If the cell is empty
                      setText(null);
                      setStyle("");
                      } else { //If the cell is not empty
                      
                      setText(String.valueOf(item2)); //Put the String data in the cell
                      
                      //We get here all the info of the Person of this row
                      pos_details sales_amount2 = getTableView().getItems().get(getIndex());
                      
                      
                      try{
                      if (sales_amount2.getITEM_CODE().isEmpty()==false) {
                      setTextFill(Color.WHITE); //The text in red
                      setStyle("-fx-background-color: PURPLE"); //The background of the cell in yellow
                      
                      }   else {
                      //Here I see if the row of this cell is selected or not
                      if(getTableView().getSelectionModel().getSelectedItems().contains(sales_amount2))
                      setTextFill(Color.WHITE);
                      else
                      setTextFill(Color.BLACK);
                      }
                      
                      
                      }
                      catch(Exception e){
                      e.printStackTrace();
                      }
                      
                      
                      }
                      }
                      };
                      });
                      
                      //   if(pos_table.getSelectionModel().isEmpty()==true){
                      //      pos_table.setItems(data);
                      //  }
                      
                      
                      
                      
                      //else{
                      // pos_table.setEditable(true);le
                      
                      
                      //pos_table.setItems(data);
                      //  pos_table.setItems(data);
                      //}
                      // pos_table.setEditable(true);
                      
                      }
                      
                      
                      //  data.removeAll(data);
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      }
                      catch(Exception e){
                      // e.printStackTrace();
                      }*/    
                  }
                  
             
            
        
         }
                
    }
    
            void loadOrderDetailsStage() throws IOException{
            
                   Scene scene3; 
               stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_orders Controller = new pos_orders();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_order_no.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 Parent root3 = loader.load();
                 scene3 = new Scene(root3);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("ALL CASH ORDERS FOR CASH SALES");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(700);
                 stage2.setY(50);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();
               stage2.showAndWait();

              String result = loader.<pos_orders>getController().getResult();
              String result2= loader.<pos_orders>getController().getResult2();
              String result5= loader.<pos_orders>getController().getResult5();
              String result6= loader.<pos_orders>getController().getResult6();
                if (result != null) {
        // if a result was selected, add it to the list
                  order_no.setText(result);
                  // result5 = "select order_number,description from cash_orders where order_number='"+order_no.getText()+"'";
                 // ledger_name3.setText(result2);
                 
              
         } 
                loadMaskerPane8(result5,customers,ledger_name3);
               // else{
                   // customers.setStyle("-fx-control-inner-background: yellow;");
                     // Image img = new Image("/images_/block_icon - Copy - Copy.jpg");
   //   Notifications displayInsertnewRecord = Notifications.create()
                       // .title("Warning!")
                       // .text("Select Customer Number and create order first before proceeding!!")
                       // .graphic(new ImageView(img))
                       // .hideAfter(Duration.seconds(5))
                      //  .position(Pos.CENTER)
                      //  .onAction((ActionEvent event1) -> {
                        //System.out.println("Clicked on notification!");
           // });  
   
           // displayInsertnewRecord.show();
               // }
        
    }
      void loadtypeDetailsStage() throws IOException{
         Scene scene3; 
               stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_type Controller = new pos_type();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_type_details.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 Parent root3 = loader.load();
                 String x="DESCRIPTION";
                 String y="MINOR_CODE";
                 String pos_types= "DOCUMENT_TYPES";
                 String sub_code = "###";
                 String sql = "select minor_code,description from list_control where reference_code='"+pos_types+"' AND sub_code='"+sub_code+"'";
                 loader.<pos_type>getController().loadtypesDetailstable(sql, x, y);
                 scene3 = new Scene(root3);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("TYPE");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(1000);
                 stage2.setY(50);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();ca
               stage2.showAndWait();

              String result = loader.<pos_type>getController().getResult();
          
                if (result != null) {
        // if a result was selected, add it to the list
                  type2.setText(result);
                 // ledger_name3.setText(result2);
         }
    }
      
    @FXML
    void mouseClicked(MouseEvent event) throws IOException {
      
                 if(event.getSource().equals(location)){
                  
                     loadlocationStage();
                     
                 }
                 else
                     if(event.getSource().equals(find2)  ){
                         if ( !order_no.getText().equalsIgnoreCase("")){
                             item_code2.setText("");
                             find.setText("");
                             loadItemDetailsStage(); } 
                         else{ 
                            Image img = new Image("/images_/block_icon - Copy - Copy.jpg");
                          Notifications approve_postError_message = Notifications.create()
                        .title("Not Allowed!!")
                        .text("Please select or create an order!!")
                        .graphic(new ImageView(img))
                        .hideAfter(Duration.seconds(5))
                        .position(Pos.CENTER)
                        .onAction((ActionEvent event1) -> {
                        //System.out.println("Clicked on notification!");
            });  
   
            approve_postError_message.show();
            order_no.setStyle("-fx-control-inner-background: yellow;");
                         }
                       
                     }
                 else
                         if(event.getSource().equals(type)){
                             loadtypeDetailsStage();
                         }
                 else
                             if(event.getSource().equals(find21)  ){
                                // customers.setStyle("-fx-control-inner-background: pink;");
                                
                                loadCustomerDetailsStage();
                             }
                             
           else
                                 if(event.getSource().equals(order_no2)){
                                   loadOrderDetailsStage();
                                   order_no.setStyle("-fx-control-inner-background: green;");
                                 }
        
    }
    
      
    
      
     final void  actionlocationsDetails_panelTable_mouse_clicked()throws IOException{ 
        //    Pos_Controller Controller =  new Pos_Controller();
      
         //FXMLLoader loader2 = new FXMLLoader(this.getClass().getResource("pos_details_panel.fxml"));
         // Parent root = (Parent) loader.load();
           //Pos_Controller Controller = new Pos_Controller();
         
         // loader.setController(Controller);
         // loader.load();
 
//      pos_details_panel  selectedItem = locations.getSelectionModel().getSelectedItem();
   //   System.out.println(selectedItem.getMAIN_LOCATION());
       try{
   //   test_me.setText(selectedItem.getMAIN_LOCATION()); 
      // FXMLLoader loader = new FXMLLoader(getClass().getResource("pos.fxml"));
      // Parent root = loader.load();
       
    
          // Controller2.actionlocationsDetails_panelTable_mouse_clicked1();
           location2.setText("INVENTORY");
         
         
       }
        catch(Exception e){
           e.printStackTrace();
      }
       
        
       
       
    }
    
     
    @FXML
    void onSelectItem(MouseEvent event) throws IOException {
        if(event.getSource()==pos_table){
            int click = event.getClickCount();
        
        if(click ==1){
            
          if ( actionPosDetailsTable_mouse_clicked()==1){
              loadMaskerPane4();
          }  
          
        } 
        else {
            //do nothig
        }
            
        
       
           
       }
        if(event.getSource()==locations){
          
            loadMaskerPane5();
        
        }

           
           
          
        
    }
    
    public  void loadPosDetailstable(String sql)throws IOException{
             conn=DBConnection.ConnectDB();
            // String sql= "SELECT * from STOCK_TRNS WHERE LEDGER_NUMBER='"+customers.getText()+"' ";
                        try{
                       pst=conn.prepareStatement(sql);
                       rs= pst.executeQuery();
                       while(rs.next()){ 
                           data.add(new pos_details(
                           rs.getString("ITEM_CODE"),
                           rs.getString("DESCRIPTION"),
                           rs.getInt("QUANTITY"),
                           rs.getInt("ITEM_PRICE"),
                           rs.getInt("AMOUNT_VALUE"),
                           rs.getInt("DISCOUNT"),
                           rs.getInt("TAX_AMOUNT"),
                           rs.getInt("TAX_AMOUNT"),
                           rs.getString("ITEM_LOCATION")
                           ));
        item_code.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, String> cellData) -> {
            return cellData.getValue().item_codeProperty();
     
        });
            
       
        item_description.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, String> cellData) -> {
            return cellData.getValue().item_descriptionProperty();
        });
        quantity.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
            return cellData.getValue().quantityProperty();
        });
        sales_price.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
            return cellData.getValue().sales_priceProperty();
        });
        sales_amount.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
            return cellData.getValue().sales_amountProperty();
        });
        discount.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
            return cellData.getValue().discountProperty();
        });
        taxable.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
            return cellData.getValue().taxableProperty();
        });
        tax_amount.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
            return cellData.getValue().tax_amountProperty();
        });
        item_location.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, String> cellData) -> {
            return cellData.getValue().item_locationProperty();
        });
        

     
       // item_code.setStyle("-fx-control-inner-background: yellow;");
       // item_code.setStyle("-fx-text-fill: red;");
       // item_description.setStyle("-fx-text-fill: green;");
       // quantity.setStyle("-fx-text-fill: blue;");
       // sales_price.setStyle("-fx-text-fill: orange;");
       // sales_amount.setStyle("-fx-text-fill: purple;");
       // discount.setStyle("-fx-text-fill: red;");
       // taxable.setStyle("-fx-text-fill: violet;");
       // tax_amount.setStyle("-fx-text-fill: blue;");
       // item_location.setStyle("-fx-text-fill: grey;");
       // display.setStyle(" -fx-font-size: 14px;");
      
                item_description.setCellFactory(column -> {
    return new TableCell<pos_details, String>() {
        @Override
        protected void updateItem(String item, boolean empty) {
            super.updateItem(item, empty); //This is mandatory

            if (item == null || empty) { //If the cell is empty
                setText(null);
                setStyle("");
            } else { //If the cell is not empty

                setText(item); //Put the String data in the cell

                //We get here all the info of the Person of this row
                pos_details item_description2 = getTableView().getItems().get(getIndex());
               

     
                try{
                if (item_description2.getITEM_DESCRIPTION().isEmpty()==false) {
                    setTextFill(Color.BLACK); //The text in red
                    setStyle("-fx-background-color:PALEGREEN"); //The background of the cell in yellow
                    
                }   else {
                    //Here I see if the row of this cell is selected or not
                    if(getTableView().getSelectionModel().getSelectedItems().contains(item_description2))
                        setTextFill(Color.WHITE);
                    else
                        setTextFill(Color.BLACK);
                }
    
                }
                catch(Exception e){
                    e.printStackTrace();
                }
                
              
            }
        }
    };
}); 
                            quantity.setCellFactory(TableColumn ->{
    return new TableCell<pos_details, Number>() {
        @Override
        protected void updateItem(Number item, boolean empty) {
            super.updateItem(item, empty); //This is mandatory

            if (item == null || empty) { //If the cell is empty
                setText(null);
                setStyle("");
            } else { //If the cell is not empty

                setText(String.valueOf(item)); //Put the String data in the cell

                //We get here all the info of the Person of this row
                pos_details quantity2 = getTableView().getItems().get(getIndex());

      
                try{
                if (quantity2.getITEM_CODE().isEmpty()==false) {
                    setTextFill(Color.WHITE); //The text in red
                    setStyle("-fx-background-color: BLUE"); //The background of the cell in yellow
                    
                }   else {
                    //Here I see if the row of this cell is selected or not
                    if(getTableView().getSelectionModel().getSelectedItems().contains(quantity2))
                        setTextFill(Color.WHITE);
                    else
                        setTextFill(Color.BLACK);
                }
                
                 
                }
                catch(Exception e){
                    e.printStackTrace();
                }
                
              
            }
        }
    };
});
                            
                        sales_amount.setCellFactory(TableColumn2 ->{
    return new TableCell<pos_details, Number>() {
        @Override
        protected void updateItem(Number item2, boolean empty) {
            super.updateItem(item2, empty); //This is mandatory

            if (item2 == null || empty) { //If the cell is empty
                setText(null);
                setStyle("");
            } else { //If the cell is not empty

                setText(String.valueOf(item2)); //Put the String data in the cell

                //We get here all the info of the Person of this row
                pos_details sales_amount2 = getTableView().getItems().get(getIndex());

      
                try{
                if (sales_amount2.getITEM_CODE().isEmpty()==false) {
                    setTextFill(Color.WHITE); //The text in red
                    setStyle("-fx-background-color: PURPLE"); //The background of the cell in yellow
                    
                }   else {
                    //Here I see if the row of this cell is selected or not
                    if(getTableView().getSelectionModel().getSelectedItems().contains(sales_amount2))
                        setTextFill(Color.WHITE);
                    else
                        setTextFill(Color.BLACK);
                }
                
                 
                }
                catch(Exception e){
                    e.printStackTrace();
                }
                
              
            }
        }
    };
});                         
  
                           pos_table.setItems(data);
                           pos_table.setEditable(true);
                           
                           
                                   
                       }
                    //   pst.close();
                    //   rs.close();
                   }
                   catch(Exception e2){
                       //e2.printStackTrace();
                   } 
}
  
       public  void loadLocationsDetailstable()throws IOException{
             
             DBConnection.dynamic_sql = "select main_location,location_name from locations"; 
                        try{
                       pst=conn.prepareStatement(DBConnection.dynamic_sql);
                       rs= pst.executeQuery();
                       while(rs.next()){ 
                           data2.add(new pos_details_panel(
                           rs.getString("MAIN_LOCATION"),
                           rs.getString("LOCATION_NAME")
                           ));
        main_location.setCellValueFactory((TableColumn.CellDataFeatures<pos_details_panel, String> cellData) -> {
            return cellData.getValue().main_locationProperty();
        });
        location_name.setCellValueFactory((TableColumn.CellDataFeatures<pos_details_panel, String> cellData) -> {
            return cellData.getValue().location_nameProperty();
        });
       
        

     
       // item_code.setStyle("-fx-control-inner-background: yellow;");
       // item_code.setStyle("-fx-text-fill: red;");
       // item_description.setStyle("-fx-text-fill: green;");
       // quantity.setStyle("-fx-text-fill: blue;");
       // sales_price.setStyle("-fx-text-fill: orange;");
       // sales_amount.setStyle("-fx-text-fill: purple;");
       // discount.setStyle("-fx-text-fill: red;");
       // taxable.setStyle("-fx-text-fill: violet;");
       // tax_amount.setStyle("-fx-text-fill: blue;");
       // item_location.setStyle("-fx-text-fill: grey;");
       // display.setStyle(" -fx-font-size: 14px;");
       
  
                           locations.setItems(data2);
                           
                                   
                       }
                    //   pst.close();
                    //   rs.close();
                   }
                   catch(Exception e2){
                   //    e2.printStackTrace();
                   } 
}
       
  
       
      
    
  void setTextColor(){
      if(find.getText()!=null){
             find.setStyle("-fx-text-fill: blue;"); 
          }
          if(item_code2.getText()!=null){
             item_code2.setStyle("-fx-text-fill: red;");  
          }
  } 
  
  void calculateTotalSalesAmount(){
      try{
        double total = 0 ;
          for (pos_details item : pos_table.getItems()) {
          total = total + item.getSALES_AMOUNT();   
         String s = NumberFormat.getNumberInstance().format(total);
          total_sales_amount.setText(s);
          //total_sales_amount.setStyle("-fx-text-fill: blue;");
          if(total_sales_amount.getText()!=null){
           total_sales_amount.setStyle("-fx-text-fill: green;"
                                       + "-fx-font-size: 30px;");  
         // total_sales_amount.setStyle("-fx-font-size: 40px;");   
          }
          
                 }  
      }
      catch(Exception e){
          e.printStackTrace();
      }
      
     
  }
  
  void calculateSalesAmount(){
      try{
       double total_amount2;
      
      total_amount2 = (Double.parseDouble(sale_quantity.getText()) * Double.parseDouble(sales_price4.getText()))- Double.parseDouble(discount_percent.getText());
      total_amount.setText(String.valueOf(total_amount2));   
      }
      catch(Exception e){
       //   e.printStackTrace();
      }
     
      
  }
  
    @FXML
    void onKeyReleased(KeyEvent event)  {
       if(event.getSource()==sales_price4){
         if(sales_price4.getText()!=null | sale_quantity.getText() !=null | discount_percent.getText() != null){
                       calculateSalesAmount();
                   }
         else{
             if(sales_price4.getText().equals("") | sale_quantity.getText().equals("") | discount_percent.getText().equals("")){
               sales_price4.setStyle("-fx-control-inner-background: red;"); 
               sale_quantity.setStyle("-fx-control-inner-background: red;");
               discount_percent.setStyle("-fx-control-inner-background: red;");
             }
         }
         
         
       } 
       else
           if(event.getSource()==sale_quantity){
            if(sales_price4.getText()!=null | sale_quantity.getText() !=null | discount_percent.getText() != null){
                       calculateSalesAmount();
                   }
            else{
             if(sales_price4.getText().equals("") | sale_quantity.getText().equals("") | discount_percent.getText().equals("")){
               sales_price4.setStyle("-fx-control-inner-background: red;"); 
               sale_quantity.setStyle("-fx-control-inner-background: red;");
               discount_percent.setStyle("-fx-control-inner-background: red;");
             }
            }
            
           }
       else
               if(event.getSource()==discount_percent){
                  if(sales_price4.getText()!=null | sale_quantity.getText() !=null | discount_percent.getText() != null){
                       calculateSalesAmount();
                   }
                  else{
             if(sales_price4.getText().equals("") | sale_quantity.getText().equals("") | discount_percent.getText().equals("")){
               sales_price4.setStyle("-fx-control-inner-background: red;"); 
               sale_quantity.setStyle("-fx-control-inner-background: red;");
               discount_percent.setStyle("-fx-control-inner-background: red;");
             }
                  }
                   
               }
       
     
                  
                   
    }
   private int  actionPosDetailsTable_mouse_clicked(){
     int status = 0;
       pos_details selectedItem = pos_table.getSelectionModel().getSelectedItem();
       String sql="select  DATE_CREATED from STOCK_TRNS where ITEM_CODE = '"+String.valueOf(selectedItem.getITEM_CODE())+"'";
       Connection conn = DBConnection.ConnectDB();
        
        try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
         java.sql.Date check_status6 = rs.getDate("DATE_CREATED");
         //System.out.println(""+check_status6+""); 
         SimpleDateFormat formatter2 = new SimpleDateFormat("MM-dd-yyyy");
        //formatter2.parse(check_status6);
        String ref = formatter2.format(check_status6);
        
        
        
        
      // System.out.println(String.valueOf(ref));
        
         String dateValue = ""+ref+"";
      //  sale_date.setValue(LocalDate.parse(ref,formatter));
       
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
        sale_date.setValue(LocalDate.parse(dateValue,formatter));
            }
           
       }
       catch(Exception e){
           e.printStackTrace();
       }
       
         /*   long millis1 =  new java.util.Date().getTime();
         java.sql.Timestamp ts = new java.sql.Timestamp(millis1);
         long millis2 = ts.getTime();
         java.util.Date date = new java.util.Date( millis2 );
         
         System.out.println("millis1 = " + millis1 );
         System.out.println("ts = " + ts );
         System.out.println("millis2 = " + millis2 );
         System.out.println("date = " + date );*/
       try{ 
           
        
         // 2017-03-31 14:46:34.53
        
     
       
        // System.out.println(selectedContact.getFIRST_NAMES());
          item_code2.setText(selectedItem.getITEM_CODE());  
          find.setText(selectedItem.getITEM_DESCRIPTION());
          sale_quantity.setText(String.valueOf(selectedItem.getQUANTITY()));
         // valueFactory.setValue("February")
          sales_price4.setText(String.valueOf(selectedItem.getSALES_PRICE()));
        // sales_price4.getValueFactory()
           total_amount.setText(String.valueOf(selectedItem.getSALES_AMOUNT()));
          discount_percent.setText(String.valueOf(selectedItem.getDISCOUNT()));
          ///taxable.setText(String.valueOf(selectedItem.getTAXABLE()));
         // tax_amount.setText(String.valueOf(selectedItem.getTAX_AMOUNT()));
          location2.setText(String.valueOf(selectedItem.getITEM_LOCATION()));
          setTextColor();
          String check_status = DBConnection.global_resultSet("select DOCUMENT_TYPE from STOCK_TRNS where ITEM_CODE = '"+String.valueOf(selectedItem.getITEM_CODE())+"'");
          type2.setText(check_status);
          String check_status2 = DBConnection.global_resultSet("select  REFERENCE_NUMBER from STOCK_TRNS where ITEM_CODE = '"+String.valueOf(selectedItem.getITEM_CODE())+"'");
          reference_account.setText(check_status2);
         // reference_account.setStyle("-fx-text-fill: green;"); 
          //reference_account.setStyle("-fx-background-color: yellow;");
          String check_status3 = DBConnection.global_resultSet("select  ITEM_SERIAL from STOCK_TRNS where ITEM_CODE = '"+String.valueOf(selectedItem.getITEM_CODE())+"'");
          serial_no.setText(check_status3);
          String check_status4 = DBConnection.global_resultSet("select  BARCODE from STOCK_TRNS where ITEM_CODE = '"+String.valueOf(selectedItem.getITEM_CODE())+"'");
          barcode2.setText(check_status4);
          String check_status5 = DBConnection.global_resultSet("select  ORDER_NUMBER from STOCK_TRNS where ITEM_CODE = '"+String.valueOf(selectedItem.getITEM_CODE())+"'");
          order_no.setText(check_status5);
          
          
          status=1;
      
       // display.setStyle(" -fx-font-size: 14px;");
       
     }
     catch(Exception  exc ){
          // System.out.printf("%s is not parsable!%n", check_status6);
    throw exc;      // Rethrow the exception.
   }
      return status;
   }
  

    
    

 
   
   void insert_pos_table_records(){
       
          DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
        LocalDate date = sale_date.getValue();
   
       String sql="Update STOCK_TRNS SET "
               + "ITEM_SERIAL='"+serial_no.getText()+"', "
               + "BARCODE='"+barcode2.getText()+"',"
               + "ORDER_NUMBER='"+order_no.getText()+"', "
              // + "REFERENCE_NUMBER='"+reference_account.getText()+"',"
               + "DATE_MODIFIED='"+formatter.format(date)+"' where ITEM_CODE='"+item_code2.getText()+"'";
       try{
           conn=DBConnection.ConnectDB();
           pst=conn.prepareStatement(sql);
           pst.execute();
       }
       catch(Exception e){
           e.printStackTrace();
       }
   }
       private void insert_pos_table()throws IOException{
                if(item_code2.getText()!=null){
                //   POS.stock_trns_insert(item_code2.getText(), location2.getText(), customers.getText(), sale_date.getValue().atStartOfDay().toString(),"DFT", "DFT", order_no.getText(), "DFT", 0, 0, 0, 0,"Y", "DFT", 0, 0,find.getText(), "DFT", "MALIPLUS",barcode2.getText(),serial_no.getText(), "DFT", type2.getText());
       // System.out.println(""+POS.stock_trns_insert("FC293", "INVETORY", "104", "20\","DFT", "DFT", order_no.getText(), "DFT", 0, 0, 0, 0,"Y", "DFT", 0, 0,find.getText(), "DFT", "MALIPLUS",barcode2.getText(),serial_no.getText(), "DFT", type2.getText()));
       conn=DBConnection.ConnectDB();
       //POS.con_pos=conn;
       if(cash_sale_rbtn.isSelected()==true){
              DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");

// ...

        LocalDate date = sale_date.getValue();
        System.out.println( Long.valueOf(order_no.getText()));
        
        /* if (date != null) {
        System.out.println(formatter.format(date));
        // display.setText(formatter.format(date));
        }*/ 
           String cso="CSO";
           pos.stock_trns_insert(
           item_code2.getText(),
           location2.getText(),
           customers.getText(),
           formatter.format(date),
           "CLT",
           cso,
           Long.valueOf(order_no.getText()),
           cso,
           Double.valueOf(sales_price4.getText()),
           Double.valueOf(sale_quantity.getText()),
           Double.valueOf(sale_quantity.getText()),
           Double.valueOf(total_amount.getText()),
           "Y",
           "A",
           Double.parseDouble(discount_percent.getText()),
           0.0,
           find.getText(),
           "EAC",
           "",
           barcode2.getText(),
           serial_no.getText(),
           reference_account.getText(),
           type2.getText(),
           generateref("CSO"));
           
           /*    String sql = "insert into stock_trns ("
           + " item_code,"
           + " item_location,"
           + " ledger_number,"
           + "ledger_type,"
           + "trn_type,"
           + "trn_date,"
           + "quantity,"
           + " item_price,"
           + " amount_value,"
           + "tax_amount,"
           + "discount,"
           + "ord_quantity,"
           + "description,"
           + " order_number,"
           + " order_type,"
           + "invoice_number,"
           + "purchase_order,"
           + "suom,"
           + "iuom,"
           + "document_number,"
           + "document_type,"
           + "account_number,"
           + "contra_account,"
           + "transfer_location,"
           + "receipt_number,"
           + "journal_number,"
           + "journal_type,"
           + "reference_number,"
           + "fiscal_year,"
           + "fiscal_month,"
           + "trn_day,"
           + "trn_month,"
           + "trn_year,"
           + "check_category,"
           + "barcode,"
           + "tax_option,"
           + "conversion,"
           + "price_type,"
           + "charge_amount,"
           + "charge_account,"
           + "charge_type,"
           + "tax_inclusive,"
           + "value_type,"
           + "value_rate,"
           + "value_amount,"
           + "item_discrate,"
           + "check_rate,"
           + "unit_discount,"
           + "item_serial,"
           + "supplier_no,"
           + "user_rate,"
           + "user_value3,"
           + "user_categ2,"
           + "date_created,created_by) "
           + " Values ("
           + "'" + item_code + "',"
           + "'" + item_location + "',"
           + "'" + cust_code + "',"
           + "'" + ledger_type + "',"
           + "'" + trn_type + "',"
           + "Date ('" + trn_date + "'),"
           + "'" + quantity + "',"
           + "'" + item_price + "',"
           + "'" + amount_value + "',"
           + "'" + tax_amount + "',"
           + "'" + total_disc + "',"
           + "'" + order_qty + "',"
           + "'" + description + "',"
           + "" + order_number + ","
           + "'" + order_type + "',"
           + "default,default,"
           + "'" + unit + "',"
           + "'" + unit + "',"
           + "'" + document_number + "',"
           + "'" + document_type + "',"
           + "'" + account_number + "',"
           + "'" + contra_account + "',"
           + "'',"
           + "'0',"
           + "'0',"
           + "'DFT',"
           + "'" + reference_number + "',"
           + "'" + fiscal_year + "',"
           + "'" + fiscal_month + "',"
           + "DAY (CURRENT_TIMESTAMP),"
           + "MONTH(CURRENT_TIMESTAMP),"
           + "YEAR(CURRENT_TIMESTAMP),"
           + "'STK',"
           + "'" + barcode + "',"
           + "'" + tax_code + "',"
           + "default,'"
           + price_type + "',"
           + "'0',"
           + "'*',"
           + " '*',"
           + "'Y',"
           + "'TXR',"
           + "'" + value_rate + "',"
           + "'" + value_amount + "',"
           + "'" + disc_perc + "',"
           + "'" + check_rate + "',"
           + "'" + disc_amount + "',"
           + "'" + serial_no + "',"
           + "'<>',"
           + "'1',"
           + "'" + cost_price + "',"
           + "'" + user_categ2 + "',"
           + "CURRENT_TIMESTAMP,"
           + "'" + loggedInUser + "'"
           + ")";
           */
           
            /* POS.stock_trns_insert("FC293", "INVETORY", "104", "01/04/2017", "CLT",
            "CSO", 19, "CSO", 100, 10, 0, 1000, "Y", "A", 0, 0, "MY DEMO ITEM", "EAC",
            "MALIPLUS", "", "", "123", "VCH");*/

            
            String sql2= "SELECT * from STOCK_TRNS WHERE ORDER_NUMBER='"+order_no.getText()+"' AND ORDER_TYPE= 'CSO' ";
                         data.removeAll(data);
                         loadPosDetailstable(sql2);
                         calculateTotalSalesAmount();
                          Image img = new Image("/images_/tick3.jpg");
      Notifications displayInsertnewRecord = Notifications.create()
                        .title("Saved!")
                        .text("Record saved successfully!!")
                        .graphic(new ImageView(img))
                        .hideAfter(Duration.seconds(5))
                        .position(Pos.CENTER)
                        .onAction((ActionEvent event1) -> {
                        //System.out.println("Clicked on notification!");
            });  
   
            displayInsertnewRecord.show();
       }
   
    //   POS.stock_trns_insert(item_code, item_location, cust_code, trn_date, ledger_type, trn_type, 0, order_type, 0, 0, 0, 0, taxable, tax_code, 0, 0, description, unit, user, barcode, serial_no, document_number, document_type)
                 
                
                        // insert_pos_table_records();
                         

                       }
                else
                   if(item_code2.getText().equals("")){
                          
                   }
   
    }
       void updatePOSdetails_Table(){
           if(item_code2.getText()!=null){
            
               pos_details selectedItem = pos_table.getSelectionModel().getSelectedItem();
              String sql="update STOCK_TRNS set "
                    + "DESCRIPTION='"+find.getText()+"',"
                   + "QUANTITY='"+sale_quantity.getText()+"',"
                   + "ITEM_PRICE='"+sales_price4.getText()+"',"
                   + "AMOUNT_VALUE='"+total_amount.getText()+"',"
                   + "DISCOUNT='"+discount_percent.getText()+"',"
                   + "ITEM_LOCATION='"+location2.getText()+"',"
                   + "DOCUMENT_TYPE='"+type2.getText()+"' where ITEM_CODE='"+selectedItem.getITEM_CODE()+"' AND LEDGER_NUMBER='"+customers.getText()+"'";
            
              try {
                   conn=DBConnection.ConnectDB();
                   pst=conn.prepareStatement(sql);
                   pst.execute();
                   insert_pos_table_records();
                   String sql2= "SELECT * from STOCK_TRNS WHERE ORDER_NUMBER='"+order_no.getText()+"' AND ORDER_TYPE= 'CSO' ";
                         data.removeAll(data);
                         loadPosDetailstable(sql2);
                         calculateTotalSalesAmount();
                         Image img = new Image("/images_/tick3.jpg");
                         Notifications displayUpdateMessage = Notifications.create()
                        .title("Updated!!")
                        .text("Record Updated successfully!!")
                        .graphic(new ImageView(img))
                        .hideAfter(Duration.seconds(5))
                        .position(Pos.CENTER)
                        .onAction((ActionEvent event1) -> {
                        //System.out.println("Clicked on notification!");
            });  
            displayUpdateMessage.darkStyle();
            displayUpdateMessage.show();
                   
              } catch (Exception ex) {
                  ex.printStackTrace();
              } 
           }
            
       }
       
       void  deletePOSdetails(){
        if(item_code2.getText()!=null){
           pos_details selectedItem = pos_table.getSelectionModel().getSelectedItem();
         
           
           String sql="Select REFERENCE_NUMBER FROM STOCK_TRNS WHERE ITEM_CODE = '"+item_code2.getText()+"'";
           try{
               pst=conn.prepareStatement(sql);
               rs=pst.executeQuery();
               while(rs.next()){
                   String deleteRecord="delete from stock_trns where item_code='"+selectedItem.getITEM_CODE()+"' and reference_number='"+rs.getString("REFERENCE_NUMBER")+"'";
                   try{
                       conn=DBConnection.ConnectDB();
                       pst=conn.prepareStatement(deleteRecord);
                       pst.execute();
                       
                        data.removeAll(data);
               String sql2= "SELECT * from STOCK_TRNS WHERE ORDER_NUMBER='"+order_no.getText()+"' AND ORDER_TYPE= 'CSO' ";
               loadPosDetailstable(sql2);
                         Image img = new Image("/images_/x3.png");
      Notifications displayUpdateMessage = Notifications.create()
                        .title("Deleted!!")
                        .text("Record Deleted successfully!!")
                        .graphic(new ImageView(img))
                        .hideAfter(Duration.seconds(5))
                        .position(Pos.CENTER)
                        .onAction((ActionEvent event1) -> {
                        //System.out.println("Clicked on notification!");
            });  
            displayUpdateMessage.darkStyle();
            displayUpdateMessage.show();
                   }
                   catch(Exception e){
                       e.printStackTrace();
                   }
               }
              
           }
           catch(Exception e){
            e.printStackTrace();
               
           } 
        }
            
           else
           {
                        Image img = new Image("/images_/warning.png");
      Notifications displayUpdateMessage = Notifications.create()
                        .title("Warning!!")
                        .text("Row not selected!!Please select row to delete before proceeding!!")
                        .graphic(new ImageView(img))
                        .hideAfter(Duration.seconds(5))
                        .position(Pos.CENTER)
                        .onAction((ActionEvent event1) -> {
                        //System.out.println("Clicked on notification!");
            });  
            displayUpdateMessage.darkStyle();
            displayUpdateMessage.show();
           }
           
          
           
       }
    /**
     * Initializes the controller class.
     */
       
      @FXML
    void onEditCommit(ActionEvent event) {
        if(event.getSource()==item_code){
       
        }
        else
            if(event.getSource()==item_description){
       item_description.setCellValueFactory(
            new PropertyValueFactory<pos_details, String>("ITEM_DESCRIPTIO"));
        item_description.setCellFactory(TextFieldTableCell.forTableColumn());
        item_description.setOnEditCommit(
            new EventHandler<CellEditEvent<pos_details, String>>() {
                @Override
                public void handle(CellEditEvent<pos_details, String> t) {
                    ((pos_details) t.getTableView().getItems().get(
                        t.getTablePosition().getRow())
                        ).SetITEM_DESCRIPTION(t.getNewValue());
                }
             }
        );      
            }
              
         
    } 
    
    void loadBarcodeDetailsonEnter(){
          conn=DBConnection.ConnectDB();
          String sql="SELECT ITEM_CODE,ITEM_NAME,BARCODE,SALE_PRICE,WHOLE_PRICE FROM ITEM_MASTER WHERE barcode='"+barcode2.getText()+"'";
               try{
                   pst=conn.prepareStatement(sql);
                   rs=pst.executeQuery();
                   while(rs.next()){
                       item_code2.setText(rs.getString("ITEM_CODE"));
                       find.setText(rs.getString("ITEM_NAME"));
                       sales_price4.setText(String.valueOf(rs.getInt("SALE_PRICE")));
                       discount_percent.setText("0");
                       sale_quantity.setText("1");
                       calculateSalesAmount();
                      // sale-quantity.
                       
                   }
               }
               catch(Exception e){
                 e.printStackTrace();  
               }
    }
      
    void makeCellEditable(){
       
           item_code.setCellValueFactory(
            new PropertyValueFactory<>("ITEM_CODE"));
        item_code.setCellFactory(TextFieldTableCell.forTableColumn());
        item_code.setOnEditCommit(
            new EventHandler<CellEditEvent<pos_details, String>>() {
                @Override
                public void handle(CellEditEvent<pos_details, String> t) {
                    ((pos_details) t.getTableView().getItems().get(
                        t.getTablePosition().getRow())
                        ).SetITEM_CODE(t.getNewValue());
                }
             }
        );
        
       
        
        
        item_code.setCellValueFactory(
            new PropertyValueFactory<pos_details, String>("ITEM_CODE"));
        item_code.setCellFactory(TextFieldTableCell.forTableColumn());
        item_code.setOnEditCommit(
            new EventHandler<CellEditEvent<pos_details, String>>() {
                @Override
                public void handle(CellEditEvent<pos_details, String> t) {
                    ((pos_details) t.getTableView().getItems().get(
                        t.getTablePosition().getRow())
                        ).SetITEM_CODE(t.getNewValue());
                }
             }
        );
        
       
        
        
        
    }
    
      String date(LocalDate date) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy");
        return date.format(formatter);
    }
    void showCurrentDateonload(){
        //DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyyy");
        /*TextField date = sale_date.getEditor();
        formatter.format(date);*/
       Date ref_date = new Date();
        SimpleDateFormat formatter2 = new SimpleDateFormat("MM-dd-yyyy");
          String ref = formatter2.format(ref_date);
     //   System.out.println(String.valueOf(ref));
        
      String dateValue = ""+ref+"";
      //  sale_date.setValue(LocalDate.parse(ref,formatter));
       
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
      
         sale_date.setValue(LocalDate.parse(dateValue,formatter));
      // SimpleDateFormat format = new SimpleDateFormat("MMM dd, yyyy");
     //  setText(format.format(date));
    
    
      
/* try{
sale_date.getEditor().setText(dateFormat.format(date));
}
catch(Exception e){
e.printStackTrace();
}*/
    }

   /*  POSFX_id.addEventHandler(KeyEvent.KEY_RELEASED, new EventHandler() {
   @Override
   public void handle(KeyEvent event) {
   if (keyComb1.match(event)) {
   System.out.println("Ctrl+R pressed");
   }
   }
   });
   */
    //public static Boolean load_approve_Post_stage= false;
     @FXML
    void handle(KeyEvent event)throws IOException {
     if (event.getCode() == KeyCode.F10) {
        clearAllTextFields();
    //Stop letting it do anything else
       event.consume();
   }
     else
          if (event.getCode() == KeyCode.F12) {
         POSFX_id.getScene().getWindow().hide();
    //Stop letting it do anything else
    event.consume();
   }
      else
          if (event.getCode() == KeyCode.F2) {
       insert_pos_table();
    //Stop letting it do anything else
    event.consume();
   }
      else
          if (event.getCode() == KeyCode.F7) {
            
                  if(!total_sales_amount.getText().equals("")){
               load_approve_Post_stage();   
              }
              
              
              else{
                 Image img = new Image("/images_/block_icon - Copy - Copy.jpg");
      Notifications approve_postError_message = Notifications.create()
                        .title("Not Allowed!!")
                        .text("Please select or create an order!!")
                        .graphic(new ImageView(img))
                        .hideAfter(Duration.seconds(5))
                        .position(Pos.CENTER)
                        .onAction((ActionEvent event1) -> {
                        //System.out.println("Clicked on notification!");
            });  
   
            approve_postError_message.show();
            order_no.setStyle("-fx-control-inner-background: yellow;");
              }
      
    //Stop letting it do anything else
    event.consume();
   }
    }
       final KeyCombination keyComb1 = new KeyCodeCombination(KeyCode.I,
                                    KeyCombination.CONTROL_ANY);
        final KeyCombination keyComb2 = new KeyCodeCombination(KeyCode.S,
                                    KeyCombination.CONTROL_ANY);
         final KeyCombination keyComb3 = new KeyCodeCombination(KeyCode.W,
                                    KeyCombination.CONTROL_ANY);
     @FXML
    void keyReleasedhandle(KeyEvent event)throws IOException {
       if (keyComb1.match(event)) {
                       insert_pos_table();
                    } 
       else
           if (keyComb2.match(event)) {
                       updatePOSdetails_Table();
                    }
       else
           if (keyComb3.match(event)) {
                      loadItemDetailsStage();
                    }
    }
    void onWindowOpened(){
         showCurrentDateonload();
         cash_sale_rbtn.setSelected(true);
         customers.setText("CASH_SALE");
         ledger_name3.setText("CASH SALE CUSTOMER");
         order_no.setEditable(false);
         type2.setEditable(false);
         location2.setText("SHELVES");
         location2.setEditable(false);
         reference_account.setEditable(false);
        
         makeCellEditable();
    }
     @Override
    public void initialize(URL url, ResourceBundle rb) {
         // Logger.getLogger(Pos_Controller.class.getName()).log(Level.SEVERE, null, ex);
         
        loadMaskerPane();   
         
        
         
    }
    
    
     public static JFrame frame;
      public static JFXPanel fxPanel = new JFXPanel();
       public  void initAndShowGUI() {
        // This method is invoked on the EDT thread
       
        try{
          frame = new JFrame("Cash Sales");
        frame.add(fxPanel);
        frame.setSize(2000, 1000);
        
        frame.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("../images_/mali_bg.png")));
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setResizable(true);
        frame.setLocationRelativeTo(null); 
       
        }
        catch(Exception e){
            e.printStackTrace();
        }
        
        
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                initFX(fxPanel);
               // loadComboBoxes();
            }
       });
    }
       
        private  void initFX(JFXPanel fxPanel) {
        // This method is invoked on the JavaFX thread
      
         //  Scene scene = createScene();
          // fxPanel.setScene(scene);
     try {
        Parent  root5 = FXMLLoader.load(getClass().getResource("pos.fxml"));
          Scene scene2 = new Scene(root5, 2000, 1000,Color.ALICEBLUE);
                scene2.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
            fxPanel.setScene(scene2);
            
            
           
        } catch (IOException exc) {
            exc.printStackTrace();
            System.exit(1);
        }
        
      
      
    }
    public static void main(String[] args) {
         SwingUtilities.invokeLater(new Runnable() {
             @Override
            public void run() {
              
                Pos_Controller test = new Pos_Controller();
                test.initAndShowGUI();
                
                
                
               
                
            }
        });
        
         
    }
    
   
   
     
    
 
    
}
