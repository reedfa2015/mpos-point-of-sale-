/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;
import java.util.ListIterator;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author PSL-STUFF
 */
public class pos_details {
private final SimpleStringProperty item_code2;
private final SimpleStringProperty item_description2;
private final SimpleIntegerProperty quantity2;
private final SimpleIntegerProperty sales_price2;
private final SimpleIntegerProperty sales_amount2;
private final SimpleIntegerProperty discount2;
private final SimpleIntegerProperty taxable2;
private final SimpleIntegerProperty tax_amount2;
private final SimpleStringProperty item_location2;

public pos_details (String I_C,String DESC,Integer QTY,Integer S_P,Integer S_A,Integer DISC,Integer T_A,
        Integer T_A_B,String I_L ){
    this.item_code2 = new SimpleStringProperty(I_C);
     this.item_description2 = new SimpleStringProperty(DESC);
      this.quantity2 = new SimpleIntegerProperty(QTY);
       this.sales_price2 = new SimpleIntegerProperty(S_P);
        this.sales_amount2 = new SimpleIntegerProperty(S_A);
         this.discount2 = new SimpleIntegerProperty(DISC);
          this.taxable2= new SimpleIntegerProperty(T_A);
           this.tax_amount2 = new SimpleIntegerProperty(T_A_B);
            this.item_location2 = new SimpleStringProperty(I_L);

         
}



  public String getITEM_CODE(){
      return item_code2.get();
  }
  public String getITEM_DESCRIPTION(){
      return item_description2.get();
  }
  public int getQUANTITY(){
      return quantity2.get();
  }
  public int getSALES_PRICE(){
      return sales_price2.get();
  }
  public int getSALES_AMOUNT(){
      return sales_amount2.get();
  }
  public int getDISCOUNT(){
      return discount2.get();
  }
  public int getTAXABLE(){
      return taxable2.get();
  }
  public int getTAX_AMOUNT(){
      return tax_amount2.get();
  }
  public String getITEM_LOCATION(){
      return item_location2.get();
  }

  
  public void SetITEM_CODE(String I_C ){
      item_code2.set(I_C);
  }
   public void SetITEM_DESCRIPTION(String DESC){
      item_description2.set(DESC);
  }
    public void SetQUANTITY(Integer QTY ){
      quantity2.set(QTY);
  }
     public void SetSALES_PRICE(Integer S_P ){
      sales_price2.set(S_P);
  }
      public void SetSALES_AMOUNT(Integer S_A ){
      sales_amount2.set(S_A);
  }
       public void SetDISCOUNT(Integer DISC ){
      discount2.set(DISC);
  }
        public void SetTAXABLE(Integer T_A){
     taxable2.set(T_A);
  }
         public void SetTAX_AMOUNT(Integer T_A_B ){
      tax_amount2.set(T_A_B);
  }
          public void SetITEM_LOCATION(String I_L ){
      item_location2.set(I_L);
  }
   
     
      public StringProperty item_codeProperty() {
        return item_code2 ;
    }
       public StringProperty item_descriptionProperty() {
        return item_description2 ;
    }
         public IntegerProperty quantityProperty() {
        return quantity2;
    }
           public IntegerProperty sales_priceProperty() {
        return sales_price2;
    }
             public IntegerProperty sales_amountProperty() {
        return sales_amount2 ;
    }
               public IntegerProperty discountProperty() {
        return discount2 ;
    }
                 public IntegerProperty taxableProperty() {
        return taxable2 ;
    }
                   public IntegerProperty tax_amountProperty() {
        return tax_amount2;
    }
                     public StringProperty item_locationProperty() {
        return item_location2 ;
    }



}
