/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableCell;
import javafx.scene.image.Image;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javax.swing.JFrame;
import maliplus.*;
import static maliplus_POS.Pos_Controller.stage2;
/**
 *
 * @author PSL-STUFF
 */
public class pos_items implements Initializable{
      static Connection conn = null;
    static ResultSet rs = null;
    static PreparedStatement pst = null;
    public static JFrame frame;
public static Scene scene2;
static Parent  root5;
    final ObservableList<pos_item_details_panel> data3= FXCollections.observableArrayList();
  @FXML
    private TableView<pos_item_details_panel> items;

    @FXML
    private TableColumn<pos_item_details_panel, String> item_code3;

    @FXML
    private TableColumn<pos_item_details_panel, String> item_name;

    @FXML
    private TableColumn<pos_item_details_panel, Number> sale_price;
    
       @FXML
    private TableColumn<pos_item_details_panel, String> barcode;
   
    @FXML
    private JFXTextField search_item_txtf;
   
    @FXML
    void onKeyTyped(KeyEvent event) {
                if(event.getSource()==search_item_txtf){
                    
                                   if (search_item_2.equals("YES")){
                    try{
                    search_item_2 = "NO";
                    loadItemDetailstable();
                    
                    } catch (IOException ex) {
                    Logger.getLogger(pos_items.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    }
       item_code3.setCellValueFactory(cellData -> cellData.getValue().item_codeProperty());
        item_name.setCellValueFactory(cellData -> cellData.getValue().item_nameProperty());
        sale_price.setCellValueFactory(cellData -> cellData.getValue().retail_priceProperty());
        barcode.setCellValueFactory(cellData -> cellData.getValue().barcodeProperty());
         FilteredList<pos_item_details_panel> filteredData = new FilteredList<>(data3, p -> true);
            search_item_txtf.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(item -> {
                // If filter text is empty, display all persons.
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }

                // Compare first name and last name of every person with filter text.
                String lowerCaseFilter = newValue.toLowerCase();
                 String upperCaseFilter = newValue.toUpperCase();
                if (item.getITEM_CODE().toUpperCase().contains(upperCaseFilter)) {
                    return true; // Filter matches item_code.
                } else 
                    if (item.getITEM_NAME().toLowerCase().contains(lowerCaseFilter)) {
                    return true; // Filter matches item_name.
                }
                else 
                    if (item.getRETAIL_PRICE().toString().toLowerCase().contains(lowerCaseFilter)) {
                    return true; // Filter matches item_name.
                }
                /*           else
                if (item.getBARCODE().toLowerCase().contains(lowerCaseFilter)) {
                return true; // Filter matches item_name.
                }*/
                return false; // Does not match.
            });
        });
            
             SortedList<pos_item_details_panel> sortedData = new SortedList<>(filteredData);
              sortedData.comparatorProperty().bind(items.comparatorProperty());
              items.setItems(sortedData);
              
        }
    }
    
   
 
  void searchitem() {
             item_code3.setCellValueFactory(cellData -> cellData.getValue().item_codeProperty());
        item_name.setCellValueFactory(cellData -> cellData.getValue().item_nameProperty());
        sale_price.setCellValueFactory(cellData -> cellData.getValue().retail_priceProperty());
        barcode.setCellValueFactory(cellData -> cellData.getValue().barcodeProperty());
         FilteredList<pos_item_details_panel> filteredData = new FilteredList<>(data3, p -> true);
            search_item_txtf.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(item -> {
                // If filter text is empty, display all persons.
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }

                // Compare first name and last name of every person with filter text.
                String lowerCaseFilter = newValue.toLowerCase();
                 String upperCaseFilter = newValue.toUpperCase();
                if (item.getITEM_CODE().toUpperCase().contains(upperCaseFilter)) {
                    return true; // Filter matches item_code.
                } else 
                    if (item.getITEM_NAME().toLowerCase().contains(lowerCaseFilter)) {
                    return true; // Filter matches item_name.
                }
                else 
                    if (item.getRETAIL_PRICE().toString().toLowerCase().contains(lowerCaseFilter)) {
                    return true; // Filter matches item_name.
                }
                /*           else
                if (item.getBARCODE().toLowerCase().contains(lowerCaseFilter)) {
                return true; // Filter matches item_name.
                }*/
                return false; // Does not match.
            });
        });
            
             SortedList<pos_item_details_panel> sortedData = new SortedList<>(filteredData);
              sortedData.comparatorProperty().bind(items.comparatorProperty());
              items.setItems(sortedData);
  } 
  
    
    @FXML
    void onSelectItem(MouseEvent event) {
           int click = event.getClickCount();
        
    if(click ==2){
        try {  
                 actionItemlocationsDetails_panelTable_mouse_clicked1();
             } catch (IOException ex) {
                 Logger.getLogger(pos_items.class.getName()).log(Level.SEVERE, null, ex);
             }
    }
             
            
    }
        
        String search_item ="";
        String search_item_2 ="NO";
    public void setsearch_item(String SearchItem) {
        this.search_item= SearchItem;
        if(!SearchItem.equals("")){
            this.search_item_2 = "YES";
        }
        else{
            this.search_item_2 = "NO";
        }
    }
    

    public  void loadItemDetailstable()throws IOException{
             conn=DBConnection.ConnectDB(); 
            // String result4= Controller3.DisplayFilteredResults();
           //  System.out.println(""+result4+"");
           if (search_item_2.equals("NO")){DBConnection.dynamic_sql = "select ITEM_CODE,ITEM_NAME,SALE_PRICE,BARCODE from ITEM_MASTER"; }
           if (search_item_2.equals("YES")){DBConnection.dynamic_sql = "select ITEM_CODE,ITEM_NAME,SALE_PRICE,BARCODE from ITEM_MASTER where item_name like '%"+ search_item +"%'"; }              
           
// search_item_2 = "NO";
           try{
                    
                  //  DBConnection.dynamic_sql = "select ITEM_CODE,ITEM_NAME,SALE_PRICE,BARCODE from ITEM_MASTER";
                    
               System.out.println(DBConnection.dynamic_sql);
               pst=conn.prepareStatement(DBConnection.dynamic_sql);
                       rs= pst.executeQuery();
                       while(rs.next()){ 
                           data3.add(new pos_item_details_panel(
                           rs.getString("ITEM_CODE"),
                           rs.getString("ITEM_NAME"),
                           rs.getInt("SALE_PRICE"),
                           rs.getString("BARCODE")        
                           ));
        item_code3.setCellValueFactory((TableColumn.CellDataFeatures<pos_item_details_panel, String> cellData) -> {
            return cellData.getValue().item_codeProperty();
        });
        item_name.setCellValueFactory((TableColumn.CellDataFeatures<pos_item_details_panel, String> cellData) -> {
            return cellData.getValue().item_nameProperty();
        });
        sale_price.setCellValueFactory((TableColumn.CellDataFeatures<pos_item_details_panel, Number> cellData) -> {
            return cellData.getValue().retail_priceProperty();
        });
        barcode.setCellValueFactory((TableColumn.CellDataFeatures<pos_item_details_panel, String> cellData) -> {
            return cellData.getValue().barcodeProperty();
        });
       
        

             item_name.setCellFactory(column -> {
    return new TableCell<pos_item_details_panel, String>() {
        @Override
        protected void updateItem(String item, boolean empty) {
            super.updateItem(item, empty); //This is mandatory

            if (item == null || empty) { //If the cell is empty
                setText(null);
                setStyle("");
            } else { //If the cell is not empty

                setText(item); //Put the String data in the cell

                //We get here all the info of the Person of this row
                pos_item_details_panel item_name2 = getTableView().getItems().get(getIndex());

      
                try{
                if (item_name2.getITEM_CODE().isEmpty()==false) {
                    setTextFill(Color.BLACK); //The text in red
                    setStyle("-fx-background-color: PINK"); //The background of the cell in yellow
                    
                }   else {
                    //Here I see if the row of this cell is selected or not
                    if(getTableView().getSelectionModel().getSelectedItems().contains(item_name2))
                        setTextFill(Color.WHITE);
                    else
                        setTextFill(Color.BLACK);
                }
                
                 
                }
                catch(Exception e){
                    e.printStackTrace();
                }
                
              
            }
        }
    };
});

                  

     
       // item_code.setStyle("-fx-control-inner-background: yellow;");
       // item_code.setStyle("-fx-text-fill: red;");
       // item_description.setStyle("-fx-text-fill: green;");
       // quantity.setStyle("-fx-text-fill: blue;");
       // sales_price.setStyle("-fx-text-fill: orange;");
       // sales_amount.setStyle("-fx-text-fill: purple;");
       // discount.setStyle("-fx-text-fill: red;");
       // taxable.setStyle("-fx-text-fill: violet;");
       // tax_amount.setStyle("-fx-text-fill: blue;");
       // item_location.setStyle("-fx-text-fill: grey;");
       // display.setStyle(" -fx-font-size: 14px;");
       
  
                           items.setItems(data3);
                           //search_item_txtf.setText(search_item);
                           //searchitem();
                           search_item_txtf.requestFocus();
                           
                                   
                       }
                    //   pst.close();
                    //   rs.close();
                   }
                   catch(Exception e2){
                    //   e2.printStackTrace();
                   } 
}
    
         private Pos_Controller Controller;

    public void setController(Pos_Controller controller ) {
        this.Controller = controller;
    }
    
       private pos_item_filter Controller3;

    public void setController(pos_item_filter controller ) {
        this.Controller3 = controller;
    }
    private String result = null;
    private String result2 = null;
     private String result5 = null;
    public String getResult() {
        
        return result;
    }
    
    public String getResult2() {
        
        return result2;
    }
     public String getResult5() {
        
        return result5;
    }

     void  actionItemlocationsDetails_panelTable_mouse_clicked1()throws IOException{ 
         // Pos_Controller Controller =  new Pos_Controller();
       

         //FXMLLoader loader2 = new FXMLLoader(this.getClass().getResource("pos_details_panel.fxml"));
         // Parent root = (Parent) loader.load();
           //Pos_Controller Controller = new Pos_Controller();
         
         // loader.setController(Controller);
         // loader.load();
         
        
         pos_item_details_panel selectedItem = items.getSelectionModel().getSelectedItem();
        
      //  System.out.println(selectedItem.getITEM_CODE());
        try{
           // test_me.setText(selectedItem.getMAIN_LOCATION());
            result =selectedItem.getITEM_CODE();
            result2 =selectedItem.getITEM_NAME();
            result5="SELECT * FROM ITEM_MASTER WHERE ITEM_CODE='"+selectedItem.getITEM_CODE()+"'";
            items.getScene().getWindow().hide();
            
           
        }
        catch(Exception e){
            
        }
        
          
    }
     
    
     void try_me() throws IOException{
         
         Controller.actionlocationsDetails_panelTable_mouse_clicked(); 
     }
         void loadFilterItemDetailsStage() throws IOException{
       
               stage2 = new Stage();
         
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_item_filter Controller8 = new pos_item_filter();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_item_filter.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller8);
                Parent root4 = loader.load();
                Scene scene3 = new Scene(root4);    
                // scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("Find Names");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                loader.<pos_item_filter>getController().setController(this);
                // stage2.show();
                 stage2.showAndWait();
               
             
        // if a result was selected, add it to the list
                 // item_code2.setText(result);
                //  find.setText(result2);
                
               //  String result4 = loader.<pos_item_filter>getController().getResult();
                //  if(result4 !=null){
                ///     Controller2.loadItemDetailstable();
                //    }
        // }
    }
   
    
    
    
   
    
    
   
      

      
        @Override
    public void initialize(URL url, ResourceBundle rb) {
       
          try {
              
             loadItemDetailstable();
             //search_item_2="";
             
          } catch (IOException ex) {
              Logger.getLogger(pos_items.class.getName()).log(Level.SEVERE, null, ex);
          }
  
    }

 
}
