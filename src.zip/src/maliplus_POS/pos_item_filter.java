/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import com.jfoenix.controls.JFXTextField;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javax.swing.JFrame;
import maliplus.DBConnection;
/**
 *
 * @author PSL-STUFF
 */
public class pos_item_filter implements Initializable{
      static Connection conn = null;
    static ResultSet rs = null;
    static PreparedStatement pst = null;
    public static JFrame frame;
public static Scene scene2;
static Parent  root5;
  @FXML
    private JFXButton ok_btn;

    @FXML
    private JFXTextField item_code_like_txtf;

    @FXML
    private JFXTextField item_name_like_txtf;

    @FXML
    private JFXTextField supplier_like_txtf;

    @FXML
    private JFXTextField item_type_txtf;

    @FXML
    private JFXTextField item_group_txtf;

    @FXML
    private JFXTextField item_sub_group_txtf;

    @FXML
    private Label item_type_lbl;

    @FXML
    private Label item_group_lbl;

    @FXML
    private Label item_sub_group_lbl;

    @FXML
    private JFXCheckBox all_items_chkbx;

    @FXML
    private Label item_type_lbl_2;

    @FXML
    private Label item_group_lbl_2;

    @FXML
    private Label item_sub_group_lbl_2;

    @FXML
    private JFXButton cancel_btn;

    
         private Pos_Controller Controller;

    public void setController(Pos_Controller controller ) {
        this.Controller = controller;
    }
    
       private pos_items Controller2;

    public void setController(pos_items controller ) {
        this.Controller2 = controller;
    }
   
    String result;
    public String getResult(){
        return result;
    }
    
    
    
   void DisplayFilteredResults(){
   
          conn= DBConnection.ConnectDB();
           String temp = "%" + item_code_like_txtf.getText() + "%";
           String  sql= "SELECT * FROM ITEM_MASTER WHERE ITEM_CODE LIKE '"+temp+"'";
             try{
                 pst=conn.prepareStatement(sql);
                 rs = pst.executeQuery(); 
                while(rs.next()){
                  result= rs.getString("ITEM_CODE");
                  System.out.println(""+result+"");
                  item_code_like_txtf.getScene().getWindow().hide();
                  Controller.loadItemDetailsStage();
                 // Controller2.loadItemDetailstable();
                }                
                 
                
                
                  
               //  jTable1.setModel(DbUtils.resultSetToTableModel(rs));
                 
                 
             }
             catch(Exception e){
                 e.printStackTrace();
             }
             
           
    }
    
    @FXML
    void actionPerformed(ActionEvent event) {
        if(event.getSource().equals(item_code_like_txtf)){
          DisplayFilteredResults();
        }
    }

    @FXML
    void mouseClicked(MouseEvent event) {

    }
    
  
    
    


    
     
    
   
     
   
    
    
    
   
    
    
   
      

      
        @Override
    public void initialize(URL url, ResourceBundle rb) {
       
      
       
    }

 
}
