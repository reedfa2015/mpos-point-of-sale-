/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;

/**
 *
 * @author PSL-STUFF
 */

public class pos_variance_calculation_getter_setter {
 private final SimpleDoubleProperty variance2;   
 
public pos_variance_calculation_getter_setter(double VAR){
    
 this.variance2 = new SimpleDoubleProperty(VAR);
}

 public Double getVARIANCE(){
      return variance2.get();
  }
 
 public void SetVARIANCE(Double VAR ){
      variance2.set(VAR);
  }
 
 public DoubleProperty varianceProperty() {
        return variance2 ;
    }

}
