/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;

import java.io.File;
import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.Stage;

/**
 *
 * @author PSL-STUFF
 */
public class pos_Initializable extends Application{
     public static Boolean load_approve_Post_stage= false;
     @Override
     public void start(Stage primarystage) throws Exception{
     //Pos_Controller Controller =  new Pos_Controller();
     FXMLLoader loader = new FXMLLoader(this.getClass().getResource("contacts.fxml"));
     //FXMLLoader loader2 = new FXMLLoader(this.getClass().getResource("pos_details_panel.fxml"));
     // Parent root = (Parent) loader.load();
     //Pos_Controller Controller = new Pos_Controller();
     //Pos_Controller Controller = loader.getController();
    // loader.setController(Controller);
     AnchorPane mainPane = (AnchorPane) loader.load();
     primarystage.setScene(new Scene(mainPane));
     primarystage.setMaximized(true);
     mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm());
     primarystage.setTitle("MaliPlus Retail ©2017 PrimeSoft Solutions (K) Ltd");
     primarystage.getIcons().add(new Image("/images_/Mali_bg.png"));
     
     
     primarystage.show();
     
     }
     
     
     
     /*    @Override
     public void start(Stage stage)  {
     String workingDirectory=System.getProperty("user.dir");
     File f= new File(workingDirectory,"//bgslide.mp4");
     
     Media m= new Media(f.toURI().toString());
     
     MediaPlayer mp= new MediaPlayer(m);
     mp.setAutoPlay(true);
     MediaView mv= new MediaView(mp);
     StackPane root= new StackPane();
     root.getChildren().add(mv);
     stage.setScene(new Scene (root,960,540));
     stage.setTitle("hello media");
     stage.show();
     
     //  mp.play();
     }*/
     public static void main(String[]args){
         
        launch(args);
    }    
    
    
}
