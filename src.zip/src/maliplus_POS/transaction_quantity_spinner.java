/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;

/**
 *
 * @author PSL-STUFF
 */
class transaction_quantity_spinner {
    
}
