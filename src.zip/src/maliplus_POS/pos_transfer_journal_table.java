/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author PSL-STUFF
 */
public class pos_transfer_journal_table {
private final SimpleStringProperty item_code2;
private final SimpleStringProperty item_name2;
private final SimpleDoubleProperty ordered_quantity2;
private final SimpleStringProperty sent_quantity2;
private final SimpleStringProperty received_quantity2;
private final SimpleStringProperty comment2;
public pos_transfer_journal_table (String I_C,String I_N,Double O_Q,String S_Q,String R_Q,String COM){
    this.item_code2 = new SimpleStringProperty(I_C);
     this.item_name2 = new SimpleStringProperty(I_N);
     this.ordered_quantity2 = new SimpleDoubleProperty(O_Q);
     this.sent_quantity2 = new SimpleStringProperty(S_Q);
     this.received_quantity2 = new SimpleStringProperty(R_Q);
     this.comment2 = new SimpleStringProperty(COM);

}

    



  public String getITEM_CODE(){
      return item_code2.get();
  }
  public String getITEM_NAME(){
      return item_name2.get();
  }

  public Double getORDERED_QUANTITY(){
      return ordered_quantity2.get();
  }
  public String getSENT_QUANTITY(){
      return sent_quantity2.get();
  }
  public String getRECEIVED_QUANTITY(){
      return received_quantity2.get();
  }
  
  public String getCOMMENT(){
      return comment2.get();
  }
 

  

  
  public void SetITEM_CODE(String I_C ){
      item_code2.set(I_C);
  }
   public void SetITEM_NAME(String I_NAME){
      item_name2.set(I_NAME);
  }
  
   public void SetORDERED_QUANTITY(Integer O_Q){
      ordered_quantity2.set(O_Q);
  }
   public void SetSENT_QUANTITY(String S_Q){
      sent_quantity2.set(S_Q);
  }
   public void SetRECEIVED_QUANTITY(String R_Q ){
      received_quantity2.set(R_Q);
  }
   
   public void SetCOMMENT(String COM){
      comment2.set(COM);
  }
 
   
     
      public StringProperty item_codeProperty() {
        return item_code2 ;
    }
       public StringProperty item_nameProperty() {
        return item_name2 ;
    }
    
      public DoubleProperty ordered_quantityProperty() {
        return ordered_quantity2 ;
    }
        public StringProperty sent_quantityProperty() {
        return sent_quantity2 ;
    }
          public StringProperty received_quantityProperty() {
        return received_quantity2 ;
    }
      
            public StringProperty commentProperty() {
        return comment2 ;
    }

  


}
