/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;
import java.util.ListIterator;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author PSL-STUFF
 */
public class pos_details_panel {
private final SimpleStringProperty main_location2;
private final SimpleStringProperty location_name2;


public pos_details_panel (String M_L,String L_N ){
    this.main_location2 = new SimpleStringProperty(M_L);
     this.location_name2 = new SimpleStringProperty(L_N);


         
}

    



  public String getMAIN_LOCATION(){
      return main_location2.get();
  }
  public String getLOCATION_NAME(){
      return location_name2.get();
  }


  
  public void SetMAIN_LOCATION(String M_L ){
      main_location2.set(M_L);
  }
   public void SetLOCATION_NAME(String L_N){
      location_name2.set(L_N);
  }
  
   
     
      public StringProperty main_locationProperty() {
        return main_location2 ;
    }
       public StringProperty location_nameProperty() {
        return location_name2 ;
    }
    



}
