/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

/**
 *
 * @author PSL-STUFF
 */
public class pos_item_master_initializable extends Application{

    @Override
    public void start(Stage primaryStage) throws Exception {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
     try {
           //Pos_Controller Controller =  new Pos_Controller();
     FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_item_details.fxml"));
     //FXMLLoader loader2 = new FXMLLoader(this.getClass().getResource("pos_details_panel.fxml"));
     // Parent root = (Parent) loader.load();
     //Pos_Controller Controller = new Pos_Controller();
     //Pos_Controller Controller = loader.getController();
    // loader.setControl ler(Controller);
     Parent mainPane = (Parent) loader.load();
     primaryStage.setScene(new Scene(mainPane));
     primaryStage.setMaximized(true);
     ///mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm());
     primaryStage.setTitle("ITEM MASTER DETAILS FORM");
     primaryStage.getIcons().add(new Image("/images_/Mali_bg.png"));
     
     
     primaryStage.show();
        } catch (IOException ex) {
            Logger.getLogger(pos_item_master.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    
    }
    
    public static void main(String [] args){
        launch(args);
    }
    
}
