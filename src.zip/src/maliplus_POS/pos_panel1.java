/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;

import java.awt.BorderLayout;
import java.beans.PropertyVetoException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.event.InternalFrameEvent;
import javax.swing.event.InternalFrameListener;
import maliplus.CodeListForm_1;
import maliplus.Configurations1;
import maliplus.Dynamic1;
import maliplus.Standard_Report;
import maliplus.Transactions_Form;
import maliplus.User_Groups;
import maliplus.users_2;


/**
 *
 * @author PSL-STUFF
 */
public class pos_panel1 extends javax.swing.JFrame  {
   
public static JDialog jd = new JDialog(new JFrame(), true);
public static JFXPanel jfxPanel;
public static  JFXPanel jfxPanel2;
public static Scene scene2;
public static Scene scene3;
public static Boolean isSplashLoaded= false;  
private static pos_panel1 mp = null;
  


    /**
     * Creates new form Maliplus_Panel
     */
 public static pos_panel1 getobj()throws IOException{
    
        if(mp == null){
        
            mp = new pos_panel1();
        }
        return mp;
    }
 
 @FXML
    private AnchorPane anchorpane;
  public  void initGui() {
     
            JFrame f = new JFrame();
            f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            String s =
                "os.name: " + System.getProperty("os.name") +
                "\nos.version: " + System.getProperty("os.version");
            //JFrame.setLocation(previousLocation.x + constant, previoudLocation.y + constant);
            f.add(new JTextArea(s,3,28));  // suggest a size
            f.pack();
            // Let the OS handle the positioning!
            f.setLocationByPlatform(true);
            f.setVisible(true);
        
    }

   public  class MyInternalFrame extends JInternalFrame implements InternalFrameListener {
       
       public MyInternalFrame(){
            super("Frame", true, true, true, true);
            setDefaultCloseOperation(dashboard.DO_NOTHING_ON_CLOSE);
        
            dashboard.addInternalFrameListener(this);
            dashboard.setLayout(new BorderLayout()); 
            jfxPanel2=new JFXPanel();
            dashboard.add(jfxPanel2, BorderLayout.CENTER);
            dashboard.setSize(1500, 858);
            dashboard.setVisible(true);
                try {
            dashboard.setMaximum(true);
           } catch (PropertyVetoException e) {
  // Vetoed by internalFrame
  // ... possibly add some handling for this case
}
            
             Platform.runLater(() -> initFX2(jfxPanel2));
  
        }
        public void internalFrameOpened(InternalFrameEvent event) {
            //To change body of implemented methods use File | Settings | File Templates.
           // MyInternalFrame inf = new MyInternalFrame();
           // inf.setVisible(true);
        }
  
        
        public void internalFrameClosing(InternalFrameEvent event) {
            int option = JOptionPane.showConfirmDialog(pos_panel1.dashboard, "Do you want to close the dashboard?WARNING!!Closing the dashboard will automatically close all active windows", "Close Dashboard", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION){
                dashboard.dispose();
            }
            else
            if (option == JOptionPane.NO_OPTION){
                dashboard.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
            }
            
          
        }
  
       
        public void internalFrameClosed(InternalFrameEvent event) {
            //To change body of implemented methods use File | Settings | File Templates.
        }
  
        
        public void internalFrameIconified(InternalFrameEvent event) {
           try {
               // Vetoed by internalFrame
               // ... possibly add some handling for this case

               dashboard.setIcon(true);
               dashboard.setVisible(false);
           } catch (PropertyVetoException ex) {
               Logger.getLogger(pos_panel1.class.getName()).log(Level.SEVERE, null, ex);
           }
            
        }
  
        
        public void internalFrameDeiconified(InternalFrameEvent event) {
            //To change body of implemented methods use File | Settings | File Templates.
        }
  
       
        public void internalFrameActivated(InternalFrameEvent event) {
            //To change body of implemented methods use File | Settings | File Templates.
        }
  
        
        public void internalFrameDeactivated(InternalFrameEvent event) {
            //To change body of implemented methods use File | Settings | File Templates.
        }
   } 
       
   
       
   private void initSwingComponents() {
        
        super.setTitle("MALIPLUS COPYRIGHT 2017 PRIME SOFT SOLUTIONS");
        this.setLayout(new BorderLayout());
        jfxPanel = new JFXPanel();
        this.add(jfxPanel, BorderLayout.CENTER);
        final JPanel swingButtons = new JPanel();
        this.add(swingButtons, BorderLayout.SOUTH);

        this.setSize(1524, 1000);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        
       try{
          Platform.runLater(() -> initFX(jfxPanel));  
       }
       catch(Exception e){
          // e.printStackTrace();
       }
              
      
       
        
        
            
    
        
      
      
    }
    
      private void initFX(JFXPanel jfxPanel) {
        try {
        Parent root3 = FXMLLoader.load(getClass().getResource("pos_panel.fxml"));
          Scene scene8 = new Scene(root3, 1400, 992);
            scene8.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
            jfxPanel.setScene(scene8);
            
         
           
              
        } catch (IOException exc) {
            //exc.printStackTrace();
            System.exit(1);
        }
    }
 
      public  void initFX2(JFXPanel jfxPanel2) {
        try {
          Parent  root5 = FXMLLoader.load(getClass().getResource("pos_dashboard.fxml"));
            scene2 = new Scene(root5, 1256, 858);
            scene2.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
            jfxPanel2.setScene(scene2);
           
        } catch (IOException exc) {
            exc.printStackTrace();
            System.exit(1);
        }
    }
      
       
       
   
    public pos_panel1() throws IOException {
      
        initComponents();
      
     // MyInternalFrame inf = new MyInternalFrame();
    //  inf.setVisible(true);
          
        
    }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenu10 = new javax.swing.JMenu();
        jMenuItem98 = new javax.swing.JMenuItem();
        jToolBar2 = new javax.swing.JToolBar();
        jButton1 = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        Account_master = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JSeparator();
        contact_details = new javax.swing.JButton();
        jSeparator3 = new javax.swing.JSeparator();
        contact_information = new javax.swing.JButton();
        jSeparator4 = new javax.swing.JSeparator();
        properties = new javax.swing.JButton();
        jSeparator5 = new javax.swing.JSeparator();
        leasing = new javax.swing.JButton();
        jToolBar1 = new javax.swing.JToolBar();
        jButton7 = new javax.swing.JButton();
        jSeparator6 = new javax.swing.JSeparator();
        jButton8 = new javax.swing.JButton();
        jSeparator7 = new javax.swing.JSeparator();
        jButton9 = new javax.swing.JButton();
        jToolBar3 = new javax.swing.JToolBar();
        jSeparator8 = new javax.swing.JSeparator();
        jButton4 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        dashboard = new javax.swing.JInternalFrame();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        open = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        close = new javax.swing.JMenuItem();
        jSeparator20 = new javax.swing.JPopupMenu.Separator();
        jMenuItem37 = new javax.swing.JMenuItem();
        jSeparator19 = new javax.swing.JPopupMenu.Separator();
        jMenu11 = new javax.swing.JMenu();
        jMenuItem3 = new javax.swing.JMenuItem();
        jSeparator13 = new javax.swing.JPopupMenu.Separator();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenu12 = new javax.swing.JMenu();
        jMenuItem6 = new javax.swing.JMenuItem();
        jSeparator14 = new javax.swing.JPopupMenu.Separator();
        jMenuItem7 = new javax.swing.JMenuItem();
        jMenuItem8 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem9 = new javax.swing.JMenuItem();
        jMenuItem10 = new javax.swing.JMenuItem();
        jSeparator17 = new javax.swing.JPopupMenu.Separator();
        jMenuItem11 = new javax.swing.JMenuItem();
        jMenuItem12 = new javax.swing.JMenuItem();
        jMenuItem13 = new javax.swing.JMenuItem();
        jSeparator18 = new javax.swing.JPopupMenu.Separator();
        jMenuItem14 = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem15 = new javax.swing.JMenuItem();
        jMenuItem16 = new javax.swing.JMenuItem();
        jSeparator16 = new javax.swing.JPopupMenu.Separator();
        jMenuItem17 = new javax.swing.JMenuItem();
        jCheckBoxMenuItem1 = new javax.swing.JCheckBoxMenuItem();
        jCheckBoxMenuItem2 = new javax.swing.JCheckBoxMenuItem();
        jMenu4 = new javax.swing.JMenu();
        jMenu13 = new javax.swing.JMenu();
        jMenuItem18 = new javax.swing.JMenuItem();
        jMenuItem19 = new javax.swing.JMenuItem();
        jMenuItem20 = new javax.swing.JMenuItem();
        jMenuItem21 = new javax.swing.JMenuItem();
        jSeparator15 = new javax.swing.JPopupMenu.Separator();
        jMenuItem23 = new javax.swing.JMenuItem();
        jMenuItem24 = new javax.swing.JMenuItem();
        jSeparator9 = new javax.swing.JPopupMenu.Separator();
        jMenuItem25 = new javax.swing.JMenuItem();
        jSeparator10 = new javax.swing.JPopupMenu.Separator();
        jMenuItem26 = new javax.swing.JMenuItem();
        jMenuItem27 = new javax.swing.JMenuItem();
        jMenuItem28 = new javax.swing.JMenuItem();
        jMenuItem29 = new javax.swing.JMenuItem();
        jMenu14 = new javax.swing.JMenu();
        jMenuItem30 = new javax.swing.JMenuItem();
        jMenuItem31 = new javax.swing.JMenuItem();
        jMenuItem32 = new javax.swing.JMenuItem();
        jMenuItem33 = new javax.swing.JMenuItem();
        jSeparator21 = new javax.swing.JPopupMenu.Separator();
        jMenuItem34 = new javax.swing.JMenuItem();
        jSeparator11 = new javax.swing.JPopupMenu.Separator();
        jMenuItem35 = new javax.swing.JMenuItem();
        jSeparator12 = new javax.swing.JPopupMenu.Separator();
        jMenuItem36 = new javax.swing.JMenuItem();
        jMenu15 = new javax.swing.JMenu();
        jMenuItem38 = new javax.swing.JMenuItem();
        jMenuItem39 = new javax.swing.JMenuItem();
        jMenuItem40 = new javax.swing.JMenuItem();
        jMenuItem41 = new javax.swing.JMenuItem();
        jSeparator22 = new javax.swing.JPopupMenu.Separator();
        jMenuItem42 = new javax.swing.JMenuItem();
        jMenu16 = new javax.swing.JMenu();
        jMenuItem43 = new javax.swing.JMenuItem();
        jMenuItem44 = new javax.swing.JMenuItem();
        jMenuItem45 = new javax.swing.JMenuItem();
        jMenu17 = new javax.swing.JMenu();
        jMenuItem46 = new javax.swing.JMenuItem();
        jMenuItem47 = new javax.swing.JMenuItem();
        jMenuItem48 = new javax.swing.JMenuItem();
        jMenuItem49 = new javax.swing.JMenuItem();
        jSeparator23 = new javax.swing.JPopupMenu.Separator();
        jMenuItem50 = new javax.swing.JMenuItem();
        jSeparator24 = new javax.swing.JPopupMenu.Separator();
        jMenuItem52 = new javax.swing.JMenuItem();
        jSeparator25 = new javax.swing.JPopupMenu.Separator();
        jMenuItem53 = new javax.swing.JMenuItem();
        jMenuItem54 = new javax.swing.JMenuItem();
        jMenu18 = new javax.swing.JMenu();
        jMenuItem55 = new javax.swing.JMenuItem();
        jMenuItem56 = new javax.swing.JMenuItem();
        jMenuItem57 = new javax.swing.JMenuItem();
        jMenuItem58 = new javax.swing.JMenuItem();
        jMenuItem59 = new javax.swing.JMenuItem();
        jSeparator26 = new javax.swing.JPopupMenu.Separator();
        jMenuItem60 = new javax.swing.JMenuItem();
        jSeparator27 = new javax.swing.JPopupMenu.Separator();
        jMenuItem61 = new javax.swing.JMenuItem();
        jMenuItem62 = new javax.swing.JMenuItem();
        jMenuItem63 = new javax.swing.JMenuItem();
        jMenu19 = new javax.swing.JMenu();
        jMenuItem64 = new javax.swing.JMenuItem();
        jMenuItem65 = new javax.swing.JMenuItem();
        jMenuItem66 = new javax.swing.JMenuItem();
        jMenuItem67 = new javax.swing.JMenuItem();
        jMenuItem68 = new javax.swing.JMenuItem();
        jMenu20 = new javax.swing.JMenu();
        jMenuItem69 = new javax.swing.JMenuItem();
        jMenuItem70 = new javax.swing.JMenuItem();
        jMenuItem71 = new javax.swing.JMenuItem();
        jMenu21 = new javax.swing.JMenu();
        jMenuItem72 = new javax.swing.JMenuItem();
        jMenuItem73 = new javax.swing.JMenuItem();
        jMenuItem74 = new javax.swing.JMenuItem();
        jMenu6 = new javax.swing.JMenu();
        jMenuItem82 = new javax.swing.JMenuItem();
        jSeparator29 = new javax.swing.JPopupMenu.Separator();
        jMenuItem83 = new javax.swing.JMenuItem();
        jMenuItem84 = new javax.swing.JMenuItem();
        jMenuItem85 = new javax.swing.JMenuItem();
        jMenuItem86 = new javax.swing.JMenuItem();
        jMenuItem87 = new javax.swing.JMenuItem();
        jMenu22 = new javax.swing.JMenu();
        jMenuItem88 = new javax.swing.JMenuItem();
        jMenuItem89 = new javax.swing.JMenuItem();
        jMenuItem90 = new javax.swing.JMenuItem();
        jMenuItem91 = new javax.swing.JMenuItem();
        jMenuItem92 = new javax.swing.JMenuItem();
        jMenuItem93 = new javax.swing.JMenuItem();
        jMenuItem94 = new javax.swing.JMenuItem();
        jMenu7 = new javax.swing.JMenu();
        jMenu23 = new javax.swing.JMenu();
        jMenuItem100 = new javax.swing.JMenuItem();
        jMenuItem101 = new javax.swing.JMenuItem();
        jMenuItem102 = new javax.swing.JMenuItem();
        jMenuItem103 = new javax.swing.JMenuItem();
        jMenuItem104 = new javax.swing.JMenuItem();
        jMenuItem95 = new javax.swing.JMenuItem();
        jMenuItem96 = new javax.swing.JMenuItem();
        jMenuItem97 = new javax.swing.JMenuItem();
        jSeparator30 = new javax.swing.JPopupMenu.Separator();
        jMenu24 = new javax.swing.JMenu();
        jMenuItem105 = new javax.swing.JMenuItem();
        jMenuItem106 = new javax.swing.JMenuItem();
        jMenuItem107 = new javax.swing.JMenuItem();
        jMenuItem99 = new javax.swing.JMenuItem();
        jMenu5 = new javax.swing.JMenu();
        jMenuItem76 = new javax.swing.JMenuItem();
        jMenuItem77 = new javax.swing.JMenuItem();
        jMenuItem78 = new javax.swing.JMenuItem();
        jMenuItem117 = new javax.swing.JMenuItem();
        jMenuItem79 = new javax.swing.JMenuItem();
        jSeparator28 = new javax.swing.JPopupMenu.Separator();
        jMenuItem80 = new javax.swing.JMenuItem();
        jMenuItem81 = new javax.swing.JMenuItem();
        jMenuItem75 = new javax.swing.JMenuItem();
        jMenu8 = new javax.swing.JMenu();
        jMenuItem108 = new javax.swing.JMenuItem();
        jMenuItem109 = new javax.swing.JMenuItem();
        jMenuItem110 = new javax.swing.JMenuItem();
        jMenuItem111 = new javax.swing.JMenuItem();
        jMenu9 = new javax.swing.JMenu();
        jMenuItem112 = new javax.swing.JMenuItem();
        jMenuItem113 = new javax.swing.JMenuItem();
        jMenuItem114 = new javax.swing.JMenuItem();
        jSeparator31 = new javax.swing.JPopupMenu.Separator();
        jMenuItem115 = new javax.swing.JMenuItem();
        jMenuItem116 = new javax.swing.JMenuItem();

        jMenu10.setText("jMenu10");

        jMenuItem98.setText("jMenuItem98");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jToolBar2.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, new java.awt.Color(255, 255, 0), null));
        jToolBar2.setRollover(true);

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/user_profile_icon.PNG"))); // NOI18N
        jButton1.setToolTipText("User Profiles");
        jButton1.setFocusable(false);
        jButton1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton1MousePressed(evt);
            }
        });
        jToolBar2.add(jButton1);

        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jToolBar2.add(jSeparator1);

        Account_master.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/account_master_icon 2.jpg"))); // NOI18N
        Account_master.setToolTipText("Account Master");
        Account_master.setFocusable(false);
        Account_master.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Account_master.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        Account_master.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Account_masterMouseClicked(evt);
            }
        });
        jToolBar2.add(Account_master);

        jSeparator2.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jToolBar2.add(jSeparator2);

        contact_details.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/contact_details.jpg"))); // NOI18N
        contact_details.setToolTipText("Contact Details");
        contact_details.setFocusable(false);
        contact_details.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        contact_details.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        contact_details.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                contact_detailsMouseClicked(evt);
            }
        });
        jToolBar2.add(contact_details);

        jSeparator3.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jToolBar2.add(jSeparator3);

        contact_information.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/contacts-icon-27.png"))); // NOI18N
        contact_information.setToolTipText("Contact Information");
        contact_information.setFocusable(false);
        contact_information.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        contact_information.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        contact_information.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                contact_informationMouseClicked(evt);
            }
        });
        jToolBar2.add(contact_information);

        jSeparator4.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jToolBar2.add(jSeparator4);

        properties.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/properties2.jpg"))); // NOI18N
        properties.setToolTipText("Property Details");
        properties.setFocusable(false);
        properties.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        properties.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        properties.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                propertiesMouseClicked(evt);
            }
        });
        jToolBar2.add(properties);

        jSeparator5.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jToolBar2.add(jSeparator5);

        leasing.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/leasing 3.jpg"))); // NOI18N
        leasing.setToolTipText("Lease Details");
        leasing.setFocusable(false);
        leasing.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        leasing.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        leasing.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                leasingMouseClicked(evt);
            }
        });
        jToolBar2.add(leasing);

        jToolBar1.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, new java.awt.Color(255, 255, 0), null));
        jToolBar1.setRollover(true);

        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/reports3.jpg"))); // NOI18N
        jButton7.setToolTipText("Reports");
        jButton7.setFocusable(false);
        jButton7.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton7.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jToolBar1.add(jButton7);

        jSeparator6.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator6.setPreferredSize(new java.awt.Dimension(1, 0));
        jToolBar1.add(jSeparator6);

        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/home 1.jpg"))); // NOI18N
        jButton8.setToolTipText("Home");
        jButton8.setFocusable(false);
        jButton8.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton8.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jToolBar1.add(jButton8);

        jSeparator7.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jToolBar1.add(jSeparator7);

        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/transactions.jpg"))); // NOI18N
        jButton9.setToolTipText("Transactions");
        jButton9.setFocusable(false);
        jButton9.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton9.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton9MouseClicked(evt);
            }
        });
        jToolBar1.add(jButton9);

        jToolBar3.setRollover(true);

        jSeparator8.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jToolBar3.add(jSeparator8);

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/favorite_tasks_icon.PNG"))); // NOI18N
        jButton4.setText("Favorite Tasks");
        jButton4.setToolTipText("Favorite Tasks");
        jButton4.setFocusable(false);
        jButton4.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        jButton4.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jToolBar3.add(jButton4);

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/back_icon.PNG"))); // NOI18N
        jButton2.setToolTipText("Back to previous page");
        jButton2.setFocusable(false);
        jButton2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jToolBar3.add(jButton2);

        jButton3.setText("Logout");
        jButton3.setFocusable(false);
        jButton3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton3.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jToolBar3.add(jButton3);

        dashboard.setClosable(true);
        dashboard.setIconifiable(true);
        dashboard.setMaximizable(true);
        dashboard.setResizable(true);
        dashboard.setAutoscrolls(true);
        dashboard.setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/mali2.png"))); // NOI18N
        dashboard.setVisible(true);

        javax.swing.GroupLayout dashboardLayout = new javax.swing.GroupLayout(dashboard.getContentPane());
        dashboard.getContentPane().setLayout(dashboardLayout);
        dashboardLayout.setHorizontalGroup(
            dashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        dashboardLayout.setVerticalGroup(
            dashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 744, Short.MAX_VALUE)
        );

        jMenu1.setText("File");

        open.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/open_folder2.jpg"))); // NOI18N
        open.setText("Open");

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_0, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/reports3.jpg"))); // NOI18N
        jMenuItem1.setText("Report ");
        open.add(jMenuItem1);

        jMenuItem2.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Q, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/query_icon2.png"))); // NOI18N
        jMenuItem2.setText("Query");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        open.add(jMenuItem2);

        jMenu1.add(open);

        close.setText("Close");
        close.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                closeMouseClicked(evt);
            }
        });
        close.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeActionPerformed(evt);
            }
        });
        jMenu1.add(close);
        jMenu1.add(jSeparator20);

        jMenuItem37.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/Actions-document-save-all-icon2.png"))); // NOI18N
        jMenuItem37.setText("Save");
        jMenu1.add(jMenuItem37);
        jMenu1.add(jSeparator19);

        jMenu11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/export_icon 3.jpg"))); // NOI18N
        jMenu11.setText("Export");

        jMenuItem3.setFont(new java.awt.Font("DialogInput", 1, 12)); // NOI18N
        jMenuItem3.setForeground(new java.awt.Color(0, 0, 204));
        jMenuItem3.setText("Exports");
        jMenuItem3.setEnabled(false);
        jMenuItem3.setRequestFocusEnabled(false);
        jMenu11.add(jMenuItem3);
        jMenu11.add(jSeparator13);

        jMenuItem4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/database_icon.jpg"))); // NOI18N
        jMenuItem4.setText("Database");
        jMenu11.add(jMenuItem4);

        jMenuItem5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/excel_icon.jpg"))); // NOI18N
        jMenuItem5.setText("Excel Data");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        jMenu11.add(jMenuItem5);

        jMenu1.add(jMenu11);

        jMenu12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/import_icon.jpg"))); // NOI18N
        jMenu12.setText("Import");

        jMenuItem6.setFont(new java.awt.Font("DialogInput", 1, 12)); // NOI18N
        jMenuItem6.setForeground(new java.awt.Color(0, 0, 204));
        jMenuItem6.setText("Imports");
        jMenuItem6.setEnabled(false);
        jMenu12.add(jMenuItem6);
        jMenu12.add(jSeparator14);

        jMenuItem7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/database_icon.jpg"))); // NOI18N
        jMenuItem7.setText("Database");
        jMenu12.add(jMenuItem7);

        jMenuItem8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/excel_icon.jpg"))); // NOI18N
        jMenuItem8.setText("Excel Data");
        jMenu12.add(jMenuItem8);

        jMenu1.add(jMenu12);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");

        jMenuItem9.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Z, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/undo_icon.jpg"))); // NOI18N
        jMenuItem9.setText("Undo");
        jMenu2.add(jMenuItem9);

        jMenuItem10.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Y, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/redo_icon.jpg"))); // NOI18N
        jMenuItem10.setText("Redo");
        jMenuItem10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem10ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem10);
        jMenu2.add(jSeparator17);

        jMenuItem11.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_X, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/cut_icon2.jpg"))); // NOI18N
        jMenuItem11.setText("Cut");
        jMenu2.add(jMenuItem11);

        jMenuItem12.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/copy_icon2.jpg"))); // NOI18N
        jMenuItem12.setText("Copy");
        jMenu2.add(jMenuItem12);

        jMenuItem13.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_V, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/paste_icon.jpg"))); // NOI18N
        jMenuItem13.setText("Paste");
        jMenu2.add(jMenuItem13);
        jMenu2.add(jSeparator18);

        jMenuItem14.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/select_all.png"))); // NOI18N
        jMenuItem14.setText("Select All");
        jMenu2.add(jMenuItem14);

        jMenuBar1.add(jMenu2);

        jMenu3.setText("View");

        jMenuItem15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/user_queries.jpg"))); // NOI18N
        jMenuItem15.setText("User Queries");
        jMenu3.add(jMenuItem15);

        jMenuItem16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/query_builds2.png"))); // NOI18N
        jMenuItem16.setText("Query Builds");
        jMenu3.add(jMenuItem16);
        jMenu3.add(jSeparator16);

        jMenuItem17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/user_options.jpg"))); // NOI18N
        jMenuItem17.setText("User Options");
        jMenu3.add(jMenuItem17);

        jCheckBoxMenuItem1.setSelected(true);
        jCheckBoxMenuItem1.setText("Toolbar");
        jMenu3.add(jCheckBoxMenuItem1);

        jCheckBoxMenuItem2.setSelected(true);
        jCheckBoxMenuItem2.setText("Show Panel");
        jMenu3.add(jCheckBoxMenuItem2);

        jMenuBar1.add(jMenu3);

        jMenu4.setText("Data");

        jMenu13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/register_icon2.jpg"))); // NOI18N
        jMenu13.setText("Master Register");

        jMenuItem18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/customer-details_icon.jpg"))); // NOI18N
        jMenuItem18.setText("Customer Details");
        jMenuItem18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem18ActionPerformed(evt);
            }
        });
        jMenu13.add(jMenuItem18);

        jMenuItem19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/supplier_details_icon.jpg"))); // NOI18N
        jMenuItem19.setText("Supplier Details");
        jMenu13.add(jMenuItem19);

        jMenuItem20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/employee_details_icon.jpg"))); // NOI18N
        jMenuItem20.setText("Employee Details");
        jMenu13.add(jMenuItem20);

        jMenuItem21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/loyalty_cards_icon.jpg"))); // NOI18N
        jMenuItem21.setText("Loyalty Cards");
        jMenu13.add(jMenuItem21);
        jMenu13.add(jSeparator15);

        jMenuItem23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/account_master_icon 2.jpg"))); // NOI18N
        jMenuItem23.setText("Account Master");
        jMenu13.add(jMenuItem23);

        jMenuItem24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/asset_register_icon.jpg"))); // NOI18N
        jMenuItem24.setText("Asset Register");
        jMenu13.add(jMenuItem24);
        jMenu13.add(jSeparator9);

        jMenuItem25.setFont(new java.awt.Font("DialogInput", 1, 12)); // NOI18N
        jMenuItem25.setForeground(new java.awt.Color(0, 0, 153));
        jMenuItem25.setText("Importing");
        jMenuItem25.setEnabled(false);
        jMenu13.add(jMenuItem25);
        jMenu13.add(jSeparator10);

        jMenuItem26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/excel_icon.jpg"))); // NOI18N
        jMenuItem26.setText("Import Customers");
        jMenu13.add(jMenuItem26);

        jMenuItem27.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/excel_icon.jpg"))); // NOI18N
        jMenuItem27.setText("Import Employees");
        jMenu13.add(jMenuItem27);

        jMenuItem28.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/excel_icon.jpg"))); // NOI18N
        jMenuItem28.setText("Import Suppliers");
        jMenu13.add(jMenuItem28);

        jMenuItem29.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/excel_icon.jpg"))); // NOI18N
        jMenuItem29.setText("Import Item Details");
        jMenu13.add(jMenuItem29);

        jMenu4.add(jMenu13);

        jMenu14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/sales_processin_icon4.jpg"))); // NOI18N
        jMenu14.setText("Sales Processing");

        jMenuItem30.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/cash_sales_icon2.png"))); // NOI18N
        jMenuItem30.setText("Cash Sales");
        jMenuItem30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem30ActionPerformed(evt);
            }
        });
        jMenu14.add(jMenuItem30);

        jMenuItem31.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/credit_sales_icon.png"))); // NOI18N
        jMenuItem31.setText("Credit Sales");
        jMenu14.add(jMenuItem31);

        jMenuItem32.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/sales_returns_icon.png"))); // NOI18N
        jMenuItem32.setText("Sale Returns");
        jMenu14.add(jMenuItem32);

        jMenuItem33.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/unposted_orders_icon.jpg"))); // NOI18N
        jMenuItem33.setText("Unposted Orders");
        jMenu14.add(jMenuItem33);
        jMenu14.add(jSeparator21);

        jMenuItem34.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/debtor_ledgers_icon.jpg"))); // NOI18N
        jMenuItem34.setText("Debtor Ledger");
        jMenu14.add(jMenuItem34);
        jMenu14.add(jSeparator11);

        jMenuItem35.setFont(new java.awt.Font("DialogInput", 1, 12)); // NOI18N
        jMenuItem35.setForeground(new java.awt.Color(0, 0, 204));
        jMenuItem35.setText("Imports");
        jMenuItem35.setEnabled(false);
        jMenu14.add(jMenuItem35);
        jMenu14.add(jSeparator12);

        jMenuItem36.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/cash_sales_icon.jpg"))); // NOI18N
        jMenuItem36.setText("Import Cash Sates");
        jMenu14.add(jMenuItem36);

        jMenu4.add(jMenu14);

        jMenu15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/purchase_ledger_icon2.jpg"))); // NOI18N
        jMenu15.setText("Purchase Ledger");

        jMenuItem38.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/cash_purchase_icon.jpg"))); // NOI18N
        jMenuItem38.setText("Cash Purchase");
        jMenu15.add(jMenuItem38);

        jMenuItem39.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/purchase_orders-icon.jpg"))); // NOI18N
        jMenuItem39.setText("Purchase Orders");
        jMenu15.add(jMenuItem39);

        jMenuItem40.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/purchase_returns_icon.png"))); // NOI18N
        jMenuItem40.setText("Purchase Returns");
        jMenuItem40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem40ActionPerformed(evt);
            }
        });
        jMenu15.add(jMenuItem40);

        jMenuItem41.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/issue_returns_icon.png"))); // NOI18N
        jMenuItem41.setText("Unposted Orders");
        jMenu15.add(jMenuItem41);
        jMenu15.add(jSeparator22);

        jMenuItem42.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/creditor_ledger-icon.jpg"))); // NOI18N
        jMenuItem42.setText("Creditor Ledger");
        jMenu15.add(jMenuItem42);

        jMenu4.add(jMenu15);

        jMenu16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/employee_issues_icon.jpg"))); // NOI18N
        jMenu16.setText("Employee Issues");

        jMenuItem43.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/stock_issues_icon.jpg"))); // NOI18N
        jMenuItem43.setText("Stock Issues");
        jMenu16.add(jMenuItem43);

        jMenuItem44.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/issue_returns_icon.png"))); // NOI18N
        jMenuItem44.setText("Issue Returns");
        jMenu16.add(jMenuItem44);

        jMenuItem45.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/issue_returns_icon.png"))); // NOI18N
        jMenuItem45.setText("Unposted Issues");
        jMenu16.add(jMenuItem45);

        jMenu4.add(jMenu16);

        jMenu17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/inventory_stocks_icon.jpg"))); // NOI18N
        jMenu17.setText("Inventory Stocks");

        jMenuItem46.setText("Stock Taking/Adjustments");
        jMenuItem46.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem46ActionPerformed(evt);
            }
        });
        jMenu17.add(jMenuItem46);

        jMenuItem47.setText("Stock Transfers");
        jMenuItem47.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem47ActionPerformed(evt);
            }
        });
        jMenu17.add(jMenuItem47);

        jMenuItem48.setText("Repackage Items");
        jMenu17.add(jMenuItem48);

        jMenuItem49.setText("Blending Items");
        jMenu17.add(jMenuItem49);
        jMenu17.add(jSeparator23);

        jMenuItem50.setText("Serialized Items");
        jMenu17.add(jMenuItem50);
        jMenu17.add(jSeparator24);

        jMenuItem52.setFont(new java.awt.Font("DialogInput", 1, 12)); // NOI18N
        jMenuItem52.setForeground(new java.awt.Color(0, 0, 204));
        jMenuItem52.setText("Imports");
        jMenuItem52.setEnabled(false);
        jMenu17.add(jMenuItem52);
        jMenu17.add(jSeparator25);

        jMenuItem53.setText("Imp.Adjustments");
        jMenu17.add(jMenuItem53);

        jMenuItem54.setText("Imp.Stock Taking");
        jMenu17.add(jMenuItem54);

        jMenu4.add(jMenu17);

        jMenu18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/ledger_accounts_icon.jpg"))); // NOI18N
        jMenu18.setText("Ledger Accounts");

        jMenuItem55.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/ledger_transactions_2_icon.png"))); // NOI18N
        jMenuItem55.setText("Ledger Transactions");
        jMenu18.add(jMenuItem55);

        jMenuItem56.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/journal_transactions_icon.jpg"))); // NOI18N
        jMenuItem56.setText("Journal Transactions");
        jMenu18.add(jMenuItem56);

        jMenuItem57.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/accounts_transactions_icon.jpg"))); // NOI18N
        jMenuItem57.setText("Account Transactions");
        jMenu18.add(jMenuItem57);

        jMenuItem58.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/recurring_transactions_icon2.png"))); // NOI18N
        jMenuItem58.setText("Reccuring Journals");
        jMenu18.add(jMenuItem58);

        jMenuItem59.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/accounts_enquiries_icon.png"))); // NOI18N
        jMenuItem59.setText("Account Enquiries");
        jMenu18.add(jMenuItem59);
        jMenu18.add(jSeparator26);

        jMenuItem60.setFont(new java.awt.Font("DialogInput", 1, 12)); // NOI18N
        jMenuItem60.setForeground(new java.awt.Color(0, 0, 204));
        jMenuItem60.setText("Import Transactions");
        jMenuItem60.setEnabled(false);
        jMenu18.add(jMenuItem60);
        jMenu18.add(jSeparator27);

        jMenuItem61.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/reconciliation_accounts_icon.png"))); // NOI18N
        jMenuItem61.setText("Reconciliation A/Cs");
        jMenu18.add(jMenuItem61);

        jMenuItem62.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/reconciliation_wrk_icon.jpg"))); // NOI18N
        jMenuItem62.setText("Reconciliation WRK");
        jMenu18.add(jMenuItem62);

        jMenuItem63.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/refresh-balances_icon2.png"))); // NOI18N
        jMenuItem63.setText("Refresh Balances");
        jMenu18.add(jMenuItem63);

        jMenu4.add(jMenu18);

        jMenu19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/budget_planning_icon.jpg"))); // NOI18N
        jMenu19.setText("Budget Planning");

        jMenuItem64.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/initialize_budget-icon.jpg"))); // NOI18N
        jMenuItem64.setText("Initialize Budgets");
        jMenu19.add(jMenuItem64);

        jMenuItem65.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/excel_icon.jpg"))); // NOI18N
        jMenuItem65.setText("Import From Excel");
        jMenu19.add(jMenuItem65);

        jMenuItem66.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/original_budget-2_icon.png"))); // NOI18N
        jMenuItem66.setText("Original Budgets");
        jMenu19.add(jMenuItem66);

        jMenuItem67.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/revise_budget_icon.jpg"))); // NOI18N
        jMenuItem67.setText("Revise Budgets");
        jMenu19.add(jMenuItem67);

        jMenuItem68.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/finalize_budget_icon.jpg"))); // NOI18N
        jMenuItem68.setText("Finalize Budgets");
        jMenu19.add(jMenuItem68);

        jMenu4.add(jMenu19);

        jMenu20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/periodical tasks_icon.jpg"))); // NOI18N
        jMenu20.setText("Periodical Tasks");

        jMenuItem69.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/close_month-icon.png"))); // NOI18N
        jMenuItem69.setText("Close Account Month");
        jMenu20.add(jMenuItem69);

        jMenuItem70.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/close_account_year_icon.jpg"))); // NOI18N
        jMenuItem70.setText("Close Account Year");
        jMenuItem70.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem70ActionPerformed(evt);
            }
        });
        jMenu20.add(jMenuItem70);

        jMenuItem71.setText("Rebuild Trial Balances");
        jMenuItem71.setEnabled(false);
        jMenu20.add(jMenuItem71);

        jMenu4.add(jMenu20);

        jMenu21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/archive_icon.jpg"))); // NOI18N
        jMenu21.setText("Archive/Purge");

        jMenuItem72.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/archive_ledgers_icon.jpg"))); // NOI18N
        jMenuItem72.setText("Archive Ledgers");
        jMenu21.add(jMenuItem72);

        jMenuItem73.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/purge_ledgers_icon.png"))); // NOI18N
        jMenuItem73.setText("Purge Masters");
        jMenu21.add(jMenuItem73);

        jMenuItem74.setText("Purge Selected");
        jMenu21.add(jMenuItem74);

        jMenu4.add(jMenu21);

        jMenuBar1.add(jMenu4);

        jMenu6.setText("Setup");

        jMenuItem82.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/configurations_icon.jpg"))); // NOI18N
        jMenuItem82.setText("Configurations");
        jMenuItem82.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem82ActionPerformed(evt);
            }
        });
        jMenu6.add(jMenuItem82);
        jMenu6.add(jSeparator29);

        jMenuItem83.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/main-location_icon.jpg"))); // NOI18N
        jMenuItem83.setText("Main Locations");
        jMenu6.add(jMenuItem83);

        jMenuItem84.setText("Sub Locations");
        jMenu6.add(jMenuItem84);

        jMenuItem85.setText("Inv.Locations");
        jMenu6.add(jMenuItem85);

        jMenuItem86.setText("Inv.Sub/Locs");
        jMenu6.add(jMenuItem86);

        jMenuItem87.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/code_list_icon.jpg"))); // NOI18N
        jMenuItem87.setText("Code Lists");
        jMenuItem87.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem87ActionPerformed(evt);
            }
        });
        jMenu6.add(jMenuItem87);

        jMenu22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/code_list_icon.jpg"))); // NOI18N
        jMenu22.setText("Sub Codes");

        jMenuItem88.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/ac categories_icon.png"))); // NOI18N
        jMenuItem88.setText("A/C Sub Categories");
        jMenu22.add(jMenuItem88);

        jMenuItem89.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/asset_register_icon.jpg"))); // NOI18N
        jMenuItem89.setText("Asset Categories");
        jMenuItem89.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem89ActionPerformed(evt);
            }
        });
        jMenu22.add(jMenuItem89);

        jMenuItem90.setText("Item Sub Groups");
        jMenu22.add(jMenuItem90);

        jMenuItem91.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/account_master_icon 2.jpg"))); // NOI18N
        jMenuItem91.setText("Account Sub Codes");
        jMenu22.add(jMenuItem91);

        jMenuItem92.setText("Unit of Measure");
        jMenu22.add(jMenuItem92);

        jMenuItem93.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/user_queries.jpg"))); // NOI18N
        jMenuItem93.setText("Query Groups");
        jMenu22.add(jMenuItem93);

        jMenuItem94.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/reports_icon.PNG"))); // NOI18N
        jMenuItem94.setText("Report Lists");
        jMenu22.add(jMenuItem94);

        jMenu6.add(jMenu22);

        jMenuBar1.add(jMenu6);

        jMenu7.setText("Tools");

        jMenu23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/security_icon_3.png"))); // NOI18N
        jMenu23.setText("Security");

        jMenuItem100.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/user_profile_icon.PNG"))); // NOI18N
        jMenuItem100.setText("Users");
        jMenuItem100.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenuItem100MouseClicked(evt);
            }
        });
        jMenuItem100.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem100ActionPerformed(evt);
            }
        });
        jMenu23.add(jMenuItem100);

        jMenuItem101.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/groups_icon.jpg"))); // NOI18N
        jMenuItem101.setText("Groups");
        jMenuItem101.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem101ActionPerformed(evt);
            }
        });
        jMenu23.add(jMenuItem101);

        jMenuItem102.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/activate_icon.jpg"))); // NOI18N
        jMenuItem102.setText("Activate");
        jMenu23.add(jMenuItem102);

        jMenuItem103.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/deactivate_icon.jpg"))); // NOI18N
        jMenuItem103.setText("De-Activate");
        jMenu23.add(jMenuItem103);

        jMenuItem104.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/block_icon.jpg"))); // NOI18N
        jMenuItem104.setText("Block Data");
        jMenu23.add(jMenuItem104);

        jMenu7.add(jMenu23);

        jMenuItem95.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/database_options_icon.jpg"))); // NOI18N
        jMenuItem95.setText("Database Options");
        jMenu7.add(jMenuItem95);

        jMenuItem96.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/options_icon.jpg"))); // NOI18N
        jMenuItem96.setText("Options");
        jMenu7.add(jMenuItem96);

        jMenuItem97.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/favorite_tasks_icon.PNG"))); // NOI18N
        jMenuItem97.setText("User Favorites");
        jMenu7.add(jMenuItem97);
        jMenu7.add(jSeparator30);

        jMenu24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/database_tools_icon.jpg"))); // NOI18N
        jMenu24.setText("Database Tools");

        jMenuItem105.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/database_backup_icon 2.jpg"))); // NOI18N
        jMenuItem105.setText("Schedule Backup");
        jMenu24.add(jMenuItem105);

        jMenuItem106.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/database_password.jpg"))); // NOI18N
        jMenuItem106.setText("Database Password");
        jMenu24.add(jMenuItem106);

        jMenuItem107.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/database_connection_icon2.png"))); // NOI18N
        jMenuItem107.setText("Close Connection");
        jMenu24.add(jMenuItem107);

        jMenu7.add(jMenu24);

        jMenuItem99.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/change_password_icon.jpg"))); // NOI18N
        jMenuItem99.setText("Change Password");
        jMenu7.add(jMenuItem99);

        jMenuBar1.add(jMenu7);

        jMenu5.setText("Reports");

        jMenuItem76.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/customer_reports.jpg"))); // NOI18N
        jMenuItem76.setText(" Standard Reports");
        jMenuItem76.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenuItem76MouseClicked(evt);
            }
        });
        jMenuItem76.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem76ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem76);

        jMenuItem77.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/supplier reports.png"))); // NOI18N
        jMenuItem77.setText("Customer Reports");
        jMenu5.add(jMenuItem77);

        jMenuItem78.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/unposted_orders_icon.jpg"))); // NOI18N
        jMenuItem78.setText("Supplier Reports");
        jMenuItem78.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem78ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem78);

        jMenuItem117.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/employee_reports_icon.jpg"))); // NOI18N
        jMenuItem117.setText("Employee Reports");
        jMenuItem117.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem117ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem117);

        jMenuItem79.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/static_queries_icon.jpg"))); // NOI18N
        jMenuItem79.setText("Static Queries");
        jMenu5.add(jMenuItem79);
        jMenu5.add(jSeparator28);

        jMenuItem80.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/view_queries_icon 2.jpg"))); // NOI18N
        jMenuItem80.setText("View Queries");
        jMenu5.add(jMenuItem80);

        jMenuItem81.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/data_queries_icon.png"))); // NOI18N
        jMenuItem81.setText("Data Queries");
        jMenuItem81.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem81ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem81);

        jMenuItem75.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/reports_icon.PNG"))); // NOI18N
        jMenuItem75.setText("Standard Reports");
        jMenu5.add(jMenuItem75);

        jMenuBar1.add(jMenu5);

        jMenu8.setText("Windows");

        jMenuItem108.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/cascade_icon.jpg"))); // NOI18N
        jMenuItem108.setText("Cascade");
        jMenuItem108.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem108ActionPerformed(evt);
            }
        });
        jMenu8.add(jMenuItem108);

        jMenuItem109.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/vertical_icon.png"))); // NOI18N
        jMenuItem109.setText("Tile Vertical");
        jMenu8.add(jMenuItem109);

        jMenuItem110.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/horizontal.png"))); // NOI18N
        jMenuItem110.setText("Tile Horizontal");
        jMenu8.add(jMenuItem110);

        jMenuItem111.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/close_all.jpg"))); // NOI18N
        jMenuItem111.setText("Close All");
        jMenu8.add(jMenuItem111);

        jMenuBar1.add(jMenu8);

        jMenu9.setText("Help");

        jMenuItem112.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F1, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem112.setText("Contents");
        jMenu9.add(jMenuItem112);

        jMenuItem113.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/index_icon.png"))); // NOI18N
        jMenuItem113.setText("Index");
        jMenuItem113.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem113ActionPerformed(evt);
            }
        });
        jMenu9.add(jMenuItem113);

        jMenuItem114.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images_/search_icon.png"))); // NOI18N
        jMenuItem114.setText("Search");
        jMenu9.add(jMenuItem114);
        jMenu9.add(jSeparator31);

        jMenuItem115.setText("About...");
        jMenu9.add(jMenuItem115);

        jMenuItem116.setText("Renew Licence");
        jMenu9.add(jMenuItem116);

        jMenuBar1.add(jMenu9);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jToolBar2, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jToolBar1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jToolBar3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(705, Short.MAX_VALUE))
            .addComponent(dashboard, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jToolBar2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jToolBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jToolBar3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(dashboard, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        try {
            dashboard.setIcon(true);
        } catch (java.beans.PropertyVetoException e1) {
            e1.printStackTrace();
        }

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1MousePressed

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        // TODO add your handling code here:
        users_2.getObj().setVisible(true);
    }//GEN-LAST:event_jButton1MouseClicked

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton8ActionPerformed

    private void Account_masterMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Account_masterMouseClicked
        // TODO add your handling code here:
            Dynamic1.getObj().setVisible(true);
           Dynamic1.callAccountMaster();
    }//GEN-LAST:event_Account_masterMouseClicked

    private void contact_detailsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_contact_detailsMouseClicked
        // TODO add your handling code here:
        Dynamic1.getObj().setVisible(true);
           Dynamic1.callContactDetails();
    }//GEN-LAST:event_contact_detailsMouseClicked

    private void contact_informationMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_contact_informationMouseClicked
        // TODO add your handling code here:
        Dynamic1.getObj().setVisible(true);
           Dynamic1.callContactInformation();
    }//GEN-LAST:event_contact_informationMouseClicked

    private void propertiesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_propertiesMouseClicked
        // TODO add your handling code here:
        Dynamic1.getObj().setVisible(true);
           Dynamic1.callProperties();
    }//GEN-LAST:event_propertiesMouseClicked

    private void leasingMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_leasingMouseClicked
        // TODO add your handling code here:
        Dynamic1.getObj().setVisible(true);
           Dynamic1.callLeasing();
    }//GEN-LAST:event_leasingMouseClicked

    private void jButton9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton9MouseClicked
        // TODO add your handling code here:
        Transactions_Form.getobj().setVisible(true);
    }//GEN-LAST:event_jButton9MouseClicked

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void closeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_closeMouseClicked
        // TODO add your handling code here:
        if(evt.getSource()==close){
           this.dispose();  
        }
       
    }//GEN-LAST:event_closeMouseClicked

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem5ActionPerformed

    private void jMenuItem10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem10ActionPerformed

    private void jMenuItem40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem40ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem40ActionPerformed

    private void jMenuItem70ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem70ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem70ActionPerformed

    private void jMenuItem81ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem81ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem81ActionPerformed

    private void jMenuItem89ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem89ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem89ActionPerformed

    private void jMenuItem113ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem113ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem113ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jMenuItem82ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem82ActionPerformed
        // TODO add your handling code here:
          Configurations1.getObj().setVisible(true);
    }//GEN-LAST:event_jMenuItem82ActionPerformed

    private void jMenuItem100MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuItem100MouseClicked
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jMenuItem100MouseClicked

    private void jMenuItem100ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem100ActionPerformed
        // TODO add your handling code here:
        users_2.getObj().setVisible(true);
    }//GEN-LAST:event_jMenuItem100ActionPerformed

    private void closeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeActionPerformed
        // TODO add your handling code here:
    
       System.exit(0); 
    }//GEN-LAST:event_closeActionPerformed

    private void jMenuItem18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem18ActionPerformed
        // TODO add your handling code here:
             Dynamic1.getObj().setVisible(true);
           Dynamic1.callContactDetails();
    }//GEN-LAST:event_jMenuItem18ActionPerformed

    private void jMenuItem87ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem87ActionPerformed
        // TODO add your handling code here:
          CodeListForm_1.getObj().setVisible(true);
    }//GEN-LAST:event_jMenuItem87ActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        // TODO add your handling code here:
     dashboard.setVisible(false);
     jToolBar1.setVisible(false);
     jToolBar2.setVisible(false);
     jToolBar3.setVisible(false);
     jMenuBar1.setVisible(false);
    }//GEN-LAST:event_formWindowOpened

    private void jMenuItem108ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem108ActionPerformed
        // TODO add your handling code here:
     initGui();
       
    }//GEN-LAST:event_jMenuItem108ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
              try {
        Parent root2 = FXMLLoader.load(getClass().getResource("splash_login.fxml"));
           scene3 = new Scene(root2, 1400, 992);
            scene3.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
            jfxPanel.setScene(scene3);
            jMenuBar1.setVisible(false);
            dashboard.setVisible(false);
            jToolBar1.setVisible(false);
            jToolBar2.setVisible(false);
            jToolBar3.setVisible(false);
           
              
        } catch (IOException exc) {
            exc.printStackTrace();
            System.exit(1);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jMenuItem78ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem78ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem78ActionPerformed

    private void jMenuItem117ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem117ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem117ActionPerformed

    private void jMenuItem76MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuItem76MouseClicked
        // TODO add your handling code here:
     
    }//GEN-LAST:event_jMenuItem76MouseClicked

    private void jMenuItem76ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem76ActionPerformed
        // TODO add your handling code here:
        Standard_Report.getObj().setVisible(true);
    }//GEN-LAST:event_jMenuItem76ActionPerformed

    private void jMenuItem101ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem101ActionPerformed
        // TODO add your handling code here:
        User_Groups.getObj().setVisible(true);
    }//GEN-LAST:event_jMenuItem101ActionPerformed

    private void jMenuItem46ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem46ActionPerformed
        // TODO add your handling code here:
       pos_stock_adjustment_initial.main(null);

    }//GEN-LAST:event_jMenuItem46ActionPerformed

    private void jMenuItem47ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem47ActionPerformed
        // TODO add your handling code here:
        pos_stock_transfer_journal.main(null);
    }//GEN-LAST:event_jMenuItem47ActionPerformed

    private void jMenuItem30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem30ActionPerformed
        // TODO add your handling code here:
        Pos_Controller.main(null);
    }//GEN-LAST:event_jMenuItem30ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(pos_panel1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(pos_panel1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(pos_panel1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(pos_panel1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        //</editor-fold>

        //</editor-fold>

        //</editor-fold>

        //</editor-fold>

        //</editor-fold>

        //</editor-fold>

        //</editor-fold>

        /* Create and display the form */
        
         
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
              
                try {
                pos_panel1 test = new pos_panel1();
                SwingUtilities.invokeLater(() -> test.initSwingComponents() );
                } catch (IOException ex) {
                Logger.getLogger(pos_panel1.class.getName()).log(Level.SEVERE, null, ex);
                }
               
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Account_master;
    private javax.swing.JMenuItem close;
    private javax.swing.JButton contact_details;
    private javax.swing.JButton contact_information;
    public static javax.swing.JInternalFrame dashboard;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem1;
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem2;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu10;
    private javax.swing.JMenu jMenu11;
    private javax.swing.JMenu jMenu12;
    private javax.swing.JMenu jMenu13;
    private javax.swing.JMenu jMenu14;
    private javax.swing.JMenu jMenu15;
    private javax.swing.JMenu jMenu16;
    private javax.swing.JMenu jMenu17;
    private javax.swing.JMenu jMenu18;
    private javax.swing.JMenu jMenu19;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu20;
    private javax.swing.JMenu jMenu21;
    private javax.swing.JMenu jMenu22;
    private javax.swing.JMenu jMenu23;
    private javax.swing.JMenu jMenu24;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenu jMenu8;
    private javax.swing.JMenu jMenu9;
    public static javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem10;
    private javax.swing.JMenuItem jMenuItem100;
    private javax.swing.JMenuItem jMenuItem101;
    private javax.swing.JMenuItem jMenuItem102;
    private javax.swing.JMenuItem jMenuItem103;
    private javax.swing.JMenuItem jMenuItem104;
    private javax.swing.JMenuItem jMenuItem105;
    private javax.swing.JMenuItem jMenuItem106;
    private javax.swing.JMenuItem jMenuItem107;
    private javax.swing.JMenuItem jMenuItem108;
    private javax.swing.JMenuItem jMenuItem109;
    private javax.swing.JMenuItem jMenuItem11;
    private javax.swing.JMenuItem jMenuItem110;
    private javax.swing.JMenuItem jMenuItem111;
    private javax.swing.JMenuItem jMenuItem112;
    private javax.swing.JMenuItem jMenuItem113;
    private javax.swing.JMenuItem jMenuItem114;
    private javax.swing.JMenuItem jMenuItem115;
    private javax.swing.JMenuItem jMenuItem116;
    private javax.swing.JMenuItem jMenuItem117;
    private javax.swing.JMenuItem jMenuItem12;
    private javax.swing.JMenuItem jMenuItem13;
    private javax.swing.JMenuItem jMenuItem14;
    private javax.swing.JMenuItem jMenuItem15;
    private javax.swing.JMenuItem jMenuItem16;
    private javax.swing.JMenuItem jMenuItem17;
    private javax.swing.JMenuItem jMenuItem18;
    private javax.swing.JMenuItem jMenuItem19;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem20;
    private javax.swing.JMenuItem jMenuItem21;
    private javax.swing.JMenuItem jMenuItem23;
    private javax.swing.JMenuItem jMenuItem24;
    private javax.swing.JMenuItem jMenuItem25;
    private javax.swing.JMenuItem jMenuItem26;
    private javax.swing.JMenuItem jMenuItem27;
    private javax.swing.JMenuItem jMenuItem28;
    private javax.swing.JMenuItem jMenuItem29;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem30;
    private javax.swing.JMenuItem jMenuItem31;
    private javax.swing.JMenuItem jMenuItem32;
    private javax.swing.JMenuItem jMenuItem33;
    private javax.swing.JMenuItem jMenuItem34;
    private javax.swing.JMenuItem jMenuItem35;
    private javax.swing.JMenuItem jMenuItem36;
    private javax.swing.JMenuItem jMenuItem37;
    private javax.swing.JMenuItem jMenuItem38;
    private javax.swing.JMenuItem jMenuItem39;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem40;
    private javax.swing.JMenuItem jMenuItem41;
    private javax.swing.JMenuItem jMenuItem42;
    private javax.swing.JMenuItem jMenuItem43;
    private javax.swing.JMenuItem jMenuItem44;
    private javax.swing.JMenuItem jMenuItem45;
    private javax.swing.JMenuItem jMenuItem46;
    private javax.swing.JMenuItem jMenuItem47;
    private javax.swing.JMenuItem jMenuItem48;
    private javax.swing.JMenuItem jMenuItem49;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem50;
    private javax.swing.JMenuItem jMenuItem52;
    private javax.swing.JMenuItem jMenuItem53;
    private javax.swing.JMenuItem jMenuItem54;
    private javax.swing.JMenuItem jMenuItem55;
    private javax.swing.JMenuItem jMenuItem56;
    private javax.swing.JMenuItem jMenuItem57;
    private javax.swing.JMenuItem jMenuItem58;
    private javax.swing.JMenuItem jMenuItem59;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JMenuItem jMenuItem60;
    private javax.swing.JMenuItem jMenuItem61;
    private javax.swing.JMenuItem jMenuItem62;
    private javax.swing.JMenuItem jMenuItem63;
    private javax.swing.JMenuItem jMenuItem64;
    private javax.swing.JMenuItem jMenuItem65;
    private javax.swing.JMenuItem jMenuItem66;
    private javax.swing.JMenuItem jMenuItem67;
    private javax.swing.JMenuItem jMenuItem68;
    private javax.swing.JMenuItem jMenuItem69;
    private javax.swing.JMenuItem jMenuItem7;
    private javax.swing.JMenuItem jMenuItem70;
    private javax.swing.JMenuItem jMenuItem71;
    private javax.swing.JMenuItem jMenuItem72;
    private javax.swing.JMenuItem jMenuItem73;
    private javax.swing.JMenuItem jMenuItem74;
    private javax.swing.JMenuItem jMenuItem75;
    private javax.swing.JMenuItem jMenuItem76;
    private javax.swing.JMenuItem jMenuItem77;
    private javax.swing.JMenuItem jMenuItem78;
    private javax.swing.JMenuItem jMenuItem79;
    private javax.swing.JMenuItem jMenuItem8;
    private javax.swing.JMenuItem jMenuItem80;
    private javax.swing.JMenuItem jMenuItem81;
    private javax.swing.JMenuItem jMenuItem82;
    private javax.swing.JMenuItem jMenuItem83;
    private javax.swing.JMenuItem jMenuItem84;
    private javax.swing.JMenuItem jMenuItem85;
    private javax.swing.JMenuItem jMenuItem86;
    private javax.swing.JMenuItem jMenuItem87;
    private javax.swing.JMenuItem jMenuItem88;
    private javax.swing.JMenuItem jMenuItem89;
    private javax.swing.JMenuItem jMenuItem9;
    private javax.swing.JMenuItem jMenuItem90;
    private javax.swing.JMenuItem jMenuItem91;
    private javax.swing.JMenuItem jMenuItem92;
    private javax.swing.JMenuItem jMenuItem93;
    private javax.swing.JMenuItem jMenuItem94;
    private javax.swing.JMenuItem jMenuItem95;
    private javax.swing.JMenuItem jMenuItem96;
    private javax.swing.JMenuItem jMenuItem97;
    private javax.swing.JMenuItem jMenuItem98;
    private javax.swing.JMenuItem jMenuItem99;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator10;
    private javax.swing.JPopupMenu.Separator jSeparator11;
    private javax.swing.JPopupMenu.Separator jSeparator12;
    private javax.swing.JPopupMenu.Separator jSeparator13;
    private javax.swing.JPopupMenu.Separator jSeparator14;
    private javax.swing.JPopupMenu.Separator jSeparator15;
    private javax.swing.JPopupMenu.Separator jSeparator16;
    private javax.swing.JPopupMenu.Separator jSeparator17;
    private javax.swing.JPopupMenu.Separator jSeparator18;
    private javax.swing.JPopupMenu.Separator jSeparator19;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JPopupMenu.Separator jSeparator20;
    private javax.swing.JPopupMenu.Separator jSeparator21;
    private javax.swing.JPopupMenu.Separator jSeparator22;
    private javax.swing.JPopupMenu.Separator jSeparator23;
    private javax.swing.JPopupMenu.Separator jSeparator24;
    private javax.swing.JPopupMenu.Separator jSeparator25;
    private javax.swing.JPopupMenu.Separator jSeparator26;
    private javax.swing.JPopupMenu.Separator jSeparator27;
    private javax.swing.JPopupMenu.Separator jSeparator28;
    private javax.swing.JPopupMenu.Separator jSeparator29;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JPopupMenu.Separator jSeparator30;
    private javax.swing.JPopupMenu.Separator jSeparator31;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    public static javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JPopupMenu.Separator jSeparator9;
    public static javax.swing.JToolBar jToolBar1;
    public static javax.swing.JToolBar jToolBar2;
    public static javax.swing.JToolBar jToolBar3;
    private javax.swing.JButton leasing;
    private javax.swing.JMenu open;
    private javax.swing.JButton properties;
    // End of variables declaration//GEN-END:variables

}
