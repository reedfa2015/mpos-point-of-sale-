/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;
import java.util.ListIterator;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author PSL-STUFF
 */
public class pos_item_details_panel {
private final SimpleStringProperty item_code2;
private final SimpleStringProperty item_name2;
private final SimpleIntegerProperty retail_price2;
private final SimpleStringProperty barcode2;

public pos_item_details_panel (String M_L,String L_N,Integer R_P,String B_C ){
    this.item_code2 = new SimpleStringProperty(M_L);
     this.item_name2 = new SimpleStringProperty(L_N);
     this.retail_price2 = new SimpleIntegerProperty(R_P);
     this.barcode2 = new SimpleStringProperty(B_C);
         
}



  public String getITEM_CODE(){
      return item_code2.get();
  }
  public String getITEM_NAME(){
      return item_name2.get();
  }
  public Integer getRETAIL_PRICE(){
      return retail_price2.get();
  }
  public String getBARCODE(){
      return barcode2.get();
  }


  
  public void SetITEM_CODE(String I_C ){
      item_code2.set(I_C);
  }
   public void SetITEM_NAME(String I_N){
     item_name2.set(I_N);
  }
    public void SetRETAIL_PRICE(Integer R_P){
     retail_price2.set(R_P);
  }
    public void SetBARCODE(String B_C){
     barcode2.set(B_C);
  }
  
   
     
      public StringProperty item_codeProperty() {
        return item_code2 ;
    }
       public StringProperty item_nameProperty() {
        return item_name2 ;
    }
      public IntegerProperty retail_priceProperty() {
        return retail_price2 ;
    }
       public StringProperty barcodeProperty() {
        return barcode2 ;
    }
      

}
