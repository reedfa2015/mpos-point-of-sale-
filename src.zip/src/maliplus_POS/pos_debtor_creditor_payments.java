/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXDialog;
import com.jfoenix.controls.JFXRadioButton;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.Spinner;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.util.Callback;
//import javax.swing.event.ChangeListener;
import maliplus.DBConnection;
import static maliplus_POS.Pos_Controller.stage2;
import org.controlsfx.control.MaskerPane;

/**
 * FXML Controller class
 *
 * @author PSL-STUFF
 */
public class pos_debtor_creditor_payments implements Initializable {
    
   static Connection conn = null;
    static ResultSet rs = null;
    static PreparedStatement pst = null;
    
       @FXML
    private ScrollPane pos_debtor_payments_root;
    
    @FXML
    private TabPane tabPane_tabpane;
    @FXML
    private JFXTextField customer_no_txtf;

    @FXML
    private JFXTextField customer_name_txtf;

    @FXML
    private JFXTextField document_number_txtf;

    @FXML
    private Spinner<?> amount_balance_spinner;

    @FXML
    private Label description_lbl;
    
    @FXML
    private Label display_message_lbl;

    @FXML
    private JFXTextField description_txtf;

    @FXML
    private Label edit_lbl;

    @FXML
    private Label bank_lbl;

    @FXML
    private JFXTextField bank_txtf;

    @FXML
    private DatePicker transaction_date_dtPicker;

    @FXML
    private JFXRadioButton credit_rdbtn;

    @FXML
    private JFXTextField type_txtf;

    @FXML
    private JFXTextField reference_doc_txtf;

    @FXML
    private JFXTextField match_document_txtf;

    @FXML
    private Label match_document_lbl;

    @FXML
    private JFXTextField ref_type_txtf;

    @FXML
    private Label ref_type_lbl;

    @FXML
    private JFXTextField match_ref_type_txtf;

    @FXML
    private Label match_ref_type_lbl;

    @FXML
    private JFXButton insert_btn;

    @FXML
    private JFXButton save_btn;

    @FXML
    private JFXButton delete_btn;

    @FXML
    private JFXButton print_preview_btn;

    @FXML
    private JFXButton export_btn;

    @FXML
    private JFXButton approve_post_btn;

    @FXML
    private JFXButton customized_stock_result_btn;

    @FXML
    private JFXButton find_items_btn;

    @FXML
    private JFXButton refresh_btn;

    @FXML
    private JFXButton clear_btn;

    @FXML
    private JFXButton item_notes_btn;

    @FXML
    private JFXButton back_btn;
    
    @FXML
    private JFXRadioButton debit_rdbtn;
    @FXML
    private Label change_name_lbl;

    @FXML
    private JFXDialog display_message_dgBox;

    @FXML
    private Tab debtor_table_tab;

    @FXML
    private TableView<pos_debtor_payment_table> debtor_tb;

    @FXML
    private TableColumn<pos_debtor_payment_table, Boolean> select_doc_tbn;

    @FXML
    private TableColumn<pos_debtor_payment_table, String> document_number_tbn;

    @FXML
    private TableColumn<pos_debtor_payment_table, String> document_type_tbn;

    @FXML
    private TableColumn<pos_debtor_payment_table, String> document_date_tbn;

    @FXML
    private TableColumn<pos_debtor_payment_table, String> due_date_tbn;

    @FXML
    private TableColumn<pos_debtor_payment_table, Number> amount_tbn;

    @FXML
    private TableColumn<pos_debtor_payment_table, String> paid_amount_tbn;

    @FXML
    private TableColumn<pos_debtor_payment_table, Number> balance_tbn;

    @FXML
    private TableColumn<pos_debtor_payment_table, String> description_tbn;

    @FXML
    private TableColumn<pos_debtor_payment_table, String> reference_tbn;

    @FXML
    private TableColumn<pos_debtor_payment_table, String> rtyp_tbn;

    @FXML
    private TableColumn<pos_debtor_payment_table, String> cat_tbn;

    @FXML
    private TableColumn<pos_debtor_payment_table, String> apv_tbn;

    @FXML
    private TableColumn<pos_debtor_payment_table, String> matched_number_tbn;

    @FXML
    private TableColumn<pos_debtor_payment_table, String> mtyp_tbn;

    @FXML
    private TableColumn<pos_debtor_payment_table, String> cmp_tbn;

    @FXML
    private Tab creditor_table_tab;

    @FXML
    private TableView<pos_debtor_payment_table> creditor_tb;

    @FXML
    private TableColumn<pos_debtor_payment_table, Boolean> select_doc_tbn2;

    @FXML
    private TableColumn<pos_debtor_payment_table, String> document_number_tbn2;

    @FXML
    private TableColumn<pos_debtor_payment_table, String> document_type_tbn2;

    @FXML
    private TableColumn<pos_debtor_payment_table, String> document_date_tbn2;

    @FXML
    private TableColumn<pos_debtor_payment_table, String> due_date_tbn2;

    @FXML
    private TableColumn<pos_debtor_payment_table, Number> amount_tbn2;

    @FXML
    private TableColumn<pos_debtor_payment_table, String> paid_amount_tbn2;

    @FXML
    private TableColumn<pos_debtor_payment_table, Number> balance_tbn2;

    @FXML
    private TableColumn<pos_debtor_payment_table, String> description_tbn2;

    @FXML
    private TableColumn<pos_debtor_payment_table, String> reference_tbn2;

    @FXML
    private TableColumn<pos_debtor_payment_table, String> rtyp_tbn2;

    @FXML
    private TableColumn<pos_debtor_payment_table, String> cat_tbn2;

    @FXML
    private TableColumn<pos_debtor_payment_table, String> apv_tbn2;

    @FXML
    private TableColumn<pos_debtor_payment_table, String> matched_number_tbn2;

    @FXML
    private TableColumn<pos_debtor_payment_table, String> mtyp_tbn2;

    @FXML
    private TableColumn<pos_debtor_payment_table, String> cmp_tbn2;

    @FXML
    private JFXRadioButton debtor_payments_rdbtn;

    @FXML
    private JFXRadioButton creditor_payments_rdbtn;
    
    @FXML
    private MaskerPane masker;
    
    class BooleanCell extends TableCell<pos_debtor_payment_table, Boolean> {
        private JFXCheckBox checkBox;
        public BooleanCell() {
            checkBox = new JFXCheckBox();
            checkBox.setDisable(true);
            checkBox.selectedProperty().addListener(new ChangeListener<Boolean> () {
                public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
                    if(isEditing())
                        commitEdit(newValue == null ? false : newValue);
                }
            });
            this.setGraphic(checkBox);
            this.setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            this.setEditable(true);
        }
        @Override
        public void startEdit() {
            super.startEdit();
            if (isEmpty()) {
                return;
            }
            checkBox.setDisable(false);
            checkBox.requestFocus();
        }
        @Override
        public void cancelEdit() {
            super.cancelEdit();
            checkBox.setDisable(false);
        }
        public void commitEdit(Boolean value) {
            super.commitEdit(value);
            checkBox.setDisable(false);
        }
        @Override
        public void updateItem(Boolean item, boolean empty) {
            super.updateItem(item, empty);
            if (!isEmpty()) {
//                checkBox.setSelected(item);
            }
        }
    }

        final ObservableList<pos_debtor_payment_table> data2= FXCollections.observableArrayList();
           public  void loadDebtorDetailstable(){
               String sql="Select * from DEBTORS_LEDGER WHERE LEDGER_NUMBER="+customer_no_txtf.getText()+"";
               conn=DBConnection.ConnectDB();
          
                        try{
                       pst=conn.prepareStatement(sql);
                       rs= pst.executeQuery();
                       while(rs.next()){
                           double difference=0.0;
                           difference=rs.getDouble("AMOUNT")-rs.getDouble("PAID_AMOUNT");
                           data2.add(new pos_debtor_payment_table(
                           rs.getString("DOCUMENT_NUMBER"),
                           rs.getString("DOCUMENT_TYPE"),
                           rs.getString("DOCUMENT_DATE"),
                           rs.getString("DUE_DATE"),
                           rs.getDouble("AMOUNT"),
                           rs.getString("PAID_AMOUNT"),
                           difference,
                           rs.getString("DESCRIPTION"),
                           rs.getString("REFERENCE_NUMBER"),
                           rs.getString("REFERENCE_TYPE"),
                           rs.getString("CATEGORY"),
                           rs.getString("APPROVED"),
                           rs.getString("MATCHED_NUMBER"),
                           rs.getString("MATCHED_TYPE"),
                           rs.getString("CHECK_OPTION")        
                           ));
        document_number_tbn.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, String> cellData) -> {
            return cellData.getValue().document_numberProperty();
     
        });
        document_type_tbn.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, String> cellData) -> {
            return cellData.getValue().document_typeProperty();
     
            
        });
        document_date_tbn.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, String> cellData) -> {
            return cellData.getValue().document_dateProperty();
     
        });
       due_date_tbn.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, String> cellData) -> {
            return cellData.getValue().due_dateProperty();
     
        });
        amount_tbn.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, Number> cellData) -> {
            return cellData.getValue().amountProperty();
     
        });
        paid_amount_tbn.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, String> cellData) -> {
            return cellData.getValue().paid_amountProperty();
     
        });
        balance_tbn.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, Number> cellData) -> {
            return cellData.getValue().balanceProperty();
     
        });
        description_tbn.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, String> cellData) -> {
            return cellData.getValue().descriptionProperty();
     
        });
        reference_tbn.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, String> cellData) -> {
            return cellData.getValue().referenceProperty();
     
        });
        rtyp_tbn.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, String> cellData) -> {
            return cellData.getValue().reference_typeProperty();
     
        });
        cat_tbn.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, String> cellData) -> {
            return cellData.getValue().categoryProperty();
     
        });
        apv_tbn.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, String> cellData) -> {
            return cellData.getValue().approvedProperty();
     
        });
        matched_number_tbn.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, String> cellData) -> {
            return cellData.getValue().matched_numberProperty();
     
        });
       mtyp_tbn.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, String> cellData) -> {
            return cellData.getValue().matched_typeProperty();
     
        });
       cmp_tbn.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, String> cellData) -> {
            return cellData.getValue().check_optionProperty();
     
        });
       
Callback<TableColumn<pos_debtor_payment_table, Boolean>, TableCell<pos_debtor_payment_table, Boolean>> booleanCellFactory = 
            new Callback<TableColumn<pos_debtor_payment_table, Boolean>, TableCell<pos_debtor_payment_table, Boolean>>() {
            @Override
                public TableCell<pos_debtor_payment_table, Boolean> call(TableColumn<pos_debtor_payment_table, Boolean> p) {
                    return new BooleanCell();
            }
        };
//        select_doc_tbn.setCellValueFactory(new PropertyValueFactory<>("active"));
        select_doc_tbn.setCellFactory(booleanCellFactory);


              
       
       
      
      
        
        

     
       // item_code.setStyle("-fx-control-inner-background: yellow;");
       // item_code.setStyle("-fx-text-fill: red;");
       // item_description.setStyle("-fx-text-fill: green;");
       // quantity.setStyle("-fx-text-fill: blue;");
       // sales_price.setStyle("-fx-text-fill: orange;");
       // sales_amount.setStyle("-fx-text-fill: purple;");
       // discount.setStyle("-fx-text-fill: red;");
       // taxable.setStyle("-fx-text-fill: violet;");
       // tax_amount.setStyle("-fx-text-fill: blue;");
       // item_location.setStyle("-fx-text-fill: grey;");
       // display.setStyle(" -fx-font-size: 14px;");
       
  
                           debtor_tb.setItems(data2);
                       }
                        }
                        catch(Exception e){
                          e.printStackTrace();  
                        }
           }
           
               final ObservableList<pos_debtor_payment_table> data3= FXCollections.observableArrayList();
           public  void loadCreditorDetailstable(){
               String sql="Select * from CREDITORS_LEDGER WHERE LEDGER_NUMBER="+customer_no_txtf.getText()+"";
               conn=DBConnection.ConnectDB();
          
                        try{
                       pst=conn.prepareStatement(sql);
                       rs= pst.executeQuery();
                       while(rs.next()){
                           double difference=0.0;
                           difference=rs.getDouble("AMOUNT")-rs.getDouble("PAID_AMOUNT");
                           data3.add(new pos_debtor_payment_table(
                           rs.getString("DOCUMENT_NUMBER"),
                           rs.getString("DOCUMENT_TYPE"),
                           rs.getString("DOCUMENT_DATE"),
                           rs.getString("DUE_DATE"),
                           rs.getDouble("AMOUNT"),
                           rs.getString("PAID_AMOUNT"),
                           difference,
                           rs.getString("DESCRIPTION"),
                           rs.getString("REFERENCE_NUMBER"),
                           rs.getString("REFERENCE_TYPE"),
                           rs.getString("CATEGORY"),
                           rs.getString("APPROVED"),
                           rs.getString("MATCHED_NUMBER"),
                           rs.getString("MATCHED_TYPE"),
                           rs.getString("CHECK_OPTION")        
                           ));
        document_number_tbn2.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, String> cellData) -> {
            return cellData.getValue().document_numberProperty();
     
        });
        document_type_tbn2.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, String> cellData) -> {
            return cellData.getValue().document_typeProperty();
     
            
        });
        document_date_tbn2.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, String> cellData) -> {
            return cellData.getValue().document_dateProperty();
     
        });
       due_date_tbn2.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, String> cellData) -> {
            return cellData.getValue().due_dateProperty();
     
        });
        amount_tbn2.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, Number> cellData) -> {
            return cellData.getValue().amountProperty();
     
        });
        paid_amount_tbn2.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, String> cellData) -> {
            return cellData.getValue().paid_amountProperty();
     
        });
        balance_tbn2.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, Number> cellData) -> {
            return cellData.getValue().balanceProperty();
     
        });
        description_tbn2.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, String> cellData) -> {
            return cellData.getValue().descriptionProperty();
     
        });
        reference_tbn2.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, String> cellData) -> {
            return cellData.getValue().referenceProperty();
     
        });
        rtyp_tbn2.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, String> cellData) -> {
            return cellData.getValue().reference_typeProperty();
     
        });
        cat_tbn2.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, String> cellData) -> {
            return cellData.getValue().categoryProperty();
     
        });
        apv_tbn2.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, String> cellData) -> {
            return cellData.getValue().approvedProperty();
     
        });
        matched_number_tbn2.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, String> cellData) -> {
            return cellData.getValue().matched_numberProperty();
     
        });
       mtyp_tbn2.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, String> cellData) -> {
            return cellData.getValue().matched_typeProperty();
     
        });
       cmp_tbn2.setCellValueFactory((TableColumn.CellDataFeatures<pos_debtor_payment_table, String> cellData) -> {
            return cellData.getValue().check_optionProperty();
     
        });
       
Callback<TableColumn<pos_debtor_payment_table, Boolean>, TableCell<pos_debtor_payment_table, Boolean>> booleanCellFactory = 
            new Callback<TableColumn<pos_debtor_payment_table, Boolean>, TableCell<pos_debtor_payment_table, Boolean>>() {
            @Override
                public TableCell<pos_debtor_payment_table, Boolean> call(TableColumn<pos_debtor_payment_table, Boolean> p) {
                    return new BooleanCell();
            }
        };
//        select_doc_tbn.setCellValueFactory(new PropertyValueFactory<>("active"));
        select_doc_tbn2.setCellFactory(booleanCellFactory);


              
       
       
      
      
        
        

     
       // item_code.setStyle("-fx-control-inner-background: yellow;");
       // item_code.setStyle("-fx-text-fill: red;");
       // item_description.setStyle("-fx-text-fill: green;");
       // quantity.setStyle("-fx-text-fill: blue;");
       // sales_price.setStyle("-fx-text-fill: orange;");
       // sales_amount.setStyle("-fx-text-fill: purple;");
       // discount.setStyle("-fx-text-fill: red;");
       // taxable.setStyle("-fx-text-fill: violet;");
       // tax_amount.setStyle("-fx-text-fill: blue;");
       // item_location.setStyle("-fx-text-fill: grey;");
       // display.setStyle(" -fx-font-size: 14px;");
       
  
                           creditor_tb.setItems(data3);
                       }
                        }
                        catch(Exception e){
                          e.printStackTrace();  
                        }
           }
             void calculateTotalSalesAmount(){
      try{
        double total = 0 ;
        if(debtor_payments_rdbtn.isSelected()==true){
           for (pos_debtor_payment_table item : debtor_tb.getItems()) {
          total = total + item.getbalance();   
         String s = NumberFormat.getNumberInstance().format(total);
          display_message_lbl.setText("BALANCE DUE:"+s+"");
          //total_sales_amount.setStyle("-fx-text-fill: blue;");
          /* if(total_sales_amount.getText()!=null){
          total_sales_amount.setStyle("-fx-text-fill: green;"
          + "-fx-font-size: 40px;");
          // total_sales_amount.setStyle("-fx-font-size: 40px;");
          }*/
          
                 } 
        }
        else
            if(creditor_payments_rdbtn.isSelected()==true){
               for (pos_debtor_payment_table item : creditor_tb.getItems()) {
          total = total + item.getbalance();   
         String s = NumberFormat.getNumberInstance().format(total);
          display_message_lbl.setText("BALANCE DUE:"+s+"");
          //total_sales_amount.setStyle("-fx-text-fill: blue;");
          /* if(total_sales_amount.getText()!=null){
          total_sales_amount.setStyle("-fx-text-fill: green;"
          + "-fx-font-size: 40px;");
          // total_sales_amount.setStyle("-fx-font-size: 40px;");
          }*/
          
                 }   
            }
            
      }
      catch(Exception e){
          e.printStackTrace();
      }
      
     
  }
           
           void loadDebtor_details(){
               customer_name_txtf.setText("");
               amount_balance_spinner.getEditor().setText("0.00");
               type_txtf.setText("");
               String getDebtor_details="Select CUSTOMERS.LEDGER_NAME,DEBTORS_LEDGER.DOCUMENT_TYPE from CUSTOMERS,DEBTORS_LEDGER WHERE CUSTOMERS.LEDGER_NUMBER='"+customer_no_txtf.getText()+"'";
               try{
                   conn=DBConnection.ConnectDB();
                   pst=conn.prepareStatement(getDebtor_details);
                   rs=pst.executeQuery();
                   while(rs.next()){
                      customer_name_txtf.setText(rs.getString("LEDGER_NAME"));
                      amount_balance_spinner.getEditor().setText("0.00");
                      type_txtf.setText(rs.getString("DOCUMENT_TYPE"));
                      //display_message_lbl.setText("BALANCE DUE:"+rs.getString("BALANCE")+"");
                      
                   }
               }
               catch(Exception e){
                   e.printStackTrace();
               }
           }
           
           void loadCreditor_details(){
                 customer_name_txtf.setText("");
               amount_balance_spinner.getEditor().setText("0.00");
               type_txtf.setText("");
               String getDebtor_details="Select SUPPLIERS.LEDGER_NAME,CREDITORS_LEDGER.DOCUMENT_TYPE from SUPPLIERS,CREDITORS_LEDGER WHERE SUPPLIERS.LEDGER_NUMBER='"+customer_no_txtf.getText()+"'";
               try{
                   conn=DBConnection.ConnectDB();
                   pst=conn.prepareStatement(getDebtor_details);
                   rs=pst.executeQuery();
                   while(rs.next()){
                      customer_name_txtf.setText(rs.getString("LEDGER_NAME"));
                      amount_balance_spinner.getEditor().setText("0.00");
                      type_txtf.setText(rs.getString("DOCUMENT_TYPE"));
                      //display_message_lbl.setText("BALANCE DUE:"+rs.getString("BALANCE")+"");
                      
                   }
               }
               catch(Exception e){
                   e.printStackTrace();
               }
           }
                void showCurrentDateonload(){
        //DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyyy");
        /*TextField date = sale_date.getEditor();
        formatter.format(date);*/
       Date ref_date = new Date();
        SimpleDateFormat formatter2 = new SimpleDateFormat("MM-dd-yyyy");
          String ref = formatter2.format(ref_date);
     //   System.out.println(String.valueOf(ref));
        
      String dateValue = ""+ref+"";
      //  sale_date.setValue(LocalDate.parse(ref,formatter));
       
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
      
          transaction_date_dtPicker.setValue(LocalDate.parse(dateValue,formatter));
      // SimpleDateFormat format = new SimpleDateFormat("MMM dd, yyyy");
     //  setText(format.format(date));
    
    
      
/* try{
sale_date.getEditor().setText(dateFormat.format(date));
}
catch(Exception e){
e.printStackTrace();
}*/
    }
                
                   void loadDescriptionDetailsStage(String desc_name,int xx,int yy,String title,JFXTextField textfield) throws IOException{
         Scene scene3; 
             Stage  stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_type Controller = new pos_type();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_type_details.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 Parent root3 = loader.load();
                 String x="DESCRIPTION";
                 String y="MINOR_CODE";
                 String sub_code = "###";
                 String sql = "select minor_code,description from list_control where reference_code='"+desc_name+"' AND sub_code='"+sub_code+"'";
                 loader.<pos_type>getController().loadtypesDetailstable(sql, x, y);
                 scene3 = new Scene(root3);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("'"+title+"'");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(xx);
                 stage2.setY(yy);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();ca
               stage2.showAndWait();

              String result = loader.<pos_type>getController().getResult2();
          
                if (result != null) {
        // if a result was selected, add it to the list
                 // textfield.setText(result);
                 loadMaskerPane7(textfield,result);
                 // ledger_name3.setText(result2);
         }
    }
                   
                      void loadtypeDetailsStage(JFXTextField textfield,int xx, int yy) throws IOException{
         Scene scene3; 
             Stage  stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_type Controller = new pos_type();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_type_details.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 Parent root3 = loader.load();
                 String x="DESCRIPTION";
                 String y="MINOR_CODE";
                 String pos_types= "DOCUMENT_TYPES";
                 String sub_code = "###";
                 String sql = "select minor_code,description from list_control where reference_code='"+pos_types+"' AND sub_code='"+sub_code+"'";
                 loader.<pos_type>getController().loadtypesDetailstable(sql, x, y);
                 scene3 = new Scene(root3);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("TYPE");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(xx);
                 stage2.setY(yy);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();ca
               stage2.showAndWait();

              String result = loader.<pos_type>getController().getResult();
          
                if (result != null) {
        // if a result was selected, add it to the list
                  textfield.setText(result);
                  //type_txtf.requestFocus();
                 // ledger_name3.setText(result2);
         }
    }
                      
                      /*  void switchdebtor_creditorRadioButtons(){
                      if(debtor_payments_rdbtn.isSelected()==true){
                      creditor_payments_rdbtn.setSelected(false);
                      debtor_table_tab.setDisable(false);
                      creditor_table_tab.setDisable(true);
                      }
                      else
                      if(creditor_payments_rdbtn.isSelected()==true){
                      debtor_payments_rdbtn.setSelected(false);
                      creditor_table_tab.setDisable(false);
                      debtor_table_tab.setDisable(true);
                      }
                      } */   
                      
     void clearFields(){
          customer_no_txtf.setText("");
                     type_txtf.setText("");
                     document_number_txtf.setText("");
                     bank_txtf.setText("");
                     amount_balance_spinner.getEditor().setText("0.00");
                     description_txtf.setText("");
                     ref_type_txtf.setText("");
                     reference_doc_txtf.setText("");
                     match_document_txtf.setText("");
                     match_ref_type_txtf.setText("");
                     customer_name_txtf.setText("");
                     
     } 
     void loadMaskerPane(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                   mouseClickeddebtorTable();
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
     }
     
   
     
     
     void loadMaskerPane3(String result,String result2){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                    try{
                    loadSupplierdetails(result,result2);  
                    }
                    catch(Exception e){
                        e.printStackTrace();
                    }
                 
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
     }
     
      void loadMaskerPane4(String result,String result2){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                    try{
                    loadCustomerDetails(result,result2);  
                    }
                    catch(Exception e){
                        e.printStackTrace();
                    }
                 
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
     }
     
      void loadMaskerPane5(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                    try{
                    loadDebtor_details(); 
                    }
                    catch(Exception e){
                        e.printStackTrace();
                    }
                 
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
     }
      
         void loadMaskerPane6(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                    try{
                    loadCreditor_details(); 
                    }
                    catch(Exception e){
                        e.printStackTrace();
                    }
                 
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
     }
     
              void loadMaskerPane7(JFXTextField textfield,String result){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                    try{
                          textfield.setText(result);
                  
                    }
                    catch(Exception e){
                        e.printStackTrace();
                    }
                 
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
     }
          
       void loadMaskerPane2(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                   debtor_table_tab.setStyle("-fx-text-fill: white;");
        creditor_table_tab.setStyle("-fx-text-fill: white;");
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
     }
    @FXML
    void actionPerformed(ActionEvent event) throws IOException{
        if(event.getSource()==customer_no_txtf){
            if(debtor_payments_rdbtn.isSelected()==true){
             data2.removeAll(data2);
           // display_message_lbl.setText("");
           // customer_name_txtf.setText("");
          //  type_txtf.setText("");
            loadDebtorDetailstable();
            loadMaskerPane5();
            showCurrentDateonload();
            calculateTotalSalesAmount(); 
           // clearFields();
            }
            else
                if(creditor_payments_rdbtn.isSelected()==true){
                  data3.removeAll(data3);
           // display_message_lbl.setText("");
          //  customer_name_txtf.setText("");
          //  type_txtf.setText("");
            loadCreditorDetailstable();
            loadMaskerPane6();
            showCurrentDateonload();
            calculateTotalSalesAmount(); 
            //clearFields();  
                }
                                  


        }
        else
            if(event.getSource()==debtor_payments_rdbtn){
                if(debtor_payments_rdbtn.isSelected()==true){
                  creditor_payments_rdbtn.setSelected(false);
                  debtor_table_tab.setDisable(false);
                  creditor_table_tab.setDisable(true);
                  tabPane_tabpane.getSelectionModel().select(0);
                  showCurrentDateonload();
                  change_name_lbl.setText("");
                  change_name_lbl.setText("Customer Number");
                  clearFields();
                 // loadCreditor_details();
                  data2.removeAll(data2);
                          
              }
                else
                {
                     creditor_payments_rdbtn.setSelected(true);
                     debtor_payments_rdbtn.setSelected(false);
                     creditor_table_tab.setDisable(false);
                     debtor_table_tab.setDisable(true); 
                     tabPane_tabpane.getSelectionModel().select(1);
                     showCurrentDateonload();
                     change_name_lbl.setText("");
                     change_name_lbl.setText("Supplier Number");
                     clearFields();
                     data3.removeAll(data3); 
                }
            }
        else
                if(event.getSource()==creditor_payments_rdbtn){
                     if(creditor_payments_rdbtn.isSelected()==true){
                     debtor_payments_rdbtn.setSelected(false);
                     creditor_table_tab.setDisable(false);
                     debtor_table_tab.setDisable(true); 
                     tabPane_tabpane.getSelectionModel().select(1);
                     showCurrentDateonload();
                     change_name_lbl.setText("");
                     change_name_lbl.setText("Supplier Number");
                     clearFields();
                     data3.removeAll(data3);
                     
                  }
                     else{
                         debtor_payments_rdbtn.setSelected(true);
                          creditor_payments_rdbtn.setSelected(false);
                  debtor_table_tab.setDisable(false);
                  creditor_table_tab.setDisable(true);
                  tabPane_tabpane.getSelectionModel().select(0);
                  showCurrentDateonload();
                  change_name_lbl.setText("");
                  change_name_lbl.setText("Customer Number");
                  clearFields();
                 // loadCreditor_details();
                  data2.removeAll(data2);
                     }
                }
        switchBetweenCreditandDebitradioButtons(debit_rdbtn,credit_rdbtn,event);
       
    }
    
    final KeyCombination keyComb1 = new KeyCodeCombination(KeyCode.F,KeyCombination.CONTROL_ANY);
    @FXML
      void keyReleasedhandle(KeyEvent event) {
       if(event.getSource()== pos_debtor_payments_root){
           if (keyComb1.match(event)){
               if(debtor_payments_rdbtn.isSelected()==true){
            
                   try {
                       loadCustomerDetailsStage();
                   } catch (IOException ex) {
                       Logger.getLogger(pos_debtor_creditor_payments.class.getName()).log(Level.SEVERE, null, ex);
                   }
               } /*else{
               try {
               loadSupplierDetailsStage();
               } catch (IOException ex) {
               Logger.getLogger(pos_stock_adjustment_initial.class.getName()).log(Level.SEVERE, null, ex);
               }
               } */
               
               if(creditor_payments_rdbtn.isSelected()==true){
                try {
        loadSupplierDetailsStage();
        } catch (IOException ex) {
        Logger.getLogger(pos_stock_adjustment_initial.class.getName()).log(Level.SEVERE, null, ex);
        }   
               }
               /*   else{
               try {
               loadCustomerDetailsStage();
               } catch (IOException ex) {
               Logger.getLogger(pos_stock_adjustment_initial.class.getName()).log(Level.SEVERE, null, ex);
               }
               }*/
           }
           
            
          /* else
          if (keyComb2.match(event)) {
          stock_adjustment_Root.getScene().getWindow().hide();
          }*/
       }
        
    }
    
           void loadCustomerDetailsStage() throws IOException{
        Scene scene3; 
               stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_customers Controller = new pos_customers();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_customers.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 Parent root3 = loader.load();
                 scene3 = new Scene(root3);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("MALIPLUS:CASH SALES");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(50);
                 stage2.setY(50);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();
               stage2.showAndWait();

              String result = loader.<pos_customers>getController().getResult();
              String result2= loader.<pos_customers>getController().getResult2();
              String result3= loader.<pos_customers>getController().getResult3();
              String result4=loader.<pos_customers>getController().getResult4();
             
                if (result != null) {
        // if a result was selected, add it to the list
                  loadMaskerPane4(result,result2);
                  /* if(result4 !=null){
                  try{
                  conn=DBConnection.ConnectDB();
                  pst=conn.prepareStatement(result4);
                  rs=pst.executeQuery();
                  while(rs.next()){
                  rs.getString("ORDER_NUMBER");
                  order_no.setText(rs.getString("ORDER_NUMBER"));
                  }
                  }
                  catch(Exception e){
                  e.printStackTrace();
                  }
                  }*/
                  if(result3 !=null){
                      /*                try{
                      conn=DBConnection.ConnectDB();
                      pst=conn.prepareStatement(result3);
                      rs= pst.executeQuery();
                      while(rs.next()){
                      
                      
                      
                      item_code.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, String> cellData) -> {
                      return cellData.getValue().item_codeProperty();
                      
                      });
                      
                      item_description.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, String> cellData) -> {
                      return cellData.getValue().item_descriptionProperty();
                      });
                      quantity.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                      return cellData.getValue().quantityProperty();
                      });
                      sales_price.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                      return cellData.getValue().sales_priceProperty();
                      });
                      sales_amount.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                      return cellData.getValue().sales_amountProperty();
                      });
                      discount.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                      return cellData.getValue().discountProperty();
                      });
                      taxable.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                      return cellData.getValue().taxableProperty();
                      });
                      tax_amount.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                      return cellData.getValue().tax_amountProperty();
                      });
                      item_location.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, String> cellData) -> {
                      return cellData.getValue().item_locationProperty();
                      });
                      
                      // pos_table.setItems(data);
                      
                      
                      
                      
                      
                      
                      item_description.setCellFactory(column -> {
                      return new TableCell<pos_details, String>() {
                      @Override
                      protected void updateItem(String item, boolean empty) {
                      super.updateItem(item, empty); //This is mandatory
                      
                      if (item == null || empty) { //If the cell is empty
                      setText(null);
                      setStyle("");
                      } else { //If the cell is not empty
                      
                      setText(item); //Put the String data in the cell
                      
                      //We get here all the info of the Person of this row
                      pos_details item_description2 = getTableView().getItems().get(getIndex());
                      
                      
                      
                      try{
                      if (item_description2.getITEM_DESCRIPTION().isEmpty()==false) {
                      setTextFill(Color.BLACK); //The text in red
                      setStyle("-fx-background-color:PALEGREEN"); //The background of the cell in yellow
                      
                      // pos_table.setItems(data);
                      // data.removeAll(data);
                      // pos_table.setItems(data);
                      
                      }   else {
                      //Here I see if the row of this cell is selected or not
                      if(getTableView().getSelectionModel().getSelectedItems().contains(item_description2))
                      setTextFill(Color.WHITE);
                      else
                      setTextFill(Color.BLACK);
                      }
                      
                      }
                      catch(Exception e){
                      e.printStackTrace();
                      }
                      
                      
                      }
                      }
                      };
                      });
                      quantity.setCellFactory(TableColumn ->{
                      return new TableCell<pos_details, Number>() {
                      @Override
                      protected void updateItem(Number item, boolean empty) {
                      super.updateItem(item, empty); //This is mandatory
                      
                      if (item == null || empty) { //If the cell is empty
                      setText(null);
                      setStyle("");
                      } else { //If the cell is not empty
                      
                      setText(String.valueOf(item)); //Put the String data in the cell
                      
                      //We get here all the info of the Person of this row
                      pos_details quantity2 = getTableView().getItems().get(getIndex());
                      
                      
                      try{
                      if (quantity2.getITEM_CODE().isEmpty()==false) {
                      setTextFill(Color.WHITE); //The text in red
                      setStyle("-fx-background-color: BLUE"); //The background of the cell in yellow
                      
                      }   else {
                      //Here I see if the row of this cell is selected or not
                      if(getTableView().getSelectionModel().getSelectedItems().contains(quantity2))
                      setTextFill(Color.WHITE);
                      else
                      setTextFill(Color.BLACK);
                      }
                      
                      
                      }
                      catch(Exception e){
                      e.printStackTrace();
                      }
                      
                      
                      }
                      }
                      };
                      });
                      
                      sales_amount.setCellFactory(TableColumn2 ->{
                      return new TableCell<pos_details, Number>() {
                      @Override
                      protected void updateItem(Number item2, boolean empty) {
                      super.updateItem(item2, empty); //This is mandatory
                      
                      if (item2 == null || empty) { //If the cell is empty
                      setText(null);
                      setStyle("");
                      } else { //If the cell is not empty
                      
                      setText(String.valueOf(item2)); //Put the String data in the cell
                      
                      //We get here all the info of the Person of this row
                      pos_details sales_amount2 = getTableView().getItems().get(getIndex());
                      
                      
                      try{
                      if (sales_amount2.getITEM_CODE().isEmpty()==false) {
                      setTextFill(Color.WHITE); //The text in red
                      setStyle("-fx-background-color: PURPLE"); //The background of the cell in yellow
                      
                      }   else {
                      //Here I see if the row of this cell is selected or not
                      if(getTableView().getSelectionModel().getSelectedItems().contains(sales_amount2))
                      setTextFill(Color.WHITE);
                      else
                      setTextFill(Color.BLACK);
                      }
                      
                      
                      }
                      catch(Exception e){
                      e.printStackTrace();
                      }
                      
                      
                      }
                      }
                      };
                      });
                      
                      //   if(pos_table.getSelectionModel().isEmpty()==true){
                      //      pos_table.setItems(data);
                      //  }
                      
                      
                      
                      
                      //else{
                      // pos_table.setEditable(true);le
                      
                      
                      //pos_table.setItems(data);
                      //  pos_table.setItems(data);
                      //}
                      // pos_table.setEditable(true);
                      
                      }
                      
                      
                      //  data.removeAll(data);
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      }
                      catch(Exception e){
                      // e.printStackTrace();
                      }*/    
                  }
                  
             
            
        
         }
                
    }
           void loadSupplierdetails(String result,String result2){
               customer_no_txtf.setText(result);
                  customer_name_txtf.setText(result2);
                  data3.removeAll(data3);
           // display_message_lbl.setText("");
          //  customer_name_txtf.setText("");
          //  type_txtf.setText("");
            loadCreditorDetailstable();
            loadCreditor_details();
            showCurrentDateonload();
            calculateTotalSalesAmount(); 
           }
           
           
           void loadCustomerDetails(String result, String result2){
                customer_no_txtf.setText(result);
                  customer_name_txtf.setText(result2);
                  data2.removeAll(data2);
           // display_message_lbl.setText("");
           // customer_name_txtf.setText("");
          //  type_txtf.setText("");
            loadDebtorDetailstable();
            loadDebtor_details();
            showCurrentDateonload();
            calculateTotalSalesAmount();
           }
               void loadSupplierDetailsStage() throws IOException{
        Scene scene3; 
               stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_creditor_suppliers Controller = new pos_creditor_suppliers();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_customers.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 Parent root3 = loader.load();
                 scene3 = new Scene(root3);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("MALIPLUS:CASH SALES");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(50);
                 stage2.setY(50);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();
               stage2.showAndWait();

              String result = loader.<pos_creditor_suppliers>getController().getResult();
              String result2= loader.<pos_creditor_suppliers>getController().getResult2();
              String result3= loader.<pos_creditor_suppliers>getController().getResult3();
              String result4=loader.<pos_creditor_suppliers>getController().getResult4();
             
                if (result != null) {
        // if a result was selected, add it to the list
                 loadMaskerPane3(result,result2);
                  /* if(result4 !=null){
                  try{
                  conn=DBConnection.ConnectDB();
                  pst=conn.prepareStatement(result4);
                  rs=pst.executeQuery();
                  while(rs.next()){
                  rs.getString("ORDER_NUMBER");
                  order_no.setText(rs.getString("ORDER_NUMBER"));
                  }
                  }
                  catch(Exception e){
                  e.printStackTrace();
                  }
                  }*/
                  if(result3 !=null){
                      /*                try{
                      conn=DBConnection.ConnectDB();
                      pst=conn.prepareStatement(result3);
                      rs= pst.executeQuery();
                      while(rs.next()){
                      
                      
                      
                      item_code.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, String> cellData) -> {
                      return cellData.getValue().item_codeProperty();
                      
                      });
                      
                      item_description.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, String> cellData) -> {
                      return cellData.getValue().item_descriptionProperty();
                      });
                      quantity.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                      return cellData.getValue().quantityProperty();
                      });
                      sales_price.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                      return cellData.getValue().sales_priceProperty();
                      });
                      sales_amount.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                      return cellData.getValue().sales_amountProperty();
                      });
                      discount.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                      return cellData.getValue().discountProperty();
                      });
                      taxable.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                      return cellData.getValue().taxableProperty();
                      });
                      tax_amount.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, Number> cellData) -> {
                      return cellData.getValue().tax_amountProperty();
                      });
                      item_location.setCellValueFactory((TableColumn.CellDataFeatures<pos_details, String> cellData) -> {
                      return cellData.getValue().item_locationProperty();
                      });
                      
                      // pos_table.setItems(data);
                      
                      
                      
                      
                      
                      
                      item_description.setCellFactory(column -> {
                      return new TableCell<pos_details, String>() {
                      @Override
                      protected void updateItem(String item, boolean empty) {
                      super.updateItem(item, empty); //This is mandatory
                      
                      if (item == null || empty) { //If the cell is empty
                      setText(null);
                      setStyle("");
                      } else { //If the cell is not empty
                      
                      setText(item); //Put the String data in the cell
                      
                      //We get here all the info of the Person of this row
                      pos_details item_description2 = getTableView().getItems().get(getIndex());
                      
                      
                      
                      try{
                      if (item_description2.getITEM_DESCRIPTION().isEmpty()==false) {
                      setTextFill(Color.BLACK); //The text in red
                      setStyle("-fx-background-color:PALEGREEN"); //The background of the cell in yellow
                      
                      // pos_table.setItems(data);
                      // data.removeAll(data);
                      // pos_table.setItems(data);
                      
                      }   else {
                      //Here I see if the row of this cell is selected or not
                      if(getTableView().getSelectionModel().getSelectedItems().contains(item_description2))
                      setTextFill(Color.WHITE);
                      else
                      setTextFill(Color.BLACK);
                      }
                      
                      }
                      catch(Exception e){
                      e.printStackTrace();
                      }
                      
                      
                      }
                      }
                      };
                      });
                      quantity.setCellFactory(TableColumn ->{
                      return new TableCell<pos_details, Number>() {
                      @Override
                      protected void updateItem(Number item, boolean empty) {
                      super.updateItem(item, empty); //This is mandatory
                      
                      if (item == null || empty) { //If the cell is empty
                      setText(null);
                      setStyle("");
                      } else { //If the cell is not empty
                      
                      setText(String.valueOf(item)); //Put the String data in the cell
                      
                      //We get here all the info of the Person of this row
                      pos_details quantity2 = getTableView().getItems().get(getIndex());
                      
                      
                      try{
                      if (quantity2.getITEM_CODE().isEmpty()==false) {
                      setTextFill(Color.WHITE); //The text in red
                      setStyle("-fx-background-color: BLUE"); //The background of the cell in yellow
                      
                      }   else {
                      //Here I see if the row of this cell is selected or not
                      if(getTableView().getSelectionModel().getSelectedItems().contains(quantity2))
                      setTextFill(Color.WHITE);
                      else
                      setTextFill(Color.BLACK);
                      }
                      
                      
                      }
                      catch(Exception e){
                      e.printStackTrace();
                      }
                      
                      
                      }
                      }
                      };
                      });
                      
                      sales_amount.setCellFactory(TableColumn2 ->{
                      return new TableCell<pos_details, Number>() {
                      @Override
                      protected void updateItem(Number item2, boolean empty) {
                      super.updateItem(item2, empty); //This is mandatory
                      
                      if (item2 == null || empty) { //If the cell is empty
                      setText(null);
                      setStyle("");
                      } else { //If the cell is not empty
                      
                      setText(String.valueOf(item2)); //Put the String data in the cell
                      
                      //We get here all the info of the Person of this row
                      pos_details sales_amount2 = getTableView().getItems().get(getIndex());
                      
                      
                      try{
                      if (sales_amount2.getITEM_CODE().isEmpty()==false) {
                      setTextFill(Color.WHITE); //The text in red
                      setStyle("-fx-background-color: PURPLE"); //The background of the cell in yellow
                      
                      }   else {
                      //Here I see if the row of this cell is selected or not
                      if(getTableView().getSelectionModel().getSelectedItems().contains(sales_amount2))
                      setTextFill(Color.WHITE);
                      else
                      setTextFill(Color.BLACK);
                      }
                      
                      
                      }
                      catch(Exception e){
                      e.printStackTrace();
                      }
                      
                      
                      }
                      }
                      };
                      });
                      
                      //   if(pos_table.getSelectionModel().isEmpty()==true){
                      //      pos_table.setItems(data);
                      //  }
                      
                      
                      
                      
                      //else{
                      // pos_table.setEditable(true);le
                      
                      
                      //pos_table.setItems(data);
                      //  pos_table.setItems(data);
                      //}
                      // pos_table.setEditable(true);
                      
                      }
                      
                      
                      //  data.removeAll(data);
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      }
                      catch(Exception e){
                      // e.printStackTrace();
                      }*/    
                  }
                  
             
            
        
         }
                
    }
    void switchBetweenCreditandDebitradioButtons(JFXRadioButton button1,JFXRadioButton button2, ActionEvent event){
       if(event.getSource()==button1){
        if(button1.isSelected()==true){
            button2.setSelected(false);
        }
        else{
            button2.setSelected(true);
        }   
       }
       else
           if(event.getSource()==button2){
           if(button2.isSelected()==true){
            button1.setSelected(false);
        }
        else{
            button1.setSelected(true);
        }    
           }
        
        
        
    }
    @FXML
    void mouseClicked(MouseEvent event)  {
        if(event.getSource()==bank_lbl){
            try{
            loadDescriptionDetailsStage("BANKS",500,100,"BANKS",bank_txtf); 
            }
            catch(Exception e){
                e.printStackTrace();
            }
            
        }
        else
            if(event.getSource()==description_lbl){
            try{
              loadDescriptionDetailsStage("DEBTOR_TRANSACTIONS",200,150,"DESCRIPTION",description_txtf);  
            }
            catch(Exception e){
                e.printStackTrace();
            }
            
        }
        else
                if(event.getSource()==ref_type_lbl){
            try {
                loadtypeDetailsStage(ref_type_txtf,1000,50);
            } catch (IOException ex) {
                Logger.getLogger(pos_debtor_creditor_payments.class.getName()).log(Level.SEVERE, null, ex);
            }
                }
                else 
                    if(event.getSource()==match_ref_type_lbl){
            try {
                loadtypeDetailsStage(match_ref_type_txtf,1000,50);
            } catch (IOException ex) {
                Logger.getLogger(pos_debtor_creditor_payments.class.getName()).log(Level.SEVERE, null, ex);
            }
                }
    }
    /**
     * Initializes the controller class.
     */
    void onMouseClickedDebtorTable(){
          pos_debtor_payment_table selectedItem = debtor_tb.getSelectionModel().getSelectedItem();
        document_number_txtf.setText(selectedItem.getdocument_number());
        type_txtf.setText(selectedItem.getdocument_type());
        //transaction_date_dtPicker.getEditor().setText(selectedItem.getdocument_date());
        amount_balance_spinner.getEditor().setText(String.valueOf(selectedItem.getamount()));
        reference_doc_txtf.setText(selectedItem.getreference());
        ref_type_txtf.setText(selectedItem.getreference_type());
        match_document_txtf.setText(selectedItem.getmatched_number());
        match_ref_type_txtf.setText(selectedItem.getmatched_type());
        description_txtf.setText(selectedItem.getdescription());
        
       
       
        String sql="select  DOCUMENT_DATE from DEBTORS_LEDGER where DOCUMENT_NUMBER = '"+String.valueOf(selectedItem.getdocument_number())+"'";
Connection conn = DBConnection.ConnectDB();
try {
pst = conn.prepareStatement(sql);
rs = pst.executeQuery();
while (rs.next()) {
java.sql.Date check_status6 = rs.getDate("DOCUMENT_DATE");
//System.out.println(""+check_status6+"");
SimpleDateFormat formatter2 = new SimpleDateFormat("MM-dd-yyyy");
//formatter2.parse(check_status6);
String ref = formatter2.format(check_status6);




// System.out.println(String.valueOf(ref));

String dateValue = ""+ref+"";
//  sale_date.setValue(LocalDate.parse(ref,formatter));

DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
transaction_date_dtPicker.setValue(LocalDate.parse(dateValue,formatter));
}

}
catch(Exception e){
e.printStackTrace();
}


  

  
       
    }
    
       void onMouseClickedCreditorTable(){
          pos_debtor_payment_table selectedItem = creditor_tb.getSelectionModel().getSelectedItem();
        document_number_txtf.setText(selectedItem.getdocument_number());
        type_txtf.setText(selectedItem.getdocument_type());
        //transaction_date_dtPicker.getEditor().setText(selectedItem.getdocument_date());
        amount_balance_spinner.getEditor().setText(String.valueOf(selectedItem.getamount()));
        reference_doc_txtf.setText(selectedItem.getreference());
        ref_type_txtf.setText(selectedItem.getreference_type());
        match_document_txtf.setText(selectedItem.getmatched_number());
        match_ref_type_txtf.setText(selectedItem.getmatched_type());
        description_txtf.setText(selectedItem.getdescription());
        
       
       
        String sql="select  DOCUMENT_DATE from CREDITORS_LEDGER where DOCUMENT_NUMBER = '"+String.valueOf(selectedItem.getdocument_number())+"'";
Connection conn = DBConnection.ConnectDB();
try {
pst = conn.prepareStatement(sql);
rs = pst.executeQuery();
while (rs.next()) {
java.sql.Date check_status6 = rs.getDate("DOCUMENT_DATE");
//System.out.println(""+check_status6+"");
SimpleDateFormat formatter2 = new SimpleDateFormat("MM-dd-yyyy");
//formatter2.parse(check_status6);
String ref = formatter2.format(check_status6);




// System.out.println(String.valueOf(ref));

String dateValue = ""+ref+"";
//  sale_date.setValue(LocalDate.parse(ref,formatter));

DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
transaction_date_dtPicker.setValue(LocalDate.parse(dateValue,formatter));
}

}
catch(Exception e){
e.printStackTrace();
}


  

  
       
    }
    
    void calculateBalance(){
     try{
          for (pos_debtor_payment_table  item : debtor_tb.getItems()) {
   // ObservableList<pos_debtor_payment_table>  selecteditem =debtor_tb.getItems();
     double difference = item.getamount()-Double.parseDouble(item.getpaid_amount()); 
         System.out.println(difference);
         
      
              String update_balance="update debtors_ledger set balance='"+difference+"' where document_number='"+document_number_txtf.getText()+"'";
              
              try{
              conn=DBConnection.ConnectDB();
              pst=conn.prepareStatement(update_balance);
              pst.execute();
             // System.out.println("Record updated successfully");
              }
              catch(Exception e){
              e.printStackTrace();
              }
        // String s = NumberFormat.getNumberInstance().format(total);
        /*total_sales_amount.setText(s);
        //total_sales_amount.setStyle("-fx-text-fill: blue;");
        if(total_sales_amount.getText()!=null){
        total_sales_amount.setStyle("-fx-text-fill: green;"
        + "-fx-font-size: 40px;");
        // total_sales_amount.setStyle("-fx-font-size: 40px;");
        }*/
          
              }  
      }
      catch(Exception e){
          e.printStackTrace();
      }
      
     
  }
    
    void mouseClickeddebtorTable(){
                     try {
                      /* try{*/
                      // debtor_tb.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
                      /*  debtor_tb.getSelectionModel().setCellSelectionEnabled(true);
                      ObservableList<TablePosition> selectedCells = debtor_tb.getSelectionModel().getSelectedCells() ;
                      selectedCells.addListener((ListChangeListener.Change<? extends TablePosition> change) -> {
                      if (selectedCells.size() > 0) {
                      TablePosition selectedCell = selectedCells.get(0);
                      TableColumn column = selectedCell.getTableColumn();
                      int rowIndex = selectedCell.getRow();
                      //       Object data = column.getCellObservableValue(rowIndex).getValue();
                      //  System.out.println(data);
                      
                      String sql="select * from debtors_ledger";
                      try{
                      conn=DBConnection.ConnectDB();
                      pst=conn.prepareStatement(sql);
                      rs=pst.executeQuery();
                      while(rs.next()){
                      
                      }
                      }
                      catch(Exception e){
                      e.printStackTrace();
                      }
                      
                      
                      
                      
                      }
                      });*/
                      
                      paid_amount_tbn.setCellValueFactory(
                              new PropertyValueFactory<>(rs.getString("PAID_AMOUNT")));
                  } catch (SQLException ex) {
                     // Logger.getLogger(pos_debtor_creditor_payments.class.getName()).log(Level.SEVERE, null, ex);
                  }
              paid_amount_tbn.setCellFactory(TextFieldTableCell.forTableColumn());
              paid_amount_tbn.setOnEditCommit((CellEditEvent<pos_debtor_payment_table, String> t) -> {
              ((pos_debtor_payment_table) t.getTableView().getItems().get(
              t.getTablePosition().getRow())
              ).SetPAID_AMOUNT(t.getNewValue());
              System.out.println(t.getNewValue());
              
              String update_paid_amount="Update  debtors_ledger set paid_amount='"+t.getNewValue()+"' where document_number='"+document_number_txtf.getText()+"'";
              
              try{
              conn=DBConnection.ConnectDB();
              pst=conn.prepareStatement(update_paid_amount);
              pst.execute();
              //calculateBalance();
              data2.removeAll(data2);
              loadDebtorDetailstable();
           //   calculateBalance();
             
              //data2.removeAll(data2);
              //loadDebtorDetailstable();
              }
              catch(Exception e){
              e.printStackTrace();
              }
              });
              
              
              /*  }
              catch(Exception e){
              //  e.printStackTrace();
              }*/
    }
      @FXML
    void onSelectItem(MouseEvent event) {
        if(event.getSource()==debtor_tb){
            
              int click = event.getClickCount();
              loadMaskerPane();
            if(click==1){
             onMouseClickedDebtorTable();   
            }
        }
        
        
        
             if(event.getSource()==creditor_tb){
            
              int click = event.getClickCount();
        
               if(click ==2){
                  try {
                      /* try{*/
                      // debtor_tb.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
                      /*  debtor_tb.getSelectionModel().setCellSelectionEnabled(true);
                      ObservableList<TablePosition> selectedCells = debtor_tb.getSelectionModel().getSelectedCells() ;
                      selectedCells.addListener((ListChangeListener.Change<? extends TablePosition> change) -> {
                      if (selectedCells.size() > 0) {
                      TablePosition selectedCell = selectedCells.get(0);
                      TableColumn column = selectedCell.getTableColumn();
                      int rowIndex = selectedCell.getRow();
                      //       Object data = column.getCellObservableValue(rowIndex).getValue();
                      //  System.out.println(data);
                      
                      String sql="select * from debtors_ledger";
                      try{
                      conn=DBConnection.ConnectDB();
                      pst=conn.prepareStatement(sql);
                      rs=pst.executeQuery();
                      while(rs.next()){
                      
                      }
                      }
                      catch(Exception e){
                      e.printStackTrace();
                      }
                      
                      
                      
                      
                      }
                      });*/
                      
                      paid_amount_tbn2.setCellValueFactory(
                              new PropertyValueFactory<>(rs.getString("PAID_AMOUNT")));
                  } catch (SQLException ex) {
                     // Logger.getLogger(pos_debtor_creditor_payments.class.getName()).log(Level.SEVERE, null, ex);
                  }
              paid_amount_tbn2.setCellFactory(TextFieldTableCell.forTableColumn());
              paid_amount_tbn2.setOnEditCommit((CellEditEvent<pos_debtor_payment_table, String> t) -> {
              ((pos_debtor_payment_table) t.getTableView().getItems().get(
              t.getTablePosition().getRow())
              ).SetPAID_AMOUNT(t.getNewValue());
              System.out.println(t.getNewValue());
              
              String update_paid_amount="Update  creditors_ledger set paid_amount='"+t.getNewValue()+"' where document_number='"+document_number_txtf.getText()+"'";
              
              try{
              conn=DBConnection.ConnectDB();
              pst=conn.prepareStatement(update_paid_amount);
              pst.execute();
              //calculateBalance();
              data3.removeAll(data3);
              loadCreditorDetailstable();
            //  calculateBalance();
             
              //data2.removeAll(data2);
              //loadDebtorDetailstable();
              }
              catch(Exception e){
              e.printStackTrace();
              }
              });
              
              
              /*  }
              catch(Exception e){
              //  e.printStackTrace();
              }*/
              
              }
              else
            if(click==1){
             onMouseClickedCreditorTable();   
            }
        }
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
       // loadDebtorDetailstable();
      loadMaskerPane2();
    }    
    
}
