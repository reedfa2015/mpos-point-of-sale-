/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDialog;
import com.jfoenix.controls.JFXTextField;
import java.awt.Toolkit;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.util.function.UnaryOperator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.concurrent.Task;
import javafx.embed.swing.JFXPanel;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextFormatter;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.util.converter.DoubleStringConverter;
import javafx.util.converter.IntegerStringConverter;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import maliplus.DBConnection;
import static maliplus_POS.pos_item_pack_types_controller.conn;
import static maliplus_POS.pos_item_pack_types_controller.frame;
import org.controlsfx.control.MaskerPane;
import org.controlsfx.control.Notifications;
/**
 *
 * @author PSL-STUFF
 */
public class pos_item_sub_group_settings_controller implements Initializable {
     static Connection conn = null;
    static ResultSet rs = null;
    static PreparedStatement pst = null;
  @FXML
    private AnchorPane item_types_settings_root;

    @FXML
    private JFXButton insert_btn;

    @FXML
    private JFXButton save_btn;

    @FXML
    private JFXButton delete_btn;

    @FXML
    private JFXButton print_preview_btn;

    @FXML
    private JFXButton export_btn;

    @FXML
    private JFXButton refresh_btn;

    @FXML
    private JFXButton clear_btn;

    @FXML
    private JFXButton back_btn;

    @FXML
    private JFXDialog display_message_dgBox;

    @FXML
    private JFXTextField list_txtf;

    @FXML
    private JFXTextField description_txtf;

    @FXML
    private JFXTextField key_word_txtf;

    @FXML
    private JFXTextField reference_txtf;

    @FXML
    private Spinner<Double> order_by_spinner;

    @FXML
    private JFXTextField search_txtf;

    @FXML
    private Label sub_group_item_lbl;

    @FXML
    private JFXTextField sub_group_item_txtf;

    @FXML
    private TableView<pos_item_sub_group_settings_table> item_types_tb;

    @FXML
    private TableColumn<pos_item_sub_group_settings_table, String> description_tbn;

    @FXML
    private TableColumn<pos_item_sub_group_settings_table, String> list_tbn;

    @FXML
    private TableColumn<pos_item_sub_group_settings_table, String> reference_code_tbn;

    @FXML
    private TableColumn<pos_item_sub_group_settings_table, String> key_word_tbn;

    @FXML
    private TableColumn<pos_item_sub_group_settings_table, Number> order_by_tbn;

    @FXML
    private TableColumn<pos_item_sub_group_settings_table, String> extend_control_tbn;

    @FXML
    private TableColumn<pos_item_sub_group_settings_table, String> date_modified_tbn;

    @FXML
    private TableColumn<pos_item_sub_group_settings_table, String> modified_by_tbn;

    @FXML
    private TableColumn<pos_item_sub_group_settings_table, String> reference_value_tbn;

    @FXML
    private TableColumn<pos_item_sub_group_settings_table, String> reference1_tbn;

    @FXML
    private TableColumn<pos_item_sub_group_settings_table, String> reference2_tbn;

    @FXML
    private TableColumn<pos_item_sub_group_settings_table, String> date_created_tbn;

    @FXML
    private TableColumn<pos_item_sub_group_settings_table, String> created_by_tbn;
    
    @FXML
    private MaskerPane masker;

    final ObservableList<pos_item_sub_group_settings_table> data= FXCollections.observableArrayList();
    void loadItemDetailsSettingsTable(String result2){
       conn=DBConnection.ConnectDB();
       String pos_types="ITEM_GROUPS";
       String sub_code="$$$";
       String extend_control="A";
       //String major_code="BVG";

       String sql="select * from list_control where LIST_CONTROL.REFERENCE_CODE='"+pos_types+"'  AND LIST_CONTROL.sub_code='"+sub_code+"' AND EXTEND_CONTROL='"+extend_control+"' AND MAJOR_CODE='"+result2+"'";
       try{
         pst=conn.prepareStatement(sql);
         rs=pst.executeQuery();
         while(rs.next()){
                data.add(new pos_item_sub_group_settings_table(
                           rs.getString("DESCRIPTION"),
                           rs.getString("MINOR_CODE"),
                           rs.getString("REFERENCE_CODE"),
                           rs.getString("DATA1"),
                           rs.getInt("SORT_ORDER"),
                           rs.getString("DATE_MODIFIED"),
                           rs.getString("MODIFIED_BY"),
                           rs.getString("REFERENCE1"),
                           rs.getString("REFERENCE2"),
                           rs.getString("DATE_CREATED"),
                           rs.getString("CREATED_BY")
                           ));
        description_tbn.setCellValueFactory((TableColumn.CellDataFeatures<pos_item_sub_group_settings_table, String> cellData) -> {
            return cellData.getValue().descriptionProperty();
     
        });
        list_tbn.setCellValueFactory((TableColumn.CellDataFeatures<pos_item_sub_group_settings_table, String> cellData) -> {
            return cellData.getValue().listProperty();
     
        });
        reference_code_tbn.setCellValueFactory((TableColumn.CellDataFeatures<pos_item_sub_group_settings_table, String> cellData) -> {
            return cellData.getValue().reference_codeProperty();
     
        });
        
        key_word_tbn.setCellValueFactory((TableColumn.CellDataFeatures<pos_item_sub_group_settings_table, String> cellData) -> {
            return cellData.getValue().textProperty();
     
        });
     
        order_by_tbn.setCellValueFactory((TableColumn.CellDataFeatures<pos_item_sub_group_settings_table, Number> cellData) -> {
            return cellData.getValue().sort_orderProperty();
     
        });
     
        date_modified_tbn.setCellValueFactory((TableColumn.CellDataFeatures<pos_item_sub_group_settings_table, String> cellData) -> {
            return cellData.getValue().date_modifiedProperty();
     
        });
        modified_by_tbn.setCellValueFactory((TableColumn.CellDataFeatures<pos_item_sub_group_settings_table, String> cellData) -> {
            return cellData.getValue().modified_byProperty();
     
        });
        reference1_tbn.setCellValueFactory((TableColumn.CellDataFeatures<pos_item_sub_group_settings_table, String> cellData) -> {
            return cellData.getValue().reference1Property();
     
        });
        reference2_tbn.setCellValueFactory((TableColumn.CellDataFeatures<pos_item_sub_group_settings_table, String> cellData) -> {
            return cellData.getValue().reference2Property();
     
        });
        date_created_tbn.setCellValueFactory((TableColumn.CellDataFeatures<pos_item_sub_group_settings_table, String> cellData) -> {
            return cellData.getValue().date_created2Property();
     
        });
        created_by_tbn.setCellValueFactory((TableColumn.CellDataFeatures<pos_item_sub_group_settings_table, String> cellData) -> {
            return cellData.getValue().created_by2Property();
     
        });
      
            
       
       
      
      
        
        

     
       // item_code.setStyle("-fx-control-inner-background: yellow;");
       // item_code.setStyle("-fx-text-fill: red;");
       // item_description.setStyle("-fx-text-fill: green;");
       // quantity.setStyle("-fx-text-fill: blue;");
       // sales_price.setStyle("-fx-text-fill: orange;");
       // sales_amount.setStyle("-fx-text-fill: purple;");
       // discount.setStyle("-fx-text-fill: red;");
       // taxable.setStyle("-fx-text-fill: violet;");
       // tax_amount.setStyle("-fx-text-fill: blue;");
       // item_location.setStyle("-fx-text-fill: grey;");
       // display.setStyle(" -fx-font-size: 14px;");
       
  
                          item_types_tb.setItems(data);
         }
       }
       catch(Exception e){
          e.printStackTrace();
       }
    }
    
      void loadtypeDetailsStage(String sql,String title,String x,String y,JFXTextField textfield,int a,int b) throws IOException{
         Scene scene3; 
             Stage  stage2 = new Stage();
              //String sql = "select minor_code,description from list_control where reference_code='"+pos_types+"' AND sub_code='"+sub_code+"'";
                
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_type Controller = new pos_type();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_type_details.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 Parent root3 = loader.load();
                // String x="DESCRIPTION";
                // String y="MINOR_CODE";
               //  String pos_types= "ITEM_TYPES";
                // String sub_code = "###";
                 loader.<pos_type>getController().loadtypesDetailstable(sql, x, y);
                 scene3 = new Scene(root3);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle(title);
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(a);
                 stage2.setY(b);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();ca
               stage2.showAndWait();

              String result = loader.<pos_type>getController().getResult2();
              String result2 = loader.<pos_type>getController().getResult();
                if (result != null) {
        // if a result was selected, add it to the list
                  textfield.setText(result);
                  loadMaskerPane2(result2);
                 // ledger_name3.setText(result2);
         }
    }
      
      void loadFirstSubgroupOption(){
           String pos_types="ITEM_GROUPS";
           String sub_code="###";
           String sql ="select DESCRIPTION,MINOR_CODE from list_control where REFERENCE_CODE='"+pos_types+"'  AND sub_code='"+sub_code+"'";
          try{
             pst=conn.prepareStatement(sql);
             rs=pst.executeQuery();
             
             while(rs.next()){
                 sub_group_item_txtf.setText(rs.getString("DESCRIPTION"));
                   data.removeAll(data);
                String result2=rs.getString("MINOR_CODE");
                    loadItemDetailsSettingsTable(result2);
                    
             }
          }
          catch(Exception e){
              //e.printStackTrace();
          }
      }
      
       void loadInsertintoTable_RefreshTable(){
           String pos_types="ITEM_GROUPS";
           String sub_code="###";
           String sql ="select MINOR_CODE from list_control where REFERENCE_CODE='"+pos_types+"'  AND sub_code='"+sub_code+"' and DESCRIPTION='"+sub_group_item_txtf.getText()+"'";
          try{
             pst=conn.prepareStatement(sql);
             rs=pst.executeQuery();
             
             while(rs.next()){
                 //sub_group_item_txtf.setText(rs.getString("DESCRIPTION"));
                   data.removeAll(data);
                String result2=rs.getString("MINOR_CODE");
                    loadItemDetailsSettingsTable(result2);
                    
             }
          }
          catch(Exception e){
              //e.printStackTrace();
          }
      }
           protected static final String INITIAL_VALUE = "0.0";
  
    
    NumberFormat format = NumberFormat.getIntegerInstance();
       UnaryOperator<TextFormatter.Change> filter = c -> {
    if (c.isContentChange()) {
        ParsePosition parsePosition = new ParsePosition(0);
        // NumberFormat evaluates the beginning of the text
        format.parse(c.getControlNewText(), parsePosition);
        if (parsePosition.getIndex() == 0 ||
                parsePosition.getIndex() < c.getControlNewText().length()) {
            // reject parsing the complete text failed
            return null;
        }
    }
    return c;
};
       void setSpinnerValue(Spinner<Double> spinner,double k){
        TextFormatter<Double> priceFormatter = new TextFormatter<Double>(
        new DoubleStringConverter(), k, filter);
        spinner.setValueFactory(new SpinnerValueFactory.DoubleSpinnerValueFactory(
        0.0, 10000.0, Double.parseDouble(INITIAL_VALUE)));
        spinner.setEditable(true);
        spinner.getEditor().setTextFormatter(priceFormatter); 
    }
      
          void insertintoTable(){
         String sub_code="###";
         String sql="select MINOR_CODE from list_control where DESCRIPTION='"+sub_group_item_txtf.getText()+"' and SUB_CODE='"+sub_code+"'";
              try{
                 pst=conn.prepareStatement(sql);
                 rs=pst.executeQuery();
                 while(rs.next()){
        String sub_code2="$$$";
        String extend_control="A";
        String created_by="SUPER";
        String sql2="insert into list_control ("
                + "DESCRIPTION,"
                + "MINOR_CODE,"
                + "REFERENCE_CODE,"
                + "DATA1,"
                + "SORT_ORDER,"
                + "SUB_CODE,"
                + "EXTEND_CONTROL,"
                + "CREATED_BY,"
                + "MODIFIED_BY,"
                + "MAJOR_CODE)"
                + "values("
                + "'"+description_txtf.getText()+"',"
                + "'"+list_txtf.getText()+"',"
                + "'"+reference_txtf.getText()+"',"
                + "'"+key_word_txtf.getText()+"',"
                + "'"+Double.parseDouble(order_by_spinner.getEditor().getText())+"',"
                + "'"+sub_code2+"',"
                + "'"+extend_control+"',"
                + "'"+created_by+"',"
                + "'"+created_by+"',"
                + "'"+rs.getString("MINOR_CODE")+"')";
        try{
            conn=DBConnection.ConnectDB();
            pst=conn.prepareStatement(sql2);
            pst.execute();
            //System.out.println("OK");
              Image img = new Image("/images_/tick3.jpg");
                 Notifications recordupdatedSuccessfully = Notifications.create()
                 .title("Record Saved!")
                 .text("Record Saved successfully!!")
                 .graphic(new ImageView(img))
                 .hideAfter(Duration.seconds(5))
                 .position(Pos.CENTER)
                 .onAction((ActionEvent event1) -> {
                 //System.out.println("Clicked on notification!");
                 });
                 
                 recordupdatedSuccessfully.show();
                 loadInsertintoTable_RefreshTable();
        }
        catch(Exception e){
            //e.printStackTrace();
        } 
                 }
              }
              catch(Exception e){
                 // e.printStackTrace();
              }
     
    }
         
           void updateTable(){
     pos_item_sub_group_settings_table selectedItem = item_types_tb.getSelectionModel().getSelectedItem();
     String sql="update list_control set description='"+description_txtf.getText()+"',"
             + "minor_code='"+list_txtf.getText()+"',"
             + "data1='"+key_word_txtf.getText()+"',"
             + "sort_order='"+order_by_spinner.getEditor().getText()+"' where date_created='"+selectedItem.getDATE_CREATED2()+"' and REFERENCE_CODE='"+selectedItem.getREFERENCE_CODE()+"'";
     try{
         conn=DBConnection.ConnectDB();
         pst=conn.prepareStatement(sql);
         pst.execute();
         //System.out.println("record updated successfully!!");
                      Image img = new Image("/images_/tick3.jpg");
                 Notifications recordupdatedSuccessfully = Notifications.create()
                 .title("Record Updated!")
                 .text("Record updated successfully!!")
                 .graphic(new ImageView(img))
                 .hideAfter(Duration.seconds(5))
                 .position(Pos.CENTER)
                 .onAction((ActionEvent event1) -> {
                 //System.out.println("Clicked on notification!");
                 });
                 
                 recordupdatedSuccessfully.show();
                loadInsertintoTable_RefreshTable();
     }
     catch(Exception e){
         e.printStackTrace();
     }
 }
          
           void deleteRecordfromTable(){
     //String sql="select serial_number from list_control where description='"+description_txtf.getText()+"'";
     pos_item_sub_group_settings_table selectedItem = item_types_tb.getSelectionModel().getSelectedItem();
         conn=DBConnection.ConnectDB();
       //  pst=conn.prepareStatement(sql);
        // rs=pst.executeQuery();
       
             String sql2="delete  from list_control where date_modified='"+selectedItem.getDATE_MODIFIED()+"' and REFERENCE_CODE='"+selectedItem.getREFERENCE_CODE()+"'";
             try{
                pst=conn.prepareStatement(sql2);
                pst.execute();
                //System.out.println("record deleted successfully!!");
                  Image img = new Image("/images_/x3.png");
                 Notifications recordupdatedSuccessfully = Notifications.create()
                 .title("Record Deleted!")
                 .text("Record deleted successfully!!")
                 .graphic(new ImageView(img))
                 .hideAfter(Duration.seconds(5))
                 .position(Pos.CENTER)
                 .onAction((ActionEvent event1) -> {
                 //System.out.println("Clicked on notification!");
                 });
                 
                 recordupdatedSuccessfully.show();
                //data.removeAll(data);
                loadInsertintoTable_RefreshTable();
                
             }
             catch(Exception e){
                 e.printStackTrace();
             }
         
     
 }
           
            void refreshFields(){
     /*  list_txtf.setText("");
     description_txtf.setText("");
     key_word_txtf.setText("");
     reference_txtf.setText("");
     setSpinnerValue(order_by_spinner,0.00);*/
     loadInsertintoTable_RefreshTable();
     
 }
            void clearFields(){
     list_txtf.setText("");
     description_txtf.setText("");
     key_word_txtf.setText("");
     //reference_txtf.setText("");
     setSpinnerValue(order_by_spinner,0.00);
     loadInsertintoTable_RefreshTable();
     
 }
            void backButtonActionPerformed(){
     //back_btn.getScene().getWindow().hide();
     frame.dispose();
 }
       
       void loadMaskerPane(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                    conn=DBConnection.ConnectDB();
                    setSpinnerValue(order_by_spinner,0.00);
                     reference_txtf.setText("ITEM_GROUPS");
                    loadFirstSubgroupOption();
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
     }
      
      void loadMaskerPane2(String result2){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                    data.removeAll(data);
                    loadItemDetailsSettingsTable(result2);
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
     }
      
       void loadMaskerPane3(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                    pos_item_sub_group_settings_table_mouse_clicked();
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
     }
       
        void loadMaskerPane4(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                    insertintoTable();
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
     }
         void loadMaskerPane5(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                    deleteRecordfromTable();
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
     }
         
          void loadMaskerPane6(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                    updateTable();
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
     }
               void loadMaskerPane7(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                    refreshFields();
                    
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
     }
               void loadMaskerPane8(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                    clearFields();
                    
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
     }
      
       
               void pos_item_sub_group_settings_table_mouse_clicked(){
          
           pos_item_sub_group_settings_table selectedItem = item_types_tb.getSelectionModel().getSelectedItem();
         
           
           description_txtf.setText(selectedItem.getDESCRIPTION());  
           list_txtf.setText(selectedItem.getLIST());
           key_word_txtf.setText(selectedItem.getTEXT());
           reference_txtf.setText(selectedItem.getREFERENCE_CODE());
            TextFormatter<Integer> priceFormatter = new TextFormatter<Integer>(
        new IntegerStringConverter(), selectedItem.getSORT_ORDER(), filter);
             order_by_spinner.getEditor().setTextFormatter(priceFormatter);
           
      }
    
    
    @FXML
    void actionPerformed(ActionEvent event) {
        if(event.getSource().equals(insert_btn)){
           loadMaskerPane4();  
        }
        else
            if(event.getSource().equals(save_btn)){
                loadMaskerPane6();
            }
            else
            if(event.getSource().equals(delete_btn)){
                loadMaskerPane5();
            }
        else
                if(event.getSource().equals(refresh_btn)){
                    loadMaskerPane7();
                }
        else
                    if(event.getSource().equals(clear_btn)){
                        loadMaskerPane8();
                    }
        else
                        if(event.getSource().equals(back_btn)){
                            backButtonActionPerformed();
                        }
    }
    
      void SearchItem(){
           FilteredList<pos_item_sub_group_settings_table> filteredData = new FilteredList<>(data, p -> true);
            search_txtf.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(item -> {
                // If filter text is empty, display all persons.
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }

                // Compare first name and last name of every person with filter text.
                String lowerCaseFilter = newValue.toLowerCase();
                 String upperCaseFilter = newValue.toUpperCase();
                if (item.getDESCRIPTION().toUpperCase().contains(upperCaseFilter)) {
                    return true; // Filter matches item_code.
                }/*else
                if (item.getKEY_WORD().toLowerCase().contains(lowerCaseFilter)) {
                return true; // Filter matches item_name.
                }*/
                else
                if (item.getLIST().toLowerCase().contains(lowerCaseFilter)) {
                return true; // Filter matches item_name.
                }
                
                /*           else
                if (item.getBARCODE().toLowerCase().contains(lowerCaseFilter)) {
                return true; // Filter matches item_name.
                }*/
                return false; // Does not match.
            });
        });
            
             SortedList<pos_item_sub_group_settings_table> sortedData = new SortedList<>(filteredData);
              sortedData.comparatorProperty().bind(item_types_tb.comparatorProperty());
              item_types_tb.setItems(sortedData);
}

    @FXML
    void onKeyTyped(KeyEvent event) {
        if(event.getSource().equals(search_txtf)){
            SearchItem();
        }
    }

    void loadtypeDetailsStage2(){
        try {
                    String x="DESCRIPTION";
                    String y="MINOR_CODE";
                    String pos_types="ITEM_GROUPS";
                    String title="ITEM SUB GROUPS";
                    String sub_code="###";
                    String sql ="select DESCRIPTION,MINOR_CODE from list_control where REFERENCE_CODE='"+pos_types+"'  AND sub_code='"+sub_code+"'";
                    loadtypeDetailsStage(sql,title,x,y,sub_group_item_txtf,200,100);
                } catch (IOException ex) {
                    Logger.getLogger(pos_item_sub_group_settings_controller.class.getName()).log(Level.SEVERE, null, ex);
                } 
    }
    @FXML
    void onmouseClicked(MouseEvent event) {
            if(event.getSource().equals(sub_group_item_lbl)){
             
               loadtypeDetailsStage2();
                
                
               
            }
    }

    @FXML
    void onselectItem(MouseEvent event) {
        if(event.getSource().equals(item_types_tb)){
          loadMaskerPane3();
        }
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       // loadItemDetailsSettingsTable();
        loadMaskerPane();
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public static JFrame frame;
      public static JFXPanel fxPanel = new JFXPanel();
       public  void initAndShowGUI() {
        // This method is invoked on the EDT thread
       
        try{
        frame = new JFrame("ITEM SUB GROUP FORM");
        frame.add(fxPanel);
        frame.setSize(2000, 1000);
        
        frame.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("../images_/mali_bg.png")));
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setResizable(true);
        frame.setLocationRelativeTo(null); 
       
        }
        catch(Exception e){
            e.printStackTrace();
        }
        
        
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                initFX(fxPanel);
               // loadComboBoxes();
            }
       });
    }
    
    
       private  void initFX(JFXPanel fxPanel) {
        // This method is invoked on the JavaFX thread
      
         //  Scene scene = createScene();
          // fxPanel.setScene(scene);
     try {
         FXMLLoader loader =new FXMLLoader();
         Parent  root5 = loader.load(this.getClass().getResource("pos_item_sub_group_settings.fxml"));
         Scene scene2 = new Scene(root5, 2000, 1000,Color.ALICEBLUE);
         scene2.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
         fxPanel.setScene(scene2);
            
            
           
        } catch (IOException exc) {
            exc.printStackTrace();
            System.exit(1);
        }
        
      
      
    }
    
     public static void main(String[] args) {
         SwingUtilities.invokeLater(new Runnable() {
             @Override
            public void run() {
              
               pos_item_sub_group_settings_controller test = new pos_item_sub_group_settings_controller();
               test.initAndShowGUI();
                
                
                
               
                
            }
        });
        
         
    }
    
}
