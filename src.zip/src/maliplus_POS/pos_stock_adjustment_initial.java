/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDialog;
import com.jfoenix.controls.JFXRadioButton;
import com.jfoenix.controls.JFXTextField;
import com.sun.javafx.css.Size;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.function.UnaryOperator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.concurrent.Task;
import javafx.embed.swing.JFXPanel;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Accordion;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextFormatter;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.util.converter.DoubleStringConverter;
import static javax.swing.text.StyleConstants.Size;
import maliplus.DBConnection;
import static maliplus_POS.Pos_Controller.stage2;
import static maliplus_POS.pos_stock_adjustment_main.conn;
import static maliplus_POS.pos_stock_adjustment_main.pst;
import org.controlsfx.control.Notifications;
import javafx.scene.control.TitledPane;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyEvent;
import javafx.scene.text.Text;
import javafx.util.converter.IntegerStringConverter;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import static maliplus_POS.Pos_Controller.stage2;
import org.controlsfx.control.MaskerPane;
/**
 *
 * @author PSL-STUFF
 */
public class pos_stock_adjustment_initial implements Initializable{
   static Connection conn = null;
    static ResultSet rs = null;
    static PreparedStatement pst = null;
       @FXML
    private JFXButton insert_btn;

    @FXML
    private JFXButton save_btn;

    @FXML
    private JFXButton delete_btn;

    @FXML
    private JFXButton search_btn;

    @FXML
    private JFXButton excel_btn;

    @FXML
    private JFXButton refresh_btn;

    @FXML
    private JFXButton clear_btn;

    @FXML
    private JFXButton back_btn;

    @FXML
    private JFXTextField journal_number_txtf;

    @FXML
    private JFXTextField control_account_txtf;

    @FXML
    private DatePicker datepicker_tdpicker;

    @FXML
    private Spinner<?> control_quantity_spinner;

    @FXML
    private JFXRadioButton stock_in_rdbtn;

    @FXML
    private JFXRadioButton stock_out_rdbtn;

    @FXML
    private Spinner<?> count_spinner;

    @FXML
    private JFXTextField description_txtf;

    @FXML
    private Label description_lbl;
    @FXML
    private Label ledger_type_lbl;

    @FXML
    private Label trn_type_lbl;
    
      
    @FXML
    private MaskerPane masker;

    @FXML
    private Spinner<Integer> fiscal_year_spinner;

    @FXML
    private Spinner<Integer> month_spinner;

    @FXML
    private Label location_lbl;

    @FXML
    private JFXTextField location_txtf;

    @FXML
    private TableView<pos_stock_adjustments_initial_table> stock_adjustment_tb;

    @FXML
    private TableColumn<pos_stock_adjustments_initial_table, String> description_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_initial_table, String> created_by_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_initial_table, String> date_created_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_initial_table, String> journal_number_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_initial_table, String> control_quantity_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_initial_table, String> count_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_initial_table, String> trn_location_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_initial_table, String> journal_status_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_initial_table, String> journal_date_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_initial_table, String> fiscal_year_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_initial_table, String> fiscal_month_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_initial_table, String> date_modified_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_initial_table, String> modified_by_tbnode;
    
    @FXML
    private JFXButton print_preview_btn;

    @FXML
    private JFXButton export_btn;

    @FXML
    private JFXButton approve_post_btn;

    @FXML
    private JFXButton customized_stock_result_btn;

    @FXML
    private JFXButton find_items_btn;

    @FXML
    private JFXButton item_notes_btn;

    @FXML
    private JFXDialog display_message_dgBox;

    @FXML
    private Label item_code_lbl;

    @FXML
    private JFXTextField item_code_txtf;

    @FXML
    private JFXTextField item_name_txtf;

    @FXML
    private DatePicker stcoking_date_dtpicker;

    @FXML
    private Spinner<Double> transaction_quantity_spinner;

    @FXML
    private Spinner<Double> buying_price_spinner;

    @FXML
    private JFXTextField description2_txtf;

    @FXML
    private Label item_location_lbl;

    @FXML
    private Label journal_number_lbl;

    @FXML
    private Label journal_display_message_lbl;

    @FXML
    private Label uom_lbl;

    @FXML
    private Label description_lbl2;
    @FXML
    private Label barcode_lbl;

    @FXML
    private Label supplier_lbl;

    @FXML
    private JFXTextField supplier_txtf;

     @FXML
    private JFXTextField description2_txtf1;
    @FXML
    private Label replicate_supplier_code_lbl;

    @FXML
    private Label type_lbl;

    @FXML
    private JFXDialog quantity_display_message_dgbox;

    @FXML
    private JFXTextField uom_txtf;

    @FXML
    private JFXTextField barcode_txtf;

    @FXML
    private JFXTextField type_txtf;

    @FXML
    private JFXTextField journal_number2_txtf;

    @FXML
    private JFXTextField item_location_txtf;

  

    @FXML
    private JFXTextField journal_quantity_txtf;

    @FXML
    private JFXTextField journal_control_count_txtf;

    @FXML
    private TableView<pos_stock_adjustments_table> stock_adjustment_tbl;

    @FXML
    private TableColumn<pos_stock_adjustments_table,String > item_code_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_table, String> item_name_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_table, String> transaction_date_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_table, Number> quantity_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_table, String> item_price_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_table, String> description2_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_table, Number> quantity_count_tbnode;
    @FXML
    private TableColumn<pos_stock_adjustments_table,Number> quantity_variance_tbnode;
    @FXML
    private TableColumn<pos_stock_adjustments_table,Number> close_tbnode;

    @FXML
    private TableColumn<pos_stock_adjustments_table, String> item_location_tbnode; 
    
        @FXML
    private Label quantity_message_display;

    @FXML
    private Label lines_message_display;
        @FXML
    private Accordion acc;
        
          @FXML
    private TitledPane stock_adjustment_transactions_tp;
            @FXML
    private TitledPane stock_adjustment_journals_tp;
            
    @FXML
    private ScrollPane stock_adjustment_Root;
    
     @FXML
    private JFXRadioButton adjustments_rdbtn;

    @FXML
    private JFXRadioButton stock_taking_rdbtn;
    
       @FXML
    private Text transaction_quantity_text;

    
 void calculateQuantityVarianceAmount(double difference){
     try{
          for (pos_stock_adjustments_table  item : stock_adjustment_tbl.getItems()) {
         difference = item.getQUANTITY()-item.getQUANTITY_STOCK_IN_HAND(); 
         System.out.println(difference);
        // String s = NumberFormat.getNumberInstance().format(total);
        /*total_sales_amount.setText(s);
        //total_sales_amount.setStyle("-fx-text-fill: blue;");
        if(total_sales_amount.getText()!=null){
        total_sales_amount.setStyle("-fx-text-fill: green;"
        + "-fx-font-size: 40px;");
        // total_sales_amount.setStyle("-fx-font-size: 40px;");
        }*/
          
                 }  
      }
      catch(Exception e){
          e.printStackTrace();
      }
      
     
  }
  
  final ObservableList<pos_stock_adjustments_table> data= FXCollections.observableArrayList();
         public  void loadStockAdjustmentDetailstable(){
               conn=DBConnection.ConnectDB();
           String sql= "SELECT STOCK_TRNS.ITEM_CODE,STOCK_TRNS.DESCRIPTION,STOCK_TRNS.QUANTITY,STOCK_TRNS.ITEM_PRICE,STOCK_TRNS.DESCRIPTION,STOCK_TRNS.ITEM_LOCATION,ITEM_BALANCES.CLOSING from STOCK_TRNS,ITEM_BALANCES"
                   + " WHERE STOCK_TRNS.JOURNAL_NUMBER='"+journal_number2_txtf.getText()+"' AND ITEM_BALANCES.ITEM_CODE=STOCK_TRNS.ITEM_CODE";
                        try{
                       pst=conn.prepareStatement(sql);
                       rs= pst.executeQuery();
                      // System.out.println(sql);
                      
                       while(rs.next()){
                          double difference=0.0; 
                          difference=rs.getDouble("QUANTITY")-rs.getDouble("CLOSING");
                          
                           data.add(new pos_stock_adjustments_table(
                           rs.getString("ITEM_CODE"),
                           rs.getString("DESCRIPTION"),
                           rs.getInt("QUANTITY"),
                           rs.getString("ITEM_PRICE"),
                           rs.getString("DESCRIPTION"),
                           rs.getString("ITEM_LOCATION"),
                           rs.getInt("CLOSING"),
                           difference, 
                           rs.getDouble("QUANTITY")
                           ));
                              
        item_code_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_table, String> cellData) -> {
            return cellData.getValue().item_codeProperty();
     
        });
            
       
        item_name_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_table, String> cellData) -> {
            return cellData.getValue().item_nameProperty();
        });
        
        quantity_count_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_table, Number> cellData) -> {
            return cellData.getValue().quantityProperty();
        });
        item_price_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_table, String> cellData) -> {
            return cellData.getValue().item_priceProperty();
        });
        description2_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_table, String> cellData) -> {
            return cellData.getValue().descriptionProperty();
        });
       
        item_location_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_table, String> cellData) -> {
            return cellData.getValue().item_locationProperty();
        });
      
        quantity_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_table, Number> cellData) -> {
            return cellData.getValue().stock_in_handProperty();
        });
         quantity_variance_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_table, Number> cellData) -> {
            return cellData.getValue().varianceProperty();
        });
         close_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_table, Number> cellData) -> {
            return cellData.getValue().closeProperty();
        });

     
       // item_code.setStyle("-fx-control-inner-background: yellow;");
       // item_code.setStyle("-fx-text-fill: red;");
       // item_description.setStyle("-fx-text-fill: green;");
       // quantity.setStyle("-fx-text-fill: blue;");
       // sales_price.setStyle("-fx-text-fill: orange;");
       // sales_amount.setStyle("-fx-text-fill: purple;");
       // discount.setStyle("-fx-text-fill: red;");
       // taxable.setStyle("-fx-text-fill: violet;");
       // tax_amount.setStyle("-fx-text-fill: blue;");
       // item_location.setStyle("-fx-text-fill: grey;");
       // display.setStyle(" -fx-font-size: 14px;");
       
  
                           stock_adjustment_tbl.setItems(data);
                           
                             item_name_tbnode.setCellFactory(column -> {
    return new TableCell<pos_stock_adjustments_table, String>() {
        @Override
        protected void updateItem(String item, boolean empty) {
            super.updateItem(item, empty); //This is mandatory

            if (item == null || empty) { //If the cell is empty
                setText(null);
                setStyle("");
            } else { //If the cell is not empty

                setText(item); //Put the String data in the cell

                //We get here all the info of the Person of this row
                pos_stock_adjustments_table item_name2 = getTableView().getItems().get(getIndex());
               

     
                try{
                if (item_name2.getITEM_NAME().isEmpty()==false) {
                    setTextFill(Color.BLACK); //The text in red
                    setStyle("-fx-background-color:PALEGREEN"); //The background of the cell in yellow
                    
                }   else {
                    //Here I see if the row of this cell is selected or not
                    if(getTableView().getSelectionModel().getSelectedItems().contains(item_name2))
                        setTextFill(Color.WHITE);
                    else
                        setTextFill(Color.BLACK);
                }
    
                }
                catch(Exception e){
                    e.printStackTrace();
                }
                
              
            }
        }
    };
});             
           
     item_price_tbnode.setCellFactory(column -> {
    return new TableCell<pos_stock_adjustments_table, String>() {
        @Override
        protected void updateItem(String item, boolean empty) {
            super.updateItem(item, empty); //This is mandatory

            if (item == null || empty) { //If the cell is empty
                setText(null);
                setStyle("");
            } else { //If the cell is not empty

                setText(item); //Put the String data in the cell

                //We get here all the info of the Person of this row
                pos_stock_adjustments_table item_price2 = getTableView().getItems().get(getIndex());
               

     
                try{
                if (item_price2.getITEM_PRICE().isEmpty()==false) {
                    setTextFill(Color.WHITE); //The text in red
                    setStyle("-fx-background-color:PURPLE"); //The background of the cell in yellow
                    
                }   else {
                    //Here I see if the row of this cell is selected or not
                    if(getTableView().getSelectionModel().getSelectedItems().contains(item_price2))
                        setTextFill(Color.WHITE);
                    else
                        setTextFill(Color.BLACK);
                }
    
                }
                catch(Exception e){
                    e.printStackTrace();
                }
                
              
            }
        }
    };
}); 
                       }
                    //   pst.close();
                    //   rs.close();
                   }
                   catch(Exception e2){
                      e2.printStackTrace();
                   } 
}
         
         // final ObservableList<pos_stock_adjustments_table> data= FXCollections.observableArrayList();
         public  void loadStockAdjustmentMAINDetailstable(String sql){
               conn=DBConnection.ConnectDB();
                        try{
                       pst=conn.prepareStatement(sql);
                       rs= pst.executeQuery();              
                       while(rs.next()){ 
                           double difference=0.0;
                           difference=rs.getDouble("QUANTITY")-rs.getDouble("CLOSING");
                           data.add(new pos_stock_adjustments_table(
                           rs.getString("ITEM_CODE"),
                           rs.getString("DESCRIPTION"),
                           rs.getInt("QUANTITY"),
                           rs.getString("ITEM_PRICE"),
                           rs.getString("DESCRIPTION"),
                           rs.getString("ITEM_LOCATION"),
                           rs.getInt("CLOSING"),
                           difference,
                           rs.getDouble("QUANTITY")        
                                   
                           ));
        item_code_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_table, String> cellData) -> {
            return cellData.getValue().item_codeProperty();
     
        });
            
       
        item_name_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_table, String> cellData) -> {
            return cellData.getValue().item_nameProperty();
        });
        
        quantity_count_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_table, Number> cellData) -> {
            return cellData.getValue().quantityProperty();
        });
        item_price_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_table, String> cellData) -> {
            return cellData.getValue().item_priceProperty();
        });
        description2_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_table, String> cellData) -> {
            return cellData.getValue().descriptionProperty();
        });
        
        item_location_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_table, String> cellData) -> {
            return cellData.getValue().item_locationProperty();
        });
      
        quantity_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_table, Number> cellData) -> {
            return cellData.getValue().stock_in_handProperty();
        });
        quantity_variance_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_table, Number> cellData) -> {
            return cellData.getValue().varianceProperty();
        });
        close_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_table, Number> cellData) -> {
            return cellData.getValue().closeProperty();
        });
        

     
       // item_code.setStyle("-fx-control-inner-background: yellow;");
       // item_code.setStyle("-fx-text-fill: red;");
       // item_description.setStyle("-fx-text-fill: green;");
       // quantity.setStyle("-fx-text-fill: blue;");
       // sales_price.setStyle("-fx-text-fill: orange;");
       // sales_amount.setStyle("-fx-text-fill: purple;");
       // discount.setStyle("-fx-text-fill: red;");
       // taxable.setStyle("-fx-text-fill: violet;");
       // tax_amount.setStyle("-fx-text-fill: blue;");
       // item_location.setStyle("-fx-text-fill: grey;");
       // display.setStyle(" -fx-font-size: 14px;");
       
  
                           stock_adjustment_tbl.setItems(data);
                           
                             item_name_tbnode.setCellFactory(column -> {
    return new TableCell<pos_stock_adjustments_table, String>() {
        @Override
        protected void updateItem(String item, boolean empty) {
            super.updateItem(item, empty); //This is mandatory

            if (item == null || empty) { //If the cell is empty
                setText(null);
                setStyle("");
            } else { //If the cell is not empty

                setText(item); //Put the String data in the cell

                //We get here all the info of the Person of this row
                pos_stock_adjustments_table item_name2 = getTableView().getItems().get(getIndex());
               

     
                try{
                if (item_name2.getITEM_NAME().isEmpty()==false) {
                    setTextFill(Color.BLACK); //The text in red
                    setStyle("-fx-background-color:PALEGREEN"); //The background of the cell in yellow
                    
                }   else {
                    //Here I see if the row of this cell is selected or not
                    if(getTableView().getSelectionModel().getSelectedItems().contains(item_name2))
                        setTextFill(Color.WHITE);
                    else
                        setTextFill(Color.BLACK);
                }
    
                }
                catch(Exception e){
                    e.printStackTrace();
                }
                
              
            }
        }
    };
});             
           
     item_price_tbnode.setCellFactory(column -> {
    return new TableCell<pos_stock_adjustments_table, String>() {
        @Override
        protected void updateItem(String item, boolean empty) {
            super.updateItem(item, empty); //This is mandatory

            if (item == null || empty) { //If the cell is empty
                setText(null);
                setStyle("");
            } else { //If the cell is not empty

                setText(item); //Put the String data in the cell

                //We get here all the info of the Person of this row
                pos_stock_adjustments_table item_price2 = getTableView().getItems().get(getIndex());
               

     
                try{
                if (item_price2.getITEM_PRICE().isEmpty()==false) {
                    setTextFill(Color.WHITE); //The text in red
                    setStyle("-fx-background-color:PURPLE"); //The background of the cell in yellow
                    
                }   else {
                    //Here I see if the row of this cell is selected or not
                    if(getTableView().getSelectionModel().getSelectedItems().contains(item_price2))
                        setTextFill(Color.WHITE);
                    else
                        setTextFill(Color.BLACK);
                }
    
                }
                catch(Exception e){
                    e.printStackTrace();
                }
                
              
            }
        }
    };
}); 
                       }
                    //   pst.close();
                    //   rs.close();
                   }
                   catch(Exception e2){
                      e2.printStackTrace();
                   } 
}
void insertToStockTrns(){
    String sql="Insert into STOCK_TRNS ("
            + "ITEM_CODE,"
            + "DESCRIPTION,"
            + "DATE_CREATED,"
            + "QUANTITY,"
            + "ITEM_PRICE,"
            + "ITEM_LOCATION,"
            + "JOURNAL_NUMBER,"
            + "IUOM,"
            + "DOCUMENT_TYPE,"
            + "ACCOUNT_NUMBER,"
            + "SUPPLIER_NO,"
            + "CREATED_BY,"
            + "LEDGER_NUMBER,"
            + "SUOM,"
            + "CHECK_CATEGORY,"
            + "BARCODE)"
            + "VALUES('"+item_code_txtf.getText()+"',"
            + "'"+item_name_txtf.getText()+"',"
            + "'"+stcoking_date_dtpicker.getEditor().getText()+"',"
            + "'"+transaction_quantity_spinner.getEditor().getText()+"',"
            + "'"+buying_price_spinner.getEditor().getText()+"',"
            + "'"+item_location_txtf.getText()+"',"
            + "'"+journal_number2_txtf.getText()+"',"
            + "'"+uom_txtf.getText()+"',"
            + "'"+type_txtf.getText()+"',"
            + "'*',"
            + "'"+supplier_txtf.getText()+"', "
            + "'SUPER',"
            + "'ADJUSTMENTS',"
            + "'"+uom_txtf.getText()+"',"
            + "'STK',"
            + "'"+barcode_txtf.getText()+"')";
    
    try{
     conn=DBConnection.ConnectDB();
     pst=conn.prepareStatement(sql);
     pst.execute();
     data.removeAll(data);
     loadStockAdjustmentDetailstable();
      Image img = new Image("/images_/tick3.jpg");
      Notifications StockrecordCreatedSuccessfully = Notifications.create()
                        .title("Stock Record Created Successfully!")
                        .text("Stock Record Created Successfully!!")
                        .graphic(new ImageView(img))
                        .hideAfter(Duration.seconds(5))
                        .position(Pos.CENTER)
                        .onAction((ActionEvent event1) -> {
                        //System.out.println("Clicked on notification!");
            });  
   
           StockrecordCreatedSuccessfully.show();
     
     
    }
    catch(Exception e){
        e.printStackTrace();
    }
}
    void getItemcodeandItemname(){
        String temp="%" + item_code_txtf.getText() + "%";
        String sql="Select item_code,item_name,buy_price,iuom from item_master WHERE item_code like '"+temp+"'";
         
        try{
         conn=DBConnection.ConnectDB();
         pst=conn.prepareStatement(sql);
         
         rs=pst.executeQuery();
         while(rs.next()){
             item_code_txtf.setText(rs.getString("ITEM_CODE"));
             item_name_txtf.setText(rs.getString("ITEM_NAME"));
             TextFormatter<Double> priceFormatter2 = new TextFormatter<Double>(
        new DoubleStringConverter(), rs.getDouble("BUY_PRICE"), filter);
            //buying_price_spinner.getEditor().setText(String.valueOf(rs.getDouble("BUY_PRICE")));
           // System.out.println(rs.getDouble("BUY_PRICE"));
             buying_price_spinner.getEditor().setTextFormatter(priceFormatter2);
             if(buying_price_spinner.getEditor().getText().equals("0.0")){
                 buying_price_spinner.setStyle("-fx-control-inner-background: yellow;"
                     + "-fx-text-fill: black;");
             }
             else{
                 buying_price_spinner.setStyle("-fx-control-inner-background: green;"
                     + "-fx-text-fill: white;"); 
             }
             uom_txtf.setText(rs.getString("IUOM"));
         }
         //rs.close();
                
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    @FXML
    void actionPerformed(ActionEvent event) {
        if(event.getSource().equals(insert_btn)){
            if(!transaction_quantity_spinner.getEditor().getText().equals("0.0")& !buying_price_spinner.getEditor().getText().equals("0.0")){
               insertintostockAdjustmentInitialTable(); 
               insertToStockTrns(); 
            }
            else{
                if(transaction_quantity_spinner.getEditor().getText().equals("0.0")){
                     transaction_quantity_spinner.getEditor().setStyle("-fx-control-inner-background: yellow;"
                        + "-fx-text-fill: black;");
                }
                else{
                    transaction_quantity_spinner.getEditor().setStyle("-fx-control-inner-background: green;"
                        + "-fx-text-fill: white;");
                }
                
                    if(buying_price_spinner.getEditor().getText().equals("0.0")){
                           buying_price_spinner.getEditor().setStyle("-fx-control-inner-background: yellow;"
                        + "-fx-text-fill: black;");  
                    }
                    else{
                         buying_price_spinner.getEditor().setStyle("-fx-control-inner-background: green;"
                        + "-fx-text-fill: white;");  
                    }
               
                //transaction_quantity_spinner.getEditor().setText("Cannot be '0.00'");
           
                //buying_price_spinner.getEditor().setText("Cannot be '0.00'");
                   Image img = new Image("/images_/warning2.png");
      Notifications JournalrecordwarningMessage = Notifications.create()
                        .title("Warning!")
                        .text("The highlighted fields should not be empty or contain '0'.Please fill them"
                                + " appropriately before proceeding.!!")
                        .graphic(new ImageView(img))
                        .hideAfter(Duration.seconds(5))
                        .position(Pos.CENTER)
                        .onAction((ActionEvent event1) -> {
                        //System.out.println("Clicked on notification!");
            });  
   
           JournalrecordwarningMessage.show();
            }
         
        }
        else
            if(event.getSource().equals(item_code_txtf)){
            loadMaskerPane5();
         }
        else
                if(event.getSource().equals(back_btn)){
                    System.exit(0);
                }
        else
                    if(event.getSource().equals(clear_btn)){
                        showCurrentDateonload();
                        control_account_txtf.setText("");
                        fiscal_year_spinner.getEditor().setText("");
                        month_spinner.getEditor().setText("");
                        journal_control_count_txtf.setText("");
                        item_location_txtf.setText("");
                        journal_quantity_txtf.setText("");
                        description2_txtf1.setText("");
                        item_code_txtf.setText("");
                        item_name_txtf.setText("");
                        uom_txtf.setText("");
                        transaction_quantity_spinner.getEditor().setText("");
                        type_txtf.setText("");
                        transaction_quantity_spinner.getEditor().setText("");
                        barcode_txtf.setText("");
                        buying_price_spinner.getEditor().setText("");
                        supplier_txtf.setText("");
                        description2_txtf.setText("");
                        data2.removeAll(data2);
                        String refresh_journal_table= "SELECT * from JOURNAL_CONTROL WHERE JOURNAL_TYPE='ADJ'";
                        loadStockAdjustmentDetailstable(refresh_journal_table);
                        data.removeAll(data);
                    }
        else
                        if(event.getSource()
                                ==stock_in_rdbtn
                                ){

                            SwitchRadioButtons(
                                    stock_in_rdbtn,
                                    stock_out_rdbtn);
                        }
        else
                            if(event.getSource()
                                    ==stock_out_rdbtn
                                    ){

                            SwitchRadioButtons(
                                    stock_out_rdbtn,
                                    stock_in_rdbtn);
                        }
        else
                                if(event.getSource()==adjustments_rdbtn){
                                   switchBetweenAdjustmentsandStockTakingButtons(
                                           adjustments_rdbtn,
                                           stock_taking_rdbtn,
                                           stock_in_rdbtn,
                                           stock_out_rdbtn,
                                           transaction_quantity_text
                                   ); 
                                }
     else
                                    if(event.getSource()==stock_taking_rdbtn){
                                  SwitchbetweenStockTakingandAdjustmentsradioButton(
                                          stock_taking_rdbtn,
                                          adjustments_rdbtn,
                                          stock_in_rdbtn,
                                          stock_out_rdbtn,
                                          transaction_quantity_text
                                  ); 
                                }
        
        else
                                        if(event.getSource()==journal_number2_txtf){
                                           conn=DBConnection.ConnectDB();
                                           getjournalNumberdetails(); 
                                           
                                        }
        else
                                            if(event.getSource()==delete_btn){
                                              // calculateQuantityVarianceAmount(); 
                                            }
           
    }
    
    void getjournalNumberdetails(){
         
        String sql="Select * from JOURNAL_CONTROL where JOURNAL_NUMBER='"+journal_number2_txtf.getText()+"'";
        conn=DBConnection.ConnectDB();
        try{
            pst=conn.prepareStatement(sql);
            rs=pst.executeQuery();
            while(rs.next()){
                    control_account_txtf.setText(rs.getString("CONTROL_ACCOUNT"));
                TextFormatter<Integer> priceFormatter5 = new TextFormatter<Integer>(
                new IntegerStringConverter(),Integer.parseInt(String.valueOf(rs.getInt("FISCAL_YEAR"))), filter);
                TextFormatter<Integer> priceFormatter6 = new TextFormatter<Integer>(
                new IntegerStringConverter(),Integer.parseInt(String.valueOf(rs.getInt("FISCAL_MONTH"))), filter);
                fiscal_year_spinner.getEditor().setTextFormatter(priceFormatter5);
                month_spinner.getEditor().setTextFormatter(priceFormatter6);
          ledger_type_lbl.setText(rs.getString("LEDGER_TYPE"));
          trn_type_lbl.setText(rs.getString("JOURNAL_TYPE"));
          journal_control_count_txtf.setText(rs.getString("CONTROL_COUNT"));
          item_location_txtf.setText(rs.getString("TRN_LOCATION"));
          description2_txtf1.setText(rs.getString("DESCRIPTION"));
          journal_quantity_txtf.setText(rs.getString("CONTROL_QUANTITY"));
           java.sql.Date check_status6 = rs.getDate("DATE_CREATED");
          //System.out.println(""+check_status6+"");
          SimpleDateFormat formatter2 = new SimpleDateFormat("MM-dd-yyyy");
          //formatter2.parse(check_status6);
          String ref = formatter2.format(check_status6);
         
          
          
          
          
          // System.out.println(String.valueOf(ref));
          
          String dateValue = ""+ref+"";
          //  sale_date.setValue(LocalDate.parse(ref,formatter));
          
          DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
          stcoking_date_dtpicker.setValue(LocalDate.parse(dateValue,formatter));
          
            }
             data.removeAll(data);
          loadStockAdjustmentDetailstable();
        }
                catch(Exception e){
                e.printStackTrace();     
                        }
    }
       void loadInventoryJournalsStage() throws IOException{
         Scene scene3; 
             Stage  stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_type Controller = new pos_type();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_type_details.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 Parent root3 = loader.load();
                 String x="DESCRIPTION";
                 String y="MINOR_CODE";
                 String pos_types= "INVENTORY_JOURNALS";
                 String sub_code = "###";
                 String sql = "select minor_code,description from list_control where reference_code='"+pos_types+"' AND sub_code='"+sub_code+"'";
                 loader.<pos_type>getController().loadtypesDetailstable(sql, x, y);
                 scene3 = new Scene(root3);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("Inventory Journal Description");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(1000);
                 stage2.setY(50);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();ca
               stage2.showAndWait();

              String result = loader.<pos_type>getController().getResult2();
          
                if (result != null) {
        // if a result was selected, add it to the list
                 description2_txtf1.setText(result);
                 // ledger_name3.setText(result2);
         }
    }
      
         void loadtypeDetailsStage() throws IOException{
         Scene scene3; 
             Stage  stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_type Controller = new pos_type();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_type_details.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 Parent root3 = loader.load();
                 String x="DESCRIPTION";
                 String y="MINOR_CODE";
                 String pos_types= "DOCUMENT_TYPES";
                 String sub_code = "###";
                 String sql = "select minor_code,description from list_control where reference_code='"+pos_types+"' AND sub_code='"+sub_code+"'";
                 loader.<pos_type>getController().loadtypesDetailstable(sql, x, y);
                 scene3 = new Scene(root3);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("TYPE");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(1000);
                 stage2.setY(50);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();ca
               stage2.showAndWait();

              String result = loader.<pos_type>getController().getResult();
          
                if (result != null) {
        // if a result was selected, add it to the list
                  type_txtf.setText(result);
                 // ledger_name3.setText(result2);
         }
    }
         void loadDescriptionDetailsStage() throws IOException{
         Scene scene3; 
             Stage  stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_type Controller = new pos_type();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_type_details.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 Parent root3 = loader.load();
                 String x="DESCRIPTION";
                 String y="MINOR_CODE";
                 String pos_types= "STOCK_ADJUSTMENT";
                 String sub_code = "###";
                 String sql = "select minor_code,description from list_control where reference_code='"+pos_types+"' AND sub_code='"+sub_code+"'";
                 loader.<pos_type>getController().loadtypesDetailstable(sql, x, y);
                 scene3 = new Scene(root3);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("TYPE");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(1000);
                 stage2.setY(50);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();ca
               stage2.showAndWait();

              String result = loader.<pos_type>getController().getResult();
          
                if (result != null) {
        // if a result was selected, add it to the list
                  type_txtf.setText(result);
                 // ledger_name3.setText(result2);
         }
    }
       
             void loadCustomerDetailsStage() throws IOException{
        Scene scene3; 
            Stage stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_customers Controller = new pos_customers();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_customers.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 Parent root3 = loader.load();
                 scene3 = new Scene(root3);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("STOCK ADJUSTMENTS");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(500);
                 stage2.setY(55);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();
               stage2.showAndWait();

              String result = loader.<pos_customers>getController().getResult();
          
          
             
                if (result != null) {
        // if a result was selected, add it to the list
                  supplier_txtf.setText(result);
              
               
                  
             
            
        
         }
                
    }
   

    @FXML
    void mouseClicked(MouseEvent event) {
            if(event.getSource()==item_location_lbl){
                try{
                    loadlocationStage();
                }
                catch(Exception e){
                    e.printStackTrace();
                }
                
            }
        else
                if(event.getSource()==type_lbl){
                    try{
                        loadtypeDetailsStage();
                    }
                    catch(Exception e){
                        e.printStackTrace();
                    }
                }
        else
                    if(event.getSource()==supplier_lbl){
                       try{
                           loadCustomerDetailsStage();
                       } 
                       catch(Exception e){
                           e.printStackTrace();
                       }
                    }
        
        else
                        if(event.getSource()== transaction_quantity_spinner){
                            if(!transaction_quantity_spinner.getEditor().getText().equals("0.0")){
                                transaction_quantity_spinner.getEditor().setStyle("-fx-control-inner-background: green;"
                                        + "-fx-text-fill: white;"); 
                            }
                            else{
                                transaction_quantity_spinner.getEditor().setStyle("-fx-control-inner-background: yellow;"
                                        + "-fx-text-fill: black;"); 
                            }
                               
              //  buying_price_spinner.getEditor().setStyle("-fx-control-inner-background: green;"); 
                        }
        else
                             if(event.getSource()== buying_price_spinner){
                                 if( !buying_price_spinner.getEditor().getText().equals("0.0")){
                                   buying_price_spinner.getEditor().setStyle("-fx-control-inner-background: green;"
                        + "-fx-text-fill: white;");    
                                 }
                                 else{
                                       buying_price_spinner.getEditor().setStyle("-fx-control-inner-background: yellow;"
                        + "-fx-text-fill: black;");  
                                 }
                               // transaction_quantity_spinner.getEditor().setStyle("-fx-control-inner-background: yellow;");
               
             
                        }
        else
                                 if(event.getSource().equals(description_lbl2)){
                                  try{
                                      loadInventoryJournalsStage();
                                  }   
                                  catch(Exception e){
                                      e.printStackTrace();
                                  }
                                 }
    }
    
      @FXML
    void keyReleased(KeyEvent event) {
           if(event.getSource()== transaction_quantity_spinner){
                            if(!transaction_quantity_spinner.getEditor().getText().equals("0.0")){
                                transaction_quantity_spinner.getEditor().setStyle("-fx-control-inner-background: green;"
                                        + "-fx-text-fill: white;"); 
                            }
                            else{
                                transaction_quantity_spinner.getEditor().setStyle("-fx-control-inner-background: yellow;"
                                        + "-fx-text-fill: black;"); 
                            }
                               
              //  buying_price_spinner.getEditor().setStyle("-fx-control-inner-background: green;"); 
                        }
        else
                             if(event.getSource()== buying_price_spinner){
                                 if( !buying_price_spinner.getEditor().getText().equals("0.0")){
                                   buying_price_spinner.getEditor().setStyle("-fx-control-inner-background: green;"
                        + "-fx-text-fill: white;");    
                                 }
                                 else{
                                       buying_price_spinner.getEditor().setStyle("-fx-control-inner-background: yellow;"
                        + "-fx-text-fill: black;");  
                                 }
                               // transaction_quantity_spinner.getEditor().setStyle("-fx-control-inner-background: yellow;");
               
             
                        }
    }
final ObservableList<pos_stock_adjustments_initial_table> data2= FXCollections.observableArrayList();
           public  void loadStockAdjustmentDetailstable(String sql){
               conn=DBConnection.ConnectDB();
          
                        try{
                       pst=conn.prepareStatement(sql);
                       rs= pst.executeQuery();
                       while(rs.next()){ 
                           data2.add(new pos_stock_adjustments_initial_table(
                           rs.getString("DESCRIPTION"),
                           rs.getString("CREATED_BY"),
                           rs.getString("DATE_CREATED"),
                           rs.getString("JOURNAL_NUMBER"),
                           rs.getString("CONTROL_QUANTITY"),
                           rs.getString("CONTROL_COUNT"),
                           rs.getString("TRN_LOCATION"),
                           rs.getString("JOURNAL_STATUS"),
                           rs.getString("JOURNAL_DATE"),
                           rs.getString("FISCAL_YEAR"),
                           rs.getString("FISCAL_MONTH"),
                           rs.getString("DATE_MODIFIED"),
                           rs.getString("MODIFIED_BY")
                           ));
        description_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_initial_table, String> cellData) -> {
            return cellData.getValue().descriptionProperty();
     
        });
        created_by_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_initial_table, String> cellData) -> {
            return cellData.getValue().created_byProperty();
     
        });
        date_created_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_initial_table, String> cellData) -> {
            return cellData.getValue().date_createdProperty();
     
        });
        journal_number_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_initial_table, String> cellData) -> {
            return cellData.getValue().journal_numberProperty();
     
        });
        control_quantity_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_initial_table, String> cellData) -> {
            return cellData.getValue().control_quantityProperty();
     
        });
        count_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_initial_table, String> cellData) -> {
            return cellData.getValue().countProperty();
     
        });
        trn_location_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_initial_table, String> cellData) -> {
            return cellData.getValue().trn_locationProperty();
     
        });
        journal_status_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_initial_table, String> cellData) -> {
            return cellData.getValue().journal_statusProperty();
     
        });
        journal_date_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_initial_table, String> cellData) -> {
            return cellData.getValue().journal_dateProperty();
     
        });
        fiscal_year_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_initial_table, String> cellData) -> {
            return cellData.getValue().fiscal_yearProperty();
     
        });
        fiscal_month_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_initial_table, String> cellData) -> {
            return cellData.getValue().fiscal_monthProperty();
     
        });
        date_modified_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_initial_table, String> cellData) -> {
            return cellData.getValue().date_modifiedProperty();
     
        });
        modified_by_tbnode.setCellValueFactory((TableColumn.CellDataFeatures<pos_stock_adjustments_initial_table, String> cellData) -> {
            return cellData.getValue().modified_byProperty();
     
        });
            
       
       
      
      
        
        

     
       // item_code.setStyle("-fx-control-inner-background: yellow;");
       // item_code.setStyle("-fx-text-fill: red;");
       // item_description.setStyle("-fx-text-fill: green;");
       // quantity.setStyle("-fx-text-fill: blue;");
       // sales_price.setStyle("-fx-text-fill: orange;");
       // sales_amount.setStyle("-fx-text-fill: purple;");
       // discount.setStyle("-fx-text-fill: red;");
       // taxable.setStyle("-fx-text-fill: violet;");
       // tax_amount.setStyle("-fx-text-fill: blue;");
       // item_location.setStyle("-fx-text-fill: grey;");
       // display.setStyle(" -fx-font-size: 14px;");
       
  
                           stock_adjustment_tb.setItems(data2);
                           
                         description_tbnode.setCellFactory(column -> {
    return new TableCell<pos_stock_adjustments_initial_table, String>() {
        @Override
        protected void updateItem(String item, boolean empty) {
            super.updateItem(item, empty); //This is mandatory

            if (item == null || empty) { //If the cell is empty
                setText(null);
                setStyle("");
            } else { //If the cell is not empty

                setText(item); //Put the String data in the cell

                //We get here all the info of the Person of this row
                pos_stock_adjustments_initial_table description2 = getTableView().getItems().get(getIndex());
               

     
                try{
                if (description2.getDESCRIPTION().isEmpty()==false) {
                    setTextFill(Color.BLACK); //The text in red
                    setStyle("-fx-background-color:PALEGREEN"); //The background of the cell in yellow
                    
                }   else {
                    //Here I see if the row of this cell is selected or not
                    if(getTableView().getSelectionModel().getSelectedItems().contains(description2))
                        setTextFill(Color.WHITE);
                    else
                        setTextFill(Color.BLACK);
                }
    
                }
                catch(Exception e){
                    e.printStackTrace();
                }
                
              
            }
        }
    };
});             
           
     journal_number_tbnode.setCellFactory(column -> {
    return new TableCell<pos_stock_adjustments_initial_table, String>() {
        @Override
        protected void updateItem(String item, boolean empty) {
            super.updateItem(item, empty); //This is mandatory

            if (item == null || empty) { //If the cell is empty
                setText(null);
                setStyle("");
            } else { //If the cell is not empty

                setText(item); //Put the String data in the cell

                //We get here all the info of the Person of this row
                pos_stock_adjustments_initial_table journal_number2 = getTableView().getItems().get(getIndex());
               

     
                try{
                if (journal_number2.getJOURNAL_NUMBER().isEmpty()==false) {
                    setTextFill(Color.WHITE); //The text in red
                    setStyle("-fx-background-color:PURPLE"); //The background of the cell in yellow
                    
                }   else {
                    //Here I see if the row of this cell is selected or not
                    if(getTableView().getSelectionModel().getSelectedItems().contains(journal_number2))
                        setTextFill(Color.WHITE);
                    else
                        setTextFill(Color.BLACK);
                }
    
                }
                catch(Exception e){
                    e.printStackTrace();
                }
                
              
            }
        }
    };
}); 
                       }
                    //   pst.close();
                    //   rs.close();
                   }
                   catch(Exception e2){
                      e2.printStackTrace();
                   } 
}
            void loadMaskerPane(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                   windowOpened();
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
     }
           
            void loadMaskerPane2(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                    StockAdjustmentTable_mouse_clicked();
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
     }
            
             void loadMaskerPane3(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                  StockAdjustmentmainTable_mouse_clicked();
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
     }
             
           void loadMaskerPanel4(String result, String result2,String load_item_details){
                 Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                  loadItemDetails(result,result2,load_item_details);
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
                 
             }
           
             void loadMaskerPane5(){
            Task task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    masker.setVisible(true);
                    return null;
                }
                @Override
                protected void succeeded(){
                    super.succeeded();
                 getItemcodeandItemname();
                    masker.setVisible(false);
                }
            };
            new Thread(task).start();
     }
           
                 void StockAdjustmentTable_mouse_clicked(){
          
           pos_stock_adjustments_initial_table selectedItem = stock_adjustment_tb.getSelectionModel().getSelectedItem();
            String sql="select  DATE_CREATED from JOURNAL_CONTROL where JOURNAL_NUMBER = '"+String.valueOf(selectedItem.getJOURNAL_NUMBER())+"'";
       Connection conn = DBConnection.ConnectDB();
           try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
         java.sql.Date check_status6 = rs.getDate("DATE_CREATED");
         //System.out.println(""+check_status6+""); 
         SimpleDateFormat formatter2 = new SimpleDateFormat("MM-dd-yyyy");
        //formatter2.parse(check_status6);
        String ref = formatter2.format(check_status6);
        
        
        
        
      // System.out.println(String.valueOf(ref));
        
         String dateValue = ""+ref+"";
      //  sale_date.setValue(LocalDate.parse(ref,formatter));
       
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
        stcoking_date_dtpicker.setValue(LocalDate.parse(dateValue,formatter));
            }
           
       }
       catch(Exception e){
           e.printStackTrace();
       }
           description2_txtf1.setText(selectedItem.getDESCRIPTION());  
           journal_number2_txtf.setText(selectedItem.getJOURNAL_NUMBER());
           String control_account="select CONTROL_ACCOUNT from JOURNAL_CONTROL";
           try{
               pst=conn.prepareStatement(control_account);
               rs=pst.executeQuery();
               while(rs.next()){
                 control_account_txtf.setText(rs.getString("CONTROL_ACCOUNT"));
               }
           }
           catch(Exception e){
               e.printStackTrace();
           }
           
        //  stcoking_date_dtpicker.getEditor().setText(String.valueOf(selectedItem.getTRN_DATE()));
         // valueFactory.setValue("February")
          transaction_quantity_spinner.getEditor().setText(String.valueOf(selectedItem.getCONTROL_QUANTITY()));;
        // sales_price4.getValueFactory()
           journal_control_count_txtf.setText(selectedItem.getCOUNT());
           TextFormatter<Integer> priceFormatter5 = new TextFormatter<Integer>(
        new IntegerStringConverter(),Integer.parseInt(selectedItem.getFISCAL_YEAR()), filter);
           TextFormatter<Integer> priceFormatter6 = new TextFormatter<Integer>(
        new IntegerStringConverter(),Integer.parseInt(selectedItem.getFISCAL_MONTH()), filter);
          fiscal_year_spinner.getEditor().setTextFormatter(priceFormatter5);
          month_spinner.getEditor().setTextFormatter(priceFormatter6);
          item_location_txtf.setText(String.valueOf(selectedItem.getTRN_LOCATION()));
          String ledger_type="select ledger_type from JOURNAL_CONTROL";
          try{
              pst=conn.prepareStatement(ledger_type);
              rs=pst.executeQuery();
              while(rs.next()){
                  ledger_type_lbl.setText(rs.getString("LEDGER_TYPE"));
              }
                      
          }
          catch(Exception e){
              e.printStackTrace();
          }
          
          String trn_type="select journal_type from JOURNAL_CONTROL";
          try{
              pst=conn.prepareStatement(trn_type);
              rs=pst.executeQuery();
              while(rs.next()){
                  trn_type_lbl.setText(rs.getString("JOURNAL_TYPE"));
              }
                      
          }
          catch(Exception e){
              e.printStackTrace();
          }
          data.removeAll(data);
          loadStockAdjustmentDetailstable();
          
          /* Alert alert = new Alert(AlertType.CONFIRMATION);
          alert.setTitle("Confirmation Dialog");
          alert.setHeaderText("Stock Adjustment Journal");
          alert.setContentText("Go to transactions?");
          
          Optional<ButtonType> result = alert.showAndWait();
          if (result.get() == ButtonType.OK){
          // ... user chose OK
          //loadStockDetailTable();
          stock_adjustment_journals_tp.setExpanded(false);
          stock_adjustment_transactions_tp.setExpanded(true);
          loadStockAdjustmentDetailstable();
          //stock_adjustment_tb.getScene().getWindow().hide();
          
          
          
          } else {
          // ... user chose CANCEL or closed the dialog
          }*/
          
          ///taxable.setText(String.valueOf(selectedItem.getTAXABLE()));
         // tax_amount.setText(String.valueOf(selectedItem.getTAX_AMOUNT()));
          //location2.setText(String.valueOf(selectedItem.getITEM_LOCATION()));
      }
                 
                        void loadStockDetailTable(){
                   try {
                       Scene scene3;
                       stage2 = new Stage();
                       //(Stage) location.getScene().getWindow();
                       // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                       // primarystage.setScene(new Scene(mainPane));
                       //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm());
                       //primarystage.show();
                       //    FXMLLoader loader = new FXMLLoader();
                       //   loader.setController(Controller);
                       
                       pos_stock_adjustment_main Controller = new pos_stock_adjustment_main();
                       FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_stock_adjustment_window2.fxml"));
                       loader.<pos_stock_adjustment_main>getController();
                       Controller.setjournal_number(journal_number_txtf.getText());
                       Controller.setitem_location(location_txtf.getText());
                       Controller.setjournal_quantity(control_quantity_spinner.getEditor().getText());
                       Controller.setjournal_control_count(count_spinner.getEditor().getText());
                       // Pos_Controller Controller = loader.getController();
                       loader.setController(Controller);
                       Parent root3 = loader.load();
                       scene3 = new Scene(root3);
                       scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                       stage2.setScene(scene3);
                       stage2.setTitle("MALIPLUS:STOCK ADJUSTMENTS FORM");
                       stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                       stage2.setResizable(true);
                       stage2.setMaximized(true);
                       //stage2.setX(450);
                       // stage2.setY(50);
                       //loader.<pos_locations>getController().setController(this);
                       // stage2.show();
                      
                       stage2.show();
                        
                        //stock_adjustment_tb.getScene().getWindow().hide();
                   } catch (IOException ex) {
                       Logger.getLogger(pos_stock_adjustment_initial.class.getName()).log(Level.SEVERE, null, ex);
                   }
    }
                 @FXML
    void onSelectItem(MouseEvent event) {
         int click = event.getClickCount();
        if(event.getSource()==stock_adjustment_tb){
            loadMaskerPane2();
           
        }
          else
        
        
         if(event.getSource()==stock_adjustment_tbl){
        
      
          loadMaskerPane3();   
        
            
       }
            
    }
    
    void insertintostockAdjustmentInitialTable(){
        Date ref_date = new Date();
        SimpleDateFormat formatter2 = new SimpleDateFormat("MM-dd-yyyy");
          String ref = formatter2.format(ref_date);
     //   System.out.println(String.valueOf(ref));
        
      String dateValue = ""+ref+"";
      
      String getNextJournalnumber="Select journal_no from journal-control";
      try{
          conn=DBConnection.ConnectDB();
          pst=conn.prepareStatement(getNextJournalnumber);
      }
      catch(Exception e){
          e.printStackTrace();
      }
      String sql="Insert into JOURNAL_CONTROL("
     // +"JOURNAL_NUMBER,"        
      +"DESCRIPTION,"
      + "CREATED_BY, "
      + "DATE_CREATED, "
      + "CONTROL_QUANTITY, "
      + "CONTROL_COUNT, "
      + "TRN_LOCATION, "
      + "JOURNAL_DATE,"
      + "FISCAL_YEAR,"
      + "FISCAL_MONTH,"
      + "DATE_MODIFIED,"
      + "MODIFIED_BY,"
      + "JOURNAL_TYPE,"
      + "JOURNAL_STATUS,"
      + "LEDGER_TYPE,"
      + "CONTROL_ACCOUNT,"
      + "JOURNAL_NUMBER)"
      +"values("        
      + "'"+description2_txtf1.getText()+"',"
      + "'SUPER',"
      + "'"+stcoking_date_dtpicker.getEditor().getText()+"',"
      + "'"+transaction_quantity_spinner.getEditor().getText()+"',"
      + "'"+journal_control_count_txtf.getText()+"',"
      + "'"+item_location_txtf.getText()+"',"
      + "'"+stcoking_date_dtpicker.getEditor().getText()+"',"
      + "'"+fiscal_year_spinner.getEditor().getText()+"',"
      + "'"+month_spinner.getEditor().getText()+"',"
      + "'"+dateValue+"',"
      + "'SUPER',"
      + "'ADJ',"
      + "'ACT',"
      + "'STK',"
      + "'ALL',"
      + "'"+journal_number2_txtf.getText()+"')";
        try{
               conn=DBConnection.ConnectDB();
               pst=conn.prepareStatement(sql);
               pst.execute();
               /* rs=pst.getGeneratedKeys();
               while(rs.next()){
               System.out.println("Generated key: " + rs.getInt(1));
               // journal_number_txtf.setText(String.valueOf(rs.getInt(1)));
               
               }*/
             
              data2.removeAll(data2);
              String refresh_journal_table= "SELECT * from JOURNAL_CONTROL WHERE JOURNAL_TYPE='ADJ'";
             loadStockAdjustmentDetailstable(refresh_journal_table);
              /* String sql2="Select * FROM STOCK_TRNS WHERE JOURNAL_TYPE='ADJ' AND ITEM_CODE='"+item_code_txtf.getText()+"'";
              loadStockAdjustmentMAINDetailstable(sql2);*/
               /* String sql2= "SELECT * from STOCK_TRNS WHERE TRN_TYPE='ADJ'";
               loadStockAdjustmentDetailstable(sql2);*/
               //loadStockAdjustmentDetailstable();
               Image img = new Image("/images_/tick3.jpg");
      Notifications JournalrecordCreatedSuccessfully = Notifications.create()
                        .title("Journal Created Successfully!")
                        .text("Journal Created Successfully!!")
                        .graphic(new ImageView(img))
                        .hideAfter(Duration.seconds(5))
                        .position(Pos.CENTER)
                        .onAction((ActionEvent event1) -> {
                        //System.out.println("Clicked on notification!");
            });  
   
           JournalrecordCreatedSuccessfully.show();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    
       void loadStockDetailmainTable()throws IOException {
         Scene scene3; 
               stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_stock_adjustment_main Controller = new pos_stock_adjustment_main();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_stock_adjustment_window2.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 Parent root3 = loader.load();
                 scene3 = new Scene(root3);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("MALIPLUS:STOCK ADJUSTMENTS FORM");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(true);
                 stage2.setMaximized(true);
                 //stage2.setX(450);
                // stage2.setY(50);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();
                 stage2.show();
    }
   String Journal_Number;
    public void setjournal_number(String journal_number) {
        this.Journal_Number= journal_number;
    }
    String Item_Location;
    public void setitem_location(String item_location) {
        this.Item_Location= item_location;
    }
    String Journal_Quantity;
    public void setjournal_quantity(String journal_quantity) {
        this.Journal_Quantity= journal_quantity;
    }
    String Journal_Control_Count;
    public void setjournal_control_count(String journal_control_count) {
        this.Journal_Control_Count= journal_control_count;
    }

    
       protected static final String INITIAL_VALUE = "0";
  
    
    NumberFormat format = NumberFormat.getIntegerInstance();
       UnaryOperator<TextFormatter.Change> filter = c -> {
    if (c.isContentChange()) {
        ParsePosition parsePosition = new ParsePosition(0);
        // NumberFormat evaluates the beginning of the text
        format.parse(c.getControlNewText(), parsePosition);
        if (parsePosition.getIndex() == 0 ||
                parsePosition.getIndex() < c.getControlNewText().length()) {
            // reject parsing the complete text failed
            return null;
        }
    }
    return c;
};
    TextFormatter<Double> priceFormatter = new TextFormatter<Double>(
        new DoubleStringConverter(), 0.00, filter);
    
   void setSpinnerValue(Spinner<Double> spinner,double k){
        TextFormatter<Double> priceFormatter = new TextFormatter<Double>(
        new DoubleStringConverter(), k, filter);
        spinner.setValueFactory(new SpinnerValueFactory.DoubleSpinnerValueFactory(
        0.00, 10000.00, Double.parseDouble(INITIAL_VALUE)));
        spinner.setEditable(true);
        spinner.getEditor().setTextFormatter(priceFormatter); 
    }
   
   void setSpinnerValue2(Spinner<Integer> spinner,int k){
        TextFormatter<Integer> priceFormatter4 = new TextFormatter<Integer>(
        new IntegerStringConverter(), k, filter);
        spinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(
        0, 10000, Integer.parseInt(INITIAL_VALUE)));
        spinner.setEditable(true);
        spinner.getEditor().setTextFormatter(priceFormatter4); 
    }
   
      void showCurrentDateonload(){
        //DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyyy");
        /*TextField date = sale_date.getEditor();
        formatter.format(date);*/
       Date ref_date = new Date();
        SimpleDateFormat formatter2 = new SimpleDateFormat("MM-dd-yyyy");
          String ref = formatter2.format(ref_date);
     //   System.out.println(String.valueOf(ref));
        
      String dateValue = ""+ref+"";
      //  sale_date.setValue(LocalDate.parse(ref,formatter));
       
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
      
          stcoking_date_dtpicker.setValue(LocalDate.parse(dateValue,formatter));
      // SimpleDateFormat format = new SimpleDateFormat("MMM dd, yyyy");
     //  setText(format.format(date));
    
    
      
/* try{
sale_date.getEditor().setText(dateFormat.format(date));
}
catch(Exception e){
e.printStackTrace();
}*/
    }
      
        void StockAdjustmentmainTable_mouse_clicked(){
          
           pos_stock_adjustments_table selectedItem = stock_adjustment_tbl.getSelectionModel().getSelectedItem();
            String sql="select  DATE_CREATED from STOCK_TRNS where ITEM_CODE = '"+String.valueOf(selectedItem.getITEM_CODE())+"'";
       Connection conn = DBConnection.ConnectDB();
           try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
         java.sql.Date check_status6 = rs.getDate("DATE_CREATED");
         //System.out.println(""+check_status6+""); 
         SimpleDateFormat formatter2 = new SimpleDateFormat("MM-dd-yyyy");
        //formatter2.parse(check_status6);
        String ref = formatter2.format(check_status6);
        
        
        
        
      // System.out.println(String.valueOf(ref));
        
         String dateValue = ""+ref+"";
      //  sale_date.setValue(LocalDate.parse(ref,formatter));
       
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
         stcoking_date_dtpicker.setValue(LocalDate.parse(dateValue,formatter));
            }
           
       }
       catch(Exception e){
           e.printStackTrace();
       }
           item_code_txtf.setText(selectedItem.getITEM_CODE());  
          item_name_txtf.setText(selectedItem.getITEM_NAME());
        //  stcoking_date_dtpicker.getEditor().setText(String.valueOf(selectedItem.getTRN_DATE()));
         // valueFactory.setValue("February")
           TextFormatter<Double> priceFormatter5 = new TextFormatter<Double>(
        new DoubleStringConverter(),selectedItem.getQUANTITY(), filter);
           TextFormatter<Double> priceFormatter6 = new TextFormatter<Double>(
        new DoubleStringConverter(),Double.parseDouble(selectedItem.getITEM_PRICE()), filter);
          transaction_quantity_spinner.getEditor().setTextFormatter(priceFormatter5);;
        // sales_price4.getValueFactory()
           buying_price_spinner.getEditor().setTextFormatter(priceFormatter6);
          description2_txtf.setText(String.valueOf(selectedItem.getDESCRIPTION()));
          item_location_txtf.setText(String.valueOf(selectedItem.getITEM_LOCATION()));
          
          ///taxable.setText(String.valueOf(selectedItem.getTAXABLE()));
         // tax_amount.setText(String.valueOf(selectedItem.getTAX_AMOUNT()));
          //location2.setText(String.valueOf(selectedItem.getITEM_LOCATION()));
      }
        
        void loadItemDetails(String result, String result2,String load_item_details){
            // if a result was selected, add it to the list
                  item_code_txtf.setText(result);
                  item_name_txtf.setText(result2);
                 
               conn=DBConnection.ConnectDB();
               try{
                   pst=conn.prepareStatement(load_item_details);
                   rs=pst.executeQuery();
                   while(rs.next()){
                      barcode_txtf.setText(rs.getString("BARCODE"));
                      uom_txtf.setText(rs.getString("IUOM"));
                     //  sales_price4.setText(String.valueOf(rs.getInt("SALE_PRICE")));
                     //  discount_percent.setText("0");
                     //  sale_quantity.setText("1");
                     //  calculateSalesAmount();
                      // sale-quantity.
                       TextFormatter<Double> priceFormatter2 = new TextFormatter<Double>(
        new DoubleStringConverter(), rs.getDouble("BUY_PRICE"), filter);
            //buying_price_spinner.getEditor().setText(String.valueOf(rs.getDouble("BUY_PRICE")));
            //System.out.println(rs.getDouble("BUY_PRICE"));
             buying_price_spinner.getEditor().setTextFormatter(priceFormatter2);
           //  System.out.println(buying_price_spinner.getEditor().getText());
             if(buying_price_spinner.getEditor().getText().equals("0.0")){
                 buying_price_spinner.setStyle("-fx-control-inner-background: yellow;"
                     + "-fx-text-fill: black;");
             }
             else{
                 buying_price_spinner.setStyle("-fx-control-inner-background: green;"
                     + "-fx-text-fill: white;"); 
             }
             
             
       // item_code.setStyle("-fx-text-fill: red;");
                       
                   }
               }
               catch(Exception e){
                 e.printStackTrace();  
               }
        }
            void loadItemDetailsStage() throws IOException{
      
               stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_items Controller = new pos_items();
             // primarystage = (Stage) Controller.getScene().getWindow(); 
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_item_details_panel.fxml"));
              /*  loader.<pos_items>getController();
              Controller.setsearch_item2(item_code_txtf.getText());*/
              
            
              loader.setController(Controller);
               Parent  root4 = loader.load();
                Scene  scene3 = new Scene(root4);
                // scene3.setRoot(root4);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("ITEM DETAILS");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(125);
                 stage2.setY(200);
               // loader.<pos_item_filter>getController().setController(this);
                // stage2.show();
               stage2.showAndWait();
               //find.setText("");
              String result = loader.<pos_items>getController().getResult();
              String result2= loader.<pos_items>getController().getResult2();
              String load_item_details= loader.<pos_items>getController().getResult5();     
                if (result != null) {
                    loadMaskerPanel4(result,result2,load_item_details);
                  }
               
                   
                
    }
              void loadlocationStage() throws IOException {
       
         Scene scene3; 
              Stage stage2 = new Stage();
               //(Stage) location.getScene().getWindow(); 
                // Pane mainPane= (Pane) FXMLLoader.load(getClass().getResource("pos_details_panel.fxml"));
                // primarystage.setScene(new Scene(mainPane));
               //mainPane.getStylesheets().addAll(this.getClass().getResource("pos.css").toExternalForm()); 
                 //primarystage.show();
             //    FXMLLoader loader = new FXMLLoader();
              //   loader.setController(Controller);
              
              pos_locations Controller = new pos_locations();
              FXMLLoader loader = new FXMLLoader(this.getClass().getResource("pos_details_panel.fxml"));
            // Pos_Controller Controller = loader.getController();
              loader.setController(Controller);
                 Parent root3 = loader.load();
                scene3 = new Scene(root3);
                 scene3.getStylesheets().add(getClass().getResource("pos.css").toExternalForm());
                 stage2.setScene(scene3);
                 stage2.setTitle("Locations");
                 stage2.getIcons().add(new Image("/images_/Mali_bg.png"));
                 stage2.setResizable(false);
                 stage2.setX(1000);
                 stage2.setY(100);
                 //loader.<pos_locations>getController().setController(this);
                // stage2.show();
               stage2.showAndWait();

              String result = loader.<pos_locations>getController().getResult();

                if (result != null) {
        // if a result was selected, add it to the list
                 item_location_txtf.setText(result);
         }
                 
               
                 
    }
        
        final KeyCombination keyComb1 = new KeyCodeCombination(KeyCode.F,KeyCombination.CONTROL_ANY);
         KeyCombination keyComb2 = new KeyCodeCombination(KeyCode.E,KeyCombination.CONTROL_ANY);
          @FXML
    void keyReleasedhandle(KeyEvent event) {
       if(event.getSource()==stock_adjustment_Root){
          if (keyComb1.match(event)) {
        try {
        loadItemDetailsStage();
        } catch (IOException ex) {
        Logger.getLogger(pos_stock_adjustment_initial.class.getName()).log(Level.SEVERE, null, ex);
        }
        }  
          /* else
          if (keyComb2.match(event)) {
          stock_adjustment_Root.getScene().getWindow().hide();
          }*/
       }
        
    }

void SwitchRadioButtons(JFXRadioButton button1,JFXRadioButton button2){
    if(button1.isSelected()==true){
        button2.setSelected(false);
    }
    else{
        button2.setSelected(true);
    }
    
        if(button2.isSelected()==true){
            button1.setSelected(false);
        }
        else{
            button1.setSelected(true);
        }
}
void switchBetweenAdjustmentsandStockTakingButtons(JFXRadioButton button1,JFXRadioButton button2,JFXRadioButton button3,JFXRadioButton button4,Text text){
    if(button1.isSelected()==true){
        button2.setSelected(false);
        button3.setSelected(true);
        button4.setSelected(false);
        button3.setDisable(false);
        button4.setDisable(false);
        text.setText("Transaction Quantity");
    }
 else
    {
        button2.setSelected(true);
        button3.setSelected(false);
        button4.setSelected(false);
        button3.setDisable(true);
        button4.setDisable(true);
        text.setText("Stock Taking Quantity");
   
    } 
   
}

void SwitchbetweenStockTakingandAdjustmentsradioButton(JFXRadioButton button1,JFXRadioButton button2,JFXRadioButton button3, JFXRadioButton button4,Text text){
    
    if(button1.isSelected()==true){
        button2.setSelected(false);
        button3.setSelected(false);
        button3.setDisable(true);
        button4.setSelected(false);
        button4.setDisable(true);
        text.setText("Stock Taking Quantity");
        
    }
    else
    {
        button2.setSelected(true);
        button3.setDisable(false);
        button3.setSelected(true);
        button4.setDisable(false);
        button4.setSelected(false);
        text.setText("Transaction Quantity");
    }
    
}

void SearchJournalNumber(){
           FilteredList<pos_stock_adjustments_initial_table> filteredData = new FilteredList<>(data2, p -> true);
            journal_number2_txtf.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(journal -> {
                // If filter text is empty, display all persons.
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }

                // Compare first name and last name of every person with filter text.
                String lowerCaseFilter = newValue.toLowerCase();
                 String upperCaseFilter = newValue.toUpperCase();
                if (journal.getJOURNAL_NUMBER().toUpperCase().contains(upperCaseFilter)) {
                    return true; // Filter matches item_code.
                } /*else
                if (journal.getTRN_LOCATION().toLowerCase().contains(lowerCaseFilter)) {
                return true; // Filter matches item_name.
                }
                else
                if (journal.getDATE_CREATED().toLowerCase().contains(lowerCaseFilter)) {
                return true; // Filter matches item_name.
                }
                else
                if (journal.getDESCRIPTION().toLowerCase().contains(lowerCaseFilter)) {
                return true; // Filter matches item_name.
                }*/
                /*           else
                if (item.getBARCODE().toLowerCase().contains(lowerCaseFilter)) {
                return true; // Filter matches item_name.
                }*/
                return false; // Does not match.
            });
        });
            
             SortedList<pos_stock_adjustments_initial_table> sortedData = new SortedList<>(filteredData);
              sortedData.comparatorProperty().bind(stock_adjustment_tb.comparatorProperty());
              stock_adjustment_tb.setItems(sortedData);
}

    @FXML
    void onkeyTyped(KeyEvent event) {
        if(event.getSource()==journal_number2_txtf){
         SearchJournalNumber();  
        }
    }
   
    void windowOpened(){
         //setSpinnerValue(transaction_quantity_spinner,0.00);
  //setSpinnerValue(buying_price_spinner,0.00);
 // showCurrentDateonload();
  // checkToseeifactiveCustomers_are_selected();
 //   loadStockAdjustmentDetailstable();
 acc.setExpandedPane(stock_adjustment_transactions_tp);
  String sql= "SELECT * from JOURNAL_CONTROL WHERE JOURNAL_TYPE='ADJ'";
    loadStockAdjustmentDetailstable(sql);
    ///showCurrentDateonload();
    setSpinnerValue(transaction_quantity_spinner,0.00);
    setSpinnerValue(buying_price_spinner,0.00);
    Calendar now = Calendar.getInstance();   // Gets the current date and time
    int year = now.get(Calendar.YEAR);       // The current year
    int month = now.get(Calendar.MONTH)+1;
    setSpinnerValue2(fiscal_year_spinner,year);
    setSpinnerValue2(month_spinner,month);
   showCurrentDateonload();
//  journal_number_txtf.setText(this.Journal_Number);
 // item_location_txtf.setText(this.Item_Location);    
//  journal_quantity_txtf.setText(this.Journal_Quantity);  
 // journal_control_count_txtf.setText(this.Journal_Control_Count);
  //loadStockAdjustmentDetailstable();
    }
      
        @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadMaskerPane();
 
    }
    public static JFrame frame;
      public static JFXPanel fxPanel = new JFXPanel();
       public  void initAndShowGUI() {
        // This method is invoked on the EDT thread
       
        try{
          frame = new JFrame("Stock Adjustment/Taking");
        frame.add(fxPanel);
        frame.setSize(2000, 1000);
        
        //frame.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("../images_/mali_bg.png")));
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setResizable(true);
        frame.setLocationRelativeTo(null); 
       
        }
        catch(Exception e){
            e.printStackTrace();
        }
        
        
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                initFX(fxPanel);
               // loadComboBoxes();
            }
       });
    }
       
        private  void initFX(JFXPanel fxPanel) {
        // This method is invoked on the JavaFX thread
      
         //  Scene scene = createScene();
          // fxPanel.setScene(scene);
     try {
        Parent  root5 = FXMLLoader.load(getClass().getResource("pos_stock_adjustment_final.fxml"));
          Scene scene2 = new Scene(root5, 2000, 1000);
                scene2.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
            fxPanel.setScene(scene2);
            
            
           
        } catch (IOException exc) {
            exc.printStackTrace();
            System.exit(1);
        }
        
      
      
    }
    public static void main(String[] args) {
         SwingUtilities.invokeLater(new Runnable() {
             @Override
            public void run() {
              
                pos_stock_adjustment_initial test = new pos_stock_adjustment_initial();
                test.initAndShowGUI();
                
                
                
               
                
            }
        });
        
         
    }

  



 
}
