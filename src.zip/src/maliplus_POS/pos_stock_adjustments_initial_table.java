/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author PSL-STUFF
 */
public class pos_stock_adjustments_initial_table {
private final SimpleStringProperty description2;
private final SimpleStringProperty created_by2;
private final SimpleStringProperty date_created2;
private final SimpleStringProperty journal_number2;
private final SimpleStringProperty control_quantity2;
private final SimpleStringProperty count2;
private final SimpleStringProperty trn_location2;
private final SimpleStringProperty journal_status2;
private final SimpleStringProperty journal_date2;
private final SimpleStringProperty fiscal_year2;
private final SimpleStringProperty fiscal_month2;
private final SimpleStringProperty date_modified2;
private final SimpleStringProperty modified_by2;

public pos_stock_adjustments_initial_table (String DESC,String C_B,String D_C,
        String J_N,String C_Q,String COUNT,String T_L,String J_S,
        String J_D,String F_Y,String F_M,String D_M,String M_B ){
    this.description2 = new SimpleStringProperty(DESC);
     this.created_by2 = new SimpleStringProperty(C_B);
     this.date_created2 = new SimpleStringProperty(D_C);
     this.journal_number2 = new SimpleStringProperty(J_N);
     this.control_quantity2 = new SimpleStringProperty(C_Q);
     this.count2 = new SimpleStringProperty(COUNT);
     this.trn_location2 = new SimpleStringProperty(T_L);
     this.journal_status2 = new SimpleStringProperty(J_S);
     this.journal_date2 = new SimpleStringProperty(J_D);
     this.fiscal_year2 = new SimpleStringProperty(F_Y);
     this.fiscal_month2 = new SimpleStringProperty(F_M); 
     this.date_modified2 = new SimpleStringProperty(D_M);
     this.modified_by2 = new SimpleStringProperty(M_B);
}

    



  public String getDESCRIPTION(){
      return description2.get();
  }
  public String getCREATED_BY(){
      return created_by2.get();
  }
  public String getDATE_CREATED(){
      return date_created2.get();
  }
  public String getJOURNAL_NUMBER(){
      return journal_number2.get();
  }
  public String getCONTROL_QUANTITY(){
      return control_quantity2.get();
  }
  public String getCOUNT(){
      return count2.get();
  }
  public String getTRN_LOCATION(){
      return trn_location2.get();
  }
  public String getJOURNAL_STATUS(){
      return journal_status2.get();
  }
  public String getJOURNAL_DATE(){
      return journal_date2.get();
  }
  public String getFISCAL_YEAR(){
      return fiscal_year2.get();
  }
  public String getFISCAL_MONTH(){
      return fiscal_month2.get();
  }
  public String getDATE_MODIFIED(){
      return date_modified2.get();
  }
  public String getMODIFIED_BY(){
      return modified_by2.get();
  }
  
  public void SetDESCRIPTION(String DESC ){
     description2.set(DESC);
  }
   public void SetCREATED_BY(String C_B){
      created_by2.set(C_B);
  }
   public void SetDATE_CREATED(String D_C ){
      date_created2.set(D_C);
  }
   public void SetJOURNAL_NUMBER(String J_N){
      journal_number2.set(J_N);
  }
   public void SetCONTROL_QUANTITY(String C_Q){
      control_quantity2.set(C_Q);
  }
   public void SetCOUNT(String COUNT ){
      count2.set(COUNT);
  }
   public void SetTRN_LOCATIONS(String T_L ){
      trn_location2.set(T_L);
  }
   public void SetJOURNAL_STATUS(String J_S){
      journal_status2.set(J_S);
  }
   public void SetJOURNAL_DATE(String J_D){
      journal_date2.set(J_D);
  }
   public void SetFISCAL_YEAR(String F_Y){
      fiscal_year2.set(F_Y);
  }
   public void SetFISCAL_MONTH(String F_M){
      fiscal_month2.set(F_M);
  }
   public void SetDATE_MODIFIED(String D_M){
      date_modified2.set(D_M);
  }
   public void SetMODIFIED_BY(String M_B){
      modified_by2.set(M_B);
  }
  
   
     
      public StringProperty descriptionProperty() {
        return description2 ;
    }
       public StringProperty created_byProperty() {
        return created_by2 ;
    }
         public StringProperty date_createdProperty() {
        return date_created2 ;
    }
      public StringProperty journal_numberProperty() {
        return journal_number2 ;
    }
        public StringProperty control_quantityProperty() {
        return control_quantity2 ;
    }
          public StringProperty countProperty() {
        return count2 ;
    }
         public StringProperty trn_locationProperty() {
        return trn_location2 ;
    }
            public StringProperty journal_statusProperty() {
        return journal_status2 ;
    }
                 public StringProperty journal_dateProperty() {
        return journal_date2 ;
    }
                      public StringProperty fiscal_yearProperty() {
        return fiscal_year2 ;
    }
                           public StringProperty fiscal_monthProperty() {
        return fiscal_month2 ;
    }
                                public StringProperty date_modifiedProperty() {
        return date_modified2 ;
    }
                                     public StringProperty modified_byProperty() {
        return modified_by2 ;
    }



}
