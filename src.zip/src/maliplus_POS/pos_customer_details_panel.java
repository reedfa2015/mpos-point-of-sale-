/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maliplus_POS;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author PSL-STUFF
 */
public class pos_customer_details_panel {
private final SimpleStringProperty ledger_number2;
private final SimpleStringProperty ledger_name2;


public pos_customer_details_panel (String L_N,String L_NAME ){
    this.ledger_number2 = new SimpleStringProperty(L_N);
     this.ledger_name2 = new SimpleStringProperty(L_NAME);


         
}

    



  public String getLEDGER_NUMBER(){
      return ledger_number2.get();
  }
  public String getLEDGER_NAME(){
      return ledger_name2.get();
  }


  
  public void SetLEDGER_NUMBER(String L_N ){
      ledger_number2.set(L_N);
  }
   public void SetLEDGER_NAME(String L_NAME){
      ledger_name2.set(L_NAME);
  }
  
   
     
      public StringProperty ledger_numberProperty() {
        return ledger_number2 ;
    }
       public StringProperty ledger_nameProperty() {
        return ledger_name2 ;
    }
    



}
